#!/usr/bin/env python3
"""Filesystem-only, byte-preserving packaging; does not authorize publication.

Run only after task completion and an explicit reviewed selection is ready.
No subprocess, network, Kubernetes, Git, redaction, extraction, or source writes.
"""
from __future__ import annotations

import argparse
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import tarfile
import sys

BASE = Path('/private/tmp/verdify-daytime-consumer-20261018')
MAX_FILE = 32 * 1024 * 1024
MAX_TOTAL = 128 * 1024 * 1024
MAX_EXPANDED = 128 * 1024 * 1024
MAX_MEMBERS = 10000
MAX_DEPTH = 2
EXCLUDED = {
    'initial/nodes.json': 'raw estate node inventory; use derived capacity only',
    'initial/metrics.json': 'raw estate node metrics; use derived capacity only',
    'platform/check-root': 'local source-check fixture tree; not task execution evidence',
    'platform/iris-inventory-check-root': 'local source-check fixture tree; not task execution evidence',
    'control/winter-image-preservation/render-check': 'complete local source-render fixture; owning patch/proof/output renders remain selected',
}
PATTERNS = {
    'private_key': rb'-----BEGIN (?:RSA |OPENSSH |EC |DSA )?PRIVATE KEY-----',
    'github_token': rb'\b(?:gh[pousr]_[A-Za-z0-9_]{30,}|github_pat_[A-Za-z0-9_]{40,})',
    'slack_token': rb'\bxox[baprs]-[A-Za-z0-9-]{20,}',
    'aws_key': rb'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b',
    'dsn_with_password': rb'postgres(?:ql)?://[^\s/\x22\x27:]+:[^\s@\x22\x27]+@',
    'literal_bearer': rb'Bearer [A-Za-z0-9._~+/=-]{24,}',
}
CREDENTIAL_NAME = re.compile(r'TOKEN|PASSWORD|PRIVATE_KEY|CLIENT_SECRET|ACCESS_KEY|AUTHORIZATION', re.I)
HEX64 = re.compile(r'[0-9a-f]{64}')
ARCHIVE_SUFFIXES = ('.tar.gz', '.tgz', '.tar')
# Exact public references from render-before/render.json; these locate credentials or an
# OAuth endpoint and do not contain credential values. No suffix-wide exception.
PUBLIC_REFERENCES = {
    ('HA_TOKEN_FILE', '/mnt/agents/shared/credentials/ha_token.txt'),
    ('VERDIFY_FRIGATE_TOKEN_FILE', '/vfrigate/token'),
    ('GF_AUTH_GENERIC_OAUTH_TOKEN_URL', 'https://auth.vallery.net/application/o/token/'),
}

# Exact nonliteral password expressions from the pinned owning public render.
# This is a complete-match hash allowlist, never a syntax-wide exemption.
DSN_REFERENCE_SOURCE = 'render-before/render.json'
DSN_REFERENCE_SOURCE_SHA256 = '176798de13ac958350a150ba37ead7ae1ffe76055aa3bdd936f3412a06a07a27'
DSN_REFERENCE_REVIEW = Path('/private/tmp/verdify-daytime-consumer-dsn-reference-review-v1.json')
DSN_REFERENCE_REVIEW_SHA256 = 'fec65296bb8737e6f0ffbc82b30e2a93f9dbccb985b9f0839d0745d64a8f00c9'
DSN_REFERENCE_MATCHES = frozenset({
    '4d9aee63cfe506ffe07a63b972c77e107b4d0d2f6f06a9cf538daf4b57e61bc1',
    '64e76a59cd1400c274d3567638c18a90f4f586c6cfd3528acf426e98c59d388f',
    '7a014ab2f94612eb217f3dc033760e4bf237039229ab30104849e85c51f04bbe',
    '978985c77cfbf584b7c49a71c766cf3cafc9dceaa3f1351279c638cd8cf89d1c',
    'dd5537b33462a5071a5bd41f9b8b55745bfc68222cca7ac2721848d48e36e857',
})


# Two additional exact public source expressions, not a syntax exemption.
# These complete source/proof/failure bytes are embedded and rechecked controls.
MCP_DSN_MATCH_SHA256 = '9eeed8f6ed34c8d3c57040a1b52562ececfd1c954f7be8edd272232d4bdc7eda'
API_DSN_MATCH_SHA256 = 'f3b37ee2a7a7738174c0af213c4f4eab4469962c61eb08f6569c28873c0e4d40'
MCP_DSN_CONTROLS = {
    'packaging/api-public-source.py': (
        BASE / 'control/model-profile/complete-v2/draft/api/main.py',
        '02672fe5de90c066078814f7051404442c2a62ca18395794dc3adcb2fffb6fe3'),
    'packaging/api-dsn-public-reference-review.json': (
        BASE / 'api-dsn-public-reference-review.json',
        '4b41580a0dcb97b246df93865cafb3376bbdb2898105a229078029b27debc4d0'),
    'packaging/prior-sealed-complete-selection.json': (
        Path('/private/tmp/verdify-daytime-selection-final-01/selection.json'),
        'bf801529ec0b8d280efe7851575a2687c715d80e35e0f47f8dd9b79e56d7205e'),
    'packaging/prior-sealed-union-index.json': (
        Path('/private/tmp/verdify-daytime-selection-split-01/union-index.json'),
        '60bc59f8d8882a680b9df86107e1fcf443c99c21c9d154572582302217d4c57a'),
    'packaging/mcp-public-source.py': (
        BASE / 'platform/draft/mcp/server.py',
        'd8926ec1bca28c10cd0109b62238b395a3d233158879e51dbb073acdc7372a9f'),
    'packaging/mcp-dsn-public-reference-review.json': (
        BASE / 'mcp-dsn-public-reference-review.json',
        'd16f75b2f820b34ee582d0c7f8f284846a4c833f058b1f98d27c23732d9409f5'),
    'packaging/prior-packet-a-01-attempt-start.json': (
        Path('/private/tmp/verdify-daytime-evidence-packet-a-01/attempt-start.json'),
        '3f388525acf7732f82931a271e92981c5065b8675c27284078bdc3e9099b515c'),
    'packaging/prior-packet-a-01-attempt-result.json': (
        Path('/private/tmp/verdify-daytime-evidence-packet-a-01/attempt-result.json'),
        '0606390e741a5a9cadb5cb9a9d94eb50a1efea2874ec6df4c2e51b0863cd5f20'),
}

def read_mcp_dsn_controls():
    controls = {}
    for name, (path, digest) in MCP_DSN_CONTROLS.items():
        raw = read_regular(path)[0]
        require(sha(raw) == digest, 'mcp_dsn_provenance_changed')
        controls[name] = raw
    return controls


# Exact retained retry-route actor metadata, authorized by ROOT for this task.
# This is one byte-bound List, not a general CI-Pod or ReplicaSet exemption.
RETRY_ACTOR_PATH = 'model-build-recovery-04/server-pods.stdout'
RETRY_ACTOR_SHA256 = 'a778e82b5b27af776cf8cc7406a2fbadc2bae60cb273d444b27fab7f657ac842'
RETRY_ACTOR_NAMESPACE = 'agent-fleet-ci'
RETRY_ACTOR_NAME = 'argo-workflows-server-796667579c-gzvwx'
RETRY_ACTOR_UID = 'c172328d-86e7-4dfa-9aa0-3446979260ca'
RETRY_ACTOR_OWNER = {'apiVersion': 'apps/v1', 'blockOwnerDeletion': True,
    'controller': True, 'kind': 'ReplicaSet',
    'name': 'argo-workflows-server-796667579c',
    'uid': 'abcf5201-9463-44c3-a2ea-fbf20ee7058c'}
RETRY_ACTOR_IMAGE = 'quay.io/argoproj/argocli:v4.0.5'
RETRY_ACTOR_IMAGE_ID = 'quay.io/argoproj/argocli@sha256:8aafa5a274978f062ca6ccbcceb739c1a107743c3b9f05bb926c13c82537f19e'

def retry_actor_object(obj):
    if not isinstance(obj, dict) or obj.get('kind') != 'Pod' or obj.get('apiVersion') != 'v1':
        return False
    meta = obj.get('metadata', {})
    if (meta.get('namespace'), meta.get('name'), meta.get('uid')) != (
            RETRY_ACTOR_NAMESPACE, RETRY_ACTOR_NAME, RETRY_ACTOR_UID):
        return False
    if meta.get('ownerReferences') != [RETRY_ACTOR_OWNER]:
        return False
    containers = obj.get('spec', {}).get('containers', [])
    statuses = obj.get('status', {}).get('containerStatuses', [])
    return (len(containers) == len(statuses) == 1
        and containers[0].get('name') == statuses[0].get('name') == 'argo-server'
        and containers[0].get('image') == RETRY_ACTOR_IMAGE
        and statuses[0].get('imageID') == RETRY_ACTOR_IMAGE_ID)


class Refusal(Exception):
    pass


def require(condition, code):
    if not condition:
        raise Refusal(code)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def file_sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def canonical(obj):
    return (json.dumps(obj, indent=2, sort_keys=True, allow_nan=False) + '\n').encode()


def pairs(items):
    result = {}
    for key, value in items:
        require(key not in result, 'duplicate_json_key')
        result[key] = value
    return result


def decode(raw):
    return json.loads(raw, object_pairs_hook=pairs,
                      parse_constant=lambda _: (_ for _ in ()).throw(Refusal('nonfinite_json')))


def relname(value):
    require(isinstance(value, str) and value != '' and '\\' not in value and '\x00' not in value,
            'invalid_relative_path')
    path = PurePosixPath(value)
    require(not path.is_absolute() and all(p not in ('', '.', '..') for p in value.split('/')),
            'unsafe_relative_path')
    return path.as_posix()


def excluded(path):
    parts = PurePosixPath(path).parts
    if '__pycache__' in parts or path.endswith(('.pyc', '.pyo')):
        return 'Python cache'
    for candidate in (path, *(str(parent) for parent in PurePosixPath(path).parents)):
        if candidate in EXCLUDED:
            return EXCLUDED[candidate]
    return None


def fingerprint(s):
    return (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)


def read_regular(path):
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode), 'not_regular_file')
    require(before.st_size <= MAX_FILE, 'file_size_limit')
    fd = os.open(path, os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0))
    with os.fdopen(fd, 'rb') as stream:
        opened = os.fstat(stream.fileno())
        require(fingerprint(before) == fingerprint(opened), 'file_changed_before_read')
        raw = stream.read(MAX_FILE + 1)
        after = os.fstat(stream.fileno())
    require(len(raw) <= MAX_FILE and fingerprint(opened) == fingerprint(after)
            and fingerprint(after) == fingerprint(path.lstat()), 'file_changed_during_read')
    return raw, fingerprint(after)


def select(base, includes):
    selected, skips = {}, {}
    require(isinstance(includes, list) and includes, 'missing_selection')

    def visit(path, rel):
        reason = excluded(rel)
        if reason:
            skips[rel] = reason
            return
        s = path.lstat()
        require(not stat.S_ISLNK(s.st_mode), 'symlink_in_selection')
        if stat.S_ISDIR(s.st_mode):
            for child in sorted(path.iterdir()):
                visit(child, f'{rel}/{child.name}')
        else:
            require(stat.S_ISREG(s.st_mode), 'special_file_in_selection')
            selected[rel] = path
            require(len(selected) <= MAX_MEMBERS, 'member_count_limit')

    for item in includes:
        rel = relname(item)
        path = base / rel
        # Check all parents too; do not traverse a selected symlink directory.
        current = base
        for part in PurePosixPath(rel).parts:
            current /= part
            require(not current.is_symlink(), 'symlink_in_selection')
        require(path.exists(), 'selected_path_missing')
        visit(path, rel)
    require(selected, 'empty_selection')
    require(sum(p.stat().st_size for p in selected.values()) <= MAX_TOTAL, 'selection_size_limit')
    return dict(sorted(selected.items())), skips


class Scanner:
    def __init__(self, policy):
        self.workflows = {(x['namespace'], x['name']): x['uid'] for x in policy['workflow_identities']}
        require(len(self.workflows) == len(policy['workflow_identities']), 'duplicate_workflow_identity')
        self.exceptions = policy.get('public_metadata_hash_exceptions', [])
        self.used = set()
        self.nested = []
        self.references = set()
        self.dsn_references = set()
        self.retry_actor_documents = set()
        self.expanded = 0
        self.scanned = 0

    def metadata_exception(self, path, digest, name, value):
        require(isinstance(value, str) and HEX64.fullmatch(value) and name.endswith('_SHA256'),
                'literal_credential_env')
        matches = [i for i, item in enumerate(self.exceptions)
                   if item.get('path') == path and item.get('file_sha256') == digest
                   and item.get('env_name') == name and item.get('value_sha256') == sha(value.encode())
                   and item.get('classification') == 'public_metadata_hash']
        require(len(matches) == 1, 'unreviewed_metadata_hash_env')
        self.used.add(matches[0])

    def structured(self, obj, path, digest):
        if isinstance(obj, dict):
            require(obj.get('kind') != 'Secret', 'Kubernetes_Secret_object')
            # Raw Node/metrics inventories are not the permitted derived capacity report.
            require(obj.get('kind') not in ('Node', 'NodeList', 'NodeMetrics', 'NodeMetricsList'),
                    'raw_estate_node_inventory')
            kind, meta = obj.get('kind'), obj.get('metadata', {})
            if kind == 'Workflow':
                if 'metadata' not in obj:
                    # Exact native ownerReference, not a full Workflow object.
                    # The containing CI Pod independently binds namespace + owner.
                    reference_fields = {'apiVersion', 'kind', 'name', 'uid',
                                        'controller', 'blockOwnerDeletion'}
                    require(set(obj) == reference_fields
                            and obj.get('apiVersion') == 'argoproj.io/v1alpha1'
                            and obj.get('controller') is True
                            and obj.get('blockOwnerDeletion') is True
                            and any(name == obj.get('name') and uid == obj.get('uid')
                                    for (_, name), uid in self.workflows.items())
                            and obj.get('uid'), 'unrelated_or_malformed_workflow_owner_reference')
                else:
                    require(isinstance(meta, dict), 'workflow_metadata_missing')
                    require(self.workflows.get((meta.get('namespace'), meta.get('name'))) == meta.get('uid')
                            and meta.get('uid'), 'unrelated_or_unbound_workflow')
            if kind == 'Pod' and meta.get('namespace') == 'agent-fleet-ci':
                owners = [x for x in meta.get('ownerReferences', []) if x.get('kind') == 'Workflow']
                exact_retry_actor = ((path, digest) in self.retry_actor_documents
                                     and retry_actor_object(obj))
                require(exact_retry_actor or (len(owners) == 1 and
                        self.workflows.get(('agent-fleet-ci', owners[0].get('name'))) == owners[0].get('uid')
                        and owners[0].get('uid')), 'unrelated_or_unbound_ci_pod')
            # Recognize env entries anywhere, including nested templates and patches.
            if isinstance(obj.get('name'), str) and 'value' in obj and CREDENTIAL_NAME.search(obj['name']):
                value = obj['value']
                if value not in ('', None):
                    if isinstance(value, str) and (obj['name'], value) in PUBLIC_REFERENCES:
                        self.references.add((path, obj['name'], sha(value.encode())))
                    else:
                        self.metadata_exception(path, digest, obj['name'], value)
            for value in obj.values():
                self.structured(value, path, digest)
        elif isinstance(obj, list):
            for value in obj:
                self.structured(value, path, digest)
        elif isinstance(obj, str):
            # Kubernetes last-applied annotations and embedded native manifest strings.
            stripped = obj.lstrip()
            if stripped.startswith(('{', '[')):
                try:
                    inner = decode(obj)
                except (ValueError, UnicodeError):
                    return
                self.structured(inner, path, digest)

    def scan(self, raw, path, depth=0):
        self.scanned += 1
        require(self.scanned <= MAX_MEMBERS, 'expanded_member_count_limit')
        digest = sha(raw)
        if path.endswith(ARCHIVE_SUFFIXES):
            require(depth < MAX_DEPTH, 'archive_depth_limit')
            with tarfile.open(fileobj=io.BytesIO(raw), mode='r:*') as archive:
                seen = set()
                for member in archive:
                    # Preserve inner bytes; never extract or repair unsafe archives.
                    name = member.name.rstrip('/') if member.isdir() else member.name
                    if name == '.' and member.isdir():
                        continue
                    if name.startswith('./'):
                        name = name[2:]
                    name = relname(name)
                    require(name not in seen, 'duplicate_archive_member')
                    seen.add(name)
                    require(member.isfile() or member.isdir(), 'archive_nonregular_member')
                    if member.isdir():
                        continue
                    require(member.size <= MAX_FILE, 'archive_member_size_limit')
                    self.expanded += member.size
                    require(self.expanded <= MAX_EXPANDED, 'archive_expansion_limit')
                    child = archive.extractfile(member).read(MAX_FILE + 1)
                    require(len(child) == member.size, 'archive_member_size_mismatch')
                    logical = f'{path}!/{name}'
                    self.nested.append({'path': logical, 'bytes': len(child), 'sha256': sha(child)})
                    self.scan(child, logical, depth + 1)
            return
        require(b'\x00' not in raw, 'unsupported_binary_input')
        for kind, pattern in PATTERNS.items():
            for match in re.finditer(pattern, raw):
                match_hash = sha(match.group())
                if kind == 'dsn_with_password' and (match_hash in DSN_REFERENCE_MATCHES
                        or match_hash in (MCP_DSN_MATCH_SHA256, API_DSN_MATCH_SHA256)):
                    self.dsn_references.add((path, digest, match_hash))
                else:
                    raise Refusal(kind)
        if path == RETRY_ACTOR_PATH or digest == RETRY_ACTOR_SHA256:
            require(path == RETRY_ACTOR_PATH and digest == RETRY_ACTOR_SHA256,
                    'retry_actor_exact_file_binding')
            actor_document = decode(raw)
            require(isinstance(actor_document, dict)
                    and actor_document.get('apiVersion') == 'v1'
                    and actor_document.get('kind') == 'List'
                    and isinstance(actor_document.get('items'), list)
                    and len(actor_document['items']) == 1
                    and retry_actor_object(actor_document['items'][0]),
                    'retry_actor_exact_list_inventory')
            self.retry_actor_documents.add((path, digest))
        if path.endswith('.json') and raw.strip():
            self.structured(decode(raw), path, digest)
        elif path.endswith('.jsonl'):
            for line in raw.splitlines():
                if line.strip():
                    self.structured(decode(line), path, digest)
        elif path.endswith(('.yaml', '.yml')):
            import yaml
            # SafeLoader constructs data only; duplicates cannot hide a Secret kind.
            class UniqueLoader(yaml.SafeLoader):
                pass

            def unique_mapping(loader, node, deep=False):
                loader.flatten_mapping(node)
                return pairs((loader.construct_object(key, deep=deep),
                              loader.construct_object(value, deep=deep))
                             for key, value in node.value)

            UniqueLoader.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, unique_mapping)
            for obj in yaml.load_all(raw, Loader=UniqueLoader):
                self.structured(obj, path, digest)
        else:
            # kubectl stdout can be one pretty-printed JSON document. Apply the
            # same structured guards before falling back to mixed JSON log lines.
            try:
                document = decode(raw)
            except (ValueError, UnicodeError):
                document = None
            if document is not None:
                self.structured(document, path, digest)
            else:
                for line in raw.splitlines():
                    if line.lstrip().startswith((b'{', b'[')):
                        try:
                            obj = decode(line)
                        except (ValueError, UnicodeError):
                            continue
                        self.structured(obj, path, digest)
        if re.search(rb'(?m)^\s*(?:kind\s*:\s*["\x27]?Secret\b|["\x27]kind["\x27]\s*:\s*["\x27]Secret["\x27])', raw):
            raise Refusal('Secret_object_in_text')


def validate_policy(policy, base):
    require(policy.get('schema') == 'verdify-daytime-consumer-evidence-selection-v1', 'policy_schema')
    require(policy.get('status') == 'ready_for_packaging', 'policy_not_ready')
    require(policy.get('taskbase') == str(base), 'policy_taskbase')
    require(isinstance(policy.get('workflow_identities'), list), 'workflow_identities_missing')
    require(isinstance(policy.get('required_files'), list) and policy['required_files'], 'required_files_missing')
    exceptions = policy.get('public_metadata_hash_exceptions', [])
    require(isinstance(exceptions, list), 'exception_list_type')
    for entry in exceptions:
        require(set(entry) == {'path', 'file_sha256', 'env_name', 'value_sha256', 'classification'},
                'exception_shape')
        require(HEX64.fullmatch(entry['file_sha256']) and HEX64.fullmatch(entry['value_sha256'])
                and entry['classification'] == 'public_metadata_hash', 'exception_binding')
    review = None
    if exceptions:
        ref = policy.get('metadata_exception_review', {})
        raw, _ = read_regular(Path(ref['path']))
        require(sha(raw) == ref.get('sha256'), 'exception_review_hash')
        review = decode(raw)
        require(review.get('schema') == 'verdify-public-metadata-hash-review-v1'
                and review.get('exceptions') == exceptions
                and review.get('credential_values_authorized') is False
                and review.get('reviewer'), 'exception_review_scope')
        return raw
    require(not policy.get('metadata_exception_review'), 'unused_exception_review')
    return None


def write_new(path, raw):
    with path.open('xb') as stream:
        os.chmod(path, 0o600)
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())


def package(args):
    base = Path(args.taskbase).resolve(strict=True)
    require(base == BASE.resolve(strict=True), 'wrong_taskbase')
    output = Path(args.outputdir).absolute()
    require(not output.exists() and not output.is_symlink(), 'output_exists')
    require(not output.resolve().is_relative_to(base), 'output_inside_taskbase')
    policy_raw, _ = read_regular(Path(args.selection))
    require(sha(policy_raw) == args.selection_sha256, 'selection_hash')
    policy = decode(policy_raw)
    review_raw = validate_policy(policy, base)
    files, skips = select(base, policy['include'])
    require(DSN_REFERENCE_SOURCE in files, 'dsn_source_provenance_not_selected')
    require(sha(read_regular(files[DSN_REFERENCE_SOURCE])[0]) == DSN_REFERENCE_SOURCE_SHA256,
            'dsn_source_provenance_changed')
    dsn_review_raw = read_regular(DSN_REFERENCE_REVIEW)[0]
    require(sha(dsn_review_raw) == DSN_REFERENCE_REVIEW_SHA256, 'dsn_reference_review_changed')
    mcp_dsn_controls = read_mcp_dsn_controls()
    for name in policy['required_files']:
        require(relname(name) in files, 'required_file_not_selected')
    output.mkdir(mode=0o700, parents=False, exist_ok=False)
    start = {'schema': 'verdify-daytime-consumer-packaging-attempt-v1', 'status': 'started',
             'taskbase': str(base), 'selection_sha256': sha(policy_raw),
             'helper_sha256': sha(Path(__file__).read_bytes()), 'publication_authorized_by_this_helper': False}
    write_new(output / 'attempt-start.json', canonical(start))
    try:
        scanner = Scanner(policy)
        members, source_stats = [], {}
        for name, path in files.items():
            raw, fp = read_regular(path)
            scanner.scan(raw, name)
            source_stats[name] = fp
            members.append({'name': f'task/{name}', 'bytes': len(raw), 'sha256': sha(raw)})
        require(scanner.used == set(range(len(scanner.exceptions))), 'unused_metadata_exception')
        controls = {'packaging/helper.py': Path(__file__).read_bytes(),
                    'packaging/selection.json': policy_raw,
                    'packaging/dsn-reference-review.json': dsn_review_raw,
                    'packaging/exclusions.json': canonical(skips),
                    **mcp_dsn_controls}
        if review_raw is not None:
            controls['packaging/metadata-exception-review.json'] = review_raw
        # Control files contain no privileged data and are scanned too.
        for name, raw in controls.items():
            scanner.scan(raw, name)
            members.append({'name': name, 'bytes': len(raw), 'sha256': sha(raw)})
        members.sort(key=lambda x: x['name'])
        manifest = {**start, 'schema': 'verdify-daytime-consumer-evidence-manifest-v1',
                    'status': 'selected_and_scanned', 'members': members,
                    'nested_original_archive_members': scanner.nested,
                    'selected_task_files': len(files), 'selected_task_bytes': sum(p.stat().st_size for p in files.values()),
                    'exclusions': skips, 'metadata_hash_exceptions_used': sorted(scanner.used),
                    'exact_source_dsn_expression_references': [
                        dict(zip(('path', 'file_sha256', 'match_sha256'), item))
                        for item in sorted(scanner.dsn_references)],
                    'dsn_reference_source_sha256': DSN_REFERENCE_SOURCE_SHA256,
                    'dsn_reference_review_sha256': DSN_REFERENCE_REVIEW_SHA256,
                    'additional_public_source_dsn_control_sha256': {
                        name: digest for name, (_, digest) in MCP_DSN_CONTROLS.items()},
                    'additional_exact_public_dsn_match_sha256': [MCP_DSN_MATCH_SHA256, API_DSN_MATCH_SHA256],
                    'exact_public_reference_envs': [dict(zip(('path', 'env_name', 'value_sha256'), x))
                                                  for x in sorted(scanner.references)],
                    'exact_task_retry_actor_evidence': [
                        {'path': path, 'file_sha256': digest, 'namespace': RETRY_ACTOR_NAMESPACE,
                         'pod_name': RETRY_ACTOR_NAME, 'pod_uid': RETRY_ACTOR_UID,
                         'controlling_replicaset_uid': RETRY_ACTOR_OWNER['uid'],
                         'image': RETRY_ACTOR_IMAGE, 'observed_image_id': RETRY_ACTOR_IMAGE_ID}
                        for path, digest in sorted(scanner.retry_actor_documents)],
                    'scan_scope': 'structured Secret/env and known token patterns; independent broader scan still required',
                    'final_ci_acceptance_asserted_by_packager': False,
                    'selected_input_bytes_rewritten': False}
        archive_path = output / 'evidence.tar.gz'
        with archive_path.open('xb') as stream:
            os.chmod(archive_path, 0o600)
            with gzip.GzipFile(filename='', mode='wb', fileobj=stream, mtime=0) as gz:
                with tarfile.open(fileobj=gz, mode='w|', format=tarfile.PAX_FORMAT) as archive:
                    for member in members:
                        name = member['name']
                        raw = controls[name] if name in controls else read_regular(files[name[5:]])[0]
                        require(sha(raw) == member['sha256'] and len(raw) == member['bytes'], 'source_changed_after_scan')
                        info = tarfile.TarInfo(name)
                        info.size, info.mode, info.mtime = len(raw), 0o600, 0
                        info.uid = info.gid = 0
                        info.uname = info.gname = ''
                        archive.addfile(info, io.BytesIO(raw))
            stream.flush()
            os.fsync(stream.fileno())
        observed = []
        with tarfile.open(archive_path, 'r:gz') as archive:
            for member in archive:
                require(member.isfile(), 'readback_nonregular')
                raw = archive.extractfile(member).read(MAX_FILE + 1)
                observed.append({'name': member.name, 'bytes': len(raw), 'sha256': sha(raw)})
        require(observed == members, 'archive_readback_mismatch')
        final_files, final_skips = select(base, policy['include'])
        require(list(final_files) == list(files) and final_skips == skips, 'selection_changed_during_packaging')
        require(all(fingerprint(files[name].lstat()) == fp for name, fp in source_stats.items()),
                'source_changed_before_final_readback')
        require(sha(read_regular(Path(__file__))[0]) == start['helper_sha256'], 'helper_changed')
        require(read_regular(Path(args.selection))[0] == policy_raw, 'selection_policy_changed')
        require(read_regular(DSN_REFERENCE_REVIEW)[0] == dsn_review_raw, 'dsn_reference_review_changed')
        require(read_mcp_dsn_controls() == mcp_dsn_controls, 'mcp_dsn_controls_changed')
        if review_raw is not None:
            require(read_regular(Path(policy['metadata_exception_review']['path']))[0] == review_raw,
                    'metadata_review_changed')
        manifest.update(status='byte_preserved_archive_verified', archive_sha256=file_sha(archive_path),
                        archive_bytes=archive_path.stat().st_size, archive_readback_exact=True)
        write_new(output / 'manifest.json', canonical(manifest))
        write_new(output / 'attempt-result.json', canonical({'status': 'PACKAGED_NOT_PUBLISHED',
            'manifest_sha256': sha((output / 'manifest.json').read_bytes()),
            'archive_sha256': manifest['archive_sha256'], 'publication_authorized_by_this_helper': False}))
        return {'status': 'PACKAGED_NOT_PUBLISHED', 'outputdir': str(output), 'files': len(files)}
    except Exception as exc:
        # Never include raw exception text or offending credential values.
        code = str(exc) if isinstance(exc, Refusal) else type(exc).__name__
        write_new(output / 'attempt-result.json', canonical({'status': 'FAILED_NOT_PUBLISHED', 'code': code,
                                                            'raw_exception_text_retained': False}))
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--taskbase', required=True)
    parser.add_argument('--outputdir', required=True)
    parser.add_argument('--selection', required=True)
    parser.add_argument('--selection-sha256', required=True)
    args = parser.parse_args()
    try:
        print(json.dumps(package(args), sort_keys=True))
        return 0
    except Exception as exc:
        print(json.dumps({'status': 'REFUSED_OR_FAILED', 'code': str(exc) if isinstance(exc, Refusal)
                          else type(exc).__name__, 'raw_values_printed': False}), file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
