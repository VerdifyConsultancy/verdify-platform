from pathlib import Path
import hashlib,json,yaml
B=Path('/private/tmp/verdify-daytime-consumer-20261018')
D=B/'report-draft'
S=Path('/private/tmp/verdify-daytime-consumer-source-20261018')
source='b814f35e228fcb35c11593c47ea1e021e5fd73de'
backlog=yaml.safe_load((S/'planning/backlog.yaml').read_text())
rows={str(i['issue_number']):i for i in backlog['issues'] if i['issue_number'] in (410,775)}
review='planning/reviews/2026-10-18-daytime-consumer/README.md'
prior='planning/reviews/2026-10-18-getter-timeout-fix/README.md'
pending={
 'SOURCE_CI_RECEIPT':'Full native gate and selected-image publication for b814f35e / verdify-platform-ci-bgf2f are running; no terminal success is asserted.',
 'MCP_RELEASE_AND_RUNTIME':'Selected MCP digest, accepted promotion/source and exact live HTTP/runtime readback remain pending. No migration change or migrate promotion is required by the additive scorecard source.',
 'IRIS_INVENTORY_REFRESH':'SOUL plus generated inventory and revision 5733c1c6b35d are prepared; integration, delivery, actual fresh Hermes identity and initial tool registration remain pending.',
 'IRIS_HTTP_READS':'Actual Iris-authenticated opt-in scorecard calls and unchanged authorization/inventory readback remain pending.',
 'BOUNDED_MODEL_CONSUMPTION':'A separate no-action model interpretation of the actual authorized response remains pending. It cannot prove a natural operating cycle or a full Hermes gateway run.',
 'FINAL_GRAPH':'Final publication-bound native graph verification remains pending; the retained before snapshot is MATCH.'
}
prior410=(
 'The installed migration 277 and ordinary-role getter proof remain accepted at their existing boundary; see '+prior+'. The original October 16 window returned zero rows/pending in 11.816649 seconds. October 4 custom/generic calls returned the same four 46-column rows in 11.269874/4.966761 seconds: two complete/ineffective and two incomplete/insufficient-evidence, none effective. These are installed-production timings within the unchanged 15-second fence; the 3.174204-second clone result is not a production timing. Original failures, twenty native full-row parity fixtures, 2,673 genuine clone readback relations, installed ledger/seal/receipt and prior runtime evidence remain unchanged.'
)
daylight=(
 'A new single bounded read-only assessment of the complete selected stored input found incomplete recorded solar-day coverage on both dates. October 16 has 644 of 669 valid recorded minutes, 25 missing clock buckets, zero known held-admission minutes and 12 ordinary dehumidification minutes. October 17 has 643 of 666, 23 missing clock buckets, zero known held-admission minutes and 2 ordinary dehumidification minutes. The 48 missing clock buckets are not interpolated or counted twice across climate/action records. Complete-recorded-daytime measured-zero remains NULL on both dates; no historical row was changed and continuous physical absence is not proved.'
)
consumer=(
 'Source b814f35e adds an optional include_realized_dryout=false flag to the existing Iris-authorized scorecard. An explicit selected solar-night start date requests one existing getter read; default calls retain their previous cost. All 46 fields, real NULLs, dispositions and confounds are preserved, with a 500-episode/64-KiB limit and explicit unavailable rather than truncation or invented zero. outcome_kpi stays admin-only, the Iris inventory stays at 23 tools, and no credential, audience, DB schema or ACL changes are introduced. The prepared SOUL/inventory revision 5733c1c6b35d instructs ordinary SUNRISE/SUNSET use of a prior completed night and supplies the existing source-owned Hermes refresh mechanism. Source and focused checks are complete; actual delivery and consumption are not yet asserted.'
)
next410=(
 'Finish the pending qualified MCP delivery, source-owned Iris inventory refresh, actual Iris-authenticated single-night scorecard reads and separately bounded no-action model interpretation, retaining real negative/incomplete/empty outcomes. Then advance an explicit observation/freshness contract and a prospectively collected complete recorded daytime window, and observe intended ordinary planner use in a natural operating cycle. Do not repeat the installed getter repair or relabel missing historical buckets; physical efficacy and crop-sensing requirements remain separate.'
)
next775=(
 'Finish the bounded ordinary-consumer delivery/readback packet without converting it into whole-issue or natural-cycle acceptance. Then pull the prospective complete-recorded-daytime observation/freshness packet, natural ordinary-consumer observation and authentic scientific/physical inputs as they become concrete. Reuse accepted getter/S3B receipts, preserve negative and incomplete results, the 40-hour budget and original 22–34h estimates; do not infer remaining hours.'
)
updates={
 '410':{
  'baseline':prior410+'\n\n'+daylight+'\n\n'+consumer+'\n\nPending actual receipts: [[PENDING_SOURCE_CI_RECEIPT]] [[PENDING_MCP_RELEASE_AND_RUNTIME]] [[PENDING_IRIS_INVENTORY_REFRESH]] [[PENDING_IRIS_HTTP_READS]] [[PENDING_BOUNDED_MODEL_CONSUMPTION]].\n\nCurrent execution allocation: S3B follow-up. Next action: '+next410+'\n\nEvidence: '+review+'. All three acceptance clauses, open state, parentage, completion edges and effort estimates remain unchanged. A bounded ordinary read and separate model interpretation, if verified, do not establish a natural planner cycle, complete historical daytime coverage or physical efficacy.',
  'how':[
   'Reuse installed migration 277 and its native parity, ledger/seal/receipt and ordinary-role evidence. Preserve original failures, all 46 values, NULL/tie behavior, helper cardinality and solar/response semantics; do not repeat the completed repair to claim broader acceptance.',
   'Use the existing Iris-authorized scorecard opt-in with one explicit prior completed solar-night start date. Preserve the default false cost boundary, 500-episode/64-KiB refusal bounds, current timeout and explicit unavailable/pending states. Keep outcome_kpi admin-only and all existing audiences and identities unchanged; an unavailable admin identity is not a prerequisite for this ordinary-reader route.',
   'Retain the complete bounded daytime assessment as incomplete: zero known held admission among observed records does not fill the 48 missing clock buckets. Define the observation/freshness contract for a prospectively collected complete recorded window; preserve ordinary daytime dehumidification and all solar, heat2, wind/dwell and temperature safeguards.',
   'Verify actual Iris HTTP dispatch, the source-owned Hermes inventory refresh and separately bounded no-action model interpretation at their stated boundaries. Observe natural ordinary-planner consumption separately. Do not turn safety status, a dry render or a bounded model read into a universal VPD, crop-safety, physical-efficacy or tuning claim.'
  ],
  'decision':'Use the existing ordinary Iris scorecard audience for realized-outcome consumption; no new credential or admin audience is needed. Preserve incomplete historical daytime evidence and all physical/control boundaries. Bounded authorized reads and source delivery do not need a new blanket approval gate. Full #410 acceptance remains open, including complete recorded daytime evidence and the limits of bounded versus natural consumer use.',
  'next_action':next410
 },
 '775':{
  'baseline':'The installed getter 277 repair and its qualified ordinary-role/ledger/runtime evidence remain accepted at their stated scope; '+prior+' retains original failures and exact installed timings. The selected October 4 outcomes remain two ineffective and two insufficient-evidence; October 16 remains empty/pending. No positive physical efficacy is inferred.\n\n'+daylight+'\n\nThe next source packet b814f35e adds a bounded optional realized-outcome read to the existing Iris scorecard and preserves the 23-tool inventory and admin denial. The separate SOUL/generated-inventory refresh draft is revision 5733c1c6b35d. The full native gate and selected builds, live MCP delivery, actual Iris HTTP read, fresh Hermes registration and separately bounded model interpretation are pending: [[PENDING_SOURCE_CI_RECEIPT]] [[PENDING_MCP_RELEASE_AND_RUNTIME]] [[PENDING_IRIS_INVENTORY_REFRESH]] [[PENDING_IRIS_HTTP_READS]] [[PENDING_BOUNDED_MODEL_CONSUMPTION]]. None is being substituted for a natural operating cycle.\n\nCurrent execution allocation: ROLLUP. Next action: '+next775+'\n\nThe 19:47:49 UTC source-bound native graph at b814f35e matched 47 open issues, 93 canonical records, 143 open acceptance clauses, 26 local plus HA #878 → #981 active edges (27 total) and 24 closed predecessor records, with matching parent/open-subissue links and no captured cycle. Final publication-bound graph: [[PENDING_FINAL_GRAPH]].\n\nEvidence: '+review+'. Preserve all acceptance clauses, issue states, dependencies and original estimates; source/CI, bounded read proof and a natural operating cycle remain distinct.',
  'how':[
   rows['775']['how'][0],rows['775']['how'][1],
   'Reuse completed P1 native/P2 admission/P4 custody, accepted MCP release and installed getter 277. Finish the existing-audience ordinary scorecard consumer packet at its bounded scope, then advance a prospective complete recorded daytime window, natural planner observation and authentic physical/input gaps. Retain ineffective, incomplete and empty results; do not repeat accepted delivery or make unavailable admin credentials a prerequisite.'
  ],
  'decision':'No old credential or two-message approval is pending, and the ordinary consumer route uses the existing Iris identity and audience. Future physical window, exact design/launch and measurement-scope decisions should be raised only with concrete ready packets, not as a blanket planning gate. Bounded source, read and model proofs leave natural-cycle, historical coverage and whole-issue acceptance explicit.',
  'next_action':next775
 }
}
(D/'proposed-updates.json').write_text(json.dumps(updates,indent=2,ensure_ascii=False)+'\n')
readme='''# Daytime coverage and ordinary realized-outcome consumption — 2026-10-18

This checkpoint preserves an incomplete daytime result and prepares a bounded ordinary Iris reader. Both #410 and #775 remain open. The source changes and focused checks are complete; the CI, delivery, HTTP, schema refresh and model steps listed below are **pending**, not accepted runtime evidence.

## Actual recorded daytime result

ROOT executed one bounded read-only assessment, independently checked against the installed migration 277 clock/classifier and the complete selected stored input. It changed no historical data.

| Solar day | Expected minute buckets | Valid recorded minutes | Missing clock buckets | Known held admission | Ordinary dehumidification | Complete-recorded-daytime zero |
|---|---:|---:|---:|---:|---:|---|
| 2026-10-16 | 669 | 644 (96.263079%) | 25 | 0 | 12 | NULL — incomplete |
| 2026-10-17 | 666 | 643 (96.546547%) | 23 | 0 | 2 | NULL — incomplete |

There are **48 distinct missing clock buckets**, not 96: climate and action coverage share those gaps. Among observed minutes there were no unknown held classifications or missing explicit hold markers. The longest consecutive gaps were three and one buckets respectively. These facts do not measure continuous controller outage duration or prove the unrecorded physical state. The ingestor stores 60-second plus selected state-change snapshots, defaults absent relay equipment to false, and has no per-relay freshness record. Complete typed rows do not prove every controller tick.

No interpolation, synthetic backfill, resampling, zero substitution or historical alteration was performed. #410's complete daytime absence criterion remains unaccepted. A future qualifying result needs an explicit observation/freshness contract and a prospectively collected complete recorded window.

## Accepted getter evidence reused

[The installed getter repair](../2026-10-18-getter-timeout-fix/README.md) remains accepted at its original scope. Actual ordinary-role calls returned October 16 with zero rows/pending in 11.816649 seconds, and October 4 with four equal 46-column rows in 11.269874 seconds (custom plan) and 4.966761 seconds (generic plan). Two rows are complete/ineffective and two incomplete/insufficient-evidence; none is effective. The unchanged product fence is 15 seconds. The earlier 3.174204-second clone candidate is not an installed-production timing.

The twenty native full-row synthetic parity cases, 2,673 genuine clone readback relations, installed ledger/seal/receipt, prior runtime receipts and original failures are retained. This follow-up does not rerun or relabel that repair.

## Ordinary reader source

Source `b814f35e228fcb35c11593c47ea1e021e5fd73de` adds `scorecard(target_date, include_realized_dryout=False)`. Existing calls remain unchanged in cost. An explicit opt-in requests exactly one selected solar night using the same explicit date as the night start; this is distinct from the scorecard's calendar-day metrics. The requested night crosses midnight.

The existing getter read is READ ONLY, uses at most the current configured 15-second budget and returns all 46 original columns. A 501-row sentinel rejects more than 500 episodes; a 64-KiB nested-evidence cap rejects oversized responses. Neither refusal truncates data or converts it to a positive result. Legitimate NULLs, episode dispositions, confounds and incomplete evidence are retained. Empty rows and all-null daytime counts remain unknown, rather than invented zero. The shared summary preserves `fail` dominance, requires every explicit `pass` for safety pass, and otherwise retains incomplete or empty/pending status. Safety status is not effectiveness or crop safety.

The optional field uses the existing Iris-authorized scorecard. The inventory remains 23 tools; `outcome_kpi` remains admin-only. Available identities are Iris and observer; no positive admin dispatch is claimed or required for this ordinary route. There is no DB schema, getter, ACL, audience or credential change. Only MCP needs promotion for this source change; selecting five build profiles does not authorize five promotions or a migrate hook change.

Focused source checks passed: 37 shared/new projection cases, 32 existing scorecard/response cases (one live case intentionally excluded), Ruff/format and shell syntax. Science independently checked field/NULL/disposition and refusal semantics. Native full-gate status is still pending below.

## Intended consumer and schema refresh

Source inspection of the captured installed Hermes client found that the periodic `list_tools` keepalive discards its response, reconnect alone does not re-register existing tool schemas, and ordinary rediscovery skips registered servers. A separate discovery process would not prove the existing gateway has the new field.

The prepared SOUL instruction asks ordinary non-experiment SUNRISE/SUNSET work to opt in once for a prior completed solar night and reuse the response. It preserves negative/incomplete/unavailable outcomes and forbids treating empty evidence as zero or making unsupported crop claims. The owning generator produces inventory revision `5733c1c6b35d`; the source draft changes only SOUL, its generated inventory payload and the existing revision annotation. Its four focused inventory tests passed. Integration and the source-owned fresh Hermes registration remain pending.

The captured gateway API always creates agents from configured full toolsets and does not enforce a per-request tool allowlist. Therefore a prompt alone is insufficient to make a full gateway run action-free. The planned qualification is one actual Iris-authenticated scorecard read followed by separately bounded, tool-disabled model interpretation. Even a successful result proves this bounded route, not a natural operating cycle, a full gateway run, controller action or physical benefit.

## Pending actual delivery receipts

- [[PENDING_SOURCE_CI_RECEIPT]] — `verdify-platform-ci-bgf2f`, UID `f2083616-e793-4994-bd3b-9a48b1fbb376`, source `b814f35e`. Selected profiles: api, mcp, ingestor, setpoint-server and lab-publisher. Last reported running.
- [[PENDING_MCP_RELEASE_AND_RUNTIME]] — exact selected MCP image/pin, intended accepted source and actual runtime readback; no inferred deployment from the merge or build.
- [[PENDING_IRIS_INVENTORY_REFRESH]] — accepted SOUL/inventory source, fresh Hermes identity and initial registration; revision draft `5733c1c6b35d` is not live proof.
- [[PENDING_IRIS_HTTP_READS]] — actual existing-Iris opt-in reads, all fields/dispositions/NULLs and unchanged authorization/inventory.
- [[PENDING_BOUNDED_MODEL_CONSUMPTION]] — separate restricted model interpretation matched to actual responses, with its limits and failures retained.
- [[PENDING_FINAL_GRAPH]] — final source/publication-bound native conformance.

Replace each token only with its actual scoped receipt and outcome. A refusal, timeout or incomplete result must remain visible; no pending item implies success.

## Planning and remaining work

The retained 19:47:49 UTC graph at `b814f35e` is MATCH: **47 open issues, 93 canonical records, 143 open acceptance clauses, 27 active edges** (26 local plus `jvallery/homeassistant#878 → #981`) and 24 closed predecessor records. Parent/open-subissue links match and the captured graph is acyclic. This is the before-publication snapshot, not the pending final graph.

No acceptance clause, issue state, parent, dependency, priority or effort estimate changes here. The S3B 40-hour budget, selected 22–34h estimates and at least six-hour reserve remain planning values, not measured effort or remaining hours.

1. Finish and verify the bounded consumer delivery/readback above, preserving all negative, incomplete and empty evidence.
2. Specify a supported observation/freshness contract and collect a prospective complete recorded daytime window without rewriting the incomplete October 16/17 history.
3. Observe intended ordinary planner consumption in a natural operating cycle separately from the bounded qualification.
4. Advance authentic sensing, physical-efficacy and crop-safety work only on its own evidence. No controller tuning, universal VPD target, OTA or device action follows from this packet.

#410 remains open: its solar/evidence semantics are preserved, complete recorded daytime absence remains unknown, and any bounded consumer proof is narrower than natural use or physical efficacy. #775 remains open as the campaign roll-up. No new approval or credential prerequisite is introduced.

## Retained receipt index

The accompanying draft evidence index binds source/preparation checks, the actual daytime assessment and the graph-before readback. Original runtime/failure histories remain in their owning custody. Public evidence should expose scoped results and hashes, not credentials, raw private rows or unrelated estate state.
'''
(D/'README.draft.md').write_text(readme)
rels=['daytime-native-01/stdout','daytime-native-01/result.json','daytime-native-01/verified.json','science/native-acceptance-review.json','graph-before/verified.json','source-impact/receipt.json','platform/handoff.json','platform/focused-checks.json','science/platform-optin-source-review.json','platform/hermes-schema-cache-source-review.json','platform/hermes-gateway-consumer-source-review.json','platform/iris-inventory-handoff.json']
index={
 'schema':'verdify-daytime-consumer-report-draft/v1','status':'DRAFT_SOURCE_AND_DAYTIME_ONLY_RUNTIME_PENDING','target_public_path':review,
 'source_revision':source,'draft_only':True,'repo_github_native_mutations':False,
 'pending_receipts':pending,
 'issue_acceptance':{'410':'OPEN_ALL_THREE_CLAUSES_UNCHANGED','775':'OPEN_ALL_THREE_CLAUSES_UNCHANGED'},
 'facts':{'missing_clock_buckets_total':48,'known_held_admission_minutes':[0,0],'ordinary_dehumidification_minutes':[12,2],'complete_recorded_daytime_zero':[None,None],'natural_planner_cycle_verified':False,'source_ci_terminal_verified':False,'new_http_consumer_verified':False,'new_model_consumer_verified':False,'new_hermes_refresh_verified':False},
 'receipts':[{'path':str(B/r),'sha256':hashlib.sha256((B/r).read_bytes()).hexdigest()} for r in rels],
 'canonical_placement':{'source':'planning/backlog.yaml','selector':'issues[].issue_number','replace_only':['baseline','how','decision'],'next_action':'The proposed next_action is already embedded in baseline after Current execution allocation; apply consistently to an existing execution_plan allocation next_action if that record exists. Do not invent a new acceptance clause or dependency.','preserve':['what','why','acceptance','status','parent','depends_on','priority','effort','owner_role','delivery','rollback','all unrelated rows','all original estimates']},
 'preserved_contracts':{k:{f:v[f] for f in ['key','issue_number','status','acceptance','parent','depends_on','priority','effort','owner_role']} for k,v in rows.items()},
 'original_issue_sha256':{k:hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest() for k,v in rows.items()},
 'proposed_updates_sha256':hashlib.sha256((D/'proposed-updates.json').read_bytes()).hexdigest(),
 'readme_sha256':hashlib.sha256((D/'README.draft.md').read_bytes()).hexdigest()
}
(D/'draft-handoff.json').write_text(json.dumps(index,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [D/'README.draft.md',D/'proposed-updates.json',D/'draft-handoff.json']},'pending_tokens':len(pending),'unchanged_acceptance_clauses':sum(len(r['acceptance']) for r in rows.values())},indent=2))
