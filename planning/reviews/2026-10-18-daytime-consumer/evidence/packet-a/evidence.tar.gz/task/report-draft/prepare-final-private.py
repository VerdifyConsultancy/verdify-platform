from pathlib import Path
import copy,datetime,difflib,hashlib,json,re,sys
B=Path('/private/tmp/verdify-daytime-consumer-20261018');S=Path('/private/tmp/verdify-daytime-consumer-source-20261018');D=B/'final-planning-draft';D.mkdir(exist_ok=False)
sys.path.insert(0,str(S))
from planning.schema import Backlog
from planning.render import outputs,issue_body
source='b814f35e228fcb35c11593c47ea1e021e5fd73de';review='planning/reviews/2026-10-18-daytime-consumer/README.md'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before=json.loads((S/'planning/backlog.yaml').read_text());after=copy.deepcopy(before)
updates=json.loads((B/'report-draft/proposed-updates.json').read_text())
for number,u in updates.items():
 u['baseline']=u['baseline'].replace('Source and focused checks are complete; actual delivery and consumption are not yet asserted.','Source and focused checks are complete. The exact b814f35e native validation Pod completed at 19:57:05 UTC with ALL GATES GREEN and all four declared containers exiting zero without restarts; image publication, live delivery and consumption are not asserted by that source gate.')
 u['baseline']=u['baseline'].replace('The full native gate and selected builds, live MCP delivery, actual Iris HTTP read, fresh Hermes registration and separately bounded model interpretation are pending:', 'The exact b814f35e native validation Pod passed at 19:57:05 UTC with ALL GATES GREEN and all four declared containers exiting zero without restarts. Selected-image publication, live MCP delivery, actual Iris HTTP read, fresh Hermes registration and separately bounded model interpretation remain pending:')
 u['baseline']=u['baseline'].replace('[[PENDING_SOURCE_CI_RECEIPT]]','[[PENDING_SOURCE_IMAGE_CI]]')
 row=next(x for x in after['issues'] if str(x['issue_number'])==number)
 for key in ('baseline','how','decision'):row[key]=u[key]
 alloc=next(x for x in after['execution_plan']['allocations'] if str(x['issue_number'])==number);alloc['next_action']=u['next_action']
# This timestamp identifies private source review, not any pending runtime acceptance.
reviewed=datetime.datetime.now(datetime.timezone.utc).isoformat()
after['execution_plan'].update(reviewed_at=reviewed,source_revision=source,review_path=review)
root=D/'repo';(root/'planning').mkdir(parents=True)
(root/'planning/backlog.yaml').write_text(json.dumps(after,indent=2,ensure_ascii=False)+'\n')
(D/'proposed-updates.json').write_text(json.dumps(updates,indent=2,ensure_ascii=False)+'\n')
plan=Backlog.model_validate(after);old=Backlog.model_validate(before)
views=outputs(plan);assert len(views)==7
for rel,text in views.items():
 p=root/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
bodydir=D/'github-bodies';bodydir.mkdir()
for item in plan.issues:
 if item.issue_number in (410,775):(bodydir/f'{item.issue_number}.md').write_text(issue_body(item,plan))
readme=(B/'report-draft/README.draft.md').read_text()
readme=readme.replace('The source changes and focused checks are complete; the CI, delivery, HTTP, schema refresh and model steps listed below are **pending**, not accepted runtime evidence.','The source changes, focused checks and exact-source full native validation gate are complete. Selected-image CI completion, delivery, HTTP, schema refresh and model steps listed below remain **pending**, not accepted runtime evidence.')
readme=readme.replace('Native full-gate status is still pending below.','The exact native validation Pod `verdify-platform-ci-bgf2f-validate-2838858741` (UID `28339d8a-8f80-4d8c-a2d6-15ed047c00e3`, node6) completed at 19:57:05 UTC with `ALL GATES GREEN`. Its init, fetch-validate-context, main and wait containers each exited zero with no restarts. Full log SHA256: `6bb40e76dfc23aeabb5b8373bf2c64295968ba32a44e64623612390439986f81` (38,669 bytes). The source-gate receipt SHA256 is `744e10862d6a65d1d9c2303e12967f6518383416766cf53db83e532c0a586f59`. This does not claim completion of all selected image builds or any runtime rollout.')
readme=readme.replace('[[PENDING_SOURCE_CI_RECEIPT]]','[[PENDING_SOURCE_IMAGE_CI]]').replace('Last reported running.','The source validation stage passed; whole Workflow/image publication is not asserted by the retained source-gate receipt.')
rp=root/review;rp.parent.mkdir(parents=True);rp.write_text(readme)
# The renderer requires this destination; it is explicitly an unfinished draft, not a fabricated final graph.
(rp.parent/'DEPENDENCIES.md').write_text('# Native dependency conformance — draft\n\n[[PENDING_FINAL_GRAPH]]\n\nThe actual before-publication snapshot at 2026-10-18T19:47:49.343562+00:00 is MATCH at b814f35e: 47 open issues, 143 open acceptance clauses, 26 local plus HA #878 → #981 active edges, 24 closed predecessor records; parent/open-subissue links match and captured graphs are acyclic. Before receipt SHA256: ca988ac58932446abc9ecea50f25f19767a3b99ebdfa5a396118bfa207952696. ROOT must replace this explicit pending final-publication graph draft with the actual final receipt and projection. No edge/state change is proposed.\n')
changes=[]
def compare(a,b,path=''):
 if type(a)!=type(b):changes.append(path);return
 if isinstance(a,dict):
  assert set(a)==set(b),path
  for k in a:compare(a[k],b[k],path+'/'+str(k))
 elif isinstance(a,list):
  assert len(a)==len(b),path
  for i,(x,y) in enumerate(zip(a,b)):compare(x,y,path+'/'+str(i))
 elif a!=b:changes.append(path)
compare(before,after)
allowed=set()
for idx,row in enumerate(before['issues']):
 if row['issue_number'] in (410,775):
  for f in ['baseline','decision']:allowed.add(f'/issues/{idx}/{f}')
  for i in range(len(row['how'])):allowed.add(f'/issues/{idx}/how/{i}')
for idx,row in enumerate(before['execution_plan']['allocations']):
 if row['issue_number'] in (410,775):allowed.add(f'/execution_plan/allocations/{idx}/next_action')
allowed|={f'/execution_plan/{f}' for f in ['reviewed_at','source_revision','review_path']}
assert set(changes)<=allowed,set(changes)-allowed
assert sum(i.status=='open' for i in plan.issues)==47
assert sum(len(i.acceptance) for i in plan.issues if i.status=='open')==143
assert len(plan.issues)==93
changed_bodies=[i.issue_number for i,j in zip(old.issues,plan.issues) if issue_body(i,old)!=issue_body(j,plan)]
assert set(changed_bodies)=={410,775},changed_bodies
assert all(getattr(i,f)==getattr(j,f) for i,j in zip(old.issues,plan.issues) for f in ['status','accepted','acceptance','parent','depends_on','priority','effort'])
assert old.execution_plan.sprints==plan.execution_plan.sprints
assert all((a.hours_min,a.hours_max,a.sprint,a.owner_role)==(c.hours_min,c.hours_max,c.sprint,c.owner_role) for a,c in zip(old.execution_plan.allocations,plan.execution_plan.allocations))
# Match all seven outputs using the actual owning renderer a second time in memory.
assert all((root/rel).read_text()==text for rel,text in outputs(Backlog.model_validate(json.loads((root/'planning/backlog.yaml').read_text()))).items())
patch=''
for rel in ['planning/backlog.yaml',*views]:
 a=(S/rel).read_text();c=(root/rel).read_text()
 patch+=''.join(difflib.unified_diff(a.splitlines(True),c.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
(D/'canonical-generated.patch').write_text(patch)
files=[p for p in D.rglob('*') if p.is_file()]
receipt={'schema':'daytime-consumer-final-private-planning-draft/v1','status':'DRAFT_NATIVE_SOURCE_GATE_PASSED_RUNTIME_AND_IMAGE_CI_PENDING','created_at':reviewed,'source_revision':source,'original_backlog_sha256':sha(S/'planning/backlog.yaml'),'actual_source_gate_receipt_sha256':sha(B/'source-validation-verified.json'),'source_gate_offline_readback':{'pod_uid':'28339d8a-8f80-4d8c-a2d6-15ed047c00e3','pod_phase':'Succeeded','declared_containers':['init','fetch-validate-context','main','wait'],'zero_exit_restart_all':True,'all_gates_green_in_complete_hash_matching_log':True},'changed_canonical_leaf_paths':changes,'changed_issue_bodies':changed_bodies,'generated_view_count':7,'counts':{'canonical_records':93,'open_issues':47,'open_acceptance_clauses':143,'local_active_edges':26,'cross_repository_active_edges':1,'total_active_edges':27},'preserved':['all acceptance clauses/states/accepted flags','all parents/dependencies/priorities/effort','all sprint definitions/estimates/allocation hours','all91 unrelated issue rows','frozen before evidence and original source/failure histories'],'pending_tokens':sorted(set(re.findall(r'\[\[PENDING_[A-Z_]+\]\]',readme))),'root_finalization':['Replace pending source-image CI token with actual selected-build/whole Workflow receipt.','Replace pending deployment, actual Iris HTTP, source-owned Hermes registration and bounded model tokens with exact observed outcomes; do not claim natural cycle.','Update report/source/review metadata to final actual accepted source and readback time.','Replace draft review DEPENDENCIES.md with actual final native conformance; rerender seven views and these two issue bodies after final text.','Apply only to latest source preserving unrelated advancement; these are draft files, not a GitHub update or deployment.'],'files':{str(p.relative_to(D)):sha(p) for p in sorted(files)},'native_operations':0,'github_writes':0,'git_operations':0,'shared_source_edits':0}
(D/'handoff.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'directory':str(D),'handoff_sha256':sha(D/'handoff.json'),'backlog_sha256':sha(root/'planning/backlog.yaml'),'report_sha256':sha(rp),'body_sha256':{p.name:sha(p) for p in bodydir.iterdir()},'changed_bodies':changed_bodies,'generated_views':len(views),'changed_canonical_leaves':len(changes)},indent=2))
