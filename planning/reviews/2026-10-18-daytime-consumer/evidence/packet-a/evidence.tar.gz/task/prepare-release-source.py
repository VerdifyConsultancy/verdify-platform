import pathlib,json,hashlib,subprocess
b=pathlib.Path('/private/tmp/verdify-daytime-consumer-20261018');r=pathlib.Path('/private/tmp/verdify-daytime-consumer-source-20261018')
def git(*a):return subprocess.check_output(['git',*a],cwd=r).decode().strip()
assert git('status','--porcelain')==''
s=json.loads((b/'source-ci-verified.json').read_text());assert s['status']=='SOURCE_GATE_FIVE_BUILDS_AND_PIN_PUBLISHER_VERIFIED'
subprocess.run(['git','fetch','origin','main'],cwd=r,check=True);subprocess.run(['git','merge','--ff-only','origin/main'],cwd=r,check=True)
import yaml
k=yaml.safe_load((r/'deploy/k8s/overlays/prod/kustomization.yaml').read_text());im={x['name'].rsplit('/',1)[-1]:x for x in k['images']};assert im['verdify-mcp']['digest']==s['images']['mcp']['digest']
(b/'candidate-readback.json').write_text(json.dumps({'candidate_commit':git('rev-parse','HEAD'),'mcp_digest':s['images']['mcp']['digest'],'source':s['source_revision']},indent=2)+'\n')
h=json.loads((b/'platform/iris-inventory-handoff.json').read_text())
for f in h['files']:
 p=r/f['path'];d=b/'platform/iris-inventory-draft'/f['path'];assert hashlib.sha256(p.read_bytes()).hexdigest()==f['original_sha256'];assert hashlib.sha256(d.read_bytes()).hexdigest()==f['draft_sha256'];p.write_bytes(d.read_bytes())
print(git('diff','--stat'))
