import json,pathlib,hashlib,os,yaml
out=[]
for path in ['/etc/verdify/hermes-config/config.yaml','/opt/data/config.yaml','/opt/data/.hermes/config.yaml']:
 p=pathlib.Path(path)
 if not p.is_file():continue
 raw=p.read_bytes();assert len(raw)<200000;d=yaml.safe_load(raw);m=d.get('model',{});assert isinstance(m,dict);out.append({'path':path,'sha256':hashlib.sha256(raw).hexdigest(),'model':{k:m[k] for k in ['default','provider','base_url'] if k in m},'reasoning_effort':d.get('agent',{}).get('reasoning_effort')})
assert out
print(json.dumps({'configs':out,'HERMES_HOME':os.environ.get('HERMES_HOME'),'model_env_overrides_present':[k for k in ['HERMES_MODEL','OPENAI_MODEL','HERMES_PROVIDER','OPENAI_BASE_URL','HERMES_REASONING_EFFORT'] if os.environ.get(k)]}))
