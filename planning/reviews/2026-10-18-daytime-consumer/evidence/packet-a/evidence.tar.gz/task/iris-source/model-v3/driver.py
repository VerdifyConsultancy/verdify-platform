import json,pathlib,hashlib,os
out=[]
for path in ['/etc/verdify/hermes-config/config.yaml','/opt/data/config.yaml']:
 p=pathlib.Path(path);raw=p.read_bytes();assert len(raw)<200000;digest=hashlib.sha256(raw).hexdigest();assert digest=='51de00576417701fc4fed8fb03ec9a3f1bfbee5e4f5d057f25b763076c2a8b5f';out.append({'path':path,'sha256':digest})
assert os.environ.get('HERMES_HOME')=='/opt/data'
overrides=[k for k in ['HERMES_MODEL','OPENAI_MODEL','HERMES_PROVIDER','OPENAI_BASE_URL','HERMES_REASONING_EFFORT'] if os.environ.get(k)];assert not overrides
print(json.dumps({'status':'MOUNTED_AND_EFFECTIVE_CONFIG_EXACT_SOURCE_HASH_MATCH','configs':out,'HERMES_HOME':'/opt/data','model_env_overrides_present':overrides}))
