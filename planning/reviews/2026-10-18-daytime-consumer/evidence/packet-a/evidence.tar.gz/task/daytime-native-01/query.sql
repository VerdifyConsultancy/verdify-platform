\set ON_ERROR_STOP on
\pset format unaligned
\pset tuples_only on
BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY;
SET LOCAL search_path=pg_catalog,public,pg_temp;
SET LOCAL statement_timeout='15s';
SET LOCAL lock_timeout='500ms';
SET LOCAL idle_in_transaction_session_timeout='15s';
SET LOCAL max_parallel_workers_per_gather=0;
SET LOCAL work_mem='4MB';
SET LOCAL temp_file_limit='64MB';
SET LOCAL TimeZone='UTC';
WITH expected_functions(signature,sha) AS (VALUES ('public.fn_realized_solar_night_dryout(date,date,text)','89782089fd6ae3ecfeecdfbc1b730f6ab6a272c0da7b35ef562788eddbfa42c0'),
('public.fn_hermite_phase(double precision,double precision,double precision,double precision,double precision,double precision)','f9642002e69bbac2d1a2dc7f9a19fb069ea86295c995713eaf37c8efa2e164fb'),
('public.fn_solar_phase(timestamp with time zone)','960f6e4c435ce534db8956630bd32408a3d1294362b2aef44c018189d250e715'),
('public.fn_solar_sunrise_hour(timestamp with time zone)','66795353790f6678c02f8f6af5e6d576fe8177714b07a679925360bd1f851d51'),
('public.fn_solar_sunset_hour(timestamp with time zone)','227310e3542f7e0bc06f0639724a72444a8366320cb30da07ecfc01f185a9c79')),
expected_ledger(filename,sha) AS (VALUES ('db/migrations/172-smooth-solar-phase.sql','bf0c60dc6f3553be395c32a22bdd5d1c00f3addfd689aa1def3f796db6db431e'),
('db/migrations/186-noaa-solar-phase-parity.sql','9e1e33b5005e183a35d84dd9b41d96b4d535faa99945d7ae6c89b196d4569e28'),
('db/migrations/277-realized-solar-night-readback-timeline.sql','a8a0bc063bd655d2e96dd3d424768169edb4ea714c7a1b51dca2b41cc39b29a1')),
verdict AS (SELECT
 current_database()='verdify' AND current_user='verdify' AND session_user='verdify'
 AND current_setting('transaction_read_only')='on'
 AND current_setting('transaction_isolation')='repeatable read'
 AND NOT pg_is_in_recovery()
 AND pg_postmaster_start_time()='2026-09-29T00:40:56.280382+00:00'::timestamptz
 AND current_setting('server_version_num')='160011'
 AND DATE '2026-10-18' <= (now() AT TIME ZONE 'America/Denver')::date
 AND (SELECT count(*)=5 AND bool_and(
   encode(sha256(convert_to(pg_get_functiondef(p.oid),'UTF8')),'hex')=e.sha
   AND pg_get_userbyid(p.proowner)='verdify' AND p.proconfig IS NULL)
   FROM expected_functions e JOIN pg_proc p ON p.oid=to_regprocedure(e.signature))
 AND (SELECT encode(sha256(convert_to(prosrc,'UTF8')),'hex')=
  '578a07bed56714cd2dfe2308ca30ced1f6fc6916fd7db9d79630a7b82b261655'
  FROM pg_proc WHERE oid='public.fn_realized_solar_night_dryout(date,date,text)'::regprocedure)
 AND (SELECT count(*)=3 AND bool_and(m.sha256=e.sha) FROM expected_ledger e
   JOIN public.schema_migrations m ON m.source='db/migrations' AND m.filename=e.filename)
 AND (SELECT max(seq)=277 FROM public.schema_migrations WHERE source='db/migrations') AS ok)
SELECT json_build_object('kind','daytime_identity_guard','passed',1/(CASE WHEN ok THEN 1 ELSE 0 END),
 'captured_at',clock_timestamp(),'database',current_database(),'current_user',current_user,
 'session_user',session_user,'postmaster',pg_postmaster_start_time(),
 'readonly',current_setting('transaction_read_only'),'isolation',current_setting('transaction_isolation'))
FROM verdict;

WITH bounds AS NOT MATERIALIZED (
 SELECT DATE '2026-10-16'::timestamp AT TIME ZONE 'America/Denver' start_ts,
        DATE '2026-10-18'::timestamp AT TIME ZONE 'America/Denver' end_ts
),
raw_climate AS MATERIALIZED (
 SELECT c.ts,c.temp_avg,c.vpd_avg,c.rh_avg FROM public.climate c CROSS JOIN bounds b
 WHERE c.greenhouse_id='vallery' AND c.ts>=b.start_ts AND c.ts<b.end_ts LIMIT 20001
),
raw_action AS MATERIALIZED (
 SELECT l.ts,l.greenhouse_id,l.climate_action,l.priority_axis,l.relay_truth,l.source_system_state
 FROM public.climate_action_log l CROSS JOIN bounds b
 WHERE l.greenhouse_id='vallery' AND l.ts>=b.start_ts AND l.ts<b.end_ts LIMIT 20001
),
clock AS MATERIALIZED (
 SELECT tick AS bucket, (tick AT TIME ZONE 'America/Denver')::date local_date,
 public.fn_solar_phase(tick) solar_phase
 FROM bounds b CROSS JOIN LATERAL generate_series(b.start_ts,b.end_ts-interval '1 minute',interval '1 minute') tick
),
climate_quality AS (
 SELECT date_trunc('minute',ts) bucket,count(*) raw_samples,
 count(*) FILTER(WHERE temp_avg IS NOT NULL AND vpd_avg IS NOT NULL AND rh_avg IS NOT NULL) getter_eligible_samples,
 count(*) FILTER(WHERE temp_avg IS NOT NULL AND vpd_avg IS NOT NULL AND rh_avg IS NOT NULL
   AND temp_avg::text NOT IN ('NaN','Infinity','-Infinity')
   AND vpd_avg::text NOT IN ('NaN','Infinity','-Infinity')
   AND rh_avg::text NOT IN ('NaN','Infinity','-Infinity')) finite_samples,
 count(*) FILTER(WHERE temp_avg IS NULL OR vpd_avg IS NULL OR rh_avg IS NULL
   OR temp_avg::text IN ('NaN','Infinity','-Infinity')
   OR vpd_avg::text IN ('NaN','Infinity','-Infinity')
   OR rh_avg::text IN ('NaN','Infinity','-Infinity')) invalid_samples
 FROM raw_climate GROUP BY 1
),
action_rows AS (
    SELECT
        (SELECT bool_and(COALESCE(jsonb_typeof(l.relay_truth -> k) = 'boolean',false))
          FROM unnest(ARRAY['vent','fan1','fan2','heat1','heat2','fog','mister_south','mister_west','mister_center']) k)
          AS relay_types_complete,
        COALESCE(jsonb_typeof(l.source_system_state -> 'climate_moisture_exchange' -> 'hold_required')='boolean',false)
          AND COALESCE(jsonb_typeof(l.source_system_state -> 'climate_moisture_exchange' -> 'reason')='string',false)
          AND COALESCE(l.source_system_state -> 'climate_moisture_exchange' ->> 'reason','')<>''
          AS hold_markers_complete,
        date_trunc('minute', l.ts) AS bucket,
        l.climate_action,
        l.priority_axis,
        NULLIF(
            l.source_system_state -> 'climate_moisture_exchange' ->> 'action',
            ''
        ) AS mx_action,
        NULLIF(
            l.source_system_state -> 'climate_moisture_exchange' ->> 'reason',
            ''
        ) AS mx_reason,
        COALESCE((l.relay_truth ->> 'vent')::boolean, false) AS vent_on,
        COALESCE((l.relay_truth ->> 'fan1')::boolean, false)
            OR COALESCE((l.relay_truth ->> 'fan2')::boolean, false) AS fan_on,
        COALESCE((l.relay_truth ->> 'heat1')::boolean, false) AS heat1_on,
        COALESCE((l.relay_truth ->> 'heat2')::boolean, false) AS heat2_on,
        COALESCE((l.relay_truth ->> 'fog')::boolean, false)
            OR COALESCE((l.relay_truth ->> 'mister_south')::boolean, false)
            OR COALESCE((l.relay_truth ->> 'mister_west')::boolean, false)
            OR COALESCE((l.relay_truth ->> 'mister_center')::boolean, false)
            AS wet_relay_on,
        l.relay_truth ?& ARRAY[
            'vent', 'fan1', 'fan2', 'heat1', 'heat2',
            'fog', 'mister_south', 'mister_west', 'mister_center'
        ]::text[] AS relay_evidence_present,
        COALESCE(
            (l.source_system_state -> 'climate_moisture_exchange'
                ->> 'hold_required')::boolean,
            false
        ) OR COALESCE((
            l.source_system_state -> 'climate_moisture_exchange' ->> 'reason'
                = 'vent_plus_heat_hold'
        ), false) AS hold_flavor
    FROM raw_action l
    CROSS JOIN bounds b
    WHERE l.greenhouse_id = 'vallery'::text
      AND l.ts >= b.start_ts
      AND l.ts < b.end_ts
),
classified_action_rows AS (
    SELECT
        a.*,
        (
            a.relay_evidence_present
            AND
            (a.priority_axis = 'vpd' OR a.climate_action = 'DEHUM_VENT')
            AND (
                (a.climate_action = 'DEHUM_VENT' AND a.vent_on AND a.fan_on)
                OR (a.mx_action = 'heat_assist' AND a.heat1_on)
                OR (
                    a.mx_reason = 'vent_plus_heat_hold'
                    AND a.vent_on AND a.fan_on AND a.heat1_on
                )
            )
        ) AS dry_action_admitted,
        (
            a.relay_evidence_present
            AND a.hold_flavor
            AND a.climate_action = 'DEHUM_VENT'
            AND a.vent_on
            AND a.fan_on
            AND a.heat1_on
        ) AS hold_action_admitted
    FROM action_rows a
),
action_minute AS (
    SELECT
        bucket,
        true AS action_sample_present,
        mode() WITHIN GROUP (ORDER BY climate_action) AS climate_action,
        mode() WITHIN GROUP (ORDER BY priority_axis) AS priority_axis,
        mode() WITHIN GROUP (ORDER BY mx_action) AS mx_action,
        mode() WITHIN GROUP (ORDER BY mx_reason) AS mx_reason,
        bool_or(vent_on) AS vent_on,
        bool_or(fan_on) AS fan_on,
        bool_or(heat1_on) AS heat1_on,
        bool_or(heat2_on) AS heat2_on,
        bool_or(wet_relay_on) AS wet_relay_on,
        bool_and(relay_evidence_present) AS relay_evidence_complete,
        bool_or(dry_action_admitted) AS dry_action_admitted,
        bool_or(hold_action_admitted) AS hold_action_admitted,
        mode() WITHIN GROUP (
            ORDER BY COALESCE(mx_reason, mx_action, climate_action)
        ) FILTER (WHERE dry_action_admitted) AS dry_admission_reason
    FROM classified_action_rows
    GROUP BY bucket
),
quality_rows AS (
 SELECT a.*, COALESCE(relay_types_complete AND climate_action IS NOT NULL
   AND (hold_flavor OR climate_action<>'DEHUM_VENT' OR NOT(vent_on AND fan_on AND heat1_on)
        OR hold_markers_complete),false) AS hold_classification_known
 FROM classified_action_rows a
),
action_quality AS (
 SELECT bucket,count(*) raw_samples,
 count(*) FILTER(WHERE dry_action_admitted) dry_raw_samples,
 count(*) FILTER(WHERE hold_action_admitted) held_raw_samples,
 count(*) FILTER(WHERE NOT relay_types_complete) relay_type_unknown_samples,
 count(*) FILTER(WHERE NOT hold_markers_complete) missing_hold_marker_samples,
 count(*) FILTER(WHERE NOT hold_classification_known) held_classification_unknown_samples,
 bool_and(hold_classification_known) held_classification_complete,
 bool_or(dry_action_admitted AND NOT hold_action_admitted AND hold_classification_known) ordinary_dry_admitted
 FROM quality_rows GROUP BY bucket
),
coverage AS MATERIALIZED (
 SELECT t.bucket,t.local_date,t.solar_phase,c.raw_samples climate_samples,
 c.getter_eligible_samples,c.finite_samples,c.invalid_samples,
 q.raw_samples action_samples,q.dry_raw_samples,q.held_raw_samples,
 q.relay_type_unknown_samples,q.missing_hold_marker_samples,q.held_classification_unknown_samples,
 q.held_classification_complete,q.ordinary_dry_admitted,
 a.dry_action_admitted,a.hold_action_admitted,
 ARRAY_REMOVE(ARRAY[
 CASE WHEN c.bucket IS NULL THEN 'missing_climate' END,
 CASE WHEN c.bucket IS NOT NULL AND (c.finite_samples=0 OR c.invalid_samples>0) THEN 'invalid_climate' END,
 CASE WHEN a.bucket IS NULL THEN 'missing_action' END,
 CASE WHEN q.relay_type_unknown_samples>0 THEN 'untyped_relay_state' END,
 CASE WHEN q.held_classification_unknown_samples>0 THEN 'unknown_held_admission' END
 ],NULL) AS gaps
 FROM clock t LEFT JOIN climate_quality c USING(bucket)
 LEFT JOIN action_minute a USING(bucket) LEFT JOIN action_quality q USING(bucket)
 WHERE t.solar_phase>=0 AND t.solar_phase<2
),
days AS (
 SELECT local_date,count(*) expected_solar_day_minutes,min(bucket) first_day_bucket,max(bucket) last_day_bucket,
 count(*) FILTER(WHERE climate_samples IS NOT NULL) observed_climate_minutes,
 count(*) FILTER(WHERE getter_eligible_samples>0) getter_eligible_climate_minutes,
 count(*) FILTER(WHERE finite_samples>0 AND invalid_samples=0) fully_valid_climate_minutes,
 count(*) FILTER(WHERE climate_samples IS NULL) missing_climate_minutes,
 count(*) FILTER(WHERE action_samples IS NOT NULL) observed_action_minutes,
 count(*) FILTER(WHERE action_samples IS NULL) missing_action_minutes,
 count(*) FILTER(WHERE held_classification_complete) known_held_classification_minutes,
 count(*) FILTER(WHERE held_classification_unknown_samples>0) unknown_held_classification_minutes,
 count(*) FILTER(WHERE missing_hold_marker_samples>0) minutes_missing_explicit_hold_markers,
 count(*) FILTER(WHERE dry_action_admitted) source_daytime_dry_admission_minutes,
 count(*) FILTER(WHERE hold_action_admitted) source_daytime_held_admission_minutes,
 count(*) FILTER(WHERE ordinary_dry_admitted) known_ordinary_daytime_dehumidification_minutes,
 COALESCE(sum(dry_raw_samples),0) dry_admitted_raw_samples,
 COALESCE(sum(held_raw_samples),0) held_admitted_raw_samples,
 bool_and(cardinality(gaps)=0) recorded_minute_coverage_complete,
 CASE WHEN bool_and(cardinality(gaps)=0) THEN count(*) FILTER(WHERE hold_action_admitted)=0 ELSE NULL END
   AS measured_zero_for_complete_recorded_minutes,
 COALESCE(jsonb_agg(jsonb_build_object('bucket',bucket,'missing_or_unknown',gaps)
   ORDER BY bucket) FILTER(WHERE cardinality(gaps)>0),'[]'::jsonb) AS all_gap_minutes
 FROM coverage GROUP BY local_date
),
totals AS (SELECT (SELECT count(*) FROM raw_climate) raw_climate_count,
 (SELECT count(*) FROM raw_action) raw_action_count,
 (SELECT count(*) FROM clock) clock_minutes,
 (SELECT count(*) FROM clock WHERE solar_phase IS NULL OR solar_phase::text IN ('NaN','Infinity','-Infinity')
  OR solar_phase<0 OR solar_phase>=4) invalid_solar_minutes)
SELECT jsonb_build_object('kind','complete_daytime_recorded_coverage',
 'source_classification_version','installed277', 'window_start','2026-10-16T00:00:00 America/Denver',
 'window_end_exclusive','2026-10-18T00:00:00 America/Denver','greenhouse_id','vallery',
 'complete_input_cap_guard',1/(CASE WHEN raw_climate_count<20001 AND raw_action_count<20001
   AND clock_minutes=2880 AND invalid_solar_minutes=0 AND (SELECT count(*) FROM days)=2 THEN 1 ELSE 0 END),
 'raw_climate_count',raw_climate_count,'raw_action_count',raw_action_count,'input_row_cap_each',20000,
 'clock_minutes',clock_minutes,'invalid_solar_minutes',invalid_solar_minutes,
 'source_action_fragment_sha256','f2407ad0fa0825a7e58df5f97336936d75a7e83d34e2b89c00ff2e8f58c14231',
 'prior_observed_count_comparison',jsonb_build_object(
  'expected_dry_minutes_by_day',jsonb_build_object('2026-10-16',12,'2026-10-17',2),
  'expected_held_minutes_each_day',0,
  'matches', (SELECT bool_and(source_daytime_dry_admission_minutes=CASE WHEN local_date=DATE '2026-10-16' THEN 12 ELSE 2 END
     AND source_daytime_held_admission_minutes=0) FROM days),
  'mismatch_policy','retain actual rows; investigate snapshot drift; never rewrite expected counts'),
 'days',(SELECT jsonb_agg(to_jsonb(d) ORDER BY local_date) FROM days d),
 'continuous_physical_absence_proven',false,'source_per_relay_freshness_proven',false,
 'full_issue_acceptance',false,
 'limitation','Complete recorded minute coverage is snapshot evidence only. Ingestor emits 60-second plus selected event snapshots, defaults absent relay state false, and carries no per-relay freshness. Missing marker/state/time is not zero.')
FROM totals;

WITH expected_functions(signature,sha) AS (VALUES ('public.fn_realized_solar_night_dryout(date,date,text)','89782089fd6ae3ecfeecdfbc1b730f6ab6a272c0da7b35ef562788eddbfa42c0'),
('public.fn_hermite_phase(double precision,double precision,double precision,double precision,double precision,double precision)','f9642002e69bbac2d1a2dc7f9a19fb069ea86295c995713eaf37c8efa2e164fb'),
('public.fn_solar_phase(timestamp with time zone)','960f6e4c435ce534db8956630bd32408a3d1294362b2aef44c018189d250e715'),
('public.fn_solar_sunrise_hour(timestamp with time zone)','66795353790f6678c02f8f6af5e6d576fe8177714b07a679925360bd1f851d51'),
('public.fn_solar_sunset_hour(timestamp with time zone)','227310e3542f7e0bc06f0639724a72444a8366320cb30da07ecfc01f185a9c79')),
expected_ledger(filename,sha) AS (VALUES ('db/migrations/172-smooth-solar-phase.sql','bf0c60dc6f3553be395c32a22bdd5d1c00f3addfd689aa1def3f796db6db431e'),
('db/migrations/186-noaa-solar-phase-parity.sql','9e1e33b5005e183a35d84dd9b41d96b4d535faa99945d7ae6c89b196d4569e28'),
('db/migrations/277-realized-solar-night-readback-timeline.sql','a8a0bc063bd655d2e96dd3d424768169edb4ea714c7a1b51dca2b41cc39b29a1')),
verdict AS (SELECT
 current_database()='verdify' AND current_user='verdify' AND session_user='verdify'
 AND current_setting('transaction_read_only')='on'
 AND current_setting('transaction_isolation')='repeatable read'
 AND NOT pg_is_in_recovery()
 AND pg_postmaster_start_time()='2026-09-29T00:40:56.280382+00:00'::timestamptz
 AND current_setting('server_version_num')='160011'
 AND DATE '2026-10-18' <= (now() AT TIME ZONE 'America/Denver')::date
 AND (SELECT count(*)=5 AND bool_and(
   encode(sha256(convert_to(pg_get_functiondef(p.oid),'UTF8')),'hex')=e.sha
   AND pg_get_userbyid(p.proowner)='verdify' AND p.proconfig IS NULL)
   FROM expected_functions e JOIN pg_proc p ON p.oid=to_regprocedure(e.signature))
 AND (SELECT encode(sha256(convert_to(prosrc,'UTF8')),'hex')=
  '578a07bed56714cd2dfe2308ca30ced1f6fc6916fd7db9d79630a7b82b261655'
  FROM pg_proc WHERE oid='public.fn_realized_solar_night_dryout(date,date,text)'::regprocedure)
 AND (SELECT count(*)=3 AND bool_and(m.sha256=e.sha) FROM expected_ledger e
   JOIN public.schema_migrations m ON m.source='db/migrations' AND m.filename=e.filename)
 AND (SELECT max(seq)=277 FROM public.schema_migrations WHERE source='db/migrations') AS ok)
SELECT json_build_object('kind','daytime_identity_guard','passed',1/(CASE WHEN ok THEN 1 ELSE 0 END),
 'captured_at',clock_timestamp(),'database',current_database(),'current_user',current_user,
 'session_user',session_user,'postmaster',pg_postmaster_start_time(),
 'readonly',current_setting('transaction_read_only'),'isolation',current_setting('transaction_isolation'))
FROM verdict;
ROLLBACK;
