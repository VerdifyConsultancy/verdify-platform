import pathlib,json,hashlib
paths=[pathlib.Path('/opt/hermes/gateway/platforms/api_server.py'),pathlib.Path('/opt/hermes/model_tools.py'),pathlib.Path('/opt/hermes/tools/registry.py')];rows=[]
for p in paths:
 if p.is_file():
  raw=p.read_bytes();assert len(raw)<500000;rows.append({'path':str(p),'sha256':hashlib.sha256(raw).hexdigest(),'source':raw.decode()})
assert rows
print(json.dumps(rows))
