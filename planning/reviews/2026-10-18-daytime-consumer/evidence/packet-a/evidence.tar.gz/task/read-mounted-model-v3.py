import json,subprocess,pathlib,datetime
b=pathlib.Path('/private/tmp/verdify-daytime-consumer-20261018/iris-source/model-v3');b.mkdir(exist_ok=False)
driver='''import json,pathlib,hashlib,os
out=[]
for path in ['/etc/verdify/hermes-config/config.yaml','/opt/data/config.yaml']:
 p=pathlib.Path(path);raw=p.read_bytes();assert len(raw)<200000;digest=hashlib.sha256(raw).hexdigest();assert digest=='51de00576417701fc4fed8fb03ec9a3f1bfbee5e4f5d057f25b763076c2a8b5f';out.append({'path':path,'sha256':digest})
assert os.environ.get('HERMES_HOME')=='/opt/data'
overrides=[k for k in ['HERMES_MODEL','OPENAI_MODEL','HERMES_PROVIDER','OPENAI_BASE_URL','HERMES_REASONING_EFFORT'] if os.environ.get(k)];assert not overrides
print(json.dumps({'status':'MOUNTED_AND_EFFECTIVE_CONFIG_EXACT_SOURCE_HASH_MATCH','configs':out,'HERMES_HOME':'/opt/data','model_env_overrides_present':overrides}))
''';(b/'driver.py').write_text(driver);k=['kubectl','--kubeconfig','/Users/jason/.kube/config','--context','vallery','--request-timeout=20s','-n','verdify-prod'];j=json.loads(subprocess.check_output(k+['get','pod','verdify-hermes-iris-fcfb7dd98-7skpf','-o','json'],timeout=25));assert j['metadata']['uid']=='fc60d2ed-f4ba-4db1-bccc-59dcf3dec378';r=subprocess.run(k+['exec','-i',j['metadata']['name'],'-c','hermes-iris','--','python3','-'],input=driver.encode(),capture_output=True,timeout=25);(b/'stdout.json').write_bytes(r.stdout);(b/'stderr').write_bytes(r.stderr);assert r.returncode==0;v=json.loads(r.stdout);print(json.dumps(v))
