#!/usr/bin/env bash
# ci-local.sh — pre-merge validation, with explicit host capability limits
# (operator host, k3s pod, the in-cluster verdify-platform-ci Argo Workflow).
# Linux publication tests run in native Linux CI; non-Linux host validation
# reports those skips and does not qualify a release on its own.
#
# 2026-07-11: GitHub Actions is removed from this repo (operator directive —
# no external CI dependency). This script IS the gate the old workflows ran:
#   ci.yml            -> lint, format, schema/logic/contract pytest suites,
#                        migration rollback safety, twin vendored-src compile
#   k8s-manifests.yml -> kustomize render of the prod overlay
#   container-publish -> image builds happen in-cluster (repo-build Kaniko
#                        workflows -> zot origin; docs/runbooks/prod-promotion.md)
#
# Gates that needed a PR event (replay-diff vs merge-base, fire-and-forget on
# the tunables diff) run in DIFF MODE when CI_BASE_REF is set:
#   CI_BASE_REF=<sha|ref> scripts/ci-local.sh
#
# Exit nonzero on the first failing gate. Keep this script dependency-light:
# python3.12+ with the repo's [dev] extras, g++, kubectl/kustomize.

set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."

PY="${PYTHON:-.venv/bin/python}"
RUFF="${RUFF:-.venv/bin/ruff}"
if [ ! -x "$PY" ]; then PY=python3; fi
if [ ! -x "$RUFF" ]; then RUFF="$PY -m ruff"; fi

# Shell helpers launch python3 themselves. Use the selected interpreter's
# environment so their imports match pytest, including native CI's fresh venv.
export PATH="$("$PY" -c 'import pathlib, sys; print(pathlib.Path(sys.executable).parent)'):$PATH"

step() { printf '\n== %s ==\n' "$1"; }

step "ruff lint"
$RUFF check ingestor/ api/ experiment_orchestrator/ mcp/ scripts/*.py tests/ verdify_public/ verdify_schemas/ \
  research/planner-efficacy/generate_v2_artifacts.py \
  research/planner-efficacy/switchback/v2_*.py \
  research/planner-efficacy/tests/test_protocol_template_contract.py \
  research/planner-efficacy/tests/test_switchback_v2_*.py

step "ruff format"
$RUFF format --check ingestor/ api/ experiment_orchestrator/ mcp/ scripts/*.py tests/ verdify_public/ verdify_schemas/ \
  research/planner-efficacy/generate_v2_artifacts.py \
  research/planner-efficacy/switchback/v2_*.py \
  research/planner-efficacy/tests/test_protocol_template_contract.py \
  research/planner-efficacy/tests/test_switchback_v2_*.py

step "schema suites (incl. drift guards + producer payload round-trips)"
$PY -m pytest -q verdify_schemas/tests/

step "ClimateIntent controller contract audit"
$PY scripts/audit-climate-intent-contract.py

step "confirmed-component v2 selector/randomization/design contracts"
$PY -m pytest -q \
  tests/test_03_ingestor.py \
  research/planner-efficacy/tests/test_protocol_template_contract.py \
  research/planner-efficacy/tests/test_switchback_v2_design.py \
  research/planner-efficacy/tests/test_switchback_v2_day1_export.py \
  research/planner-efficacy/tests/test_switchback_v2_randomization.py \
  research/planner-efficacy/tests/test_switchback_v2_selector.py
$PY research/planner-efficacy/generate_v2_artifacts.py --check

step "device write gate"
$PY -m pytest -q tests/test_device_write_gate.py tests/test_replay_outdoor_device_age.py tests/test_replay_setpoint_export.py

step "pure-logic / contract tests"
$PY -m pytest -q -rs \
  tests/test_275_c0_delivery.py \
  tests/test_277_getter_delivery.py \
  tests/test_realized_solar_night_dryout_timeline.py \
  tests/test_05_dispatcher.py \
  tests/test_irrigation_stop_edges.py \
  tests/test_bounded_reconcile.py \
  tests/test_recovered_confirmation_expiry.py \
  tests/test_10_planner_routing.py \
  tests/test_11_planner_milestones.py \
  tests/test_13_grafana_band_traceability.py \
  tests/test_14_shadow_mode.py \
  tests/test_14_site_doctor.py \
  tests/test_16_writer_lifecycle.py \
  tests/test_17_planner_health_surface.py \
  tests/test_iris_inventory.py \
  tests/test_cnpg_s2_profile.py \
  tests/test_cnpg_s2_pitr_pair.py \
  tests/test_cnpg_s2_marker_client.py \
  tests/test_cnpg_s2_archive_reader.py \
  tests/test_cnpg_s2_failover_client.py \
  tests/test_cnpg_current275_transition.py \
  tests/test_cnpg_s2_integration_recovery.py \
  tests/test_cnpg_complete_copy_receipt.py \
  tests/test_cnpg_solar_dryout_time_projection.py \
  tests/test_ordinary_runtime_qualification.py \
  tests/test_restored_runtime_duties.py \
  tests/test_restored_duty_transport_readiness.py \
  tests/test_ingestor_committed_spool_qualification.py \
  tests/test_cnpg_s2_client_policy.py \
  tests/test_historical_suppressed_alert_maintenance.py \
  tests/test_18_twin_divergence_dashboard.py \
  tests/test_20_vision_src_sync.py \
  tests/test_vision_authenticated_snapshots.py \
  tests/test_21_config_revision.py \
  tests/test_component_grid_capture.py \
  tests/test_c1_grid_projection.py \
  tests/test_c1_qualification_overlay.py \
  tests/test_c1_native_capture.py \
  tests/test_control_band_wire.py \
  tests/test_component_prefix_replay.py \
  tests/test_component_prefix_inputs.py \
  tests/test_fog_vent_consumer.py \
  tests/test_cnpg_rehearsal.py \
  tests/test_cnpg_runtime_client_qualification.py \
  tests/test_cnpg_restore_qualification.py \
  tests/test_cnpg_portable_witness_v3.py \
  tests/test_cnpg_boundary_default_acl.py \
  tests/test_cnpg_historical_chunk_source.py \
  tests/test_cnpg_restore_private_scratch.py \
  tests/test_cnpg_source_grantor_continuation.py \
  tests/test_cnpg_target_runtime_transition.py \
  tests/test_cnpg_retained_session_admission.py \
  tests/test_cnpg_target270_successor.py \
  tests/test_cnpg_physical_runtime_transition.py \
  tests/test_cnpg_public_count_time_clock.py \
  tests/test_cnpg_policy_twin_count_time.py \
  tests/test_cnpg_policy_twin_endpoints.py \
  tests/test_cnpg_physical_client_qualification.py \
  tests/test_db_backup_retry_classifier.py \
  tests/test_backup_freshness_exporter.py \
  tests/test_action_log_policy_identity.py \
  tests/test_moisture_state_boundary.py \
  tests/test_anchor_service_sync.py \
  tests/test_api_light_command_boundary.py \
  tests/test_api_public_output_policy.py \
  tests/test_climate_intent_replay_evaluator.py \
  tests/test_compliance_feasibility_classifier.py \
  tests/test_component_experiment_api.py \
  tests/test_component_experiment_contract.py \
  tests/test_component_experiment_executor.py \
  tests/test_component_experiment_observability.py \
  tests/test_component_alert_scope.py \
  tests/test_264_facility_safe_closure_delivery.py \
  tests/test_component_experiment_source.py \
  tests/test_native_transport_liveness.py \
  tests/test_k3s_smoke_device_monitor.py \
  tests/test_k3s_smoke_g10.py \
  tests/test_component_experiment_store.py \
  tests/test_component_experiment_writer.py \
  tests/test_component_grid_qualification.py \
  tests/test_esp32_policy_transaction.py \
  tests/test_experiment_api.py \
  tests/test_experiment_gather_mode.py \
  tests/test_experiment_qualification_regimes.py \
  tests/test_experiment_qualification_scheduler.py \
  tests/test_experiment_qualification_settling.py \
  tests/test_experiment_qualification_spec.py \
  tests/test_experiment_schema_migration.py \
  tests/test_experiment_v2_counter_source.py \
  tests/test_experiment_v2_orchestrator_contracts.py \
  tests/test_experiment_v2_orchestrator_database.py \
  tests/test_experiment_v2_orchestrator_manifests.py \
  tests/test_experiment_v2_orchestrator_outcome.py \
  tests/test_experiment_v2_orchestrator_provider.py \
  tests/test_experiment_v2_orchestrator_runtime.py \
  tests/test_experiment_v2_orchestrator_service.py \
  tests/test_experiment_v2_orchestrator_stores.py \
  tests/test_experiment_v2_reconcile.py \
  tests/test_experiment_v2_reconcile_archive.py \
  tests/test_experiment_v2_capture_inputs.py \
  tests/test_freeze_route_day_target.py \
  tests/test_experiment_v2_restore_rehearsal.py \
  tests/test_experiment_v2_shadow_source_lock.py \
  tests/test_experiment_v2_data_contract.py \
  tests/test_experiment_v2_day1_authorization.py \
  tests/test_experiment_v2_direct_launch_runtime.py \
  tests/test_experiment_v2_launch_artifacts.py \
  tests/test_experiment_v2_direct_proof_activation.py \
  tests/test_experiment_v2_direct_proof_attempt_status.py \
  tests/test_experiment_v2_direct_proof_recovery_range_rollover.py \
  tests/test_experiment_v2_direct_proof_retry.py \
  tests/test_experiment_v2_gate_r_activation.py \
  tests/test_experiment_v2_gate_r_readiness_activation.py \
  tests/test_experiment_v2_proof_packet.py \
  tests/test_experiment_v2_wetting_disposition.py \
  tests/test_783_current_role_admission.py \
  tests/test_experiment_v2_readiness_guard.py \
  tests/test_experiment_v2_emergency_recovery_retry.py \
  tests/test_experiment_v2_recovery_generation_guard.py \
  tests/test_experiment_v2_recovery_failure_boundary.py \
  tests/test_experiment_verify.py \
  tests/test_experiment_workers.py \
  tests/test_api_deferred_batch_patch.py \
  tests/test_api_overflow_patch.py tests/test_api_heap_owner_counters.py tests/test_api_iterator_backpressure.py \
  tests/test_sensor_health_modbus_native.py \
  tests/test_probe_diagnostics_native.py \
  tests/test_policy_relay_dwell_refresh.py \
  tests/test_firmware_builder_image.py \
  tests/test_firmware_provisional_rollback.py \
  tests/test_firmware_crop_agnostic_guard.py \
  tests/test_forecast_action_engine_path.py \
  tests/test_g5_dualwrite_validation.py \
  tests/test_generate_daily_plan.py \
  tests/test_grafana_cm_check.py \
  tests/test_grafana_manifest_security.py \
  tests/test_ha_gap_backfill_runtime_boundary.py \
  tests/test_ha_light_writer_boundary.py \
  tests/test_ingestor_setpoint_placement.py \
  tests/test_ingestor_gap_snapshot.py \
  tests/test_source_spool.py \
  tests/test_climate_event_spool.py \
  tests/test_observation_spool.py \
  tests/test_observational_source_migration.py \
  tests/test_lab_generator_standardization.py \
  tests/test_lab_publish_k3s_guard.py \
  tests/test_mcp_audience_auth.py \
  tests/test_mcp_transport_runtime.py \
  tests/test_outcome_kpi_dryout_projection.py \
  tests/test_scorecard_realized_dryout.py \
  tests/test_solar_night_packet.py \
  tests/test_mcp_semantic_dependency_lifecycle.py \
  tests/test_mqtt_fanout.py \
  tests/test_no_hosted_runner_workflows.py \
  tests/test_planner_graph_contract.py \
  tests/test_planner_memory_ingest.py \
  tests/test_planner_runtime_db_boundary.py \
  tests/test_six_runtime_role_bootstrap.py \
  tests/test_policy_arbiter_migration.py \
  tests/test_policy_arbiter_worker.py \
  tests/test_policy_delivery_worker.py \
  tests/test_prometheus_rule_source_guard.py \
  tests/test_policy_writer_demotion.py \
  tests/test_prepare_component_prefix_replay.py \
  tests/test_prepare_experiment_v2_shadow.py \
  tests/test_prod_release_pins.py \
  tests/test_psql_verdify_backend.py \
  tests/test_publish_site_content_guard.py \
  tests/test_public_output_generators.py \
  tests/test_public_output_guard.py \
  tests/test_public_output_policy.py \
  tests/test_public_output_remediation.py \
  tests/test_public_zone_renderer.py \
  tests/test_release_dockerfile_base_pins.py \
  tests/test_route_only_crop_band.py \
  tests/test_route_only_crop_band_reader.py \
  tests/test_runtime_role_cutover_manifests.py \
  tests/test_service_restart_drift_guard.py \
  tests/test_setpoint_server_db_backend.py \
  tests/test_site_content_refresh.py \
  tests/test_slack_config.py \
  tests/test_slack_ops.py \
  tests/test_soil_dryout_alert.py \
  tests/test_solar_band_anchors.py \
  tests/test_solar_constants_check.py \
  tests/test_tempest_sync.py \
  tests/test_twin_agreement_report.py \
  tests/test_twin_asof_migration.py \
  tests/test_twin_live_driver.py \
  tests/test_verdify_traefik_placement.py \
  tests/test_verify_component_proof_packet.py \
  tests/test_writer_lease_fence.py

step "migration rollback safety classification"
$PY scripts/check_migration_rollback_safety.py

step "grafana dashboard CMs match JSON sources (#392)"
$PY scripts/gen-grafana-dashboard-cms.py --check

step "solar site constants SSOT guard (#393)"
$PY scripts/check-solar-constants.py

step "config-revision annotations match verdify-config sources (#587)"
bash scripts/gen-config-revision.sh --check

step "policy consumer manifest drift (Lane E, #586)"
$PY scripts/gen-policy-consumer-manifest.py --check

step "firmware policy engine native tests + §8.10 recovery-image proof (#586)"
# Tranche 2 (#586): the policy engine and its journal are on the control path
# of every consumer read, and the recovery image must provably not resume or
# actuate an experiment. Both suites are small native binaries (< 5 s).
if command -v g++ >/dev/null; then
  make test-policy-engine test-policy-recovery
else
  echo "SKIP: g++ not available on this host (required in the CI image)"
fi

step "twin follower source compiles (the twin image's exact build, #587)"
# The firmware-twin component now runs the pre-baked twin image (twin/Dockerfile
# builds from these CANONICAL sources — the vendored src/ copies are gone), so
# syntax-check the exact -DREPLAY_EMIT_STREAM compile the image performs.
if command -v g++ >/dev/null; then
  g++ -std=c++17 -fsyntax-only -DREPLAY_EMIT_STREAM \
    -Ifirmware/lib \
    firmware/test/replay_emit.cpp
else
  echo "SKIP: g++ not available on this host (required in the CI image)"
fi

step "prod overlay renders"
if command -v kustomize >/dev/null; then
  kustomize build deploy/k8s/overlays/prod > /dev/null
elif command -v kubectl >/dev/null; then
  kubectl kustomize deploy/k8s/overlays/prod > /dev/null
else
  echo "SKIP: no kustomize/kubectl on this host (required in the CI image)"
fi

step "Prometheus rule-file delivery guard (#563)"
$PY scripts/check-prometheus-rule-source.py

# ── Diff-scoped gates (merge-base semantics from the retired PR workflows) ──
if [ -n "${CI_BASE_REF:-}" ]; then
  BASE=$(git merge-base "${CI_BASE_REF}" HEAD)

  step "no-new-fire-and-forget (rule 6, num_* + sw_*) vs ${BASE}"
  NEW_IDS=$(git diff "$BASE" HEAD -- firmware/greenhouse/tunables.yaml 2>/dev/null \
    | grep -oE '^\+[[:space:]]+id:[[:space:]]+(num|sw)_[a-z0-9_]+' \
    | sed -E 's/.*id:[[:space:]]+(num|sw)_//' | sort -u || true)
  MISSING=""
  for id in $NEW_IDS; do
    grep -qE "id: cfg_(sw_)?${id}\b" firmware/greenhouse/sensors.yaml || MISSING="$MISSING $id"
  done
  [ -z "$MISSING" ] || { echo "New tunables without cfg_* readback:$MISSING" >&2; exit 1; }

  step "service-restart drift guard (rule 7, schema -> runtime) vs ${BASE}"
  # #391: the retired ci.yml job grepped the bare word 'service' and
  # false-passed on ~every PR body. The structural contract lives in the guard.
  bash scripts/check-service-restart-drift.sh "$BASE" HEAD

  step "firmware replay-diff trigger check vs ${BASE}"
  CHANGED=$(git diff --name-only "$BASE" HEAD -- 'firmware/lib/*.h' 'firmware/lib/*.cpp' \
    firmware/greenhouse/controls.yaml firmware/greenhouse/tunables.yaml firmware/greenhouse/globals.yaml)
  if [ -n "$CHANGED" ]; then
    THRESHOLD_PCT="${THRESHOLD_PCT:-0}" bash scripts/firmware-replay-diff.sh "$BASE" HEAD
    if git diff --name-only "$BASE" HEAD -- firmware/lib/greenhouse_solar.h | grep -q .; then
      REPLAY_EMIT_BAND_DERIVE=1 THRESHOLD_PCT="${BAND_THRESHOLD_PCT:-0}" \
        bash scripts/firmware-replay-diff.sh "$BASE" HEAD
    fi
  else
    echo "no firmware-logic diff; replay gates not required"
  fi
fi

if [ "$(uname -s)" = Linux ]; then
  printf '\nALL GATES GREEN\n'
else
  printf '\nHOST GATES GREEN — native Linux publication qualification remains required\n'
fi
