from pathlib import Path
import ast,copy,datetime,hashlib,json,re
B=Path('/private/tmp/verdify-daytime-consumer-20261018')
D=B/'platform/evidence-selection';D.mkdir(exist_ok=False)
helper=Path('/private/tmp/verdify-package-daytime-consumer-evidence-v1.py')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(helper)=='675c713d10a35f7fd57a967d4656338ce7af38b654f7f7cb13e33267043d5e49'
policy=json.loads((B/'control/packaging/selection.draft.json').read_text())
newknown=['candidate-readback.json','check-hermes-idle-health.py','check-idle-ledger-pilot.py','consumer-input-oct04.json','consumer-input-oct16.json','dispatch-rollout.py','final-planning-draft','idle-health-pilot','idle-ledger-pilot','mcp-promotion-source.json','prepare-release-source.py','release-ci','release-ci-discovery.json','render-after','rollout','source-ci-verified.json','verify-validation-ci.py']
for name in newknown:assert (B/name).exists() and not (B/name).is_symlink(),name
policy['include']=sorted(set(policy['include'])|set(newknown))
policy['required_files']=sorted(set(policy['required_files'])|{'source-ci-verified.json','candidate-readback.json','mcp-promotion-source.json','render-after/render.json','rollout/application-before.json','rollout/application-immediate.json','rollout/prepared/plan.json','rollout/prepared/patch.json','control/runtime-readback.py','platform/runtime-reader-independent-source-review.json'})
for name in policy['required_files']:assert (B/name).is_file() and not (B/name).is_symlink(),name
source=json.loads((B/'source-ci-verified.json').read_text());assert source['status']=='SOURCE_GATE_FIVE_BUILDS_AND_PIN_PUBLISHER_VERIFIED'
assert source['workflow_uid']=='f2083616-e793-4994-bd3b-9a48b1fbb376' and source['source_revision']=='b814f35e228fcb35c11593c47ea1e021e5fd73de'
release=json.loads((B/'release-ci-discovery.json').read_text());wm=release['metadata']
assert (wm['name'],wm['namespace'],wm['uid'])==('verdify-platform-ci-bq2rq','agent-fleet-ci','ec8026c4-6986-4443-8559-c1931b4c754a')
assert next(x['value'] for x in release['spec']['arguments']['parameters'] if x['name']=='revision')=='e545380a23129eb1830e9d6d804334f46f8fdcfe'
policy['workflow_identities'].append({k:wm[k] for k in ['name','namespace','uid']})
policy['workflow_identity_evidence']=[policy['workflow_identity_evidence'],{'path':'release-ci-discovery.json','sha256':sha(B/'release-ci-discovery.json')}]
policy['status']='draft_not_ready'
policy['pending_before_execution']=[
 'Wait for terminal release CI and actual rollout/runtime/consumer results. Retain every failed or uncertain attempt alongside any separate reconciliation; no original result is relabelled.',
 'Add exact completion receipt paths and their whole narrowly scoped attempt directories from completion-bindings.template.json after ROOT has verified them. Do not invent paths, outputs, success or a natural cycle.',
 'Add final database/source-identity and graph/publication custody when it exists; bind any later task-owned Workflow by actual retained namespace/name/UID evidence before inclusion. Unknown Workflow/CI-Pod objects must remain refused.',
 'Review actual final selected paths, exact per-file/total/member bounds and credential-pattern outcomes before setting ready_for_packaging. No automatic limit/credential waiver; no Secret values or raw estate Nodes/metrics.',
 'Existing helper675c713d excludes initial/nodes.json, initial/metrics.json, platform/check-root and platform/iris-inventory-check-root including all descendants before read. Keep those exclusions and all original evidence.',
 'No actual packaging is authorized/performed by this draft. ROOT separately authorizes execution after complete selection review; publication authorization and acceptance remain separate.'
]
(D/'selection.final-draft.json').write_text(json.dumps(policy,indent=2,sort_keys=True)+'\n')
completion={'schema':'daytime-consumer-evidence-completion-bindings-template/v1','status':'UNBOUND_DO_NOT_PACKAGE','taskbase':str(B),'binding_fields':['path','sha256','status_observed','reviewed_by_root','attempt_directories_to_include'],'required_roles':{k:None for k in ['release_ci_terminal','exact_three_resource_rollout_terminal','runtime_readback','consumer_oct04_terminal','consumer_oct16_terminal','final_database_identity_readback','final_native_graph_conformance','final_public_report_or_checkpoint']},'rules':['Fill only from actual retained receipt files; no placeholder counts as evidence.','Select whole exact task attempt directories, including failed/refused originals and complete retained logs, not just successful result JSON.','Unknown/new Workflow identities need a separate actual task receipt binding; never add foreign/broad discovery to make the scanner pass.','A terminal failed/incomplete consumer result can be retained truthfully; success, issue closure and natural-use acceptance are not packager decisions.','Copy these exact bound receipt paths into required_files and their reviewed attempt paths into include before final policy review; preserve all existing entries and hard exclusions.']}
(D/'completion-bindings.template.json').write_text(json.dumps(completion,indent=2)+'\n')
constants={}
for n in ast.parse(helper.read_text()).body:
 if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name):
  try:constants[n.targets[0].id]=ast.literal_eval(n.value)
  except (TypeError,ValueError):pass
ref=json.loads(Path('/private/tmp/verdify-daytime-consumer-dsn-reference-review-v1.json').read_text());wanted={x['match_sha256']:x['match_bytes'] for x in ref['accepted_matches']}
render_checks=[]
for rel in ['render-before/render.json','render-after/render.json']:
 raw=(B/rel).read_bytes();observed={hashlib.sha256(m.group(0)).hexdigest():len(m.group(0)) for m in re.finditer(constants['PATTERNS']['dsn_with_password'],raw)}
 assert observed==wanted
 render_checks.append({'path':rel,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'complete_match_hashes':sorted(observed),'exact_same_five_nonliteral_source_expression_matches':True})
review={'schema':'daytime-final-selection-preparation-review/v1','created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PREPARED_CURRENT_FILES_TERMINAL_COMPLETIONS_PENDING','helper_sha256':sha(helper),'selection_sha256':sha(D/'selection.final-draft.json'),'completion_template_sha256':sha(D/'completion-bindings.template.json'),'known_workflow_identities':policy['workflow_identities'],'source_ci_verified_receipt_sha256':sha(B/'source-ci-verified.json'),'release_discovery_sha256':sha(B/'release-ci-discovery.json'),'dsn_source_review_sha256':sha(Path('/private/tmp/verdify-daytime-consumer-dsn-reference-review-v1.json')),'render_dsn_provenance':render_checks,'public_metadata_hash_exceptions':[],'public_metadata_scope':'No new exception requested or added. Existing exact five public DSN-expression hashes and exact public reference env names are unchanged. This is a two-owning-render provenance check, not a complete selected-evidence credential scan. Any later _SHA256 metadata exception still needs the existing exact-file/value/review binding.','hard_exclusions':constants['EXCLUDED'],'current_explicit_include_roots':len(policy['include']),'current_required_files':len(policy['required_files']),'all_current_required_paths_exist_regular_not_symlink':True,'selected_tree_walk_or_scan_performed':False,'packager_invoked':False,'native_calls':0,'source_git_github_writes':0,'next':'ROOT fills completion bindings from actual verified terminal custody, reviews final exact selection/identities/size and credential scans, then alone invokes unchanged helper. This draft remains deliberately rejected by the helper.'}
(D/'preparation-review.json').write_text(json.dumps(review,indent=2,sort_keys=True)+'\n')
(D/'README.md').write_text('''# Final evidence selection — prepared, not ready to package

Use `selection.final-draft.json` as the explicit successor of Control's original draft. It includes the actual source-CI terminal receipt, candidate/promotion/render-after custody, the submitted rollout and release-CI collectors, all prepared readers and original failures. No actual runtime or consumer success is invented.

The only known Workflow identities are source `bgf2f` / `f2083616-e793-4994-bd3b-9a48b1fbb376` and release `bq2rq` / `ec8026c4-6986-4443-8559-c1931b4c754a`, both bound to retained native metadata. Later report Workflow custody needs its own actual identity binding before it can be included.

ROOT fills `completion-bindings.template.json` only after actual terminal receipts exist, then includes each exact receipt and narrowly scoped attempt directory (including original failures and logs). Keep the policy `draft_not_ready` until that review is complete. The unchanged helper rejects it now.

The public before/after renders contain exactly the same five reviewed nonliteral DSN-expression match hashes. No generic DSN, variable or metadata waiver was added. This narrow provenance comparison is not a full credential scan of final selected evidence. The packager's original Secret/credential/ownerReference/archive/size guards remain unchanged, as do its raw Nodes/metrics and fixture-tree exclusions.

No packaging, publication, native action, Git or GitHub write was performed. Runtime, consumer, final database and final native graph evidence remain ROOT-owned completion bindings.
''')
print(json.dumps({'directory':str(D),'selection_sha256':sha(D/'selection.final-draft.json'),'review_sha256':sha(D/'preparation-review.json'),'completion_template_sha256':sha(D/'completion-bindings.template.json'),'known_workflows':len(policy['workflow_identities']),'include_roots':len(policy['include']),'required_files':len(policy['required_files'])},indent=2))
