from pathlib import Path
import ast,hashlib,json,re,datetime
B=Path('/private/tmp/verdify-daytime-consumer-20261018')
P=Path('/private/tmp/verdify-package-daytime-consumer-evidence-v1.py')
old=Path('/private/tmp/verdify-package-getter277-evidence-v3.py')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def assigned(p):
 return {n.targets[0].id:n.value for n in ast.parse(p.read_text()).body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)}
newc,oldc=assigned(P),assigned(old)
for k in ['PATTERNS','MAX_FILE','MAX_TOTAL','MAX_EXPANDED','MAX_MEMBERS','MAX_DEPTH','PUBLIC_REFERENCES','DSN_REFERENCE_MATCHES']:
 assert ast.dump(newc[k],include_attributes=False)==ast.dump(oldc[k],include_attributes=False)
review=Path('/private/tmp/verdify-daytime-consumer-dsn-reference-review-v1.json')
r=json.loads(review.read_text());render=B/'render-before/render.json';raw=render.read_bytes()
assert sha(render)==r['source_sha256']==ast.literal_eval(newc['DSN_REFERENCE_SOURCE_SHA256'])
assert len(raw)==r['source_bytes']
actual={hashlib.sha256(m.group(0)).hexdigest():len(m.group(0)) for m in re.finditer(ast.literal_eval(newc['PATTERNS'])['dsn_with_password'],raw)}
expected={m['match_sha256']:m['match_bytes'] for m in r['accepted_matches']}
assert actual==expected
oldreview=json.loads(Path('/private/tmp/verdify-getter277-dsn-reference-review-v2.json').read_text())
assert {x['match_sha256']:x['match_bytes'] for x in oldreview['accepted_matches']}==expected
plan=B/'control/packaging/source-review-plan-v1.json';pol=B/'control/packaging/selection.draft.json'
for p,h in json.loads(plan.read_text())['files'].items():assert sha(Path(p))==h
policy=json.loads(pol.read_text());assert policy['status']=='draft_not_ready';assert len(policy['workflow_identities'])==1
w=policy['workflow_identities'][0]; evidence=policy['workflow_identity_evidence'];wp=B/evidence['path'];assert sha(wp)==evidence['sha256']
wm=json.loads(wp.read_text())['metadata'];assert all(wm[k]==w[k] for k in ['name','namespace','uid'])
receipt={'schema':'daytime-consumer-packager-independent-source-review/v1','checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'CLEAR_SOURCE_ONLY_DRAFT_SELECTION_NOT_READY','helper_sha256':sha(P),'preserved_predecessor_sha256':sha(old),'selection_sha256':sha(pol),'review_plan_sha256':sha(plan),'dsn_reference_review_sha256':sha(review),'render_provenance_sha256':sha(render),'exact_dsn_match_hashes':sorted(actual),'exact_match_bytes_equal_prior_review':True,'all_pattern_definitions_and_resource_bounds_unchanged':True,'exact_delta':['taskbase/schema/provenance pin changes','four task exclusions','ancestor exclusion check covers descendants before stat/read'],'workflow_policy_bound_to_actual_task_receipt':w,'guards_reviewed':['Exact five complete DSN matches, no generic variable or credential waiver','Unchanged structured Secret/env/foreign Workflow/CI-Pod ownerReference guards','Unchanged nested archive regular-member/depth/expanded-byte bounds and deterministic full readback','Selection remains draft_not_ready; final terminal receipts/identity policy and selected-only broader scan required before actual packaging','Raw initial nodes/metrics and both local fixture roots/descendants excluded before reading'],'reused_guard_tests_reported':24,'tests_reexecuted_by_reviewer':False,'actual_package_or_selected_task_scan_performed':False,'native_calls':0,'source_edits':False,'blockers':[]}
out=B/'platform/packager-v1-independent-source-review.json';out.write_text(json.dumps(receipt,indent=2)+'\n');print('packager_receipt',str(out),sha(out))
v1=B/'control/deploy-plan/emit.py';v2=B/'control/deploy-plan-v2/emit.py'; a1=ast.parse(v1.read_text());a2=ast.parse(v2.read_text());f1={n.name:ast.dump(n,include_attributes=False) for n in a1.body if isinstance(n,ast.FunctionDef)};f2={n.name:ast.dump(n,include_attributes=False) for n in a2.body if isinstance(n,ast.FunctionDef)}
assert set(f1)==set(f2);changed=[k for k in f1 if f1[k]!=f2[k]];assert set(changed)=={'validate_idle','main'}
assert sha(v1)=='7cec5b28f50513994c66a2ce19ea009504fd1a0ce0effcf03b44a54bfa7a3dbf'
assert (B/'control/deploy-plan/idle-ledger.sql').read_bytes()==(B/'control/deploy-plan-v2/idle-ledger.sql').read_bytes()
receipt={'schema':'daytime-consumer-deploy-v2-independent-source-review/v1','checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'CLEAR_SOURCE_ONLY','helper_sha256':sha(v2),'preserved_v1_sha256':sha(v1),'readme_sha256':sha(B/'control/deploy-plan-v2/README.md'),'idle_ledger_sha256':sha(B/'control/deploy-plan-v2/idle-ledger.sql'),'changed_functions':changed,'unchanged_render_patch_and_sql_guards':True,'finding':'Fresh actual health HTTP200 is distinct from persistent startup status; updated_at and active_agents are retained as non-authoritative and do not prove current idleness. Bounded fresh complete ledger plus actual200 terminal responses for every known unresolved run still refuse known activity. No exhaustive-idle or dispatch-freeze claim.','outer_responsibilities':['ROOT binds normalized facts to original current Pod/HTTP/SQL/status receipts and exact source/image qualification.','ROOT checks30s plan expiry and performs one CAS patch, retaining failure without automatic retry.','Known-run observation cannot exclude older/unrecorded/new incoming activity; stop for newly observed run before dispatch.'],'tests_reexecuted_by_reviewer':False,'patch_emitted':False,'native_calls':0,'source_edits':False,'blockers':[]}
out=B/'platform/deploy-v2-independent-source-review.json';out.write_text(json.dumps(receipt,indent=2)+'\n');print('deploy_receipt',str(out),sha(out))
