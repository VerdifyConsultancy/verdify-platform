# Final evidence selection — prepared, not ready to package

Use `selection.final-draft.json` as the explicit successor of Control's original draft. It includes the actual source-CI terminal receipt, candidate/promotion/render-after custody, the submitted rollout and release-CI collectors, all prepared readers and original failures. No actual runtime or consumer success is invented.

The only known Workflow identities are source `bgf2f` / `f2083616-e793-4994-bd3b-9a48b1fbb376` and release `bq2rq` / `ec8026c4-6986-4443-8559-c1931b4c754a`, both bound to retained native metadata. Later report Workflow custody needs its own actual identity binding before it can be included.

ROOT fills `completion-bindings.template.json` only after actual terminal receipts exist, then includes each exact receipt and narrowly scoped attempt directory (including original failures and logs). Keep the policy `draft_not_ready` until that review is complete. The unchanged helper rejects it now.

The public before/after renders contain exactly the same five reviewed nonliteral DSN-expression match hashes. No generic DSN, variable or metadata waiver was added. This narrow provenance comparison is not a full credential scan of final selected evidence. The packager's original Secret/credential/ownerReference/archive/size guards remain unchanged, as do its raw Nodes/metrics and fixture-tree exclusions.

No packaging, publication, native action, Git or GitHub write was performed. Runtime, consumer, final database and final native graph evidence remain ROOT-owned completion bindings.
