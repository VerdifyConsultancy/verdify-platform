import os,json,urllib.request,urllib.error,hashlib,pathlib,time
start=time.monotonic();base='http://127.0.0.1:'+os.environ.get('MCP_HTTP_PORT','8000');token=os.environ['VERDIFY_MCP_TOKEN_IRIS']
def request(path,body=None,auth=True):
 headers={'Accept':'application/json, text/event-stream'}
 if auth:headers['Authorization']='Bearer '+token
 data=None if body is None else json.dumps(body).encode()
 if data is not None:headers['Content-Type']='application/json'
 try:
  with urllib.request.urlopen(urllib.request.Request(base+path,data=data,headers=headers),timeout=5) as r:code=r.status;raw=r.read(262145)
 except urllib.error.HTTPError as e:code=e.code;raw=e.read(262145)
 assert len(raw)<=262144
 try:v=json.loads(raw)
 except ValueError:
  parts=[json.loads(line[6:]) for line in raw.decode().splitlines() if line.startswith('data: ')];assert len(parts)==1;v=parts[0]
 return code,v
readycode,ready=request('/readyz');assert readycode==200
initcode,init=request('/mcp',{'jsonrpc':'2.0','id':1,'method':'initialize','params':{'protocolVersion':'2025-03-26','capabilities':{},'clientInfo':{'name':'verdify-release-readonly','version':'1'}}});assert initcode==200 and 'result' in init
code,listed=request('/mcp',{'jsonrpc':'2.0','id':2,'method':'tools/list','params':{}});assert code==200;tools=sorted(x['name'] for x in listed['result']['tools']);assert len(tools)==23 and 'outcome_kpi' not in tools
code,denied=request('/mcp',{'jsonrpc':'2.0','id':3,'method':'tools/call','params':{'name':'outcome_kpi','arguments':{'target_date':'2026-10-16'}}});assert code==200 and denied['result']['isError'] is True;text=' '.join(x.get('text','') for x in denied['result'].get('content',[]));assert 'unauthorized' in text and 'iris' in text
print(json.dumps({'status':'PASSED','readyz':ready,'ready_http':readycode,'authenticated_iris_initialize':True,'iris_tools':tools,'outcome_kpi_iris_denied':True,'denial_response':denied,'configured_audience_names':[k.removeprefix('VERDIFY_MCP_TOKEN_').lower() for k,v in os.environ.items() if k.startswith('VERDIFY_MCP_TOKEN_') and v],'baked_git_sha':os.environ.get('VERDIFY_GIT_SHA'),'server_sha256':hashlib.sha256(pathlib.Path('/app/mcp/server.py').read_bytes()).hexdigest(),'positive_admin_dispatch_verified':False,'elapsed_seconds':time.monotonic()-start}))
