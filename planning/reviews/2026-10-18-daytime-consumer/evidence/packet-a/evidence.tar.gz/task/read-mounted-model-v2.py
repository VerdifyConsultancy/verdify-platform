import json,subprocess,pathlib,datetime
b=pathlib.Path('/private/tmp/verdify-daytime-consumer-20261018/iris-source/model-v2');b.mkdir(exist_ok=False)
driver='''import json,pathlib,hashlib,os,yaml
out=[]
for path in ['/etc/verdify/hermes-config/config.yaml','/opt/data/config.yaml','/opt/data/.hermes/config.yaml']:
 p=pathlib.Path(path)
 if not p.is_file():continue
 raw=p.read_bytes();assert len(raw)<200000;d=yaml.safe_load(raw);m=d.get('model',{});assert isinstance(m,dict);out.append({'path':path,'sha256':hashlib.sha256(raw).hexdigest(),'model':{k:m[k] for k in ['default','provider','base_url'] if k in m},'reasoning_effort':d.get('agent',{}).get('reasoning_effort')})
assert out
print(json.dumps({'configs':out,'HERMES_HOME':os.environ.get('HERMES_HOME'),'model_env_overrides_present':[k for k in ['HERMES_MODEL','OPENAI_MODEL','HERMES_PROVIDER','OPENAI_BASE_URL','HERMES_REASONING_EFFORT'] if os.environ.get(k)]}))
''';(b/'mounted-model-driver.py').write_text(driver);k=['kubectl','--kubeconfig','/Users/jason/.kube/config','--context','vallery','--request-timeout=20s','-n','verdify-prod'];j=json.loads(subprocess.check_output(k+['get','pod','verdify-hermes-iris-fcfb7dd98-7skpf','-o','json'],timeout=25));assert j['metadata']['uid']=='fc60d2ed-f4ba-4db1-bccc-59dcf3dec378';r=subprocess.run(k+['exec','-i',j['metadata']['name'],'-c','hermes-iris','--','python3','-'],input=driver.encode(),capture_output=True,timeout=25);(b/'mounted-model.stdout').write_bytes(r.stdout);(b/'mounted-model.stderr').write_bytes(r.stderr);assert r.returncode==0;v=json.loads(r.stdout);assert all(c['model']=={'default':'gpt-5.6-luna','provider':'custom','base_url':'https://api.openai.com/v1'} and c['reasoning_effort']=='xhigh' for c in v['configs']);assert not v['model_env_overrides_present'];print(json.dumps(v))
