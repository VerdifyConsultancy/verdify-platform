\set ON_ERROR_STOP on
\pset format unaligned
\pset tuples_only on
BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY;
SET LOCAL search_path=pg_catalog,public,pg_temp;
SET LOCAL statement_timeout='2s';
SET LOCAL lock_timeout='500ms';
SET LOCAL idle_in_transaction_session_timeout='5s';
SET LOCAL max_parallel_workers_per_gather=0;
SET LOCAL work_mem='4MB';
SET LOCAL temp_file_limit='16MB';
WITH recent AS MATERIALIZED (
 SELECT id,delivered_at,status,terminal_at,hermes_run_id
 FROM public.plan_delivery_log
 WHERE delivered_at>=now()-interval '180 minutes'
 ORDER BY delivered_at DESC,id DESC LIMIT 201
)
SELECT json_build_object('kind','hermes_recent_delivery_readback','captured_at',clock_timestamp(),
 'database',current_database(),'current_user',current_user,'postmaster',pg_postmaster_start_time(),
 'readonly',current_setting('transaction_read_only')='on','window_minutes',180,
 'complete',(SELECT count(*)<=200 FROM recent),'rows_examined',(SELECT count(*) FROM recent),
 'pending_without_run_id',(SELECT count(*) FROM recent WHERE terminal_at IS NULL AND NULLIF(hermes_run_id,'') IS NULL),
 'unresolved_run_ids',COALESCE((SELECT json_agg(DISTINCT hermes_run_id) FROM recent
    WHERE terminal_at IS NULL AND NULLIF(hermes_run_id,'') IS NOT NULL),'[]'::json),
 'recent_rows',COALESCE((SELECT json_agg(row_to_json(r)) FROM recent r),'[]'::json),
 'limitation','Bounded recent delivery ledger is not an exhaustive gateway run list or dispatch freeze; pair with fresh health/detailed and exact unresolved run-status GETs.') ;
ROLLBACK;
