# Post-rollout runtime custody

Source-only preparation. ROOT runs this once after the separately verified exact three-resource Argo operation reaches its intended release revision. It does not submit an Argo operation, create a Job, call a provider, read a Secret object, or call scorecard. The later bounded consumer cases retain their one actual scorecard read per date.

The required CLI inputs are the actual `source-ci-verified.json` path and its reviewed SHA256, the actual 40-character release commit, an unchanged source worktree holding the pinned supported smoke sources, an existing kubeconfig, and a new output directory. No future image digest or release placeholder is embedded: the MCP digest is read from the qualified b814 build receipt. The unchanged API digest is derived from the hash-bound initial Deployment; its reviewed source remains cb21fd3d3295aa8d7183f70b0d5ac82405410b1a.

```text
python3 control/runtime-readback.py --help
```

The helper seals its inputs and source before the first native call. It checks all15 Deployment UIDs, all13 unrelated Deployment specs, and exactly the MCP image / Hermes inventory-revision differences. It resolves MCP/Hermes Pods through their explicit owning Deployment/ReplicaSet identities and requires two new MCP UIDs and one new Hermes UID, all ready with zero restarts and successful init states. The existing DB Pod, two API Pods, and ingestor Pod retain their exact identities and container states. No watchdog/CronJob prefix selector is used in these comparisons.

Both MCP replicas must match baked b814 and the three exact changed module hashes, report only Iris+observer audiences, return the exact23 Iris tools and an optional boolean `include_realized_dryout` defaulting false, and deny Iris dispatch of the admin-only outcome tool. This denial is the only tools/call request. The script does not make a positive admin call or any scorecard/provider/action request.

The two public ConfigMaps are compared by their full5+2 data hashes. Hermes readback hashes only the three source-owned home files, the effective/mounted profile, and the mounted readiness source. The main container does not mount the inventory ConfigMap. The seed-config terminal state and complete bounded seed log must confirm the exact three copied hashes, preserved learned SKILL.md, and profile copy. Learned SKILL.md, historical runs, provider keys and credential files are not read.

The unchanged supported `scripts/k3s-smoke.sh` runs once with the existing kubeconfig, explicit reviewed API identity, and10-second per-check bounds. Its expected result is9 green checks. The separate supported device-monitor runs once and requires exactly one existing ESP32 socket; it opens no device connection. That existing monitor intentionally observes every Running Pod in the namespace to find unexpected writers; the wrapper does not duplicate or broaden its logic.

Bounds are25seconds per metadata step,35seconds per child exec (MCP child25seconds total),120seconds smoke,180seconds device-monitor,480seconds overall, and2MiB per stdout capture. Commands run without shell interpolation, with fixed Kubernetes context `vallery`. The kubeconfig's current context is also checked because the unchanged smoke helper uses it. Public metadata/driver stdout and partial failure stdout are retained; raw CLI stderr and exception values are not published or stored, only byte count/SHA and fixed failure codes. No phase is automatically retried. A fresh output-directory check prevents replacing old custody.

Repeat metadata capture after smoke checks binds the same successor Pod/container identities and critical unchanged workloads. Success is a bounded runtime/source/readiness/single-writer result. Exact Argo resource-operation acceptance belongs to ROOT's separate dispatcher receipt. It does not establish natural-cycle consumption, a live Hermes registry/PID schema inspection, causal efficacy, crop safety, or complete daytime coverage.
