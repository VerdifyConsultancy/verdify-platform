"""Existing Iris authentication; metadata/tools/schema and denied admin call only."""
import hashlib,json,os,pathlib,signal,sys,time,urllib.error,urllib.request
EXPECTED_SOURCE='b814f35e228fcb35c11593c47ea1e021e5fd73de'
MODULES={'/app/mcp/server.py':'d8926ec1bca28c10cd0109b62238b395a3d233158879e51dbb073acdc7372a9f','/app/verdify_schemas/realized_dryout.py':'7364d30ddea52fc5d5588f174b95de67c70a966224a5746c33f1838ba7586479','/app/verdify_schemas/mcp_responses.py':'edccf0a7740421aaeaa9b402e446c769fc1cd4b3fbfdc646e13cb83d1e3b82ee'}
TOOLS=sorted(['climate','scorecard','equipment_state','forecast','get_setpoints','plan_status','history','alerts','slack_ops','lessons','lessons_search','knowledge_search','crops','observations','topology','position_current','crop_history','crop_lifecycle','set_plan','set_tunable','acknowledge_trigger','plan_evaluate','lessons_manage'])
class Refusal(Exception):pass
def need(ok,code):
 if not ok:raise Refusal(code)
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*a,**kw):raise Refusal('redirect_refused')
def alarm(*_):raise Refusal('inner_deadline')
def run():
 signal.signal(signal.SIGALRM,alarm);signal.alarm(25);start=time.monotonic()
 need(os.environ.get('VERDIFY_GIT_SHA')==EXPECTED_SOURCE,'baked_source')
 observed={p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest() for p in MODULES};need(observed==MODULES,'module_hash')
 audiences=sorted(k.removeprefix('VERDIFY_MCP_TOKEN_').lower() for k,v in os.environ.items() if k.startswith('VERDIFY_MCP_TOKEN_') and v)
 need(audiences==['iris','observer'],'audience_config')
 token=os.environ['VERDIFY_MCP_TOKEN_IRIS'];need(bool(token),'iris_token_absent')
 opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())
 def request(path,body=None):
  headers={'Accept':'application/json, text/event-stream','Authorization':'Bearer '+token}
  data=None if body is None else json.dumps(body).encode()
  if data is not None:headers['Content-Type']='application/json'
  with opener.open(urllib.request.Request('http://127.0.0.1:8000'+path,data=data,headers=headers),timeout=5) as r:
   need(r.status==200,'http_not200');raw=r.read(262145);need(len(raw)<=262144,'response_cap')
  try:return json.loads(raw)
  except ValueError:
   parts=[json.loads(x[6:]) for x in raw.splitlines() if x.startswith(b'data: ')];need(len(parts)==1,'sse_shape');return parts[0]
 ready=request('/readyz');need(ready.get('auth_audiences_configured')==['iris','observer'],'ready_audiences')
 init=request('/mcp',{'jsonrpc':'2.0','id':1,'method':'initialize','params':{'protocolVersion':'2025-03-26','capabilities':{},'clientInfo':{'name':'verdify-daytime-runtime-readonly','version':'1'}}});need('result' in init,'initialize')
 listed=request('/mcp',{'jsonrpc':'2.0','id':2,'method':'tools/list','params':{}});ts=listed['result']['tools'];need(sorted(t['name'] for t in ts)==TOOLS,'exact_tool_inventory')
 score=[t for t in ts if t['name']=='scorecard'];need(len(score)==1,'scorecard_schema_count');schema=score[0]['inputSchema'];prop=schema['properties']['include_realized_dryout'];need(prop.get('type')=='boolean' and prop.get('default') is False and 'include_realized_dryout' not in schema.get('required',[]),'scorecard_optin_schema')
 denied=request('/mcp',{'jsonrpc':'2.0','id':3,'method':'tools/call','params':{'name':'outcome_kpi','arguments':{'target_date':'2026-10-16'}}});need(denied.get('result',{}).get('isError') is True,'admin_denial')
 text=' '.join(x.get('text','') for x in denied['result'].get('content',[]));need('unauthorized' in text and 'iris' in text,'admin_denial_semantics')
 signal.alarm(0)
 return {'status':'MCP_READONLY_RUNTIME_PASSED','source_sha':EXPECTED_SOURCE,'module_sha256':observed,'audiences':audiences,'iris_tools':TOOLS,'scorecard_schema':score[0],'ready_http_status':200,'iris_initialize':True,'outcome_kpi_iris_denied':True,'admin_configured':False,'actual_scorecard_calls':0,'provider_calls':0,'elapsed_seconds':time.monotonic()-start,'natural_cycle_verified':False,'existing_gateway_registry_introspected':False}
if __name__=='__main__':
 try:print(json.dumps(run(),sort_keys=True))
 except Exception as e:
  print(json.dumps({'status':'FAILED','code':str(e) if isinstance(e,Refusal) else type(e).__name__,'raw_error_values_retained':False}));sys.exit(1)
