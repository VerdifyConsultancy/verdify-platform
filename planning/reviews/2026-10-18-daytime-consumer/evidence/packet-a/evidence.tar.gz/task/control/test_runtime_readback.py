"""Small pure reader/refusal tests; native subprocess creation is forbidden."""
import copy,datetime as dt,importlib.util,json,pathlib,unittest
from unittest.mock import patch
BASE=pathlib.Path('/private/tmp/verdify-daytime-consumer-20261018');CONTROL=BASE/'control'
s=importlib.util.spec_from_file_location('runtime',CONTROL/'runtime-readback.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
class Readback(unittest.TestCase):
 def setUp(self):
  self.block=patch.object(m.subprocess,'Popen',side_effect=AssertionError('native forbidden'));self.block.start();self.addCleanup(self.block.stop)
  self.before=json.loads((BASE/'initial/deployments.json').read_bytes());self.pods=json.loads((BASE/'initial/pods.json').read_bytes())
 def successor(self):
  new=copy.deepcopy(self.before);by=m.by_name(new['items']);m.container(by['verdify-mcp'],'mcp')['image']='registry.vallery.net/verdifyconsultancy/verdify-mcp@sha256:'+'a'*64
  by['verdify-hermes-iris']['spec']['template']['metadata']['annotations']['verdify.io/iris-inventory-revision']=m.INVENTORY
  for name,n in [('verdify-mcp',2),('verdify-hermes-iris',1)]:
   by[name]['status'].update({k:n for k in ('replicas','updatedReplicas','readyReplicas','availableReplicas')});by[name]['status']['observedGeneration']=by[name]['metadata']['generation']
  return new
 def test_exact_two_specs_and_all_fifteen_uids(self):
  self.assertEqual(len(m.verify_deployments(self.before,self.successor(),'a'*64)),15)
 def test_unrelated_or_extra_deployment_rejected(self):
  for mode in ('replicas','image','uid','extra'):
   v=self.successor();x=m.by_name(v['items'])['verdify-ingestor']
   if mode=='replicas':x['spec']['replicas']=2
   elif mode=='image':m.container(x,'ingestor')['image']='unexpected'
   elif mode=='uid':x['metadata']['uid']='changed'
   else:v['items'].append(copy.deepcopy(v['items'][0]))
   with self.subTest(mode=mode),self.assertRaises(m.Refusal):m.verify_deployments(self.before,v,'a'*64)
 def test_mcp_extra_env_and_hermes_image_refused(self):
  for name,field in [('verdify-mcp','env'),('verdify-hermes-iris','image')]:
   v=self.successor();x=m.container(m.by_name(v['items'])[name],'mcp' if name.endswith('mcp') else 'hermes-iris')
   if field=='env':x['env'].append({'name':'CHANGED','value':'1'})
   else:x['image']='changed'
   with self.assertRaises(m.Refusal):m.verify_deployments(self.before,v,'a'*64)
 def test_incomplete_rollout_refused(self):
  v=self.successor();m.by_name(v['items'])['verdify-mcp']['status']['updatedReplicas']=1
  with self.assertRaises(m.Refusal):m.verify_deployments(self.before,v,'a'*64)
 def test_current_mcp_status_and_missing_or_restarted_container(self):
  p=copy.deepcopy(next(p for p in self.pods['items'] if p['metadata'].get('labels',{}).get('app.kubernetes.io/component')=='mcp'))
  m.pod_ready(p,'mcp',m.OLD_MCP)
  for change in ('empty','restart','deleting','laststate'):
   q=copy.deepcopy(p)
   if change=='empty':q['status']['containerStatuses']=[]
   elif change=='restart':q['status']['containerStatuses'][0]['restartCount']=1
   elif change=='deleting':q['metadata']['deletionTimestamp']='now'
   else:q['status']['containerStatuses'][0]['lastState']={'terminated':{'exitCode':1}}
   with self.subTest(change=change),self.assertRaises(m.Refusal):m.pod_ready(q,'mcp',m.OLD_MCP)
 def test_failed_seed_refused(self):
  p=copy.deepcopy(next(p for p in self.pods['items'] if p['metadata'].get('labels',{}).get('app.kubernetes.io/component')=='hermes-iris'))
  p['status']['containerStatuses'][0]['restartCount']=0;p['status']['containerStatuses'][0]['lastState']={}
  m.pod_ready(p,'hermes-iris',m.HERMES)
  p['status']['initContainerStatuses'][0]['state']['terminated']['exitCode']=1
  with self.assertRaises(m.Refusal):m.pod_ready(p,'hermes-iris',m.HERMES)
 def test_critical_state_fingerprint_detects_restart_and_container_replacement(self):
  p=next(p for p in self.pods['items'] if p['metadata']['name']=='verdify-db-0');a=m.state_fingerprint(p)
  for field,value in [('restartCount',1),('containerID','different')]:
   q=copy.deepcopy(p);q['status']['containerStatuses'][0][field]=value;self.assertNotEqual(a,m.state_fingerprint(q))
 def test_smoke_source_and_expected_module_hashes(self):
  e=json.loads((CONTROL/'runtime-expectations.json').read_bytes());root=pathlib.Path('/private/tmp/verdify-daytime-consumer-source-20261018')
  for n,h in e['smoke_files'].items():self.assertEqual(m.sha((root/n).read_bytes()),h)
  self.assertEqual(len(e['hermes_cm']['verdify-iris-inventory']),5);self.assertEqual(len(e['hermes_cm']['verdify-hermes-iris-config']),2)
  self.assertFalse(any(p.endswith('/SKILL.md') for p in e['installed_hermes_files']))
 def test_native_drivers_have_no_service_import_or_scorecard_dispatch(self):
  import ast
  for name in ('runtime-mcp-readonly.py','runtime-hermes-readonly.py'):
   tree=ast.parse((CONTROL/name).read_text())
   modules={x.name for n in ast.walk(tree) if isinstance(n,ast.Import) for x in n.names};self.assertFalse(modules & {'mcp.server','planner_graph','ingestor','openai','asyncpg'})
  source=(CONTROL/'runtime-mcp-readonly.py').read_text();self.assertEqual(source.count("'method':'tools/call'"),1);self.assertIn("'name':'outcome_kpi'",source);self.assertNotIn("'name':'scorecard','arguments'",source)
if __name__=='__main__':unittest.main()
