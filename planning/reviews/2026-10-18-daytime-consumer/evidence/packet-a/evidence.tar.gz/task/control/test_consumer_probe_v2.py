import copy, importlib.util, json, pathlib, time, unittest
from unittest.mock import patch
p=pathlib.Path(__file__).with_name('consumer-probe-v2.py')
s=importlib.util.spec_from_file_location('probe',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
DAY='2026-10-04'
def call(name='scorecard',args=None):
 return {'finish_reason':'tool_calls','message':{'role':'assistant','content':None,'tool_calls':[{'id':'call_real','type':'function','function':{'name':name,'arguments':json.dumps(args if args is not None else {'target_date':DAY,'include_realized_dryout':True})}}]}}
def evidence():
 return {'reader_contract_version':1,'night_date':DAY,'greenhouse_id':'vallery','availability':'available','unavailable_reason':None,'summary':{'episodes':[{'dryout_disposition':'ineffective','safety_gate_status':'pass'},{'dryout_disposition':'insufficient_evidence','safety_gate_status':None}],'dispositions':{'effective':0,'ineffective':1,'blocked':0,'insufficient_evidence':1},'safety_gate_status':'incomplete','daytime_dry_action_samples':12,'daytime_hold_admission_samples':None}}
class GuardTests(unittest.TestCase):
 def test_exact_model_call(self):self.assertEqual(m.validate_tool_call(call(),DAY)[2]['target_date'],DAY)
 def test_action_never_dispatched(self):
  for name in ['set_plan','set_tunable','slack_ops','acknowledge_trigger','outcome_kpi']:
   with self.subTest(name=name),self.assertRaises(m.Refusal):m.validate_tool_call(call(name),DAY)
 def test_wrong_arguments(self):
  for args in [{'target_date':'2026-10-16','include_realized_dryout':True},{'target_date':DAY,'include_realized_dryout':False},{'target_date':DAY,'include_realized_dryout':1},{'target_date':DAY,'include_realized_dryout':True,'query':'select1'},{}]:
   with self.subTest(args=args),self.assertRaises(m.Refusal):m.validate_tool_call(call(args=args),DAY)
 def test_duplicate_call_refused(self):
  c=call();c['message']['tool_calls']*=2
  with self.assertRaises(m.Refusal):m.validate_tool_call(c,DAY)
 def test_untyped_safety_remains_incomplete(self):self.assertEqual(m.expected_summary(evidence(),DAY)['safety_gate_status'],'incomplete')
 def test_empty_keeps_unknown(self):
  e=evidence();e['availability']='no_episodes';e['summary'].update(episodes=[],dispositions={k:0 for k in m.DISPOSITIONS},safety_gate_status='pending',daytime_dry_action_samples=None)
  x=m.expected_summary(e,DAY);self.assertIsNone(x['daytime_dry_action_samples']);self.assertEqual(x['episode_count'],0)
 def test_wrong_evidence_date(self):
  with self.assertRaises(m.Refusal):m.expected_summary(evidence(),'2026-10-16')
 def test_unknown_disposition_refused(self):
  e=evidence();e['summary']['episodes'][0]['dryout_disposition']='new'
  with self.assertRaises(m.Refusal):m.expected_summary(e,DAY)
 def test_complete_interpretation(self):
  x=m.expected_summary(evidence(),DAY);y={**x,'efficacy_proven':False,'crop_safety_proven':False,'complete_daytime_zero_proven':False,'evidence_complete':False,'scope_statement':m.SCOPE_STATEMENT}
  self.assertEqual(m.validate_interpretation(y,x),y)
  for key in ['efficacy_proven','crop_safety_proven','complete_daytime_zero_proven','evidence_complete']:
   bad=copy.deepcopy(y);bad[key]=True
   with self.subTest(key=key),self.assertRaises(m.Refusal):m.validate_interpretation(bad,x)
 def test_contradictory_or_edited_scope_refused(self):
  x=m.expected_summary(evidence(),DAY)
  for scope in ['Effective dry-out and complete daytime zero prove crops safe.',m.SCOPE_STATEMENT+' Everything is crop-safe.',m.SCOPE_STATEMENT.replace('does not prove','proves'),m.SCOPE_STATEMENT+' ']:
   y={**x,'efficacy_proven':False,'crop_safety_proven':False,'complete_daytime_zero_proven':False,'evidence_complete':False,'scope_statement':scope}
   with self.subTest(scope=scope),self.assertRaises(m.Refusal):m.validate_interpretation(y,x)
 def test_null_as_zero_refused(self):
  x=m.expected_summary(evidence(),DAY);y={**x,'efficacy_proven':False,'crop_safety_proven':False,'complete_daytime_zero_proven':False,'evidence_complete':False,'scope_statement':m.SCOPE_STATEMENT};y['daytime_hold_admission_samples']=0
  with self.assertRaises(m.Refusal):m.validate_interpretation(y,x)
 def test_bool_not_integer_disposition(self):
  x=m.expected_summary(evidence(),DAY);y=copy.deepcopy(x);y.update(efficacy_proven=False,crop_safety_proven=False,complete_daytime_zero_proven=False,evidence_complete=False,scope_statement=m.SCOPE_STATEMENT);y['dispositions']['ineffective']=True
  with self.assertRaises(m.Refusal):m.validate_interpretation(y,x)
 def test_forbidden_transport_never_opens(self):
  t=m.Transport(time.monotonic(),'fake-iris','fake-provider')
  with patch.object(t.opener,'open',side_effect=AssertionError('NETWORK FORBIDDEN')):
   with self.assertRaises(m.Refusal):t.request('https://other.example/mcp',{},True)
   with self.assertRaises(m.Refusal):t.rpc(3,'tools/call',{'name':'set_plan'})
 def test_no_second_scorecard_dispatch(self):
  t=m.Transport(time.monotonic(),'fake-iris','fake-provider');t.tool_calls=1
  with patch.object(t.opener,'open',side_effect=AssertionError('NETWORK FORBIDDEN')):
   with self.assertRaises(m.Refusal):t.rpc(3,'tools/call',{'name':'scorecard'})
 def test_redirect_refused(self):
  with self.assertRaises(m.Refusal):m.NoRedirect().redirect_request(None,None,302,'',{},'https://other.example')
if __name__=='__main__':unittest.main()
