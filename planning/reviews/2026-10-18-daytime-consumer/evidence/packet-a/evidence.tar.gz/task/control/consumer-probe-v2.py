#!/usr/bin/env python3
"""One native, bounded Iris-context read qualification. No service/worker imports.
Inputs are a presealed JSON packet on stdin, passed by ROOT to the UID-bound MCP
container. Only fixed localhost MCP and official provider HTTPS are reachable.
No retries: any error retains the emitted phase records and fails this attempt.
"""
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import sys
import time
import urllib.error
import urllib.request

CAP = 262144
DEADLINE_SECONDS = 90
SOURCE_PATHS = ("/app/mcp/server.py", "/app/verdify_schemas/realized_dryout.py", "/app/verdify_schemas/mcp_responses.py")
PREAMBLE_SHA = "c82f764d8322059e38aa7c4edb924ab4089e214c8e096c976123d9adefaba199"
IRIS_SOURCE_SHA = "bf18a3e5cf8746803f1c5fe5ef7ce344a6e9b70b40b735d382aae83186f7b3f5"
IRIS_CONFIG_SHA = "51de00576417701fc4fed8fb03ec9a3f1bfbee5e4f5d057f25b763076c2a8b5f"
DISPOSITIONS = ("effective", "ineffective", "blocked", "insufficient_evidence")
SCOPE_STATEMENT = 'This read-only qualification does not prove natural-cycle use, complete daytime coverage, causal efficacy, or crop safety.'
LIMITS = {"whole_issue_acceptance": False, "natural_planner_cycle": False,
          "positive_admin_dispatch": False, "experiment_authority": False,
          "physical_crop_safety": False, "continuous_daytime_absence": False}


class Refusal(Exception):
    pass


def require(ok, code):
    if not ok:
        raise Refusal(code)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def encoded(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def emit(kind, **kwargs):
    print(json.dumps({"kind": kind, **kwargs}, sort_keys=True, allow_nan=False), flush=True)


def alarm(*_):
    raise Refusal("overall_deadline")


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *_args, **_kwargs):
        raise Refusal("redirect_refused")


class Transport:
    def __init__(self, start, iris_token, provider_key):
        self.start = start
        self.iris_token = iris_token
        self.provider_key = provider_key
        self.opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())
        self.model_calls = 0
        self.tool_calls = 0

    def request(self, url, payload, provider=False, seconds=5):
        require(url in ("http://127.0.0.1:8000/readyz", "http://127.0.0.1:8000/mcp",
                        "https://api.openai.com/v1/chat/completions"), "endpoint_not_allowed")
        require(provider == url.startswith("https://api.openai.com/"), "credential_destination")
        left = DEADLINE_SECONDS - (time.monotonic() - self.start)
        require(left > 0, "overall_deadline")
        headers = {"Accept": "application/json" if provider else "application/json, text/event-stream"}
        if url.endswith("/mcp"):
            headers["Authorization"] = "Bearer " + self.iris_token
        if provider:
            headers["Authorization"] = "Bearer " + self.provider_key
        data = None if payload is None else encoded(payload)
        if data is not None:
            require(len(data) <= CAP, "request_limit")
            headers["Content-Type"] = "application/json"
        try:
            with self.opener.open(urllib.request.Request(url, data=data, headers=headers),
                                  timeout=min(seconds, left)) as response:
                require(response.status == 200, "http_status")
                raw = response.read(CAP + 1)
        except urllib.error.HTTPError as exc:
            # Never print provider bodies/headers: only safe status classification.
            raise Refusal("provider_http_" + str(exc.code) if provider else "mcp_http_" + str(exc.code)) from None
        require(len(raw) <= CAP, "response_limit")
        try:
            parsed = json.loads(raw)
        except ValueError:
            require(not provider, "provider_json")
            parts = [json.loads(line[6:]) for line in raw.decode().splitlines() if line.startswith("data: ")]
            require(len(parts) == 1, "mcp_single_event")
            parsed = parts[0]
        return parsed

    def rpc(self, ident, method, params):
        allowed = {"initialize", "tools/list", "tools/call"}
        require(method in allowed, "rpc_not_allowed")
        if method == "tools/call":
            require(params["name"] == "scorecard" and self.tool_calls == 0, "tool_dispatch_refused")
            self.tool_calls += 1
        result = self.request("http://127.0.0.1:8000/mcp",
                              {"jsonrpc": "2.0", "id": ident, "method": method, "params": params},
                              seconds=35 if method == "tools/call" else 5)
        require(result.get("id") == ident and "error" not in result and "result" in result, "rpc_result")
        require(not result["result"].get("isError", False), "mcp_tool_error")
        return result["result"]

    def model(self, payload):
        require(self.model_calls < 2, "provider_call_limit")
        self.model_calls += 1
        emit("provider_request", ordinal=self.model_calls, model=payload["model"],
             reasoning_effort=payload["reasoning_effort"], max_completion_tokens=payload["max_completion_tokens"],
             tools=[t["function"]["name"] for t in payload.get("tools", [])],
             tool_choice=payload.get("tool_choice"), request_sha256=digest(encoded(payload)),
             request_bytes=len(encoded(payload)), retries=0, store=False)
        response = self.request("https://api.openai.com/v1/chat/completions", payload, provider=True, seconds=35)
        choices = response.get("choices", [])
        require(len(choices) == 1, "single_choice")
        usage = response.get("usage", {})
        require(type(usage.get("completion_tokens")) is int and
                0 <= usage["completion_tokens"] <= payload["max_completion_tokens"], "provider_usage_limit")
        emit("provider_response", ordinal=self.model_calls, response_id=response.get("id"),
             model=response.get("model"), finish_reason=choices[0].get("finish_reason"),
             usage=usage, response_sha256=digest(encoded(response)))
        return choices[0], usage["completion_tokens"]


def validate_tool_call(choice, day):
    require(choice.get("finish_reason") == "tool_calls", "first_turn_must_call_tool")
    message = choice.get("message", {})
    calls = message.get("tool_calls", [])
    require(len(calls) == 1 and calls[0].get("type") == "function", "single_function_call")
    call = calls[0]
    require(call.get("function", {}).get("name") == "scorecard", "only_scorecard")
    args = json.loads(call["function"]["arguments"])
    require(encoded(args) == encoded({"target_date": day, "include_realized_dryout": True}), "exact_date_and_optin")
    require(isinstance(call.get("id"), str) and 0 < len(call["id"]) < 256, "tool_call_id")
    # Retain only protocol fields; no opaque provider extension is replayed.
    return {"role": "assistant", "content": message.get("content"), "tool_calls": calls}, call["id"], args


def expected_summary(evidence, day):
    require(evidence.get("reader_contract_version") == 1 and evidence.get("night_date") == day and
            evidence.get("greenhouse_id") == "vallery", "evidence_scope")
    require(evidence.get("availability") in ("available", "no_episodes") and
            evidence.get("unavailable_reason") is None, "evidence_unavailable")
    summary = evidence.get("summary")
    require(isinstance(summary, dict), "summary_missing")
    episodes = summary.get("episodes")
    require(isinstance(episodes, list) and len(episodes) <= 500, "episode_shape")
    counts = {k: sum(e.get("dryout_disposition") == k for e in episodes) for k in DISPOSITIONS}
    require(counts == summary.get("dispositions") and sum(counts.values()) == len(episodes), "disposition_consistency")
    status = ("pending" if not episodes else "fail" if any(e.get("safety_gate_status") == "fail" for e in episodes)
              else "pass" if all(e.get("safety_gate_status") == "pass" for e in episodes) else "incomplete")
    require(status == summary.get("safety_gate_status"), "safety_consistency")
    return {"night_date": day, "availability": evidence["availability"], "episode_count": len(episodes),
            "dispositions": counts, "safety_gate_status": status,
            "daytime_dry_action_samples": summary.get("daytime_dry_action_samples"),
            "daytime_hold_admission_samples": summary.get("daytime_hold_admission_samples")}


def validate_interpretation(value, expected):
    keys = set(expected) | {"efficacy_proven", "crop_safety_proven", "complete_daytime_zero_proven",
                           "evidence_complete", "scope_statement"}
    require(isinstance(value, dict) and set(value) == keys, "interpretation_shape")
    for key, wanted in expected.items():
        require(encoded(value[key]) == encoded(wanted) and type(value[key]) is type(wanted), "interpretation_" + key)
    for key in ("efficacy_proven", "crop_safety_proven", "complete_daytime_zero_proven", "evidence_complete"):
        require(value[key] is False, "overclaim_" + key)
    text = value["scope_statement"]
    require(text == SCOPE_STATEMENT, "scope_statement")
    return value


def main():
    start = time.monotonic()
    signal.signal(signal.SIGALRM, alarm)
    signal.alarm(DEADLINE_SECONDS)
    phase = "input"
    try:
        raw = sys.stdin.buffer.read(524289)
        require(len(raw) <= 524288, "input_limit")
        packet = json.loads(raw)
        day = packet["target_date"]
        require(day in ("2026-10-04", "2026-10-16"), "target_date")
        require(re.fullmatch(r"[0-9a-f]{40}", packet["mcp_baked_git_sha"]) is not None, "baked_source_pin")
        require(os.environ.get("VERDIFY_GIT_SHA") == packet["mcp_baked_git_sha"], "baked_source_mismatch")
        require(set(packet["mcp_source_sha256"]) == set(SOURCE_PATHS), "source_inventory")
        for name in SOURCE_PATHS:
            require(re.fullmatch(r"[0-9a-f]{64}", packet["mcp_source_sha256"][name]) is not None,
                    "source_hash_shape")
            require(digest(Path(name).read_bytes()) == packet["mcp_source_sha256"][name], "source_mismatch")
        prompt = packet["iris_source"]
        require(prompt["source_sha256"] == IRIS_SOURCE_SHA and prompt["preamble_sha256"] == PREAMBLE_SHA,
                "iris_source_pin")
        preamble = "".join(prompt["constants"][key] for key in ("_STANDING_DIRECTIVES", "_PLANNER_CORE", "_PLANNER_EXTENDED"))
        require(digest(preamble.encode()) == PREAMBLE_SHA, "preamble_bytes")
        model = packet["model_config"]
        require(model == {"default": "gpt-5.6-luna", "provider": "custom", "base_url": "https://api.openai.com/v1",
                          "reasoning_effort": "xhigh", "effective_config_sha256": IRIS_CONFIG_SHA}, "model_config")
        require(os.environ.get("MCP_HTTP_PORT", "8000") == "8000", "mcp_port")
        iris_token = os.environ["VERDIFY_MCP_TOKEN_IRIS"]
        provider_key = os.environ["OPENAI_API_KEY"]
        require(bool(iris_token) and bool(provider_key), "existing_credentials_missing")
        transport = Transport(start, iris_token, provider_key)
        emit("source_admitted", packet_sha256=digest(raw), baked_sha=packet["mcp_baked_git_sha"],
             source_sha256=packet["mcp_source_sha256"], preamble_sha256=PREAMBLE_SHA,
             effective_config_sha256=IRIS_CONFIG_SHA, target_date=day, scope=LIMITS)
        phase = "mcp_discovery"
        ready = transport.request("http://127.0.0.1:8000/readyz", None)
        require(ready.get("ready") is True and sorted(ready.get("auth_audiences_configured", [])) == ["iris", "observer"], "ready_auth")
        transport.rpc(1, "initialize", {"protocolVersion": "2025-03-26", "capabilities": {},
                     "clientInfo": {"name": "verdify-contained-read-consumer", "version": "1"}})
        listed = transport.rpc(2, "tools/list", {})
        selected = [t for t in listed["tools"] if t["name"] == "scorecard"]
        require(len(selected) == 1 and not any(t["name"] == "outcome_kpi" for t in listed["tools"]), "tool_audience")
        tool = selected[0]
        require(tool["inputSchema"]["properties"]["include_realized_dryout"]["type"] == "boolean" and
                tool["inputSchema"]["properties"]["include_realized_dryout"]["default"] is False, "optin_schema")
        emit("actual_tool_discovery", scorecard=tool, scorecard_schema_sha256=digest(encoded(tool)),
             iris_tool_names=sorted(t["name"] for t in listed["tools"]))
        tools = [{"type": "function", "function": {"name": "scorecard", "description": tool["description"],
                                                       "parameters": tool["inputSchema"]}}]
        qualification = ("This is a bounded read-only qualification, not a planning event. Do not acknowledge, plan, "
                         "actuate, post, or request any action tool. Only read scorecard for the exact supplied historical "
                         "date with include_realized_dryout=true. Then interpret its actual evidence only. No operational "
                         "authority or permission is granted by this conversation. Do not claim a natural planner cycle.")
        user = (f"Read the realized solar-night evidence for {day}. Request scorecard(target_date='{day}', "
                "include_realized_dryout=true). After receiving the response, produce one JSON object with exactly: "
                "night_date, availability, episode_count, dispositions (all four named counts), safety_gate_status, "
                "daytime_dry_action_samples, daytime_hold_admission_samples, efficacy_proven, crop_safety_proven, "
                "complete_daytime_zero_proven, evidence_complete, scope_statement. Preserve null/missing coverage "
                "rather than turning it into zero. Separate safety status from efficacy, physical crop safety, "
                "and complete-daylight coverage. Set scope_statement to exactly this literal, without any other prose: "
                + json.dumps(SCOPE_STATEMENT))
        messages = [{"role": "system", "content": preamble}, {"role": "developer", "content": qualification},
                    {"role": "user", "content": user}]
        common = {"model": model["default"], "reasoning_effort": model["reasoning_effort"],
                  "parallel_tool_calls": False, "n": 1, "store": False}
        phase = "model_read_request"
        first, used1 = transport.model({**common, "messages": messages, "tools": tools,
                         "tool_choice": {"type": "function", "function": {"name": "scorecard"}},
                         "max_completion_tokens": 800})
        assistant, call_id, arguments = validate_tool_call(first, day)
        emit("model_requested_read", call_id=call_id, arguments=arguments)
        phase = "actual_scorecard"
        result = transport.rpc(3, "tools/call", {"name": "scorecard", "arguments": arguments})
        text = [v["text"] for v in result.get("content", []) if v.get("type") == "text"]
        require(len(text) == 1, "single_scorecard_text")
        scorecard = json.loads(text[0])
        evidence = scorecard.get("realized_solar_night_dryout", {})
        expected = expected_summary(evidence, day)
        # Qualification is for actual negative/incomplete history, not generic all-good evidence.
        require(expected["episode_count"] == 0 or expected["dispositions"]["ineffective"] +
                expected["dispositions"]["blocked"] + expected["dispositions"]["insufficient_evidence"] > 0,
                "negative_or_empty_evidence_required")
        emit("actual_scorecard_response", result=result, result_sha256=digest(encoded(result)), evidence_summary=expected)
        messages += [assistant, {"role": "tool", "tool_call_id": call_id, "content": text[0]}]
        phase = "model_interpretation"
        second, used2 = transport.model({**common, "messages": messages, "tools": [], "tool_choice": "none",
                           "response_format": {"type": "json_object"}, "max_completion_tokens": 1200})
        require(second.get("finish_reason") == "stop" and not second.get("message", {}).get("tool_calls"), "final_no_tools")
        interpretation = validate_interpretation(json.loads(second["message"]["content"]), expected)
        require(used1 + used2 <= 2000, "combined_completion_budget")
        for name, wanted in packet["mcp_source_sha256"].items():
            require(digest(Path(name).read_bytes()) == wanted, "source_changed")
        emit("complete", status="BOUNDED_ORDINARY_CONSUMER_PASSED", interpretation=interpretation,
             completion_tokens=used1 + used2, provider_calls=transport.model_calls,
             actual_scorecard_calls=transport.tool_calls, other_tools_dispatched=0, retries=0,
             elapsed_seconds=round(time.monotonic()-start, 3), scope=LIMITS)
        return 0
    except Exception as exc:
        code = str(exc) if type(exc) is Refusal else None
        emit("failed", status="FAILED", phase=phase, error_type=type(exc).__name__, refusal_code=code,
             elapsed_seconds=round(time.monotonic()-start, 3), retries=0, scope=LIMITS)
        return 1
    finally:
        signal.alarm(0)


if __name__ == "__main__":
    raise SystemExit(main())
