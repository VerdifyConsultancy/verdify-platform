#!/usr/bin/env python3
"""Prepare public, source-pinned input only; never executes a probe or reads keys."""
import argparse, hashlib, json, pathlib, re
BASE=pathlib.Path('/private/tmp/verdify-daytime-consumer-20261018')
p=argparse.ArgumentParser()
p.add_argument('--source-root',type=pathlib.Path,required=True)
p.add_argument('--mcp-baked-sha',required=True)
p.add_argument('--target-date',choices=['2026-10-04','2026-10-16'],required=True)
p.add_argument('--out',type=pathlib.Path,required=True)
a=p.parse_args()
assert re.fullmatch('[0-9a-f]{40}',a.mcp_baked_sha)
assert not a.out.exists()
sha=lambda b:hashlib.sha256(b).hexdigest()
prompt=json.loads((BASE/'iris-source/stdout.json').read_text())
config=json.loads((BASE/'iris-source/live-model-config.json').read_text())
effective=json.loads((BASE/'iris-source/model-v3/stdout.json').read_text())
assert effective['status']=='MOUNTED_AND_EFFECTIVE_CONFIG_EXACT_SOURCE_HASH_MATCH'
assert effective['model_env_overrides_present']==[]
c=config['configs'][0]
assert c['key']=='config.yaml'
assert all(v['sha256']==c['file_sha256'] for v in effective['configs'])
assert 'scorecard' in c['iris_tool_includes']['verdify_greenhouse']
files=['mcp/server.py','verdify_schemas/realized_dryout.py','verdify_schemas/mcp_responses.py']
packet={'schema':'bounded-iris-consumer-input-v1','target_date':a.target_date,'mcp_baked_git_sha':a.mcp_baked_sha,
        'mcp_source_sha256':{'/app/'+f:sha((a.source_root/f).read_bytes()) for f in files},
        'iris_source':prompt,'model_config':{**c['model'],'reasoning_effort':c['reasoning_effort'],'effective_config_sha256':c['file_sha256']},
        'custody_sha256':{str(f.relative_to(BASE)):sha(f.read_bytes()) for f in [BASE/'iris-source/stdout.json',BASE/'iris-source/live-model-config.json',BASE/'iris-source/model-v3/stdout.json']}}
a.out.write_text(json.dumps(packet,indent=2)+'\n')
print(json.dumps({'status':'INPUT_PREPARED_NOT_EXECUTED','path':str(a.out),'sha256':sha(a.out.read_bytes())}))
