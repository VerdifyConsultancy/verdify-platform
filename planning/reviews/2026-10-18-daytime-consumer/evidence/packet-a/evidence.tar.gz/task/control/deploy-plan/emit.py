#!/usr/bin/env python3
"""Pure exact-three-resource Argo JSON-patch emitter. No network or subprocesses.
ROOT supplies fresh retained metadata and executes at most one reviewed patch.
A generated patch does not claim admission, submission, rollout or acceptance.
"""
import argparse, copy, datetime as dt, hashlib, json, pathlib, re, uuid
OLD_MCP='registry.vallery.net/verdifyconsultancy/verdify-mcp@sha256:264f5fcb4da78a068c5bc64ec2b70d9efe122a473a1f92bb5d923565fb47a393'
OLD_INVENTORY='aaefffac230b'
RESOURCES=[{'group':'','kind':'ConfigMap','name':'verdify-iris-inventory','namespace':'verdify-prod'},
           {'group':'apps','kind':'Deployment','name':'verdify-mcp','namespace':'verdify-prod'},
           {'group':'apps','kind':'Deployment','name':'verdify-hermes-iris','namespace':'verdify-prod'}]
TERMINAL={'Succeeded','Failed','Error'}

def require(ok,code):
 if not ok:raise ValueError(code)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def load(path):return json.loads(path.read_text())
def key(obj):
 api=obj['apiVersion'];return (api.split('/')[0] if '/' in api else '',obj['kind'],obj['metadata']['name'],obj['metadata'].get('namespace','verdify-prod'))
def inventory(data):
 data=data.get('items') if isinstance(data,dict) else data
 require(isinstance(data,list),'render_list_required')
 out={}
 for obj in data:
  k=key(obj);require(k not in out,'duplicate_object');require(obj['kind']!='Secret','rendered_secret_forbidden');out[k]=obj
 return out
def tuple_of(r):return (r['group'],r['kind'],r['name'],r['namespace'])
def ctr(obj,name):
 matches=[x for x in obj['spec']['template']['spec']['containers'] if x['name']==name]
 require(len(matches)==1,'container_identity');return matches[0]
def validate_render(before,after,digest):
 require(set(before)==set(after),'inventory_changed')
 changed={k for k in before if before[k]!=after[k]}
 require(changed=={tuple_of(r) for r in RESOURCES},'diff_not_exact_three')
 cmk,mcpk,hk=[tuple_of(r) for r in RESOURCES]
 oldcm,newcm=before[cmk],after[cmk]
 require(set(oldcm['data'])==set(newcm['data']),'inventory_data_keys_changed')
 require({k for k in oldcm['data'] if oldcm['data'][k]!=newcm['data'][k]}=={'SOUL.md'},'only_soul_change_allowed')
 copycm=copy.deepcopy(newcm);copycm['data']['SOUL.md']=oldcm['data']['SOUL.md'];require(copycm==oldcm,'configmap_other_change')
 require(oldcm['metadata'].get('annotations',{}).get('argocd.argoproj.io/sync-wave','0')=='0','configmap_wave')
 revision=sha(json.dumps(newcm['data'],sort_keys=True).encode())[:12]
 require(sha(json.dumps(oldcm['data'],sort_keys=True).encode())[:12]==OLD_INVENTORY,'old_inventory_hash')
 oldm,newm=before[mcpk],after[mcpk]
 require(ctr(oldm,'mcp')['image']==OLD_MCP,'old_mcp_pin')
 image='registry.vallery.net/verdifyconsultancy/verdify-mcp@sha256:'+digest
 require(ctr(newm,'mcp')['image']==image and image!=OLD_MCP,'new_mcp_pin')
 copym=copy.deepcopy(newm);ctr(copym,'mcp')['image']=OLD_MCP;require(copym==oldm,'mcp_change_not_image_only')
 require(newm['metadata']['annotations']['argocd.argoproj.io/sync-wave']=='10','mcp_wave')
 oldh,newh=before[hk],after[hk]
 annot='verdify.io/iris-inventory-revision'
 require(oldh['spec']['template']['metadata']['annotations'][annot]==OLD_INVENTORY,'old_hermes_revision')
 require(newh['spec']['template']['metadata']['annotations'][annot]==revision and revision!=OLD_INVENTORY,'new_hermes_revision')
 copyh=copy.deepcopy(newh);copyh['spec']['template']['metadata']['annotations'][annot]=OLD_INVENTORY;require(copyh==oldh,'hermes_other_change')
 require(newh['spec']['replicas']==1 and newh['spec']['strategy']['type']=='Recreate','single_gateway')
 require(newh['metadata']['annotations']['argocd.argoproj.io/sync-wave']=='20','hermes_wave')
 return {'new_mcp_image':image,'old_mcp_image':OLD_MCP,'old_inventory_revision':OLD_INVENTORY,
         'new_inventory_revision':revision,'old_inventory_data_sha256':sha(json.dumps(oldcm['data'],sort_keys=True).encode()),
         'new_inventory_data_sha256':sha(json.dumps(newcm['data'],sort_keys=True).encode()),
         'old_soul_sha256':sha(oldcm['data']['SOUL.md'].encode()),'new_soul_sha256':sha(newcm['data']['SOUL.md'].encode())}
def stamp(value):
 if isinstance(value,(int,float)) and not isinstance(value,bool):return dt.datetime.fromtimestamp(value,dt.timezone.utc)
 require(isinstance(value,str),'timestamp_type')
 parsed=dt.datetime.fromisoformat(value.replace('Z','+00:00'));require(parsed.tzinfo is not None,'timestamp_timezone');return parsed
def recent(value,now,seconds,code):
 age=(now-stamp(value)).total_seconds();require(-2<=age<=seconds,code)
def validate_idle(idle,now,hermes_uid):
 require(idle['schema']=='hermes-idle-readback-v1','idle_schema')
 require(idle['pod_uid']==hermes_uid and str(uuid.UUID(hermes_uid))==hermes_uid,'idle_pod_uid')
 recent(idle['captured_at'],now,60,'stale_idle_capture')
 h=idle['health'];require(h.get('status')=='ok' and h.get('platform')=='hermes-agent','gateway_health')
 require(h.get('gateway_state') in ('running','ready'),'gateway_state')
 require(type(h.get('active_agents')) is int and h['active_agents']==0,'active_agents')
 require(h.get('updated_at') is not None and h.get('platforms'),'missing_runtime_status')
 recent(h['updated_at'],now,60,'stale_runtime_status')
 require(type(h.get('pid')) is int and h['pid']>0,'gateway_pid')
 ledger=idle['delivery_ledger'];require(ledger['readonly'] is True and ledger['complete'] is True,'ledger_not_complete_readonly')
 recent(ledger['captured_at'],now,60,'stale_ledger_capture')
 require(type(ledger['rows_examined']) is int and 0<=ledger['rows_examined']<=200,'ledger_cap')
 require(ledger['window_minutes']==180,'ledger_window')
 require(ledger['pending_without_run_id']==0,'pending_without_run_id')
 require(set(ledger['unresolved_run_ids'])==set(x['run_id'] for x in idle['run_statuses']),'run_id_coverage')
 require(len(idle['run_statuses'])==len(set(x['run_id'] for x in idle['run_statuses']))<=20,'run_status_cap')
 for item in idle['run_statuses']:
  require(item['http_status']==200 and item['status'] in ('completed','failed','cancelled'),'run_not_terminal')
  recent(item['captured_at'],now,60,'stale_run_status')
 require(idle['incoming_dispatch_frozen'] is False,'no_freeze_claim')
 return {'health_snapshot_only':True,'no_incoming_dispatch_freeze':True,'restart_race_remains':True,
         'gateway_pod_uid':hermes_uid,'gateway_pid':h['pid'],'ledger_rows_examined':ledger['rows_examined'],
         'terminal_run_statuses':len(idle['run_statuses']),'run_status404_is_not_terminal':True}
def build_patch(app,uid,rv,phase,revision):
 require(re.fullmatch('[0-9a-f]{40}',revision) is not None,'main_revision_shape')
 require(str(uuid.UUID(uid))==uid and re.fullmatch('[0-9]+',rv) is not None,'app_identity_shape')
 require(app['apiVersion']=='argoproj.io/v1alpha1' and app['kind']=='Application','app_kind')
 m=app['metadata'];require(m['name']=='verdify-prod-dark' and m['namespace']=='argocd','app_name')
 require(m['uid']==uid and m['resourceVersion']==rv and not m.get('deletionTimestamp'),'app_identity')
 require(app.get('operation') is None,'active_application_operation')
 require(phase in TERMINAL and app['status']['operationState']['phase']==phase,'prior_operation_not_terminal')
 require(app['spec']['source']=={'path':'deploy/k8s/overlays/prod','repoURL':'https://github.com/VerdifyConsultancy/verdify-platform.git','targetRevision':'main'},'app_source')
 require(app['spec']['destination']=={'namespace':'verdify-prod','server':'https://kubernetes.default.svc'},'app_destination')
 patch=[{'op':'test','path':'/metadata/uid','value':uid},{'op':'test','path':'/metadata/resourceVersion','value':rv}]
 if 'operation' in app:patch.append({'op':'test','path':'/operation','value':None})
 # RV binds the absent operation field too; JSON Patch cannot test an absent path.
 patch += [{'op':'test','path':'/status/operationState/phase','value':phase},
           {'op':'add','path':'/status/operationState','value':None},
           {'op':'add','path':'/operation','value':{'initiatedBy':{'username':'laptop-root'},
              'sync':{'revision':revision,'prune':False,'resources':copy.deepcopy(RESOURCES)}}}]
 return patch

def main():
 p=argparse.ArgumentParser()
 for key in ('application','render_before','render_after','idle_evidence'):p.add_argument('--'+key.replace('_','-'),type=pathlib.Path,required=True)
 for key in ('expected_app_uid','expected_app_rv','expected_terminal_phase','expected_hermes_pod_uid','main_revision','mcp_digest'):p.add_argument('--'+key.replace('_','-'),required=True)
 p.add_argument('--out',type=pathlib.Path,required=True);a=p.parse_args()
 require(re.fullmatch('[0-9a-f]{64}',a.mcp_digest) is not None,'qualified_digest_shape')
 require(not a.out.exists(),'fresh_output_required');now=dt.datetime.now(dt.timezone.utc)
 inputs={key:getattr(a,key) for key in ('application','render_before','render_after','idle_evidence')}
 bytes_before={k:v.read_bytes() for k,v in inputs.items()}
 patch=build_patch(json.loads(bytes_before['application']),a.expected_app_uid,a.expected_app_rv,a.expected_terminal_phase,a.main_revision)
 delta=validate_render(inventory(json.loads(bytes_before['render_before'])),inventory(json.loads(bytes_before['render_after'])),a.mcp_digest)
 idle=validate_idle(json.loads(bytes_before['idle_evidence']),now,a.expected_hermes_pod_uid)
 a.out.mkdir()
 for name,raw in bytes_before.items():(a.out/(name+'.json')).write_bytes(raw)
 (a.out/'patch.json').write_text(json.dumps(patch,indent=2)+'\n')
 receipt={'schema':'exact-three-resource-selective-plan-v1','status':'PREPARED_NOT_SUBMITTED',
  'created_at':now.isoformat(),'expires_at':(now+dt.timedelta(seconds=30)).isoformat(),
  'main_revision':a.main_revision,'application_uid':a.expected_app_uid,'application_resource_version':a.expected_app_rv,
  'prior_terminal_phase':a.expected_terminal_phase,'resources':RESOURCES,'render_delta':delta,'idle_admission':idle,
  'input_sha256':{k:sha(raw) for k,raw in bytes_before.items()},'driver_sha256':sha(pathlib.Path(__file__).read_bytes()),
  'patch_sha256':sha((a.out/'patch.json').read_bytes()),'native_calls':0,
  'execution_rule':'ROOT checks30s expiry then sends exactly one JSON patch to the named Application. Any rejection/uncertainty is retained; no automatic retry.',
  'rollback_rule':'Use old source-owned SOUL/inventory/revision and old MCP release pin in a separate reviewed source revision. Reusing an old rendered hook/fullsync is forbidden; no deployment patch rollback is embedded.'}
 (a.out/'plan.json').write_text(json.dumps(receipt,indent=2)+'\n')
 require(all(fp.read_bytes()==bytes_before[k] for k,fp in inputs.items()),'input_changed_during_emission')
 print(json.dumps({'status':'PREPARED_NOT_SUBMITTED','path':str(a.out),'plan_sha256':sha((a.out/'plan.json').read_bytes())}))
if __name__=='__main__':main()
