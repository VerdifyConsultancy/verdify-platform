from pathlib import Path
import hashlib,json
base=Path('/private/tmp/verdify-daytime-consumer-20261018');old=base/'control';out=old/'runtime-model-v2';out.mkdir(exist_ok=False)
sha=lambda raw:hashlib.sha256(raw).hexdigest()
profile='2261f5c1a236202b3bfccedd82f1284f50ab27445767dcb09439a92a8d58b56b'
oldprofile='51de00576417701fc4fed8fb03ec9a3f1bfbee5e4f5d057f25b763076c2a8b5f'
source='182691082420466dc1c5b39bae2fd84f49f38dbf'
root=Path('/private/tmp/verdify-daytime-consumer-source-20261018')
(out/'runtime-mcp-readonly.py').write_bytes((old/'runtime-mcp-readonly.py').read_bytes())
(out/'runtime-hermes-readonly.py').write_text((old/'runtime-hermes-readonly.py').read_text().replace(oldprofile,profile))
api_driver='''"""Fixed public API model attribution read. No imports of services or credential reads."""
import hashlib,json,os,pathlib,signal,sys,urllib.request
SOURCE=__SOURCE__
MAIN_SHA=__MAIN_SHA__
LABEL='hermes-iris/custom:gpt-6-luna/xhigh'
def need(ok,code):
 if not ok:raise ValueError(code)
def alarm(*a):raise ValueError('deadline')
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*a,**kw):raise ValueError('redirect')
def run():
 signal.signal(signal.SIGALRM,alarm);signal.alarm(20)
 need(pathlib.Path('/etc/verdify/source-revision').read_text().strip()==SOURCE,'source_file')
 need(os.environ.get('VERDIFY_GIT_SHA') in (SOURCE,'unknown',None),'source_env')
 raw=pathlib.Path('/app/main.py').read_bytes();need(hashlib.sha256(raw).hexdigest()==MAIN_SHA,'source_hash')
 need(os.environ.get('VERDIFY_PLANNER_MODEL_LABEL')==LABEL,'model_env')
 opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())
 with opener.open('http://127.0.0.1:8080/api/v1/public/planner-health',timeout=10) as r:
  need(r.status==200,'status');data=r.read(262145)
 need(len(data)<=262144,'response_cap');value=json.loads(data);need(value.get('current_model_label')==LABEL,'public_model_label')
 return {'status':'API_MODEL_ATTRIBUTION_READONLY_PASSED','source_sha':SOURCE,'main_sha256':MAIN_SHA,'model_label':LABEL,'http_status':200,'response_sha256':hashlib.sha256(data).hexdigest(),'response_bytes':len(data),'actual_scorecard_calls':0,'provider_calls':0,'writes':0}
if __name__=='__main__':
 try:print(json.dumps(run(),sort_keys=True))
 except Exception as e:print(json.dumps({'status':'FAILED','code':type(e).__name__,'raw_error_values_retained':False}));sys.exit(1)
 finally:signal.alarm(0)
'''.replace('__SOURCE__',repr(source)).replace('__MAIN_SHA__',repr(sha((root/'api/main.py').read_bytes())))
(out/'runtime-api-readonly.py').write_text(api_driver)
expect=json.loads((old/'runtime-expectations.json').read_text());expect['schema']='verdify-daytime-runtime-model-expectations-v2';expect['api_source_revision']=source
expect['hermes_cm']['verdify-hermes-iris-config']['config.yaml']=profile
expect['installed_hermes_files']={k:(profile if v==oldprofile else v) for k,v in expect['installed_hermes_files'].items()}
expect['smoke_files']['deploy/k8s/components/hermes-iris/hermes-config.yaml']=sha((root/'deploy/k8s/components/hermes-iris/hermes-config.yaml').read_bytes())
previous={'verified.json','after-application.stdout','after-deployments.stdout','after-critical-pods.stdout','after-mcp-pods.stdout','after-hermes-iris-pods.stdout'}
expect['previous_runtime']={p:sha((base/'runtime-01'/p).read_bytes()) for p in sorted(previous)}
expect['previous_runtime']['verified.json']=='a9c05666e60d68feaeaab5edcb3797aa2f19bff4c6e0df388cc254d099cca138' or (_ for _ in ()).throw(ValueError('previous receipt'))
(out/'runtime-expectations.json').write_text(json.dumps(expect,sort_keys=True,indent=2)+'\n')
s=(old/'runtime-readback.py').read_text()
s=s.replace("API_SOURCE='cb21fd3d3295aa8d7183f70b0d5ac82405410b1a'",f"API_SOURCE='{source}'\nPROFILE='{profile[:12]}'\nMCP_DIGEST='ae8a367035a3ae8a06ab2384bc166f444b3decad0da21e5c70e53e76203d9c73'\nMODEL_LABEL='hermes-iris/custom:gpt-6-luna/xhigh'")
start=s.index('INPUT_PINS=');end=s.index('\nclass Refusal',start)
pins={p:sha((out/p).read_bytes()) for p in ('runtime-expectations.json','runtime-mcp-readonly.py','runtime-hermes-readonly.py','runtime-api-readonly.py')}
s=s[:start]+'INPUT_PINS='+repr(pins)+s[end:]
s=s.replace('def verify_deployments(initial,current,digest):','def verify_deployments(initial,current,digest,api_digest):')
start=s.index("  if name=='verdify-mcp':");end=s.index("  need(b['spec']==wanted",start)
s=s[:start]+'''  if name=='verdify-mcp':need(container(a,'mcp')['image'].endswith('@sha256:'+digest) and digest==MCP_DIGEST,'accepted_mcp_digest')
  elif name=='verdify-api':
   c=container({'spec':wanted},'api');c['image']='registry.vallery.net/verdifyconsultancy/verdify-api@sha256:'+api_digest
   env=[e for e in c['env'] if e['name']=='VERDIFY_PLANNER_MODEL_LABEL'];need(env==[{'name':'VERDIFY_PLANNER_MODEL_LABEL','value':'hermes-iris/custom:gpt-5.6-luna/xhigh'}],'previous_api_model_label');env[0]['value']=MODEL_LABEL
  elif name=='verdify-hermes-iris':
   ann=wanted['template']['metadata']['annotations'];need(ann['verdify.io/iris-inventory-revision']==INVENTORY and ann['verdify.io/hermes-profile-revision']=='51de00576417','previous_hermes_revisions');ann['verdify.io/hermes-profile-revision']=PROFILE
'''+s[end:]
s=s.replace("if name in ('verdify-mcp','verdify-hermes-iris'):","if name in ('verdify-mcp','verdify-api','verdify-hermes-iris'):")
s=s.replace("count=2 if name=='verdify-mcp' else 1", "count=1 if name=='verdify-hermes-iris' else 2")
s=s.replace('dm=verify_deployments(initial_deps,deps,digest)','dm=verify_deployments(initial_deps,deps,digest,self.api_digest)')
s=s.replace("in ('api','ingestor')","in ('ingestor',)").replace("need(len(critical)==4,","need(len(critical)==2,")
s=s.replace("[('mcp',2,'mcp',digest),('hermes-iris',1,'hermes-iris',HERMES)]","[('mcp',2,'mcp',digest),('api',2,'api',self.api_digest),('hermes-iris',1,'hermes-iris',HERMES)]")
s=s.replace("pod_ready(p,ctr,dig);need(p['metadata']['uid'] not in old_uids,'old_rollout_pod')","pod_ready(p,ctr,dig)\n    if comp=='mcp':\n     need(p['metadata']['uid'] in old_uids and state_fingerprint(p)==state_fingerprint(prior[p['metadata']['name']]),'accepted_mcp_pod_changed')\n    else:need(p['metadata']['uid'] not in old_uids,'old_rollout_pod')")
s=s.replace("return {'mcp':selected['mcp'],'hermes':", "return {'mcp':selected['mcp'],'api':selected['api'],'hermes':")
s=s.replace("'hermes_driver':controls/'runtime-hermes-readonly.py','ci_receipt':a.ci_receipt,","'hermes_driver':controls/'runtime-hermes-readonly.py','api_driver':controls/'runtime-api-readonly.py','api_ci_receipt':a.api_ci_receipt,'ci_receipt':a.ci_receipt,")
s=s.replace("for key in ('expectations','mcp_driver','hermes_driver'):","for key in ('expectations','mcp_driver','hermes_driver','api_driver'):")
needle="  for n,h in expect['smoke_files'].items():need(sha((a.source_worktree/n).read_bytes())==h,'smoke_source_hash')"
insert='''  need(re.fullmatch('[0-9a-f]{64}',a.api_ci_receipt_sha256) is not None and sha(inputs['api_ci_receipt'])==a.api_ci_receipt_sha256,'api_ci_receipt_hash')
  api_ci=json.loads(inputs['api_ci_receipt']);need(api_ci['status']=='SOURCE_GATE_TWO_BUILDS_AND_PIN_PUBLISHER_VERIFIED' and api_ci['source_revision']==API_SOURCE and api_ci['workflow_uid']==a.api_workflow_uid,'api_source_ci_binding')
  api_image=api_ci['images']['api'];need(api_image['source-revision']==api_image['resolved-revision']==API_SOURCE and re.fullmatch('sha256:[0-9a-f]{64}',api_image['digest']) is not None,'ci_api_source_digest');self.api_digest=api_image['digest'][7:]
  previous={n:(BASE/'runtime-01'/n).read_bytes() for n in expect['previous_runtime']}
  need(all(sha(raw)==expect['previous_runtime'][n] for n,raw in previous.items()),'previous_runtime_hash')
  prev_receipt=json.loads(previous['verified.json']);need(prev_receipt['status']=='POST_ROLLOUT_RUNTIME_CUSTODY_PASSED' and prev_receipt['source_sha']==SOURCE and prev_receipt['mcp_digest']==digest,'previous_runtime_scope')
  prev_records={r['phase']:r for r in prev_receipt['records']}
  for n,raw in previous.items():
   if n.endswith('.stdout'):need(prev_records[n[:-7]]['returncode']==0 and prev_records[n[:-7]]['stdout_sha256']==sha(raw),'previous_record_binding')
'''
s=s.replace(needle,insert+needle)
start=s.index("  self.initial_app=json.loads(inputs['application.json']);");end=s.index("  for name,raw in inputs.items():",start)
s=s[:start]+'''  self.initial_app=json.loads(previous['after-application.stdout']);initial_deps=json.loads(previous['after-deployments.stdout'])
  initial_pods={'items':sum((items(json.loads(previous[n])) for n in ('after-critical-pods.stdout','after-mcp-pods.stdout','after-hermes-iris-pods.stdout')),[])}
  need(len({p['metadata']['uid'] for p in initial_pods['items']})==7,'previous_pod_inventory');api_digest='sha256:'+self.api_digest
'''+s[end:]
s=s.replace("  (self.out/'runtime-readback.py').write_bytes", "  for name,raw in previous.items():(self.out/('previous-'+name)).write_bytes(raw)\n  (self.out/'runtime-readback.py').write_bytes")
s=s.replace("'mcp_digest':digest,'input_sha256'", "'mcp_digest':digest,'api_source_sha':API_SOURCE,'api_digest':self.api_digest,'previous_runtime_sha256':expect['previous_runtime'],'input_sha256'")
needle="  hp=pre['hermes'];hermes="
insert="  api_results=[]\n  for i,p in enumerate(sorted(pre['api'],key=lambda x:x['metadata']['name'])):\n   result=self.exec_driver('api-readonly-'+str(i),p['metadata']['name'],'api','python',inputs['api_driver']);need(result.get('status')=='API_MODEL_ATTRIBUTION_READONLY_PASSED','api_runtime_failed');api_results.append({'pod':p['metadata']['name'],'uid':p['metadata']['uid'],'result':result})\n"
s=s.replace(needle,insert+needle)
s=s.replace("and state_fingerprint(pre['hermes'])", "and {p['metadata']['uid']:state_fingerprint(p) for p in pre['api']}=={p['metadata']['uid']:state_fingerprint(p) for p in post['api']} and state_fingerprint(pre['hermes'])")
s=s.replace("  need(all(p.read_bytes()==inputs[k] for k,p in paths.items()),'inputs_changed')", "  need(all(p.read_bytes()==inputs[k] for k,p in paths.items()),'inputs_changed')\n  need(all((BASE/'runtime-01'/n).read_bytes()==raw for n,raw in previous.items()),'previous_runtime_changed')")
s=s.replace("'unchanged_deployment_specs':13,'critical_pods_and_container_states_unchanged':4", "'unchanged_deployment_specs':13,'unrelated_deployment_specs_unchanged':12,'accepted_mcp_deployment_and_pods_unchanged':True,'critical_pods_and_container_states_unchanged':2")
s=s.replace("'mcp':mcp_results,'hermes':", "'mcp':mcp_results,'api':api_results,'api_source_sha':API_SOURCE,'api_digest':self.api_digest,'api_ci_receipt_sha256':a.api_ci_receipt_sha256,'effective_model_config_sha256':expect['hermes_cm']['verdify-hermes-iris-config']['config.yaml'],'hermes':")
s=s.replace("'argo_exact_three_resource_operation_proof'", "'argo_exact_four_resource_operation_proof'")
s=s.replace("p.add_argument('--release-sha',required=True);", "p.add_argument('--api-ci-receipt',type=pathlib.Path,required=True);p.add_argument('--api-ci-receipt-sha256',required=True);p.add_argument('--api-workflow-uid',required=True);p.add_argument('--release-sha',required=True);")
(out/'runtime-readback.py').write_text(s)
print(json.dumps({'out':str(out),'driver_sha256':sha(s.encode()),'pins':pins},indent=2))
