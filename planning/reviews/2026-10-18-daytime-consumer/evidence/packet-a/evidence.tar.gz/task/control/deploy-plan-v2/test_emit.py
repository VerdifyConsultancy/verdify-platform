import copy, datetime as dt, importlib.util, json, pathlib, unittest
p=pathlib.Path(__file__).with_name('emit.py');s=importlib.util.spec_from_file_location('emit',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
BASE=pathlib.Path('/private/tmp/verdify-daytime-consumer-20261018')
class Tests(unittest.TestCase):
 def app(self):return json.loads((BASE/'initial/application.json').read_text())
 def make(self,a):return m.build_patch(a,a['metadata']['uid'],a['metadata']['resourceVersion'],'Succeeded','1'*40)
 def test_actual_saved_terminal_app_exact_patch(self):
  p=self.make(self.app());op=p[-1]['value'];self.assertEqual(op['sync']['resources'],m.RESOURCES);self.assertIs(op['sync']['prune'],False);self.assertEqual(p[0]['path'],'/metadata/uid');self.assertEqual(p[1]['path'],'/metadata/resourceVersion');self.assertEqual(p[-2],{'op':'add','path':'/status/operationState','value':None})
 def test_current_operation_refused(self):
  a=self.app();a['operation']={'sync':{}}
  with self.assertRaises(ValueError):self.make(a)
 def test_nonterminal_phase_refused(self):
  a=self.app();a['status']['operationState']['phase']='Running'
  with self.assertRaises(ValueError):self.make(a)
 def test_uid_rv_mismatch_refused(self):
  a=self.app()
  for uid,rv in [('11111111-1111-1111-1111-111111111111',a['metadata']['resourceVersion']),(a['metadata']['uid'],'1')]:
   with self.assertRaises(ValueError):m.build_patch(a,uid,rv,'Succeeded','1'*40)
 def test_placeholder_revision_refused(self):
  a=self.app()
  with self.assertRaises(ValueError):m.build_patch(a,a['metadata']['uid'],a['metadata']['resourceVersion'],'Succeeded','TBD')
 def test_source_or_namespace_drift(self):
  for field,val in [('path','other'),('targetRevision','other')]:
   a=self.app();a['spec']['source'][field]=val
   with self.assertRaises(ValueError):self.make(a)
 def idle(self):
  now=dt.datetime.now(dt.timezone.utc);uid='11111111-1111-1111-1111-111111111111';v={'schema':'hermes-idle-readback-v2','pod_uid':uid,'captured_at':now.isoformat(),'health_http_status':200,'health':{'status':'ok','platform':'hermes-agent','gateway_state':'running','active_agents':0,'updated_at':now.isoformat(),'platforms':{'api_server':{}},'pid':32},'delivery_ledger':{'readonly':True,'complete':True,'captured_at':now.isoformat(),'rows_examined':0,'window_minutes':180,'pending_without_run_id':0,'unresolved_run_ids':[]},'run_statuses':[],'incoming_dispatch_frozen':False};return v,now,uid
 def test_idle_snapshot_honest_race(self):
  v,n,u=self.idle();self.assertTrue(m.validate_idle(v,n,u)['restart_race_remains'])
 def test_persistent_old_zero_is_not_current_idle_proof(self):
  v,n,u=self.idle();v['health']['updated_at']='2026-10-11T22:15:45.870281+00:00'
  out=m.validate_idle(v,n,u);self.assertTrue(out['health_non_authoritative']);self.assertFalse(out['health_activity_used_as_idle_proof']);self.assertFalse(out['current_exhaustive_idle_proven']);self.assertEqual(out['health_reported_active_agents'],0)
 def test_stale_health_fields_do_not_replace_live_known_run_status(self):
  v,n,u=self.idle();v['health']['active_agents']=3;v['health']['updated_at']=None
  v['delivery_ledger']['unresolved_run_ids']=['r'];v['run_statuses']=[{'run_id':'r','http_status':200,'status':'completed','captured_at':n.isoformat()}]
  self.assertEqual(m.validate_idle(v,n,u)['terminal_run_statuses'],1)
  v['run_statuses'][0]['status']='running'
  with self.assertRaises(ValueError):m.validate_idle(v,n,u)
 def test_stale_http_or_ledger_capture_refused(self):
  for part in ('captured_at','delivery_ledger'):
   v,n,u=self.idle()
   if part=='captured_at':v[part]='2000-01-01T00:00:00Z'
   else:v[part]['captured_at']='2000-01-01T00:00:00Z'
   with self.assertRaises(ValueError):m.validate_idle(v,n,u)
 def test_unknown_pending_or_incomplete_ledger_refused(self):
  for field,value in [('pending_without_run_id',1),('complete',False),('rows_examined',201)]:
   v,n,u=self.idle();v['delivery_ledger'][field]=value
   with self.assertRaises(ValueError):m.validate_idle(v,n,u)
 def test_health_http_failure_and_false_freeze_claim_refused(self):
  v,n,u=self.idle();v['health_http_status']=503
  with self.assertRaises(ValueError):m.validate_idle(v,n,u)
  v,n,u=self.idle();v['incoming_dispatch_frozen']=True
  with self.assertRaises(ValueError):m.validate_idle(v,n,u)
 def test_missing_run_or404_refused(self):
  v,n,u=self.idle();v['delivery_ledger']['unresolved_run_ids']=['r']
  with self.assertRaises(ValueError):m.validate_idle(v,n,u)
  v['run_statuses']=[{'run_id':'r','http_status':404,'status':'completed','captured_at':n.isoformat()}]
  with self.assertRaises(ValueError):m.validate_idle(v,n,u)
 def test_actual_source_diff_and_mutations(self):
  f=json.loads(p.with_name('render-test-fixture.json').read_text())
  self.assertEqual(m.validate_render(m.inventory(f['old']),m.inventory(f['new']),'a'*64)['new_inventory_revision'],'5733c1c6b35d')
  for mode in ['extra_cm_data','mcp_env','hermes_image','new_object']:
   new=copy.deepcopy(f['new'])
   if mode=='extra_cm_data':new[0]['data']['SKILL.md']+='changed'
   elif mode=='mcp_env':m.ctr(new[1],'mcp')['env'].append({'name':'UNEXPECTED','value':'1'})
   elif mode=='hermes_image':m.ctr(new[2],'hermes-iris')['image']='unexpected'
   else:new.append({'apiVersion':'v1','kind':'ConfigMap','metadata':{'name':'other'}})
   with self.subTest(mode=mode),self.assertRaises(ValueError):m.validate_render(m.inventory(f['old']),m.inventory(new),'a'*64)
 def test_secret_or_duplicate_render_refused(self):
  with self.assertRaises(ValueError):m.inventory([{'apiVersion':'v1','kind':'Secret','metadata':{'name':'x'}}])
  obj={'apiVersion':'v1','kind':'ConfigMap','metadata':{'name':'x'}}
  with self.assertRaises(ValueError):m.inventory([obj,obj])
if __name__=='__main__':unittest.main()
