# Exact three-resource rollout preparation

This source-only emitter creates an expiring JSON patch; it does not call Kubernetes, Argo, Hermes, the database, or Git. ROOT owns execution after the normal source CI and actual MCP candidate image are qualified.

The complete before/after rendered JSON inventories must differ only in `verdify-iris-inventory` (SOUL data), `verdify-mcp` (the qualified image), and `verdify-hermes-iris` (generated inventory revision). Their waves remain 0/10/20. The exact selector is core ConfigMap `verdify-iris-inventory`, apps Deployment `verdify-mcp`, and apps Deployment `verdify-hermes-iris`, all in `verdify-prod`. The script preserves every other object, release pin, migration hook, getter, security setting, credential reference, and persistent resource by equality.

Before emission, ROOT captures a fresh exact Application UID/RV with no `.operation` and terminal prior operation; full rendered before/after files; and the following normalized idle receipt from original retained read-only outputs. The local emitter checks timestamps and declared facts; ROOT must verify the raw receipt linkage and exact gateway Pod UID before using it.

```json
{
  "schema": "hermes-idle-readback-v1",
  "pod_uid": "<actual current Hermes UID>",
  "captured_at": "<actual aware timestamp>",
  "health": {"status":"ok","platform":"hermes-agent","gateway_state":"running","platforms":{"api_server":{}},"active_agents":0,"updated_at":"<actual runtime timestamp>","pid":1},
  "delivery_ledger": {"readonly":true,"captured_at":"<actual timestamp>","complete":true,"window_minutes":180,"rows_examined":0,"pending_without_run_id":0,"unresolved_run_ids":[]},
  "run_statuses": [],
  "incoming_dispatch_frozen": false
}
```

These are explanatory shapes, not executable input. `health/detailed` can default `active_agents` to zero when runtime state is missing, so fresh nonnull `updated_at`, gateway state, and platform information are required. The unchanged gateway supports authenticated GET `/v1/runs/{run_id}` only for exact known IDs, not a run-list endpoint. For each unresolved recent `plan_delivery_log.hermes_run_id`, retain `{run_id,http_status,status,captured_at}`; only actual HTTP200 completed/failed/cancelled is terminal. HTTP404 is unknown, not success. `idle-ledger.sql` is an optional fixed2s/200-row read-only query for this supplemental custody, not an action or an assertion that older/unrecorded runs cannot exist. Existing native identity/owner guards must wrap it.

No incoming-dispatch lock or freeze is implemented. These observations reduce avoidable interruption; they cannot exclude a new ordinary run between observation and Recreate rollout. If a run appears before dispatch, stop and preserve that observation instead of overriding it. Do not invoke `/v1/runs` or `/planner-runs`, pause/stop any run, or use an operator override for this qualification.

`emit.py --help` lists required concrete arguments. `--main-revision` must be an actual40-hex main revision; `--mcp-digest` an actual64-hex qualified image digest. The emitter refuses old/wrong pins and incomplete inputs, and its `plan.json` expires30s after emission. ROOT separately checks expiry and sends **one** `patch.json` to `argocd/verdify-prod-dark` as JSON Patch. UID/RV/terminal phase are atomically tested; an absent operation is protected by the same RV, and a present-null operation gets an explicit test. The patch clears stale operationState and sets the exact revision with prune:false and only the three resource selectors. It contains no hook, full-sync, create/delete, retry, or rollback command.

Immediately retain the accepted new operation and selector; require exactly those three tuples. Stop for added/missing resources, stale operation reuse, a different revision, patch rejection, or uncertainty. Retain original failure; do not automatically resend. At terminal success require exactly three matching resource results, actual new MCP Pods/source/image/ready state, and actual new Hermes UID with seed-config exit0 and installed source-owned SOUL/inventory/config hashes. A process restart clears old in-process schema state, but acceptance still requires fresh readiness/tool-discovery evidence. Do not claim a natural model cycle from gateway readiness or the separate bounded consumer harness.

Inverse coordinates are retained in the plan: original MCP `264f5fcb4da78a068c5bc64ec2b70d9efe122a473a1f92bb5d923565fb47a393`, old inventory revision `aaefffac230b`, old complete rendered objects and SOUL hash. If rollback is necessary, restore those source-owned pins/persona in a separate source revision and use a separately reviewed exact three-resource operation. Do not run the full-sync bootstrap or raw object patches merely to restore this release.
