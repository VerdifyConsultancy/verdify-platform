"""One cluster-local authenticated read; no provider key access or external URL."""
import hashlib,json,os,pathlib,signal,sys,time,urllib.request
SOURCE='b814f35e228fcb35c11593c47ea1e021e5fd73de'
MODULES={'/app/mcp/server.py': 'd8926ec1bca28c10cd0109b62238b395a3d233158879e51dbb073acdc7372a9f', '/app/verdify_schemas/realized_dryout.py': '7364d30ddea52fc5d5588f174b95de67c70a966224a5746c33f1838ba7586479', '/app/verdify_schemas/mcp_responses.py': 'edccf0a7740421aaeaa9b402e446c769fc1cd4b3fbfdc646e13cb83d1e3b82ee'}
DISPOSITIONS=('effective','ineffective','blocked','insufficient_evidence')
class Refusal(Exception):pass
def require(ok,code):
 if not ok:raise Refusal(code)
def digest(b):return hashlib.sha256(b).hexdigest()
def encoded(v):return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def emit(kind,**kw):print(json.dumps({'kind':kind,**kw},sort_keys=True,allow_nan=False),flush=True)
def alarm(*_):raise Refusal('inner_deadline')
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*a,**kw):raise Refusal('redirect_refused')
def expected_summary(evidence, day):
    require(evidence.get("reader_contract_version") == 1 and evidence.get("night_date") == day and
            evidence.get("greenhouse_id") == "vallery", "evidence_scope")
    require(evidence.get("availability") in ("available", "no_episodes") and
            evidence.get("unavailable_reason") is None, "evidence_unavailable")
    summary = evidence.get("summary")
    require(isinstance(summary, dict), "summary_missing")
    episodes = summary.get("episodes")
    require(isinstance(episodes, list) and len(episodes) <= 500, "episode_shape")
    counts = {k: sum(e.get("dryout_disposition") == k for e in episodes) for k in DISPOSITIONS}
    require(counts == summary.get("dispositions") and sum(counts.values()) == len(episodes), "disposition_consistency")
    status = ("pending" if not episodes else "fail" if any(e.get("safety_gate_status") == "fail" for e in episodes)
              else "pass" if all(e.get("safety_gate_status") == "pass" for e in episodes) else "incomplete")
    require(status == summary.get("safety_gate_status"), "safety_consistency")
    return {"night_date": day, "availability": evidence["availability"], "episode_count": len(episodes),
            "dispositions": counts, "safety_gate_status": status,
            "daytime_dry_action_samples": summary.get("daytime_dry_action_samples"),
            "daytime_hold_admission_samples": summary.get("daytime_hold_admission_samples")}
def main():
 start=time.monotonic();phase='input';calls=0;signal.signal(signal.SIGALRM,alarm);signal.alarm(50)
 try:
  raw=sys.stdin.buffer.read(4097);require(len(raw)<=4096,'input_cap');packet=json.loads(raw);day=packet['target_date']
  require(set(packet)=={'schema','target_date','mcp_baked_git_sha','mcp_source_sha256'} and packet['schema']=='verdify-iris-http-only-read-v1','packet_shape')
  require(day in ('2026-10-04','2026-10-16') and packet['mcp_baked_git_sha']==SOURCE and packet['mcp_source_sha256']==MODULES,'packet_scope')
  require(os.environ.get('VERDIFY_GIT_SHA')==SOURCE and os.environ.get('MCP_HTTP_PORT','8000')=='8000','runtime_source')
  actual={p:digest(pathlib.Path(p).read_bytes()) for p in MODULES};require(actual==MODULES,'source_hash')
  token=os.environ['VERDIFY_MCP_TOKEN_IRIS'];require(bool(token),'iris_token_absent')
  opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())
  def rpc(ident,method,params):
   nonlocal calls
   require(method in ('initialize','tools/list','tools/call'),'rpc_method')
   if method=='tools/call':
    require(calls==0 and params=={'name':'scorecard','arguments':{'target_date':day,'include_realized_dryout':True}},'only_exact_scorecard_read');calls+=1
   data=encoded({'jsonrpc':'2.0','id':ident,'method':method,'params':params})
   req=urllib.request.Request('http://127.0.0.1:8000/mcp',data=data,headers={'Accept':'application/json, text/event-stream','Content-Type':'application/json','Authorization':'Bearer '+token})
   with opener.open(req,timeout=35 if method=='tools/call' else 5) as response:
    require(response.status==200,'http_status');body=response.read(262145);require(len(body)<=262144,'response_cap')
   try:value=json.loads(body)
   except ValueError:
    rows=[json.loads(line[6:]) for line in body.splitlines() if line.startswith(b'data: ')];require(len(rows)==1,'sse_shape');value=rows[0]
   require('result' in value and not value['result'].get('isError',False),'mcp_result_error');return value['result']
  emit('source_admitted',packet_sha256=digest(raw),baked_sha=SOURCE,source_sha256=actual,target_date=day)
  phase='discovery';rpc(1,'initialize',{'protocolVersion':'2025-03-26','capabilities':{},'clientInfo':{'name':'verdify-iris-http-only-qualification','version':'1'}})
  tools=rpc(2,'tools/list',{})['tools'];selected=[t for t in tools if t['name']=='scorecard'];require(len(tools)==23 and len(selected)==1 and not any(t['name']=='outcome_kpi' for t in tools),'iris_tool_inventory')
  tool=selected[0];prop=tool['inputSchema']['properties']['include_realized_dryout'];require(prop.get('type')=='boolean' and prop.get('default') is False and 'include_realized_dryout' not in tool['inputSchema'].get('required',[]),'optional_bool_schema')
  emit('actual_tool_discovery',scorecard=tool,iris_tool_names=sorted(t['name'] for t in tools))
  arguments={'target_date':day,'include_realized_dryout':True};emit('read_requested',arguments=arguments);phase='actual_scorecard'
  result=rpc(3,'tools/call',{'name':'scorecard','arguments':arguments})
  texts=[x['text'] for x in result.get('content',[]) if x.get('type')=='text'];require(len(texts)==1,'single_scorecard_payload');evidence=json.loads(texts[0])['realized_solar_night_dryout'];summary=expected_summary(evidence,day)
  emit('actual_scorecard_response',result=result,result_sha256=digest(encoded(result)),evidence_summary=summary)
  require({p:digest(pathlib.Path(p).read_bytes()) for p in MODULES}==MODULES,'source_changed')
  emit('complete',status='IRIS_HTTP_ONLY_READ_PASSED',actual_scorecard_calls=calls,provider_calls=0,external_http_calls=0,other_tools_dispatched=0,retries=0,elapsed_seconds=time.monotonic()-start,natural_cycle_verified=False,model_interpretation_verified=False,whole_issue_acceptance=False)
  return 0
 except Exception as e:
  emit('failed',status='FAILED',phase=phase,code=str(e) if isinstance(e,Refusal) else type(e).__name__,actual_scorecard_calls=calls,provider_calls=0,external_http_calls=0,retries=0,raw_error_values_retained=False);return 1
 finally:signal.alarm(0)
if __name__=='__main__':raise SystemExit(main())
