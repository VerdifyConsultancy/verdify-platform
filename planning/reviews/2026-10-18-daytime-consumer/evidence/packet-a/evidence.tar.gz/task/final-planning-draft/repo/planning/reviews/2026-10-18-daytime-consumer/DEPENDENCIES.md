# Native dependency conformance — draft

[[PENDING_FINAL_GRAPH]]

The actual before-publication snapshot at 2026-10-18T19:47:49.343562+00:00 is MATCH at b814f35e: 47 open issues, 143 open acceptance clauses, 26 local plus HA #878 → #981 active edges, 24 closed predecessor records; parent/open-subissue links match and captured graphs are acyclic. Before receipt SHA256: ca988ac58932446abc9ecea50f25f19767a3b99ebdfa5a396118bfa207952696. ROOT must replace this explicit pending final-publication graph draft with the actual final receipt and projection. No edge/state change is proposed.
