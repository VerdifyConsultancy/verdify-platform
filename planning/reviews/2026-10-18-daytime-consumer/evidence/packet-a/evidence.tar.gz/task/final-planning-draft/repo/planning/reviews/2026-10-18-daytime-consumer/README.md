# Daytime coverage and ordinary realized-outcome consumption — 2026-10-18

This checkpoint preserves an incomplete daytime result and prepares a bounded ordinary Iris reader. Both #410 and #775 remain open. The source changes, focused checks and exact-source full native validation gate are complete. Selected-image CI completion, delivery, HTTP, schema refresh and model steps listed below remain **pending**, not accepted runtime evidence.

## Actual recorded daytime result

ROOT executed one bounded read-only assessment, independently checked against the installed migration 277 clock/classifier and the complete selected stored input. It changed no historical data.

| Solar day | Expected minute buckets | Valid recorded minutes | Missing clock buckets | Known held admission | Ordinary dehumidification | Complete-recorded-daytime zero |
|---|---:|---:|---:|---:|---:|---|
| 2026-10-16 | 669 | 644 (96.263079%) | 25 | 0 | 12 | NULL — incomplete |
| 2026-10-17 | 666 | 643 (96.546547%) | 23 | 0 | 2 | NULL — incomplete |

There are **48 distinct missing clock buckets**, not 96: climate and action coverage share those gaps. Among observed minutes there were no unknown held classifications or missing explicit hold markers. The longest consecutive gaps were three and one buckets respectively. These facts do not measure continuous controller outage duration or prove the unrecorded physical state. The ingestor stores 60-second plus selected state-change snapshots, defaults absent relay equipment to false, and has no per-relay freshness record. Complete typed rows do not prove every controller tick.

No interpolation, synthetic backfill, resampling, zero substitution or historical alteration was performed. #410's complete daytime absence criterion remains unaccepted. A future qualifying result needs an explicit observation/freshness contract and a prospectively collected complete recorded window.

## Accepted getter evidence reused

[The installed getter repair](../2026-10-18-getter-timeout-fix/README.md) remains accepted at its original scope. Actual ordinary-role calls returned October 16 with zero rows/pending in 11.816649 seconds, and October 4 with four equal 46-column rows in 11.269874 seconds (custom plan) and 4.966761 seconds (generic plan). Two rows are complete/ineffective and two incomplete/insufficient-evidence; none is effective. The unchanged product fence is 15 seconds. The earlier 3.174204-second clone candidate is not an installed-production timing.

The twenty native full-row synthetic parity cases, 2,673 genuine clone readback relations, installed ledger/seal/receipt, prior runtime receipts and original failures are retained. This follow-up does not rerun or relabel that repair.

## Ordinary reader source

Source `b814f35e228fcb35c11593c47ea1e021e5fd73de` adds `scorecard(target_date, include_realized_dryout=False)`. Existing calls remain unchanged in cost. An explicit opt-in requests exactly one selected solar night using the same explicit date as the night start; this is distinct from the scorecard's calendar-day metrics. The requested night crosses midnight.

The existing getter read is READ ONLY, uses at most the current configured 15-second budget and returns all 46 original columns. A 501-row sentinel rejects more than 500 episodes; a 64-KiB nested-evidence cap rejects oversized responses. Neither refusal truncates data or converts it to a positive result. Legitimate NULLs, episode dispositions, confounds and incomplete evidence are retained. Empty rows and all-null daytime counts remain unknown, rather than invented zero. The shared summary preserves `fail` dominance, requires every explicit `pass` for safety pass, and otherwise retains incomplete or empty/pending status. Safety status is not effectiveness or crop safety.

The optional field uses the existing Iris-authorized scorecard. The inventory remains 23 tools; `outcome_kpi` remains admin-only. Available identities are Iris and observer; no positive admin dispatch is claimed or required for this ordinary route. There is no DB schema, getter, ACL, audience or credential change. Only MCP needs promotion for this source change; selecting five build profiles does not authorize five promotions or a migrate hook change.

Focused source checks passed: 37 shared/new projection cases, 32 existing scorecard/response cases (one live case intentionally excluded), Ruff/format and shell syntax. Science independently checked field/NULL/disposition and refusal semantics. The exact native validation Pod `verdify-platform-ci-bgf2f-validate-2838858741` (UID `28339d8a-8f80-4d8c-a2d6-15ed047c00e3`, node6) completed at 19:57:05 UTC with `ALL GATES GREEN`. Its init, fetch-validate-context, main and wait containers each exited zero with no restarts. Full log SHA256: `6bb40e76dfc23aeabb5b8373bf2c64295968ba32a44e64623612390439986f81` (38,669 bytes). The source-gate receipt SHA256 is `744e10862d6a65d1d9c2303e12967f6518383416766cf53db83e532c0a586f59`. This does not claim completion of all selected image builds or any runtime rollout.

## Intended consumer and schema refresh

Source inspection of the captured installed Hermes client found that the periodic `list_tools` keepalive discards its response, reconnect alone does not re-register existing tool schemas, and ordinary rediscovery skips registered servers. A separate discovery process would not prove the existing gateway has the new field.

The prepared SOUL instruction asks ordinary non-experiment SUNRISE/SUNSET work to opt in once for a prior completed solar night and reuse the response. It preserves negative/incomplete/unavailable outcomes and forbids treating empty evidence as zero or making unsupported crop claims. The owning generator produces inventory revision `5733c1c6b35d`; the source draft changes only SOUL, its generated inventory payload and the existing revision annotation. Its four focused inventory tests passed. Integration and the source-owned fresh Hermes registration remain pending.

The captured gateway API always creates agents from configured full toolsets and does not enforce a per-request tool allowlist. Therefore a prompt alone is insufficient to make a full gateway run action-free. The planned qualification is one actual Iris-authenticated scorecard read followed by separately bounded, tool-disabled model interpretation. Even a successful result proves this bounded route, not a natural operating cycle, a full gateway run, controller action or physical benefit.

## Pending actual delivery receipts

- [[PENDING_SOURCE_IMAGE_CI]] — `verdify-platform-ci-bgf2f`, UID `f2083616-e793-4994-bd3b-9a48b1fbb376`, source `b814f35e`. Selected profiles: api, mcp, ingestor, setpoint-server and lab-publisher. The source validation stage passed; whole Workflow/image publication is not asserted by the retained source-gate receipt.
- [[PENDING_MCP_RELEASE_AND_RUNTIME]] — exact selected MCP image/pin, intended accepted source and actual runtime readback; no inferred deployment from the merge or build.
- [[PENDING_IRIS_INVENTORY_REFRESH]] — accepted SOUL/inventory source, fresh Hermes identity and initial registration; revision draft `5733c1c6b35d` is not live proof.
- [[PENDING_IRIS_HTTP_READS]] — actual existing-Iris opt-in reads, all fields/dispositions/NULLs and unchanged authorization/inventory.
- [[PENDING_BOUNDED_MODEL_CONSUMPTION]] — separate restricted model interpretation matched to actual responses, with its limits and failures retained.
- [[PENDING_FINAL_GRAPH]] — final source/publication-bound native conformance.

Replace each token only with its actual scoped receipt and outcome. A refusal, timeout or incomplete result must remain visible; no pending item implies success.

## Planning and remaining work

The retained 19:47:49 UTC graph at `b814f35e` is MATCH: **47 open issues, 93 canonical records, 143 open acceptance clauses, 27 active edges** (26 local plus `jvallery/homeassistant#878 → #981`) and 24 closed predecessor records. Parent/open-subissue links match and the captured graph is acyclic. This is the before-publication snapshot, not the pending final graph.

No acceptance clause, issue state, parent, dependency, priority or effort estimate changes here. The S3B 40-hour budget, selected 22–34h estimates and at least six-hour reserve remain planning values, not measured effort or remaining hours.

1. Finish and verify the bounded consumer delivery/readback above, preserving all negative, incomplete and empty evidence.
2. Specify a supported observation/freshness contract and collect a prospective complete recorded daytime window without rewriting the incomplete October 16/17 history.
3. Observe intended ordinary planner consumption in a natural operating cycle separately from the bounded qualification.
4. Advance authentic sensing, physical-efficacy and crop-safety work only on its own evidence. No controller tuning, universal VPD target, OTA or device action follows from this packet.

#410 remains open: its solar/evidence semantics are preserved, complete recorded daytime absence remains unknown, and any bounded consumer proof is narrower than natural use or physical efficacy. #775 remains open as the campaign roll-up. No new approval or credential prerequisite is introduced.

## Retained receipt index

The accompanying draft evidence index binds source/preparation checks, the actual daytime assessment and the graph-before readback. Original runtime/failure histories remain in their owning custody. Public evidence should expose scoped results and hashes, not credentials, raw private rows or unrelated estate state.
