import subprocess,json,pathlib,hashlib
b=pathlib.Path('/private/tmp/verdify-daytime-consumer-20261018/hermes-mcp-source');b.mkdir(exist_ok=False)
driver='''import pathlib,json,hashlib
root=pathlib.Path('/opt/hermes');paths=sorted((root/'tools').glob('*mcp*.py'));assert paths and len(paths)<10;rows=[]
for p in paths:
 raw=p.read_bytes();assert len(raw)<400000;rows.append({'path':str(p),'sha256':hashlib.sha256(raw).hexdigest(),'source':raw.decode()})
print(json.dumps(rows))
''';(b/'driver.py').write_text(driver);k=['kubectl','--kubeconfig','/Users/jason/.kube/config','--context','vallery','--request-timeout=20s','-n','verdify-prod'];p=json.loads(subprocess.check_output(k+['get','pod','verdify-hermes-iris-fcfb7dd98-7skpf','-o','json'],timeout=25));assert p['metadata']['uid']=='fc60d2ed-f4ba-4db1-bccc-59dcf3dec378';r=subprocess.run(k+['exec','-i',p['metadata']['name'],'-c','hermes-iris','--','python3','-'],input=driver.encode(),capture_output=True,timeout=25);(b/'stdout.json').write_bytes(r.stdout);(b/'stderr').write_bytes(r.stderr);assert r.returncode==0 and len(r.stdout)<1200000
rows=json.loads(r.stdout)
for x in rows:
 assert hashlib.sha256(x['source'].encode()).hexdigest()==x['sha256'];(b/pathlib.Path(x['path']).name).write_text(x['source'])
print(json.dumps([{k:x[k] for k in ['path','sha256']} for x in rows]))
