import pathlib,json,hashlib
root=pathlib.Path('/opt/hermes');paths=sorted((root/'tools').glob('*mcp*.py'));assert paths and len(paths)<10;rows=[]
for p in paths:
 raw=p.read_bytes();assert len(raw)<400000;rows.append({'path':str(p),'sha256':hashlib.sha256(raw).hexdigest(),'source':raw.decode()})
print(json.dumps(rows))
