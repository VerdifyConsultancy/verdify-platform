import subprocess,json,pathlib,datetime,concurrent.futures,hashlib
b=pathlib.Path('/private/tmp/verdify-daytime-consumer-20261018/initial');b.mkdir(exist_ok=False)
k=['kubectl','--kubeconfig','/Users/jason/.kube/config','--context','vallery','--request-timeout=15s']
def get(label,args):
 r=subprocess.run(k+args,capture_output=True,timeout=25);assert r.returncode==0,label
 j=json.loads(r.stdout);(b/(label+'.json')).write_bytes(r.stdout);return label,j
commands=[('application',['-n','argocd','get','application','verdify-prod-dark','-o','json']),('pods',['-n','verdify-prod','get','pods','-o','json']),('deployments',['-n','verdify-prod','get','deployments','-o','json']),('jobs',['-n','verdify-prod','get','jobs','-o','json']),('nodes',['get','nodes','-o','json']),('metrics',['get','--raw','/apis/metrics.k8s.io/v1beta1/nodes']),('limits',['-n','verdify-prod','get','limitrange','-o','json']),('quotas',['-n','verdify-prod','get','resourcequota','-o','json'])]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as p:data=dict(p.map(lambda x:get(*x),commands))
app=data['application'];assert app['metadata']['uid']=='cae977c6-dcd1-42aa-a526-dc9ff2bd8c69';assert not app.get('operation') and app['status'].get('operationState',{}).get('phase')!='Running'
assert not any(j.get('status',{}).get('active') and j['metadata']['name'].startswith(('verdify-migrate','verdify-getter')) for j in data['jobs']['items'])
selected=[]
for p in data['pods']['items']:
 if p['metadata']['name']=='verdify-db-0' or p['metadata']['labels'].get('app.kubernetes.io/component') in ['mcp','ingestor','hermes-iris','api']:
  if p['status']['phase']=='Running':selected.append({'name':p['metadata']['name'],'uid':p['metadata']['uid'],'node':p['spec']['nodeName'],'containers':[{'name':c['name'],'image':c['image'],'imageID':c.get('imageID'),'ready':c['ready'],'restarts':c['restartCount']} for c in p['status']['containerStatuses']]})
nodes=[{'name':n['metadata']['name'],'unschedulable':n['spec'].get('unschedulable',False),'taints':n['spec'].get('taints',[]),'allocatable':{a:n['status']['allocatable'][a] for a in ['cpu','memory']},'conditions':{c['type']:c['status'] for c in n['status']['conditions']}} for n in data['nodes']['items']]
r={'status':'INITIAL_IDENTITIES_CAPTURED_NO_MUTATION','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'context':'vallery','namespace':'verdify-prod','application':{'sync':app['status']['sync'],'health':app['status']['health'],'last_operation_finished':app['status'].get('operationState',{}).get('finishedAt')},'selected_pods':selected,'nodes':nodes,'queries_planned':'finite bounded read-only SQL through owning DB script; HTTP through existing MCP Pod; no new workloads/identities'}
(b/'result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
