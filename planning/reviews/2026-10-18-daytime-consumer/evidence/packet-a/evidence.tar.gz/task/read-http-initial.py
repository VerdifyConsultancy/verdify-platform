import subprocess,json,pathlib,hashlib,datetime
b=pathlib.Path('/private/tmp/verdify-daytime-consumer-20261018/http-initial');b.mkdir(exist_ok=False)
driver=pathlib.Path('/private/tmp/verdify-getter-fix-20261018/runtime-after277-v2/http-driver.py').read_bytes();(b/'driver.py').write_bytes(driver)
expected={'verdify-mcp-67bdb8d8c8-dwfdm':'863f88e7-cc66-42d9-8a79-a78b7676e0ad','verdify-mcp-67bdb8d8c8-jzfrn':'c5c8b3d2-0b0f-474a-a4c1-1ed0fbb33095'}
k=['kubectl','--kubeconfig','/Users/jason/.kube/config','--context','vallery','--request-timeout=20s','-n','verdify-prod'];rows=[]
for pod,uid in expected.items():
 j=json.loads(subprocess.check_output(k+['get','pod',pod,'-o','json'],timeout=25));assert j['metadata']['uid']==uid and j['status']['containerStatuses'][0]['ready'];assert j['status']['containerStatuses'][0]['imageID'].endswith('@sha256:264f5fcb4da78a068c5bc64ec2b70d9efe122a473a1f92bb5d923565fb47a393')
 r=subprocess.run(k+['exec','-i',pod,'-c','mcp','--','python','-'],input=driver,capture_output=True,timeout=25);(b/(pod+'.stdout')).write_bytes(r.stdout);(b/(pod+'.stderr')).write_bytes(r.stderr);assert r.returncode==0
 value=json.loads(r.stdout);assert value['status']=='PASSED' and value['server_sha256']=='db8cb106eb397219750548c9ab9e0ecc2a740f741d6cf58720d040fc0437ed91' and value['readyz']['auth_audiences_configured']==['iris','observer'];rows.append({'pod':pod,'uid':uid,'ready':True,'iris_tools':len(value['iris_tools']),'admin_not_configured':True,'outcome_iris_denied':value['outcome_kpi_iris_denied'],'source_sha256':value['server_sha256']})
r={'status':'EXISTING_AUTH_ROUTES_VERIFIED','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'driver_sha256':hashlib.sha256(driver).hexdigest(),'results':rows,'no_auth_creation':True,'no_DB_analytical_queries':True};(b/'result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
