# Daytime coverage: verified, incomplete

ROOT's single read-only execution completed in0.517s with exit0. The independent parser reproduced the retained review exactly. Submitted SQL, complete8,236-byte output, target UID and output digest agree with the terminal receipt. Source classifier counts match the previous12/2 ordinary dehumidification minutes and zero held-admission minutes.

| Denver date | Expected solar-day minute buckets | Valid observed climate/action buckets | Missing both | Longest consecutive missing buckets | Ordinary dehumidification | Recorded held admission |
|---|---:|---:|---:|---:|---:|---:|
|2026-10-16|669|644|25|3|12|0|
|2026-10-17|666|643|23|1|2|0|

All observed daytime records have the checked typed relay state and explicit hold markers; unknown held classification is zero among those records. The48 missing buckets remain unknown. Consequently `measured_zero_for_complete_recorded_minutes` is **NULL on both dates**, and #410's complete daytime measured-zero acceptance remains unmet. The ordinary dehumidification distinction is supported by actual stored records.

These are clock-bucket coverage gaps: no stored climate/action row fell within each listed one-minute interval. They do not measure continuous telemetry outage duration or prove what the controller did between samples. The mostly isolated gaps do not establish a cause. The source's60-second scheduling plus selected change snapshots and absent per-relay freshness prevent continuous physical proof even from otherwise complete bucket coverage. No interpolation, resampling, historical backfill or default-to-zero repair is justified.

This closes the bounded daytime audit, not #410/#775. Preserve the full gap list and incomplete result. Further complete-day acceptance requires a supported observation/freshness contract and an authentic newly collected window; no repeated getter query or historical reinterpretation is needed. Authenticated MCP dispatch and intended planner consumption remain separate acceptance boundaries.

Native custody: `../daytime-native-01/{stdout,result.json,verified.json}`. Exact hashes and independent checks: `native-acceptance-review.json`. No native operation or source-repository change was performed by this review lane.
