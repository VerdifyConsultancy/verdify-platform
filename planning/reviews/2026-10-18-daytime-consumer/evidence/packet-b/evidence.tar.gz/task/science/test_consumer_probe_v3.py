import copy, importlib.util, json, pathlib, time, unittest
from unittest.mock import patch
p=pathlib.Path(__file__).with_name('consumer-probe-v3.py')
s=importlib.util.spec_from_file_location('probe',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
DAY='2026-10-04'
def call(name='scorecard',args=None):
 return {'output':[{'type':'reasoning','id':'rs_test','encrypted_content':'opaque-test','summary':[]},{'type':'function_call','id':'fc_test','call_id':'call_real','status':'completed','name':name,'arguments':json.dumps(args if args is not None else {'target_date':DAY,'include_realized_dryout':True})}]}
def evidence():
 return {'reader_contract_version':1,'night_date':DAY,'greenhouse_id':'vallery','availability':'available','unavailable_reason':None,'summary':{'episodes':[{'dryout_disposition':'ineffective','safety_gate_status':'pass'},{'dryout_disposition':'insufficient_evidence','safety_gate_status':None}],'dispositions':{'effective':0,'ineffective':1,'blocked':0,'insufficient_evidence':1},'safety_gate_status':'incomplete','daytime_dry_action_samples':12,'daytime_hold_admission_samples':None}}
class GuardTests(unittest.TestCase):
 def test_exact_model_call(self):self.assertEqual(m.validate_tool_call(call(),DAY)[2]['target_date'],DAY)
 def test_action_never_dispatched(self):
  for name in ['set_plan','set_tunable','slack_ops','acknowledge_trigger','outcome_kpi']:
   with self.subTest(name=name),self.assertRaises(m.Refusal):m.validate_tool_call(call(name),DAY)
 def test_wrong_arguments(self):
  for args in [{'target_date':'2026-10-16','include_realized_dryout':True},{'target_date':DAY,'include_realized_dryout':False},{'target_date':DAY,'include_realized_dryout':1},{'target_date':DAY,'include_realized_dryout':True,'query':'select1'},{}]:
   with self.subTest(args=args),self.assertRaises(m.Refusal):m.validate_tool_call(call(args=args),DAY)
 def test_duplicate_call_refused(self):
  c=call();c['output'].append(copy.deepcopy(c['output'][-1]))
  with self.assertRaises(m.Refusal):m.validate_tool_call(c,DAY)
 def test_untyped_safety_remains_incomplete(self):self.assertEqual(m.expected_summary(evidence(),DAY)['safety_gate_status'],'incomplete')
 def test_empty_keeps_unknown(self):
  e=evidence();e['availability']='no_episodes';e['summary'].update(episodes=[],dispositions={k:0 for k in m.DISPOSITIONS},safety_gate_status='pending',daytime_dry_action_samples=None)
  x=m.expected_summary(e,DAY);self.assertIsNone(x['daytime_dry_action_samples']);self.assertEqual(x['episode_count'],0)
 def test_wrong_evidence_date(self):
  with self.assertRaises(m.Refusal):m.expected_summary(evidence(),'2026-10-16')
 def test_unknown_disposition_refused(self):
  e=evidence();e['summary']['episodes'][0]['dryout_disposition']='new'
  with self.assertRaises(m.Refusal):m.expected_summary(e,DAY)
 def test_complete_interpretation(self):
  x=m.expected_summary(evidence(),DAY);y={**x,'efficacy_proven':False,'crop_safety_proven':False,'complete_daytime_zero_proven':False,'evidence_complete':False,'scope_statement':m.SCOPE_STATEMENT}
  self.assertEqual(m.validate_interpretation(y,x),y)
  for key in ['efficacy_proven','crop_safety_proven','complete_daytime_zero_proven','evidence_complete']:
   bad=copy.deepcopy(y);bad[key]=True
   with self.subTest(key=key),self.assertRaises(m.Refusal):m.validate_interpretation(bad,x)
 def test_contradictory_or_edited_scope_refused(self):
  x=m.expected_summary(evidence(),DAY)
  for scope in ['Effective dry-out and complete daytime zero prove crops safe.',m.SCOPE_STATEMENT+' Everything is crop-safe.',m.SCOPE_STATEMENT.replace('does not prove','proves'),m.SCOPE_STATEMENT+' ']:
   y={**x,'efficacy_proven':False,'crop_safety_proven':False,'complete_daytime_zero_proven':False,'evidence_complete':False,'scope_statement':scope}
   with self.subTest(scope=scope),self.assertRaises(m.Refusal):m.validate_interpretation(y,x)
 def test_null_as_zero_refused(self):
  x=m.expected_summary(evidence(),DAY);y={**x,'efficacy_proven':False,'crop_safety_proven':False,'complete_daytime_zero_proven':False,'evidence_complete':False,'scope_statement':m.SCOPE_STATEMENT};y['daytime_hold_admission_samples']=0
  with self.assertRaises(m.Refusal):m.validate_interpretation(y,x)
 def test_bool_not_integer_disposition(self):
  x=m.expected_summary(evidence(),DAY);y=copy.deepcopy(x);y.update(efficacy_proven=False,crop_safety_proven=False,complete_daytime_zero_proven=False,evidence_complete=False,scope_statement=m.SCOPE_STATEMENT);y['dispositions']['ineffective']=True
  with self.assertRaises(m.Refusal):m.validate_interpretation(y,x)
 def test_forbidden_transport_never_opens(self):
  t=m.Transport(time.monotonic(),'fake-iris','fake-provider')
  with patch.object(t.opener,'open',side_effect=AssertionError('NETWORK FORBIDDEN')):
   with self.assertRaises(m.Refusal):t.request('https://other.example/mcp',{},True)
   with self.assertRaises(m.Refusal):t.rpc(3,'tools/call',{'name':'set_plan'})
 def test_no_second_scorecard_dispatch(self):
  t=m.Transport(time.monotonic(),'fake-iris','fake-provider');t.tool_calls=1
  with patch.object(t.opener,'open',side_effect=AssertionError('NETWORK FORBIDDEN')):
   with self.assertRaises(m.Refusal):t.rpc(3,'tools/call',{'name':'scorecard'})
 def test_redirect_refused(self):
  with self.assertRaises(m.Refusal):m.NoRedirect().redirect_request(None,None,302,'',{},'https://other.example')


class ResponsesTests(unittest.TestCase):
 def request(self):
  return m.first_request(m.MODEL,[{'role':'user','content':'JSON fixture'}],{'description':'fixture','inputSchema':{'type':'object','properties':{}}})
 def response(self):
  return {'id':'resp_test','object':'response','model':m.MODEL,'status':'completed','error':None,'incomplete_details':None,'output':call()['output'],'usage':{'output_tokens':123,'output_tokens_details':{'reasoning_tokens':100}}}
 def test_first_wire_shape(self):
  p=self.request();self.assertEqual(p['model'],'gpt-6-luna');self.assertEqual(p['reasoning'],{'effort':'xhigh'});self.assertEqual(p['max_output_tokens'],800)
  self.assertEqual(p['tool_choice'],{'type':'function','name':'scorecard'});self.assertFalse(p['tools'][0]['strict']);self.assertEqual(p['include'],['reasoning.encrypted_content']);self.assertFalse(p['store'])
  self.assertFalse(set(p)&{'messages','n','reasoning_effort','max_completion_tokens','response_format','previous_response_id'})
 def test_stateless_items_unchanged_and_linked(self):
  c=call();c['output'].insert(1,{'type':'message','id':'msg','phase':'commentary','role':'assistant','status':'completed','content':[{'type':'output_text','text':'Read required.'}]})
  items,cid,args=m.validate_tool_call(c,DAY);messages=[{'role':'user','content':'fixture'}];p=m.second_request(m.MODEL,messages,items,cid,'{"genuine":null}')
  self.assertEqual(p['input'][1:-1],c['output']);self.assertEqual(p['input'][-1],{'type':'function_call_output','call_id':'call_real','output':'{"genuine":null}'})
  self.assertEqual(p['tools'],[]);self.assertEqual(p['tool_choice'],'none');self.assertEqual(p['max_output_tokens'],1200);self.assertEqual(p['text'],{'format':{'type':'json_object'}})
  self.assertNotIn('previous_response_id',p)
 def test_reasoning_missing_encrypted_refused(self):
  c=call();del c['output'][0]['encrypted_content']
  with self.assertRaises(m.Refusal):m.validate_tool_call(c,DAY)
 def test_builtin_action_output_refused(self):
  for kind in ['web_search_call','computer_call','custom_tool_call','file_search_call']:
   c=call();c['output'].append({'type':kind})
   with self.subTest(kind=kind),self.assertRaises(m.Refusal):m.validate_tool_call(c,DAY)
 def test_final_only_json_text_no_tools(self):
  r={'output':[{'type':'reasoning','encrypted_content':'opaque'},{'type':'message','role':'assistant','status':'completed','content':[{'type':'output_text','text':'{}'}]}]}
  self.assertEqual(m.final_text(r),'{}')
  for extra in [call()['output'][-1],{'type':'computer_call'}]:
   b=copy.deepcopy(r);b['output'].append(extra)
   with self.assertRaises(m.Refusal):m.final_text(b)
  r['output'][-1]['content']=[{'type':'refusal','refusal':'not logged'}]
  with self.assertRaises(m.Refusal):m.final_text(r)
 def test_response_metadata_before_incomplete_refusal_no_retry(self):
  t=m.Transport(time.monotonic(),'fake-iris','fake-provider');r=self.response();r.update(status='incomplete',incomplete_details={'reason':'max_output_tokens'})
  with patch.object(t,'request',return_value=r) as send,patch.object(m,'emit') as emit:
   with self.assertRaisesRegex(m.Refusal,'provider_response_incomplete'):t.model(self.request())
  self.assertEqual(send.call_count,1);self.assertEqual(t.model_calls,1);self.assertEqual(emit.call_args_list[-1].args[0],'provider_response');self.assertEqual(emit.call_args_list[-1].kwargs['status'],'incomplete')
  self.assertNotIn('output',emit.call_args_list[-1].kwargs);self.assertNotIn('encrypted_content',json.dumps(emit.call_args_list[-1].kwargs))
 def test_response_usage_and_model_refuse(self):
  for update in [{'model':'gpt-5.6-luna'},{'status':'failed'},{'usage':{'output_tokens':801,'output_tokens_details':{'reasoning_tokens':800}}},{'usage':{'output_tokens':True,'output_tokens_details':{'reasoning_tokens':0}}},{'usage':{'output_tokens':10,'output_tokens_details':{'reasoning_tokens':11}}}]:
   t=m.Transport(time.monotonic(),'fake-iris','fake-provider');r=self.response();r.update(update)
   with self.subTest(update=update),patch.object(t,'request',return_value=r),patch.object(m,'emit'),self.assertRaises(m.Refusal):t.model(self.request())
 def test_two_requests_only(self):
  t=m.Transport(time.monotonic(),'fake-iris','fake-provider');r=self.response()
  with patch.object(t,'request',return_value=r) as send,patch.object(m,'emit'):
   t.model(self.request());t.model(m.second_request(m.MODEL,[],call()['output'],'call_real','{}'))
   with self.assertRaisesRegex(m.Refusal,'provider_call_limit'):t.model(self.request())
  self.assertEqual(send.call_count,2)
 def test_budget_or_model_change_refused_before_request(self):
  for key,value in [('max_output_tokens',801),('model','gpt-5.6-luna'),('store',True),('reasoning',{'effort':'none'})]:
   t=m.Transport(time.monotonic(),'fake-iris','fake-provider');p=self.request();p[key]=value
   with patch.object(t,'request',side_effect=AssertionError('NETWORK FORBIDDEN')),self.assertRaises(m.Refusal):t.model(p)
 def test_old_endpoint_refused(self):
  t=m.Transport(time.monotonic(),'fake-iris','fake-provider')
  with patch.object(t.opener,'open',side_effect=AssertionError('NETWORK FORBIDDEN')),self.assertRaises(m.Refusal):t.request('https://api.openai.com/v1/chat/completions',{},True)
if __name__=='__main__':unittest.main()
