# #410 daytime recorded coverage — prepared, not executed

ROOT runs `daytime-coverage.sql` once through the existing owner psql route, with its exact SQL digest and fresh Pod UID/image/postmaster captured before and after. Submit with `psql -X -q -A -t -v ON_ERROR_STOP=1 -f` (or stdin), never mixed `-c` because this file has psql commands. Recommended outer deadline45s and complete stdout cap1MiB. An error, timeout, truncated output, changed target or input cap is a refusal; preserve it, do not retry automatically.

The SQL fixes vallery and the completed America/Denver dates October16–17. It starts a read-only repeatable-read transaction, uses15s statement,500ms lock and15s idle deadlines, parallel0, work_mem4MiB and temp64MiB. It guards installed getter277 definition/body, exact solar phase/sunrise/sunset/Hermite definitions, their172/186/277 ledger source hashes, owner, PG16.11 and current postmaster. ROOT owns fresh Kubernetes admission; no new identity, ACL, route, Job, persistent state or deployment is needed. The owner-role selection is explicit; this is not ordinary MCP/planner role evidence.

The native query does not invoke the repaired getter, band models, setpoint history or episode computation. It covers all2880 minute starts in the48-hour window using the installed solar phase. Solar day means phase>=0 and<2. The clock guard refuses invalid phases. Climate/action input scans are time-bounded, each refuses a20,001st row; limit20,000 is an admission bound, never silent truncation. It preserves duplicate timestamp rows and computes the installed action classifier on each row before minute aggregation.

Output is exactly three JSON records: identical source/identity guards around one coverage object. The coverage object has two date summaries and every daytime missing/invalid/unknown minute. It separately reports raw sample counts, source admission minute counts, ordinary dehumidification minutes, missing climate/action minutes, invalid climate state and unknown held classification. The source's old counts12/2 dry minutes and zero held minutes are an explicit retained-evidence comparison, not hardcoded observations or a replacement for coverage. A mismatch must be investigated with the actual results retained.

The source coalesces absent hold flags and relay state to false. Supplemental checks prevent that default from proving measured zero: all nine relay values must be typed booleans; an otherwise potentially held DEHUM_VENT row needs an explicit complete hold/reason marker or a positive hold marker. Rows whose recorded action/relay prerequisites rule out held admission remain classifiable even when the optional hold marker is absent. The report separately counts all missing hold markers. Missing/invalid telemetry makes the complete-recorded-minute zero value NULL, never true.

Acceptance is deliberately scoped. Complete, known recorded daytime minutes with zero source-classified held admissions can prove zero **in the stored minute snapshots**. Ingestor records60-second snapshots plus selected state changes, defaults absent relay equipment false, and stores no individual relay freshness. Consequently this packet cannot prove continuous physical absence or every controller tick. Ordinary dehumidification remains a distinct observed action, not a safety/efficacy claim. It does not close #410/#775 or satisfy authenticated dispatch or planner consumption.

After ROOT saves complete stdout and its verified digest:

```text
python3 check_daytime_coverage.py /actual/custody/stdout --sha256 ACTUAL_SHA --out /actual/custody/coverage-review.json
```

This is a pure parser and integrity/claim check, not a native executor. Source and manifest reside beside it. No native execution was performed while preparing this packet.
