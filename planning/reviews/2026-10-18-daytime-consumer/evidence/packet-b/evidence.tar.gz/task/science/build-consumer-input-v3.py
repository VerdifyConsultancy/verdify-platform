#!/usr/bin/env python3
"""Prepare Responses inputs from an ACTUAL post-model runtime receipt; no native calls."""
import argparse, hashlib, json
from pathlib import Path
BASE=Path('/private/tmp/verdify-daytime-consumer-20261018')
CONFIG='2261f5c1a236202b3bfccedd82f1284f50ab27445767dcb09439a92a8d58b56b'
SOURCE='b814f35e228fcb35c11593c47ea1e021e5fd73de'
MODULES={'/app/mcp/server.py':'d8926ec1bca28c10cd0109b62238b395a3d233158879e51dbb073acdc7372a9f','/app/verdify_schemas/realized_dryout.py':'7364d30ddea52fc5d5588f174b95de67c70a966224a5746c33f1838ba7586479','/app/verdify_schemas/mcp_responses.py':'edccf0a7740421aaeaa9b402e446c769fc1cd4b3fbfdc646e13cb83d1e3b82ee'}
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def need(ok,code):
 if not ok:raise ValueError(code)
def validate_runtime(rt,terminal,raw,expected_sha):
 need(sha(raw)==expected_sha,'runtime_hash')
 need(rt['status']=='POST_ROLLOUT_RUNTIME_CUSTODY_PASSED' and rt['source_sha']==SOURCE,'runtime_status_source')
 need(terminal['status']=='PASSED' and terminal['verified_sha256']==sha(raw),'runtime_terminal')
 files=rt['hermes']['files'];need(files['status']=='HERMES_SOURCE_OWNED_FILES_MATCH','hermes_file_guard')
 need(all(files['file_sha256'].get(k)==CONFIG for k in ['/etc/verdify/hermes-config/config.yaml','/opt/data/config.yaml']),'new_effective_profile_required')
 need(rt['new_gateway_process_verified'] is True and len(rt['mcp'])==2,'runtime_processes')
 need(all(x['result']['source_sha']==SOURCE and x['result']['module_sha256']==MODULES for x in rt['mcp']),'mcp_source')
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--runtime-dir',type=Path,required=True);p.add_argument('--runtime-sha256',required=True);p.add_argument('--target-date',choices=['2026-10-04','2026-10-16'],required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
 need(not a.out.exists(),'fresh_output_required');raw=(a.runtime_dir/'verified.json').read_bytes();rt=json.loads(raw);terminal=json.loads((a.runtime_dir/'attempt-result.json').read_bytes());validate_runtime(rt,terminal,raw,a.runtime_sha256)
 prompt_path=BASE/'iris-source/stdout.json';prompt=json.loads(prompt_path.read_bytes())
 need(prompt['source_sha256']=='bf18a3e5cf8746803f1c5fe5ef7ce344a6e9b70b40b735d382aae83186f7b3f5' and prompt['preamble_sha256']=='c82f764d8322059e38aa7c4edb924ab4089e214c8e096c976123d9adefaba199','actual_prompt_pin')
 text=''.join(prompt['constants'][k] for k in ['_STANDING_DIRECTIVES','_PLANNER_CORE','_PLANNER_EXTENDED']);need(sha(text.encode())==prompt['preamble_sha256'],'actual_prompt_bytes')
 packet={'schema':'bounded-iris-consumer-input-v3','target_date':a.target_date,'mcp_baked_git_sha':SOURCE,'mcp_source_sha256':MODULES,'iris_source':prompt,'model_config':{'default':'gpt-6-luna','provider':'custom','base_url':'https://api.openai.com/v1','reasoning_effort':'xhigh','effective_config_sha256':CONFIG},'provider_api':'responses','runtime_verified_sha256':a.runtime_sha256,'runtime_hermes_uid':rt['hermes']['uid'],'custody_sha256':{str(prompt_path):sha(prompt_path.read_bytes()),str(a.runtime_dir/'verified.json'):sha(raw),str(a.runtime_dir/'attempt-result.json'):sha((a.runtime_dir/'attempt-result.json').read_bytes())}}
 a.out.write_text(json.dumps(packet,sort_keys=True,indent=2)+'\n');print(json.dumps({'status':'INPUT_PREPARED_NOT_EXECUTED','path':str(a.out),'sha256':sha(a.out.read_bytes())}))
if __name__=='__main__':main()
