import copy,importlib.util,json,pathlib,unittest
from unittest.mock import patch
p=pathlib.Path(__file__).with_name('run_bounded_consumers.py');s=importlib.util.spec_from_file_location('wrapper',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
OLD=json.loads((m.OLD/'stdout').read_bytes());FIELDS=set(OLD['rows'][0])
class Tests(unittest.TestCase):
 def test_original_complete_rows(self):
  self.assertEqual(len(m.canonical_rows(OLD['rows'],FIELDS)),4)
 def test_timestamp_normalization_only(self):
  rows=copy.deepcopy(OLD['rows'])
  for r in rows:
   for k in ('episode_started_at','episode_ended_at'):r[k]=r[k].replace('+00:00','Z')
  self.assertEqual(m.encode(m.canonical_rows(rows,FIELDS)),m.encode(m.canonical_rows(OLD['rows'],FIELDS)))
 def test_null_not_zero(self):
  rows=copy.deepcopy(OLD['rows']);r=rows[0];k=next(k for k,v in r.items() if v is None);r[k]=0
  self.assertNotEqual(m.encode(m.canonical_rows(rows,FIELDS)),m.encode(m.canonical_rows(OLD['rows'],FIELDS)))
 def test_negative_disposition_not_positive(self):
  rows=copy.deepcopy(OLD['rows']);rows[0]['dryout_disposition']='effective'
  self.assertNotEqual(m.encode(m.canonical_rows(rows,FIELDS)),m.encode(m.canonical_rows(OLD['rows'],FIELDS)))
 def test_missing_or_extra_field(self):
  for mode in ['missing','extra']:
   rows=copy.deepcopy(OLD['rows'])
   if mode=='missing':rows[0].pop('confound_reasons')
   else:rows[0]['fabricated']=True
   with self.assertRaises(m.Refusal):m.canonical_rows(rows,FIELDS)
 def test_missing_row_and_duplicate_retained(self):
  with self.assertRaises(m.Refusal):m.canonical_rows(OLD['rows'][:3],FIELDS)
  rows=copy.deepcopy(OLD['rows']);rows[1]=copy.deepcopy(rows[0])
  self.assertNotEqual(m.encode(m.canonical_rows(rows,FIELDS)),m.encode(m.canonical_rows(OLD['rows'],FIELDS)))
 def test_naive_time_refused(self):
  rows=copy.deepcopy(OLD['rows']);rows[0]['episode_started_at']='2026-10-05T04:47:00'
  with self.assertRaises(m.Refusal):m.canonical_rows(rows,FIELDS)
 def test_runtime_target_guard(self):
  path=m.BASE/'runtime-01/after-mcp-pods.stdout'
  if not path.exists():self.skipTest('runtime not yet available')
  pod=json.loads(path.read_bytes())['items'][0];m.ready(pod,pod)
  for field in ['uid','image','restart','ready']:
   changed=copy.deepcopy(pod)
   if field=='uid':changed['metadata']['uid']='changed'
   elif field=='image':changed['status']['containerStatuses'][0]['imageID']='wrong'
   elif field=='restart':changed['status']['containerStatuses'][0]['restartCount']=1
   else:changed['status']['conditions']=[{'type':'Ready','status':'False'}]
   with self.subTest(field=field),self.assertRaises(m.Refusal):m.ready(changed,pod)
if __name__=='__main__':
 with patch.object(m.subprocess,'Popen',side_effect=AssertionError('NO_NATIVE_CALL')):unittest.main()
