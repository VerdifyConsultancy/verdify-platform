import copy,importlib.util,json,pathlib,unittest
from unittest.mock import patch
p=pathlib.Path(__file__).with_name('run_bounded_consumers_v3.py');s=importlib.util.spec_from_file_location('wrapper',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
OLD=json.loads((m.OLD/'stdout').read_bytes());FIELDS=set(OLD['rows'][0])
class Tests(unittest.TestCase):
 def test_original_complete_rows(self):
  self.assertEqual(len(m.canonical_rows(OLD['rows'],FIELDS)),4)
 def test_timestamp_normalization_only(self):
  rows=copy.deepcopy(OLD['rows'])
  for r in rows:
   for k in ('episode_started_at','episode_ended_at'):r[k]=r[k].replace('+00:00','Z')
  self.assertEqual(m.encode(m.canonical_rows(rows,FIELDS)),m.encode(m.canonical_rows(OLD['rows'],FIELDS)))
 def test_null_not_zero(self):
  rows=copy.deepcopy(OLD['rows']);r=rows[0];k=next(k for k,v in r.items() if v is None);r[k]=0
  self.assertNotEqual(m.encode(m.canonical_rows(rows,FIELDS)),m.encode(m.canonical_rows(OLD['rows'],FIELDS)))
 def test_negative_disposition_not_positive(self):
  rows=copy.deepcopy(OLD['rows']);rows[0]['dryout_disposition']='effective'
  self.assertNotEqual(m.encode(m.canonical_rows(rows,FIELDS)),m.encode(m.canonical_rows(OLD['rows'],FIELDS)))
 def test_missing_or_extra_field(self):
  for mode in ['missing','extra']:
   rows=copy.deepcopy(OLD['rows'])
   if mode=='missing':rows[0].pop('confound_reasons')
   else:rows[0]['fabricated']=True
   with self.assertRaises(m.Refusal):m.canonical_rows(rows,FIELDS)
 def test_missing_row_and_duplicate_retained(self):
  with self.assertRaises(m.Refusal):m.canonical_rows(OLD['rows'][:3],FIELDS)
  rows=copy.deepcopy(OLD['rows']);rows[1]=copy.deepcopy(rows[0])
  self.assertNotEqual(m.encode(m.canonical_rows(rows,FIELDS)),m.encode(m.canonical_rows(OLD['rows'],FIELDS)))
 def test_naive_time_refused(self):
  rows=copy.deepcopy(OLD['rows']);rows[0]['episode_started_at']='2026-10-05T04:47:00'
  with self.assertRaises(m.Refusal):m.canonical_rows(rows,FIELDS)
 def test_runtime_target_guard(self):
  path=m.BASE/'runtime-01/after-mcp-pods.stdout'
  if not path.exists():self.skipTest('runtime not yet available')
  pod=json.loads(path.read_bytes())['items'][0];m.ready(pod,pod)
  for field in ['uid','image','restart','ready']:
   changed=copy.deepcopy(pod)
   if field=='uid':changed['metadata']['uid']='changed'
   elif field=='image':changed['status']['containerStatuses'][0]['imageID']='wrong'
   elif field=='restart':changed['status']['containerStatuses'][0]['restartCount']=1
   else:changed['status']['conditions']=[{'type':'Ready','status':'False'}]
   with self.subTest(field=field),self.assertRaises(m.Refusal):m.ready(changed,pod)

class ResponsesReceiptTests(unittest.TestCase):
 def setUp(self):
  import types
  self.probe=types.ModuleType('probe');exec(compile((m.BASE/'science/consumer-probe-v3.py').read_bytes(),'probe','exec'),self.probe.__dict__)
  self.r=m.Runner(types.SimpleNamespace(out=pathlib.Path('/tmp/not-used'),kubeconfig=pathlib.Path('/tmp/not-used')))
  self.r.probe=self.probe;self.r.fields=FIELDS;self.r.old_rows=m.canonical_rows(OLD['rows'],FIELDS)
  self.packet={'target_date':'2026-10-16','model_config':{'default':'gpt-6-luna','reasoning_effort':'xhigh'}};self.r.inputs={'oct16':m.encode(self.packet)}
  summary={'episodes':[],'dispositions':{k:0 for k in self.probe.DISPOSITIONS},'safety_gate_status':'pending','daytime_dry_action_samples':None,'daytime_hold_admission_samples':None}
  evidence={'reader_contract_version':1,'night_date':'2026-10-16','greenhouse_id':'vallery','availability':'no_episodes','unavailable_reason':None,'summary':summary}
  expected=self.probe.expected_summary(evidence,'2026-10-16');result={'content':[{'type':'text','text':json.dumps({'realized_solar_night_dryout':evidence})}]}
  req=lambda n:{'kind':'provider_request','ordinal':n,'api':'responses','model':'gpt-6-luna','reasoning_effort':'xhigh','max_output_tokens':800 if n==1 else 1200,'tools':['scorecard'] if n==1 else [],'tool_choice':{'type':'function','name':'scorecard'} if n==1 else 'none','retries':0,'store':False}
  res=lambda n:{'kind':'provider_response','api':'responses','status':'completed','incomplete_reason':None,'output_item_types':['reasoning','function_call' if n==1 else 'message'],'usage':{'output_tokens':100}}
  self.rows=[{'kind':'source_admitted','packet_sha256':m.sha(self.r.inputs['oct16']),'baked_sha':m.SOURCE,'source_sha256':m.MODULES,'scope':self.probe.LIMITS},{'kind':'actual_tool_discovery'},req(1),res(1),{'kind':'model_requested_read','arguments':{'target_date':'2026-10-16','include_realized_dryout':True}},{'kind':'actual_scorecard_response','result':result,'result_sha256':m.sha(m.encode(result)),'evidence_summary':expected},req(2),res(2),{'kind':'complete','status':'BOUNDED_ORDINARY_CONSUMER_PASSED','provider_api':'responses','model':'gpt-6-luna','provider_calls':2,'actual_scorecard_calls':1,'other_tools_dispatched':0,'retries':0,'output_tokens':200,'elapsed_seconds':1,'scope':self.probe.LIMITS,'interpretation':{**expected,'efficacy_proven':False,'crop_safety_proven':False,'complete_daytime_zero_proven':False,'evidence_complete':False,'scope_statement':self.probe.SCOPE_STATEMENT}}]
 def verify(self):return self.r.verify_case(b'\n'.join(m.encode(v) for v in self.rows),'oct16',self.packet)
 def test_responses_success_receipt(self):self.assertEqual(self.verify()['output_tokens'],200)
 def test_incomplete_refused(self):
  self.rows[3]['status']='incomplete'
  with self.assertRaises(m.Refusal):self.verify()
 def test_old_model_refused(self):
  self.rows[2]['model']='gpt-5.6-luna'
  with self.assertRaises(m.Refusal):self.verify()
 def test_final_action_refused(self):
  self.rows[7]['output_item_types'].append('function_call')
  with self.assertRaises(m.Refusal):self.verify()
 def test_unknown_day_not_zero(self):
  self.rows[-1]['interpretation']['daytime_hold_admission_samples']=0
  with self.assertRaises(self.probe.Refusal):self.verify()
 def test_hermes_replaced_or_not_ready_refused(self):
  hp=json.loads((m.BASE/'runtime-01/after-hermes-iris-pods.stdout').read_bytes())['items'][0];m.hermes_ready(hp,hp)
  for field in ['uid','ready','restart']:
   p=copy.deepcopy(hp)
   if field=='uid':p['metadata']['uid']='new'
   elif field=='ready':p['status']['conditions']=[]
   else:p['status']['containerStatuses'][0]['restartCount']=1
   with self.subTest(field=field),self.assertRaises(m.Refusal):m.hermes_ready(p,hp)
 def test_old_runtime_profile_cannot_make_new_input(self):
  import types
  b=types.ModuleType('builder');exec(compile((m.BASE/'science/build-consumer-input-v3.py').read_bytes(),'builder','exec'),b.__dict__)
  raw=(m.BASE/'runtime-01/verified.json').read_bytes();rt=json.loads(raw);terminal=json.loads((m.BASE/'runtime-01/attempt-result.json').read_bytes())
  with self.assertRaisesRegex(ValueError,'new_effective_profile_required'):b.validate_runtime(rt,terminal,raw,m.sha(raw))
if __name__=='__main__':
 with patch.object(m.subprocess,'Popen',side_effect=AssertionError('NO_NATIVE_CALL')):unittest.main()
