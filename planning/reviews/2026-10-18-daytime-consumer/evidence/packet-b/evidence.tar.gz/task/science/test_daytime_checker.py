import copy, unittest
from check_daytime_coverage import check, EXPECTED_FRAGMENT

def fixture():
    guard=dict(kind='daytime_identity_guard',passed=1,database='verdify',current_user='verdify',session_user='verdify',readonly='on',isolation='repeatable read',postmaster='2026-09-29T00:40:56.280382+00:00')
    days=[]
    for date,dry in [('2026-10-16',12),('2026-10-17',2)]:
        days.append(dict(local_date=date,expected_solar_day_minutes=720,observed_climate_minutes=720,fully_valid_climate_minutes=720,missing_climate_minutes=0,observed_action_minutes=720,missing_action_minutes=0,known_held_classification_minutes=720,unknown_held_classification_minutes=0,source_daytime_dry_admission_minutes=dry,source_daytime_held_admission_minutes=0,known_ordinary_daytime_dehumidification_minutes=dry,all_gap_minutes=[],recorded_minute_coverage_complete=True,measured_zero_for_complete_recorded_minutes=True))
    data=dict(kind='complete_daytime_recorded_coverage',complete_input_cap_guard=1,clock_minutes=2880,invalid_solar_minutes=0,source_action_fragment_sha256=EXPECTED_FRAGMENT,continuous_physical_absence_proven=False,source_per_relay_freshness_proven=False,full_issue_acceptance=False,raw_climate_count=2880,raw_action_count=2880,days=days,prior_observed_count_comparison={'matches':True})
    return [guard,data,copy.deepcopy(guard)]

class Tests(unittest.TestCase):
    def test_complete_snapshot_zero_is_not_physical_acceptance(self):
        result=check(fixture());self.assertTrue(result['complete_recorded_daytime_zero']);self.assertFalse(result['full_issue_acceptance']);self.assertFalse(result['continuous_physical_absence_proven'])
    def test_gap_yields_unknown(self):
        rows=fixture();d=rows[1]['days'][0];d.update(observed_climate_minutes=719,fully_valid_climate_minutes=719,missing_climate_minutes=1,all_gap_minutes=[{'bucket':'2026-10-16T15:00:00Z','missing_or_unknown':['missing_climate']}],recorded_minute_coverage_complete=False,measured_zero_for_complete_recorded_minutes=None)
        self.assertFalse(check(rows)['complete_recorded_daytime_zero'])
    def test_incomplete_false_zero_refused(self):
        rows=fixture();rows[1]['days'][0]['all_gap_minutes']=[{'bucket':'2026-10-16T15:00:00Z','missing_or_unknown':['missing_action']}]
        with self.assertRaises(ValueError):check(rows)
    def test_unknown_state_refused_as_complete(self):
        rows=fixture();rows[1]['days'][0]['known_held_classification_minutes']=719
        with self.assertRaises(ValueError):check(rows)
    def test_real_hold_retained_not_relabelled(self):
        rows=fixture();rows[1]['days'][0]['source_daytime_held_admission_minutes']=1;rows[1]['days'][0]['measured_zero_for_complete_recorded_minutes']=False;rows[1]['prior_observed_count_comparison']['matches']=False
        result=check(rows);self.assertFalse(result['complete_recorded_daytime_zero']);self.assertFalse(result['prior_observed_counts_match'])
    def test_extra_or_missing_record_refused(self):
        for rows in [fixture()[:2],fixture()+[fixture()[0]]]:
            with self.assertRaises(ValueError):check(rows)
    def test_changed_postmaster_refused(self):
        rows=fixture();rows[2]['postmaster']='changed'
        with self.assertRaises(ValueError):check(rows)
    def test_cap_or_solar_guard_refused(self):
        for key,value in [('complete_input_cap_guard',0),('invalid_solar_minutes',1),('clock_minutes',2879),('raw_action_count',20001)]:
            rows=fixture();rows[1][key]=value
            with self.assertRaises(ValueError):check(rows)
    def test_overclaim_refused(self):
        rows=fixture();rows[1]['continuous_physical_absence_proven']=True
        with self.assertRaises(ValueError):check(rows)

if __name__=='__main__':unittest.main()
