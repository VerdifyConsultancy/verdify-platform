#!/usr/bin/env python3
"""ROOT-only finite consumer execution. Preparation/import performs no native calls.
One Oct04 case on sorted MCP replica A, then Oct16 on replica B; never retry.
"""
import argparse,datetime as dt,hashlib,json,os,pathlib,signal,subprocess,time,types
BASE=pathlib.Path('/private/tmp/verdify-daytime-consumer-20261018')
OLD=pathlib.Path('/private/tmp/verdify-getter-fix-20261018/installed-oct04-custom-01')
SOURCE='b814f35e228fcb35c11593c47ea1e021e5fd73de'
IMAGE='ae8a367035a3ae8a06ab2384bc166f444b3decad0da21e5c70e53e76203d9c73'
PINS={
 'probe':('control/consumer-probe-v2.py','707cb308584f7ae340a09bd4952b4536912222a8b811ca87fb10859f004c8b9d'),
 'ci':('source-ci-verified.json','26a7ae9165c2de368320ec1f75916564119d7ea22126f844dcf006da869c14b2'),
 'oct04':('consumer-input-oct04.json','770f35a7c6a75f933f645dd2ceb63c0ea21862b098b44156c00df37ad4e8c1c9'),
 'oct16':('consumer-input-oct16.json','6add5d340687081099e0fdcc854ce904adb5f671f657ad061e82714bc7fb81e1')}
OLD_SHA='3cfc70df66dd6d95c4d2f4b59e2ee62a7be1a1752ac1a2424ce709680f62f487'
OLD_RECEIPT_SHA='bea41dfc30cd902e56257ecc62f7051db1e21cafd795994313a380a6bb9aaf16'
MODULES={'/app/mcp/server.py':'d8926ec1bca28c10cd0109b62238b395a3d233158879e51dbb073acdc7372a9f','/app/verdify_schemas/realized_dryout.py':'7364d30ddea52fc5d5588f174b95de67c70a966224a5746c33f1838ba7586479','/app/verdify_schemas/mcp_responses.py':'edccf0a7740421aaeaa9b402e446c769fc1cd4b3fbfdc646e13cb83d1e3b82ee'}
MAX_OUTPUT=2*1024*1024
class Refusal(Exception):pass
def need(ok,code):
 if not ok:raise Refusal(code)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def encode(v):return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def dump(path,v):path.write_bytes(json.dumps(v,sort_keys=True,indent=2,allow_nan=False).encode()+b'\n')
def read_json(path):return json.loads(path.read_bytes())
def fingerprint(p):
 return {'uid':p['metadata']['uid'],'owners':p['metadata'].get('ownerReferences',[]),'spec':p['spec'],
         'states':{k:p['status'].get(k,[]) for k in ('containerStatuses','initContainerStatuses')}}
def ready(p,expected):
 need(p['metadata']['name']==expected['metadata']['name'] and fingerprint(p)==fingerprint(expected),'pod_identity_spec_or_state_changed')
 need(not p['metadata'].get('deletionTimestamp') and p['status'].get('phase')=='Running' and
      any(c.get('type')=='Ready' and c.get('status')=='True' for c in p['status'].get('conditions',[])),'pod_not_ready')
 states=p['status'].get('containerStatuses',[]);spec=p['spec']['containers']
 need(len(states)==len(spec)>0 and {c['name'] for c in states}=={c['name'] for c in spec},'container_inventory')
 need(all(c.get('ready') is True and c.get('restartCount')==0 and c.get('state',{}).get('running') and not c.get('lastState') for c in states),'container_not_stable')
 main=[c for c in states if c['name']=='mcp'];declared=[c for c in spec if c['name']=='mcp']
 need(len(main)==len(declared)==1 and main[0]['imageID'].endswith('@sha256:'+IMAGE) and declared[0]['image'].endswith('@sha256:'+IMAGE),'actual_mcp_image')
 need(all(c.get('restartCount')==0 and c.get('state',{}).get('terminated',{}).get('exitCode')==0 for c in p['status'].get('initContainerStatuses',[])),'init_state')
def canonical_rows(rows,fields):
 need(isinstance(rows,list) and len(rows)==4,'oct04_four_rows')
 normalized=[]
 for row in rows:
  need(isinstance(row,dict) and set(row)==set(fields) and len(row)==46,'full46_inventory')
  r=dict(row)
  for name in ('episode_started_at','episode_ended_at'):
   v=dt.datetime.fromisoformat(r[name].replace('Z','+00:00'));need(v.tzinfo is not None,'aware_episode_timestamp')
   r[name]=v.astimezone(dt.timezone.utc).isoformat(timespec='microseconds')
  need(r['night_date']=='2026-10-04','oct04_row_date');normalized.append(r)
 return sorted(normalized,key=lambda r:encode(r))
SOURCE_GUARD='''import hashlib,json,os,pathlib,sys\nexpected=__MODULES__\ntry:\n actual={p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest() for p in expected}\n ok=actual==expected and os.environ.get("VERDIFY_GIT_SHA")=="__SOURCE__"\n print(json.dumps({"status":"SOURCE_MATCH" if ok else "FAILED","source_sha":"__SOURCE__","module_sha256":actual}))\n sys.exit(0 if ok else 1)\nexcept Exception as e:\n print(json.dumps({"status":"FAILED","error_type":type(e).__name__}));sys.exit(1)\n'''.replace('__MODULES__',repr(MODULES)).replace('__SOURCE__',SOURCE)
class Runner:
 def __init__(self,a):
  self.a=a;self.out=a.out;self.records=[];self.phase='preseal';self.owned=False;self.started=time.monotonic();self.results=[]
  self.k=['kubectl','--kubeconfig',str(a.kubeconfig),'--context','vallery','--request-timeout=15s','-n','verdify-prod']
 def command(self,label,args,timeout=20,stdin=None):
  self.phase=label;remaining=360-(time.monotonic()-self.started);need(remaining>0,'overall_deadline')
  out=self.out/(label+'.stdout');err=self.out/(label+'.stderr');start=time.monotonic();code=None;timed=False
  with out.open('xb') as sout,err.open('xb') as serr:
   p=subprocess.Popen(args,stdin=subprocess.PIPE if stdin is not None else subprocess.DEVNULL,stdout=sout,stderr=serr,start_new_session=True)
   try:p.communicate(input=stdin,timeout=min(timeout,remaining));code=p.returncode
   except (subprocess.TimeoutExpired,KeyboardInterrupt):
    timed=True
    try:os.killpg(p.pid,signal.SIGTERM)
    except ProcessLookupError:pass
    try:p.communicate(timeout=3)
    except subprocess.TimeoutExpired:
     try:os.killpg(p.pid,signal.SIGKILL)
     except ProcessLookupError:pass
     p.communicate(timeout=3)
    code=p.returncode
  ob=out.read_bytes();eb=err.read_bytes()
  r={'phase':label,'returncode':code,'timeout':timed,'seconds':time.monotonic()-start,
     'stdout_sha256':sha(ob),'stdout_bytes':len(ob),'stderr_sha256':sha(eb),'stderr_bytes':len(eb),'automatic_retries':0}
  self.records.append(r);dump(self.out/(label+'.receipt.json'),r)
  need(not timed,'command_timeout_unknown_native_completion');need(code==0,'command_nonzero');need(len(ob)<=MAX_OUTPUT and len(eb)<=MAX_OUTPUT,'output_limit');return ob
 def get_pods(self,label):
  v=json.loads(self.command(label,self.k+['get','pods','-l','app.kubernetes.io/component=mcp','-o','json']))
  need(len(v['items'])==2,'mcp_replica_count');actual={p['metadata']['name']:p for p in v['items']}
  need(set(actual)==set(self.expected_pods),'mcp_names_changed')
  for name,p in actual.items():ready(p,self.expected_pods[name])
  return actual
 def source_guard(self,label,pod):
  r=json.loads(self.command(label,self.k+['exec',pod,'-c','mcp','--','python','-c',SOURCE_GUARD],15))
  need(r.get('status')=='SOURCE_MATCH' and r.get('module_sha256')==MODULES,'source_guard')
 def app_guard(self,label):
  argv=['kubectl','--kubeconfig',str(self.a.kubeconfig),'--context','vallery','--request-timeout=15s','-n','argocd','get','application','verdify-prod-dark','-o','json']
  v=json.loads(self.command(label,argv));need(v['metadata']['uid']==self.runtime_app['metadata']['uid'] and not v.get('operation') and v['status']['sync']['status']=='Synced' and v['status']['sync']['revision']==self.runtime['release_sha'] and v['status']['health']['status']=='Healthy' and v['status']['operationState']['phase']=='Succeeded','application_drift')
 def verify_case(self,raw,key,packet):
  rows=[json.loads(x) for x in raw.decode().splitlines() if x.strip()]
  need([r.get('kind') for r in rows]==['source_admitted','actual_tool_discovery','provider_request','provider_response','model_requested_read','actual_scorecard_response','provider_request','provider_response','complete'],'phase_inventory')
  first,discovery,req1,res1,call,score,req2,res2,end=rows
  need(first['packet_sha256']==sha(self.inputs[key]) and first['baked_sha']==SOURCE and first['source_sha256']==MODULES,'native_input_source')
  need(call['arguments']=={'target_date':packet['target_date'],'include_realized_dryout':True},'actual_tool_args')
  need(req1['ordinal']==1 and req2['ordinal']==2 and req1['max_completion_tokens']==800 and req2['max_completion_tokens']==1200 and req1['tools']==['scorecard'] and req2['tools']==[] and req2['tool_choice']=='none','actual_provider_request_bounds')
  need(res1['finish_reason']=='tool_calls' and res2['finish_reason']=='stop','provider_terminal')
  need(all(r['model']==packet['model_config']['default'] and r['reasoning_effort']==packet['model_config']['reasoning_effort'] and r['retries']==0 and r['store'] is False for r in [req1,req2]),'provider_model_config')
  used=[r['usage']['completion_tokens'] for r in [res1,res2]];need(all(type(x)is int and x>=0 for x in used) and used[0]<=800 and used[1]<=1200,'token_bounds')
  result=score['result'];need(sha(encode(result))==score['result_sha256'] and not result.get('isError',False),'scorecard_result_digest')
  texts=[v['text'] for v in result['content'] if v['type']=='text'];need(len(texts)==1,'single_scorecard_payload')
  evidence=json.loads(texts[0])['realized_solar_night_dryout'];expected=self.probe.expected_summary(evidence,packet['target_date'])
  need(score['evidence_summary']==expected,'native_summary_consistency');self.probe.validate_interpretation(end['interpretation'],expected)
  need(end['status']=='BOUNDED_ORDINARY_CONSUMER_PASSED' and end['provider_calls']==2 and end['actual_scorecard_calls']==1 and end['other_tools_dispatched']==0 and end['retries']==0 and end['completion_tokens']==sum(used)<=2000 and end['elapsed_seconds']<=90,'native_completion')
  need(first['scope']==end['scope']==self.probe.LIMITS,'native_scope')
  comparison=None
  if key=='oct04':
   actual=canonical_rows(evidence['summary']['episodes'],self.fields);need(encode(actual)==encode(self.old_rows),'oct04_full46_historical_mismatch')
   comparison={'all46_exact_after_timestamp_normalization':True,'rows':4,'old_stdout_sha256':OLD_SHA,'canonical_rows_sha256':sha(encode(actual)),'same_database_snapshot_claimed':False}
  else:
   need(expected['availability']=='no_episodes' and expected['episode_count']==0 and expected['safety_gate_status']=='pending' and expected['daytime_dry_action_samples'] is None and expected['daytime_hold_admission_samples'] is None,'oct16_empty_unknown_regression')
  return {'date':packet['target_date'],'interpretation':end['interpretation'],'historical_row_comparison':comparison,'provider_calls':2,'scorecard_calls':1,'completion_tokens':sum(used),'native_elapsed_seconds':end['elapsed_seconds'],'native_stdout_sha256':sha(raw),'whole_issue_acceptance':False,'natural_cycle_verified':False}
 def run(self):
  need(not self.out.exists(),'fresh_output_required');self.out.mkdir(mode=0o700);self.owned=True
  self.inputs={k:(BASE/path).read_bytes() for k,(path,h) in PINS.items()}
  for k,(_,h) in PINS.items():need(sha(self.inputs[k])==h,'input_pin_'+k)
  rp=self.a.runtime_dir
  more={'runtime':(rp/'verified.json').read_bytes(),'runtime_terminal':(rp/'attempt-result.json').read_bytes(),'runtime_pods':(rp/'after-mcp-pods.stdout').read_bytes(),'runtime_app':(rp/'after-application.stdout').read_bytes(),'old_stdout':(OLD/'stdout').read_bytes(),'old_receipt':(OLD/'receipt.json').read_bytes()}
  self.inputs.update(more);need(sha(more['runtime'])==self.a.runtime_sha256,'runtime_receipt_pin')
  rt=json.loads(more['runtime']);self.runtime=rt
  need(rt['status']=='POST_ROLLOUT_RUNTIME_CUSTODY_PASSED' and rt['source_sha']==SOURCE and rt['mcp_digest']==IMAGE and rt['ci_receipt_sha256']==PINS['ci'][1],'runtime_admission')
  term=json.loads(more['runtime_terminal']);need(term['status']=='PASSED' and term['verified_sha256']==sha(more['runtime']),'runtime_terminal')
  for key,phase in [('runtime_pods','after-mcp-pods'),('runtime_app','after-application')]:
   rs=[r for r in rt['records'] if r['phase']==phase];need(len(rs)==1 and rs[0]['returncode']==0 and not rs[0]['timed_out'] and rs[0]['stdout_sha256']==sha(more[key]),'runtime_native_input_custody')
  self.runtime_app=json.loads(more['runtime_app']);self.expected_pods={p['metadata']['name']:p for p in json.loads(more['runtime_pods'])['items']}
  need(len(self.expected_pods)==2 and {p['metadata']['uid'] for p in self.expected_pods.values()}=={p['uid'] for p in rt['mcp']},'runtime_pod_inventory')
  for p in self.expected_pods.values():ready(p,p)
  need(all(x['result']['source_sha']==SOURCE and x['result']['module_sha256']==MODULES for x in rt['mcp']),'runtime_source_admission')
  ci=json.loads(self.inputs['ci']);need(ci['status']=='SOURCE_GATE_FIVE_BUILDS_AND_PIN_PUBLISHER_VERIFIED' and ci['source_revision']==SOURCE and ci['images']['mcp']['digest']=='sha256:'+IMAGE and ci['images']['mcp']['resolved-revision']==SOURCE,'ci_binding')
  need(sha(more['old_stdout'])==OLD_SHA and sha(more['old_receipt'])==OLD_RECEIPT_SHA,'historical_pins');old=json.loads(more['old_stdout']);oldr=json.loads(more['old_receipt'])
  need(old['passed'] is True and old['row_count']==4 and oldr['exit']==0 and oldr['stdout_sha256']==OLD_SHA and oldr['unchanged_container'] is True,'historical_accepted')
  self.fields=set(old['rows'][0]);self.old_rows=canonical_rows(old['rows'],self.fields)
  self.probe=types.ModuleType('reviewed_consumer_probe');exec(compile(self.inputs['probe'],str(BASE/PINS['probe'][0]),'exec'),self.probe.__dict__)
  names=sorted(self.expected_pods);assignments=[('oct04',names[0]),('oct16',names[1])]
  for key,pod in assignments:
   packet=json.loads(self.inputs[key]);need(packet['mcp_baked_git_sha']==SOURCE and packet['mcp_source_sha256']==MODULES and packet['target_date']==('2026-10-04' if key=='oct04' else '2026-10-16'),'packet_binding')
  for key,raw in self.inputs.items():(self.out/(key+'.input')).write_bytes(raw)
  (self.out/'run_bounded_consumers.py').write_bytes(pathlib.Path(__file__).read_bytes());(self.out/'source-guard.py').write_text(SOURCE_GUARD)
  dump(self.out/'attempt-start.json',{'status':'STARTED','source':SOURCE,'image':IMAGE,'runtime_verified_sha256':self.a.runtime_sha256,'input_sha256':{k:sha(v) for k,v in self.inputs.items()},'driver_sha256':sha(pathlib.Path(__file__).read_bytes()),'assignments':[{'case':key,'pod':pod,'uid':self.expected_pods[pod]['metadata']['uid']} for key,pod in assignments],'bounds':{'overall_seconds':360,'inner_seconds_each':90,'exec_seconds_each':105,'provider_calls_each':2,'scorecard_calls_each':1,'completion_tokens_each':2000,'output_bytes_each':MAX_OUTPUT},'automatic_retries':0})
  for key,pod in assignments:
   self.app_guard(key+'-before-app');self.get_pods(key+'-before-pods');self.source_guard(key+'-before-source',pod)
   packet=json.loads(self.inputs[key]);native_error=None;answer=None
   try:
    raw=self.command(key+'-native',self.k+['exec','-i',pod,'-c','mcp','--','python','-c',self.inputs['probe'].decode()],105,stdin=self.inputs[key])
    answer=self.verify_case(raw,key,packet)
   except Exception as e:native_error=e
   # Post-checks run even after a failed/timeout native attempt; never release another case on failure.
   post_error=None
   try:self.get_pods(key+'-after-pods');self.source_guard(key+'-after-source',pod);self.app_guard(key+'-after-app')
   except Exception as e:post_error=e
   dump(self.out/(key+'-case-result.json'),{'status':'PASSED' if native_error is None and post_error is None else 'FAILED','native_failure':str(native_error) if isinstance(native_error,Refusal) else type(native_error).__name__ if native_error else None,'post_failure':str(post_error) if isinstance(post_error,Refusal) else type(post_error).__name__ if post_error else None,'actual_result':answer,'pod':pod,'uid':self.expected_pods[pod]['metadata']['uid'],'automatic_retries':0})
   if native_error:raise native_error
   if post_error:raise post_error
   answer.update(pod=pod,uid=self.expected_pods[pod]['metadata']['uid']);self.results.append(answer)
  for key,(path,h) in PINS.items():need(sha((BASE/path).read_bytes())==h,'input_changed')
  need(sha((rp/'verified.json').read_bytes())==self.a.runtime_sha256,'runtime_receipt_changed')
  dump(self.out/'verified.json',{'status':'TWO_BOUNDED_ORDINARY_CONSUMERS_PASSED','source':SOURCE,'image':IMAGE,'cases':self.results,'automatic_retries':0,'provider_calls':4,'actual_scorecard_calls':2,'total_completion_tokens':sum(x['completion_tokens'] for x in self.results),'other_tools_dispatched':0,'all46_oct04_values_preserved':True,'daytime_complete_zero_proven':False,'natural_cycle_verified':False,'whole_issue_acceptance':False,'records':self.records})
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--runtime-dir',type=pathlib.Path,default=BASE/'runtime-01');p.add_argument('--runtime-sha256',required=True);p.add_argument('--out',type=pathlib.Path,required=True);p.add_argument('--kubeconfig',type=pathlib.Path,default=pathlib.Path('/Users/jason/.kube/config'));a=p.parse_args();r=Runner(a)
 try:
  r.run();result={'status':'PASSED','verified_sha256':sha((a.out/'verified.json').read_bytes()),'automatic_retries':0};code=0
 except Exception as e:
  result={'status':'FAILED','phase':r.phase,'error_type':type(e).__name__,'refusal_code':str(e) if isinstance(e,Refusal) else None,'automatic_retries':0,'records':r.records,'completed_cases':r.results};code=1
 if r.owned:dump(a.out/'attempt-result.json',result)
 print(json.dumps({k:v for k,v in result.items() if k not in ('records','completed_cases')},sort_keys=True));return code
if __name__=='__main__':raise SystemExit(main())
