#!/usr/bin/env python3
"""Pure review of ROOT's retained stdout; does not execute SQL or read credentials."""
import argparse, hashlib, json
from pathlib import Path
EXPECTED_DATES=['2026-10-16','2026-10-17']
EXPECTED_FRAGMENT='f2407ad0fa0825a7e58df5f97336936d75a7e83d34e2b89c00ff2e8f58c14231'
def check(records):
    if [r.get('kind') for r in records] != ['daytime_identity_guard','complete_daytime_recorded_coverage','daytime_identity_guard']:
        raise ValueError('incomplete_or_unexpected_result_inventory')
    before, data, after=records
    for r in [before,after]:
        if r.get('passed')!=1 or r.get('database')!='verdify' or r.get('current_user')!='verdify' or r.get('session_user')!='verdify' or r.get('readonly')!='on' or r.get('isolation')!='repeatable read':
            raise ValueError('identity_or_readonly_guard')
    if before['postmaster']!=after['postmaster']:raise ValueError('postmaster_changed')
    if data.get('complete_input_cap_guard')!=1 or data.get('clock_minutes')!=2880 or data.get('invalid_solar_minutes')!=0 or data.get('source_action_fragment_sha256')!=EXPECTED_FRAGMENT:
        raise ValueError('source_clock_or_cap_guard')
    if data.get('continuous_physical_absence_proven') is not False or data.get('source_per_relay_freshness_proven') is not False or data.get('full_issue_acceptance') is not False:
        raise ValueError('overclaimed_acceptance')
    for field in ['raw_climate_count','raw_action_count']:
        if type(data.get(field)) is not int or not 0<=data[field]<=20000:raise ValueError('raw_input_limit')
    days=data.get('days',[])
    if [d.get('local_date') for d in days]!=EXPECTED_DATES:raise ValueError('date_inventory')
    summaries=[]
    for d in days:
        n=d['expected_solar_day_minutes']
        if type(n)is not int or not 0<n<=1440:raise ValueError('invalid_solar_day_count')
        for field in ['observed_climate_minutes','fully_valid_climate_minutes','missing_climate_minutes','observed_action_minutes','missing_action_minutes','known_held_classification_minutes','unknown_held_classification_minutes','source_daytime_dry_admission_minutes','source_daytime_held_admission_minutes','known_ordinary_daytime_dehumidification_minutes']:
            if type(d.get(field))is not int or not 0<=d[field]<=n:raise ValueError('invalid_minute_count:'+field)
        if d['observed_climate_minutes']+d['missing_climate_minutes']!=n or d['observed_action_minutes']+d['missing_action_minutes']!=n:raise ValueError('minute_accounting')
        gaps=d['all_gap_minutes']
        if len(gaps)>n or len({g['bucket'] for g in gaps})!=len(gaps) or any(not g['missing_or_unknown'] for g in gaps):raise ValueError('gap_inventory')
        complete=(len(gaps)==0 and d['fully_valid_climate_minutes']==n and d['observed_action_minutes']==n and d['known_held_classification_minutes']==n)
        if d['recorded_minute_coverage_complete'] is not complete:raise ValueError('false_complete_coverage')
        zero=(d['source_daytime_held_admission_minutes']==0) if complete else None
        if d['measured_zero_for_complete_recorded_minutes'] is not zero:raise ValueError('false_measured_zero')
        summaries.append({'local_date':d['local_date'],'recorded_coverage':'complete' if complete else 'incomplete',
          'expected_solar_day_minutes':n,'missing_climate_minutes':d['missing_climate_minutes'],
          'missing_action_minutes':d['missing_action_minutes'],'unknown_held_classification_minutes':d['unknown_held_classification_minutes'],
          'source_daytime_held_admission_minutes':d['source_daytime_held_admission_minutes'],
          'known_ordinary_daytime_dehumidification_minutes':d['known_ordinary_daytime_dehumidification_minutes'],
          'measured_zero_for_complete_recorded_minutes':zero})
    expected_match=all(d['source_daytime_dry_admission_minutes']==(12 if d['local_date']=='2026-10-16' else 2) and d['source_daytime_held_admission_minutes']==0 for d in days)
    if data.get('prior_observed_count_comparison',{}).get('matches') is not expected_match:raise ValueError('prior_count_comparison_disagrees')
    return {'schema':'daytime-recorded-coverage-review-v1','result_integrity_passed':True,
      'prior_observed_counts_match':expected_match,'days':summaries,
      'complete_recorded_daytime_zero':all(d['measured_zero_for_complete_recorded_minutes'] is True for d in summaries),
      'continuous_physical_absence_proven':False,'full_issue_acceptance':False,
      'limits':['Source produces sampled state and lacks per-relay freshness; full minute coverage does not prove every controller tick.',
                'No authenticated MCP dispatch, planner consumption, crop-safety or daytime effectiveness proof.',
                'ROOT must bind submitted SQL, native target/admission, exit code and complete output custody separately.']}
def main():
    p=argparse.ArgumentParser();p.add_argument('stdout',type=Path);p.add_argument('--sha256',required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
    raw=a.stdout.read_bytes()
    if len(raw)>1048576 or hashlib.sha256(raw).hexdigest()!=a.sha256:raise SystemExit('stdout_size_or_digest_mismatch')
    rows=[json.loads(line) for line in raw.decode().splitlines() if line.lstrip().startswith('{')]
    result=check(rows);result['stdout_sha256']=a.sha256
    a.out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
if __name__=='__main__':main()
