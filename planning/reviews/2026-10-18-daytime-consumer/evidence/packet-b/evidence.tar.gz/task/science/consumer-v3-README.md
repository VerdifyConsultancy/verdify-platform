# GPT-6 Luna Responses qualification — prepared, not executed

This successor preserves the v1/v2 artifacts and their prior approval rejection. The user subsequently approved the export and required GPT-6 Luna for both live Iris and this qualification. ROOT owns the rollout, fresh runtime verification, and the two one-shot consumer operations. This packet has made no native or provider call.

The probe pins model `gpt-6-luna`, effort `xhigh`, and mounted/effective profile SHA256 `2261f5c1a236202b3bfccedd82f1284f50ab27445767dcb09439a92a8d58b56b`. Old profile `51de…`, old input packets, and the Chat Completions wrapper are not admissible.

The runtime adapter expects the existing `POST_ROLLOUT_RUNTIME_CUSTODY_PASSED` verified receipt schema with MCP source b814/ae8 unchanged, the new current release SHA, new Hermes UID, and both config paths at 2261. Its actual `hermes-files` readback and final Pod list must be among the verified command records. The former runtime-01 cannot satisfy this condition. Runtime-only API rollout metadata is owned by ROOT's new runtime reader.

## Exact invocation after actual post-model runtime verification

ROOT supplies actual paths/hashes; the uppercase shell placeholders below are not released values.

```sh
python3 /private/tmp/verdify-daytime-consumer-20261018/science/build-consumer-input-v3.py --runtime-dir "$RUNTIME_DIR" --runtime-sha256 "$RUNTIME_SHA256" --target-date 2026-10-04 --out /private/tmp/verdify-daytime-consumer-20261018/consumer-input-v3-oct04.json
python3 /private/tmp/verdify-daytime-consumer-20261018/science/build-consumer-input-v3.py --runtime-dir "$RUNTIME_DIR" --runtime-sha256 "$RUNTIME_SHA256" --target-date 2026-10-16 --out /private/tmp/verdify-daytime-consumer-20261018/consumer-input-v3-oct16.json
python3 /private/tmp/verdify-daytime-consumer-20261018/science/run_bounded_consumers_v3.py --runtime-dir "$RUNTIME_DIR" --runtime-sha256 "$RUNTIME_SHA256" --oct04-input /private/tmp/verdify-daytime-consumer-20261018/consumer-input-v3-oct04.json --oct04-sha256 "$OCT04_PACKET_SHA256" --oct16-input /private/tmp/verdify-daytime-consumer-20261018/consumer-input-v3-oct16.json --oct16-sha256 "$OCT16_PACKET_SHA256" --out "$FRESH_EXECUTION_DIRECTORY"
```

The builder is pure filesystem processing. The ROOT wrapper seals source, actual inputs and attempt metadata before native calls, checks current app/release/MCP/Hermes identities and public source/config hashes before and after each case, executes exactly one case on each sorted MCP replica, and preserves terminal/failure outputs. A failed first case prevents the second. No retry, credential creation, database write, action route, extra provider request, or increased token allowance exists.

## Responses protocol and bounds

Use only `https://api.openai.com/v1/responses` with `store:false`, `reasoning:{effort:xhigh}`, `parallel_tool_calls:false`, and `include:[reasoning.encrypted_content]`. The first request offers only the actual authenticated Iris `scorecard` schema, using explicit `strict:false` to retain its existing optional inputs, and forces that function. Exactly one function call with the selected date and boolean true is admitted. Replay the complete returned output item list unchanged, including encrypted reasoning and message phase, then append its matching `function_call_output`. The second request exposes no tools and requests one JSON object. Encrypted reasoning and full provider responses remain only in process memory; logs retain IDs, types, usage, hashes, actual scorecard and checked interpretation.

Each case permits at most two provider requests and one real scorecard read in 90 seconds. First/second `max_output_tokens` are 800/1200, including reasoning tokens. Total is at most four provider calls and 4,000 output tokens across both cases. Incomplete or failed Responses, refusal, changed model, excess budget, extra tools, wrong arguments, missing encrypted reasoning, or contradictory interpretation fail without fallback or retry. A high-reasoning response may honestly exhaust these small bounds.

The exact negative/unknown evidence guards are unchanged. Oct04 must preserve all 46 fields in all four historical episodes, normalizing only equivalent aware episode timestamp strings; Oct16 remains empty/pending with null daytime counters. Safety, efficacy, evidence completeness, daytime coverage and crop safety remain separate. The final literal is:

> This read-only qualification does not prove natural-cycle use, complete daytime coverage, causal efficacy, or crop safety.

This qualifies bounded ordinary Iris-authenticated HTTP dispatch and source-prompt consumption. It does not invoke a gateway planning cycle, certify natural future use, repair historical gaps, prove complete daytime zero, or close #410/#775.

Official references used for the protocol: [GPT-6 Luna](https://developers.openai.com/api/docs/models/gpt-6-luna), [Responses migration](https://developers.openai.com/api/docs/guides/migrate-to-responses), [function calling](https://developers.openai.com/api/docs/guides/function-calling), [reasoning and stateless continuation](https://developers.openai.com/api/docs/guides/reasoning).
