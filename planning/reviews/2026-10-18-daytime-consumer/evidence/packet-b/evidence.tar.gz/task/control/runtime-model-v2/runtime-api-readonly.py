"""Fixed public API model attribution read. No imports of services or credential reads."""
import hashlib,json,os,pathlib,signal,sys,urllib.request
SOURCE='182691082420466dc1c5b39bae2fd84f49f38dbf'
MAIN_SHA='02672fe5de90c066078814f7051404442c2a62ca18395794dc3adcb2fffb6fe3'
LABEL='hermes-iris/custom:gpt-6-luna/xhigh'
def need(ok,code):
 if not ok:raise ValueError(code)
def alarm(*a):raise ValueError('deadline')
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*a,**kw):raise ValueError('redirect')
def run():
 signal.signal(signal.SIGALRM,alarm);signal.alarm(20)
 need(pathlib.Path('/etc/verdify/source-revision').read_text().strip()==SOURCE,'source_file')
 need(os.environ.get('VERDIFY_GIT_SHA') in (SOURCE,'unknown',None),'source_env')
 raw=pathlib.Path('/app/main.py').read_bytes();need(hashlib.sha256(raw).hexdigest()==MAIN_SHA,'source_hash')
 need(os.environ.get('VERDIFY_PLANNER_MODEL_LABEL')==LABEL,'model_env')
 opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())
 with opener.open('http://127.0.0.1:8080/api/v1/public/planner-health',timeout=10) as r:
  need(r.status==200,'status');data=r.read(262145)
 need(len(data)<=262144,'response_cap');value=json.loads(data);need(value.get('current_model_label')==LABEL,'public_model_label')
 return {'status':'API_MODEL_ATTRIBUTION_READONLY_PASSED','source_sha':SOURCE,'main_sha256':MAIN_SHA,'model_label':LABEL,'http_status':200,'response_sha256':hashlib.sha256(data).hexdigest(),'response_bytes':len(data),'actual_scorecard_calls':0,'provider_calls':0,'writes':0}
if __name__=='__main__':
 try:print(json.dumps(run(),sort_keys=True))
 except Exception as e:print(json.dumps({'status':'FAILED','code':type(e).__name__,'raw_error_values_retained':False}));sys.exit(1)
 finally:signal.alarm(0)
