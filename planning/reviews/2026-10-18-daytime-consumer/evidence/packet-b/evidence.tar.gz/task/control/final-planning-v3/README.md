This v3 successor preserves both strict predecessors and requires corrected model source `56b316f3fda666b25665dfc0f791d6be6db0fa46`; the failed `18269108` / `99648` attempt remains a failed historical record in the report. No receipt is relabeled.

# Private final planning/report preparation

`finalize.py` performs no native, provider, Git or GitHub operation. It reads the existing draft and explicit hash-bound completed receipts, writes a new private directory, and uses the owning `planning.render` functions for the seven views and #410/#775 bodies. It never modifies the supplied source checkout.

The generated report separates source CI, selective delivery, runtime identity, authenticated ordinary reads, bounded GPT-6 Luna interpretation, incomplete recorded daytime coverage and unproved natural use. Natural-cycle cost has no measured baseline. Preserved prompt/playbook prose may still name the old model; the actual profile and API label supply model attribution. The prior graph snapshot is retained as prior evidence; no future publication-bound MATCH or evidence publication is asserted.

This finalizer emits the accepted source/runtime/consumer packet when that actual receipt chain is present. Model-release CI alone may explicitly remain pending in this report while it and later report CI finish concurrently; their actual terminal receipts remain required by final immutable evidence custody. All other missing, failed or incomplete required receipts cause a refusal with no output directory. That is a reporting safeguard, not a new execution gate or an instruction to retry a workload. Preserve failed attempts; if the final outcome is a genuine unresolved failure, write that outcome explicitly rather than relabeling a receipt to satisfy this positive-path finalizer.

## Inputs

Copy `inputs.unbound.json` into a new private binding file. Populate each actual path and SHA only after the receipts exist; set status to `ready_actual_receipts`. Existing completed paths/hashes in the unbound example are actual; future roles are null, so the example cannot execute. `database` must identify the chosen latest bounded metadata read, and its exact timestamp is printed rather than claiming later observations. `model_rollout` is ROOT's four-resource terminal proof, independent of runtime verification. Consumer terminal/start receipts bind the successful native consumer to that exact runtime.

The review source SHA is an actual existing source revision supplied by ROOT; it is not a prediction of the eventual report commit. The source backlog must still equal the before-graph bound backlog. Any intervening canonical edit requires a deliberate merge/rebase of this narrow draft, not overwriting another lane.

```sh
/Users/jason/repos/verdify-platform/.venv/bin/python \
  /private/tmp/verdify-daytime-consumer-20261018/control/final-planning-v3/finalize.py \
  --source-root /private/tmp/verdify-daytime-consumer-source-20261018 \
  --backlog-sha256 eafcf1c5be8f36a43c7f9314fa20dba563fdef43432f2eb13a9de3a390b95c8c \
  --inputs /private/tmp/ACTUAL-final-planning-inputs.json \
  --review-source-sha ACTUAL_EXISTING_40_CHARACTER_REVISION \
  --out /private/tmp/verdify-daytime-final-planning-01
```

The illustrative path/revision above are intentionally not executable inputs. ROOT installs `repo/`, reviews `canonical-generated.patch`, validates, commits and publishes. The two `github-bodies/` files are generated drafts only. Record the later native graph match, report CI and remote byte checks in separate postpublication custody; this helper does not invent them.

## Preservation and checks

Only #410/#775 baseline, how and decision, their allocation next actions, and execution review metadata may change. All 93 records, 47 open states, 143 open acceptance clauses, parents, dependencies, priorities, estimates, capacities, sprint definitions and the other 91 issue rows remain exact. All unrelated rendered issue bodies must also remain equal. Acceptance checkboxes stay open.

Eighteen small pure regression tests passed, including a temporary full private render with synthetic future receipts. They cover wrong CI/runtime linkage, an extra rollout resource, a missing consumer case, invented zero, natural-cycle/scope overclaims and preserved canonical data. No actual finalization, native probe or provider call was performed during preparation. The temporary synthetic output was removed.

## Explicit deferred model-release CI

To create the canonical report while normal model-release CI runs, set only `receipts.model_release_ci` to JSON `null`, and add:

```json
"deferred_receipts": {
  "model_release_ci": {
    "state": "recorded_later_in_custody",
    "source_revision": "ACTUAL_MODEL_RELEASE_40_CHARACTER_REVISION"
  }
}
```

The revision must equal the actual completed rollout/runtime release. This does not invent a CI receipt, mark CI passed, or relax an enforced CI check. The report explicitly says its model-release terminal verification is pending and the later model-release/report-CI terminal results belong in immutable custody. Final packaging remains outside this helper and still requires both actual terminal results. If an actual model-release terminal receipt is supplied instead, omit `deferred_receipts`. No other receipt can be deferred.
