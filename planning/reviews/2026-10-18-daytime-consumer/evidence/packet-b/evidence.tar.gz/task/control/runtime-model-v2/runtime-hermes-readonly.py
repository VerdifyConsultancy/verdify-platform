"""Hash only source-owned public files. Never imports the gateway or reads credentials/history."""
import hashlib,json,os,pathlib,sys
EXPECTED = {'/opt/data/SOUL.md': '11a0fdc4be8f31b0f7872ea2184ea4e502b8be7902b11a85275c9b8af8809f1f', '/opt/data/skills/devops/greenhouse-planning-mcp/references/greenhouse-playbook.md': '38396eb74de01f4b09eae4175801a2e6e9ff5802aa489c6c59ab5c1d78a03a95', '/opt/data/skills/devops/greenhouse-planning-mcp/references/full-plan-payload-preflight.md': 'cace1f0c1769ade8026ce43cab638727b61423b71c0daa1859b3746f7fed0f23', '/etc/verdify/hermes-config/config.yaml': '2261f5c1a236202b3bfccedd82f1284f50ab27445767dcb09439a92a8d58b56b', '/opt/data/config.yaml': '2261f5c1a236202b3bfccedd82f1284f50ab27445767dcb09439a92a8d58b56b', '/etc/verdify/hermes-config/tool-readiness.py': '6f0ec53b599f0c55424978612d63c6604affca4e72a2b241991eb4d66e4dbf6d'}
def run():
 if os.environ.get('HERMES_HOME')!='/opt/data':raise ValueError('home')
 if any(os.environ.get(k) for k in ('HERMES_MODEL','OPENAI_MODEL','HERMES_PROVIDER','OPENAI_BASE_URL','HERMES_REASONING_EFFORT')):raise ValueError('model_override')
 observed={}
 for name,expected in EXPECTED.items():
  p=pathlib.Path(name)
  if p.stat().st_size>2000000:raise ValueError('public_file_cap')
  digest=hashlib.sha256(p.read_bytes()).hexdigest()
  if digest!=expected:raise ValueError('public_file_hash')
  observed[name]=digest
 return {'status':'HERMES_SOURCE_OWNED_FILES_MATCH','file_sha256':observed,'learned_skill_read_or_overwritten':False,'registry_pid_introspection':False,'natural_cycle_verified':False}
if __name__=='__main__':
 try:print(json.dumps(run(),sort_keys=True))
 except Exception as e:
  print(json.dumps({'status':'FAILED','code':type(e).__name__,'raw_error_values_retained':False}));sys.exit(1)
