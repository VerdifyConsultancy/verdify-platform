# GPT-6 Luna profile and API label rollout — source-only preparation

This is a separate successor to the preserved model-only draft. It emits one expiring Argo JSON patch and never calls Kubernetes, Git, a provider or the database. ROOT owns fresh source/CI/digest verification, actual render/idle custody and the one native operation.

The exact selectors are:

- ConfigMap `verdify-hermes-iris-config` in `verdify-prod`, effective wave 0.
- Deployment `verdify-api` in `verdify-prod`, existing effective wave 0 (the current object has no sync-wave annotation).
- Deployment `verdify-hermes-iris` in `verdify-prod`, wave 20.

Complete before/after rendered inventories must have identical object keys and exactly those three changed objects. The retained current render contains 129 total objects, so 126 would be unchanged; the emitter reports the actual count instead of assuming a larger inventory. No MCP, migration hook, DB, ingestor, inventory payload, security setting, credential, PVC or Namespace change is permitted.

The profile ConfigMap must retain its exact two keys, and only `data.config.yaml` may differ. The old profile bytes are SHA256 `51de00576417701fc4fed8fb03ec9a3f1bfbee5e4f5d057f25b763076c2a8b5f`. The new bytes must match ROOT's explicit reviewed `--profile-sha256`. A strict duplicate-refusing YAML parser verifies that the only semantic change is `model.default: gpt-5.6-luna` to `gpt-6-luna`; comments may change. Provider, endpoint, xhigh effort, tools, API settings and every other semantic field must remain unchanged. The current frozen draft profile SHA is `2261f5c1a236202b3bfccedd82f1284f50ab27445767dcb09439a92a8d58b56b`, revision `2261f5c1a236`.

The API must change only its `api` container image from `75f510f52d71846197fdc1ddabead87912d8a31070439a29747e4ec36dc37624` to the explicit `--api-digest`, plus the existing `VERDIFY_PLANNER_MODEL_LABEL` value from `hermes-iris/custom:gpt-5.6-luna/xhigh` to `hermes-iris/custom:gpt-6-luna/xhigh`. No added env entry, sidecar, port, annotation, strategy or other field is accepted. ROOT must supply the digest and `--api-source-sha` from the exact qualified native build receipt; these parameters are custody bindings, not proof by themselves. The already accepted MCP image must remain `ae8a367035a3ae8a06ab2384bc166f444b3decad0da21e5c70e53e76203d9c73`.

The Hermes Deployment may change only `verdify.io/hermes-profile-revision`, which must equal the first 12 hex characters of the new profile hash. Inventory revision `5733c1c6b35d`, singleton Recreate behavior, upstream image and every other field remain unchanged.

The v2 idle contract is reused unchanged: fresh exact-Pod HTTP200 is a capture observation, while health `updated_at` and `active_agents` come from persistent startup status and do not prove current activity. Fresh bounded complete delivery-ledger data, no pending delivery without a run ID, and real HTTP200 terminal states for every known unresolved run are required. HTTP404, active run, stale or incomplete data refuses emission. There is no dispatch freeze or exhaustive-idle claim; incoming/older/unrecorded activity remains a limitation. ROOT binds normalized fields to raw receipts and stops if new activity appears before dispatch. The unchanged optional `idle-ledger.sql` is READ ONLY, capped at 200 rows with a 201 sentinel, 2-second statement timeout and 500-ms lock timeout.

`emit.py --help` lists exact input arguments. It writes only a new local output directory. Supply fresh Application UID/RV, terminal prior phase and no operation; a real accepted main revision; current Hermes Pod UID; complete rendered JSON inventories; normalized v2 idle evidence; and qualified profile/API source/digest bindings. ROOT checks the plan's 30-second expiry, then sends one JSON patch. The patch tests UID/RV/terminal state, clears stale operationState and supplies exactly the three selectors with prune:false. It does not run hooks, full sync, retries, an automatic rollback or any direct Deployment patch.

After dispatch, retain the actual accepted selector/revision and all terminal resource results. Verify actual API source/image/model label and both new API Pods, actual Hermes seed exit0 and effective profile hash/model, preserved inventory and accepted MCP identity, and the separately scoped provider/consumer result. A current label or successful deployment does not prove an actual provider call or a natural planner cycle. The earlier runtime reader pins the old profile/API identity and must not be reused unchanged for this successor.

For an inverse, use a separately reviewed source revision restoring only the old API image/model label and old Hermes profile/revision; preserve the accepted MCP pin and inventory. There is no embedded mutation/rollback command.

Validation: 25 bounded pure checks passed in 0.172 seconds, using the retained actual complete render as a fixture. They cover model-only semantics, duplicate YAML refusal, extra config/env/image/wave changes, profile/inventory revisions, exact selectors, accepted MCP preservation, Application UID/RV/operation guards and honest bounded idle behavior. No native operation or provider call was made.
