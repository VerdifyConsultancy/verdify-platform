#!/usr/bin/env python3
"""One finite post-rollout readback. ROOT alone executes; no mutation or retry.
Separate ROOT Argo operation proof and later one-scorecard-read/date qualification
remain required. Only reviewed supported smoke/device observation is invoked.
"""
import argparse,copy,datetime as dt,hashlib,json,os,pathlib,re,signal,subprocess,time
BASE=pathlib.Path('/private/tmp/verdify-daytime-consumer-20261018')
SOURCE='b814f35e228fcb35c11593c47ea1e021e5fd73de'
OLD_MCP='264f5fcb4da78a068c5bc64ec2b70d9efe122a473a1f92bb5d923565fb47a393'
HERMES='a7111ab1cc43b5a1bc76090a505d6462aa1af4b43f603f0113bf5eb121aec72e'
API_SOURCE='56b316f3fda666b25665dfc0f791d6be6db0fa46'
PROFILE='2261f5c1a236'
MCP_DIGEST='ae8a367035a3ae8a06ab2384bc166f444b3decad0da21e5c70e53e76203d9c73'
MODEL_LABEL='hermes-iris/custom:gpt-6-luna/xhigh'
INVENTORY='5733c1c6b35d'
NS='verdify-prod';MAX_OUTPUT=2*1024*1024
INPUT_PINS={'runtime-expectations.json': 'f8b1120e8247c8c8d47897c5bd34e9e5c2fc0d73b6f75faba9c29a1a64d40a45', 'runtime-mcp-readonly.py': '3e02d797fe6d296edd2df53de3de01455e4bdfee48b8e0364fe54aa857c01166', 'runtime-hermes-readonly.py': '496913b0c3a90aaee536e4c41a8a770f33e14f44b019b0a58644e05e286ceefa', 'runtime-api-readonly.py': '78e287bbe48ccde04fda5607f1effec8e0d5b3f04edbf2a57f2761dbb5bc2eda'}
class Refusal(Exception):pass
def need(ok,code):
 if not ok:raise Refusal(code)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def load(p):return json.loads(p.read_bytes())
def dump(p,v):p.write_text(json.dumps(v,sort_keys=True,indent=2)+'\n')
def items(v):return v['items'] if v.get('kind','').endswith('List') else [v]
def by_name(values):
 result={v['metadata']['name']:v for v in values};need(len(result)==len(values),'duplicate_object_name');return result
def container(obj,name):
 values=[c for c in obj['spec']['template']['spec']['containers'] if c['name']==name];need(len(values)==1,'container_identity');return values[0]
def conditions_ready(p):return any(x['type']=='Ready' and x['status']=='True' for x in p['status'].get('conditions',[]))
def pod_ready(p,name,digest):
 need(not p['metadata'].get('deletionTimestamp') and p['status']['phase']=='Running' and conditions_ready(p),'pod_not_ready')
 specs=p['spec']['containers'];sts=p['status'].get('containerStatuses',[])
 need(len(sts)==len(specs)>0 and {x['name'] for x in sts}=={x['name'] for x in specs},'pod_container_inventory')
 need(all(x['ready'] is True and x['restartCount']==0 and x.get('state',{}).get('running') and not x.get('lastState') for x in sts),'pod_container_not_stable')
 spec=[x for x in specs if x['name']==name];status=[x for x in sts if x['name']==name]
 need(len(spec)==len(status)==1 and spec[0]['image'].endswith('@sha256:'+digest) and status[0]['imageID'].endswith('@sha256:'+digest),'pod_digest')
 init=p['status'].get('initContainerStatuses',[]) or [];declared=p['spec'].get('initContainers',[])
 need({x['name'] for x in init}=={x['name'] for x in declared},'pod_init_inventory')
 need(all(x['restartCount']==0 and x['state'].get('terminated',{}).get('exitCode')==0 and not x.get('lastState') for x in init),'pod_init_failed')
def state_fingerprint(p):
 return {'uid':p['metadata']['uid'],'owners':p['metadata'].get('ownerReferences',[]),'phase':p['status']['phase'],'states':{kind:[{key:s.get(key) for key in ('name','containerID','imageID','restartCount','ready','state','lastState')} for s in p['status'].get(kind,[]) or []] for kind in ('containerStatuses','initContainerStatuses')}}
def verify_deployments(initial,current,digest,api_digest):
 old=by_name(initial['items']);new=by_name(current['items']);need(set(old)==set(new) and len(old)==15,'deployment_inventory')
 for name,a in old.items():
  b=new[name];need(a['metadata']['uid']==b['metadata']['uid'] and not b['metadata'].get('deletionTimestamp'),'deployment_identity')
  wanted=copy.deepcopy(a['spec'])
  if name=='verdify-mcp':need(container(a,'mcp')['image'].endswith('@sha256:'+digest) and digest==MCP_DIGEST,'accepted_mcp_digest')
  elif name=='verdify-api':
   c=container({'spec':wanted},'api');c['image']='registry.vallery.net/verdifyconsultancy/verdify-api@sha256:'+api_digest
   env=[e for e in c['env'] if e['name']=='VERDIFY_PLANNER_MODEL_LABEL'];need(env==[{'name':'VERDIFY_PLANNER_MODEL_LABEL','value':'hermes-iris/custom:gpt-5.6-luna/xhigh'}],'previous_api_model_label');env[0]['value']=MODEL_LABEL
  elif name=='verdify-hermes-iris':
   ann=wanted['template']['metadata']['annotations'];need(ann['verdify.io/iris-inventory-revision']==INVENTORY and ann['verdify.io/hermes-profile-revision']=='51de00576417','previous_hermes_revisions');ann['verdify.io/hermes-profile-revision']=PROFILE
  need(b['spec']==wanted,'unexpected_deployment_spec')
  if name in ('verdify-mcp','verdify-api','verdify-hermes-iris'):
   count=1 if name=='verdify-hermes-iris' else 2;st=b['status']
   need(b['spec']['replicas']==count and all(st.get(k)==count for k in ('replicas','updatedReplicas','readyReplicas','availableReplicas')) and st.get('observedGeneration',0)>=b['metadata']['generation'],'deployment_rollout_incomplete')
 return new
class Runner:
 def __init__(self,args):
  self.a=args;self.out=args.out;self.phase='preseal';self.start=time.monotonic();self.records=[];self.owned_out=False
  self.k=['kubectl','--kubeconfig',str(args.kubeconfig),'--context','vallery','--request-timeout=15s']
 def command(self,label,argv,timeout=25,input=None,env=None):
  self.phase=label;need(time.monotonic()-self.start<480,'overall_deadline')
  timeout=min(timeout,max(1,480-(time.monotonic()-self.start)));path=self.out/(label+'.stdout')
  start=time.monotonic();code=None;stderr=b'';timed=False
  with path.open('xb') as stream:
   p=subprocess.Popen(argv,stdin=subprocess.PIPE if input is not None else subprocess.DEVNULL,stdout=stream,stderr=subprocess.PIPE,start_new_session=True,env=env)
   try:_,stderr=p.communicate(input=input,timeout=timeout);code=p.returncode
   except (subprocess.TimeoutExpired,KeyboardInterrupt):
    timed=True
    try:os.killpg(p.pid,signal.SIGTERM)
    except ProcessLookupError:pass
    try:_,stderr=p.communicate(timeout=3)
    except subprocess.TimeoutExpired:
     try:os.killpg(p.pid,signal.SIGKILL)
     except ProcessLookupError:pass
     _,stderr=p.communicate(timeout=3)
    code=p.returncode
  raw=path.read_bytes();rec={'phase':label,'returncode':code,'timed_out':timed,'seconds':time.monotonic()-start,'stdout_sha256':sha(raw),'stdout_bytes':len(raw),'stderr_sha256':sha(stderr),'stderr_bytes':len(stderr),'raw_stderr_retained':False,'automatic_retries':0}
  self.records.append(rec);dump(self.out/(label+'.result.json'),rec)
  need(not timed,'command_timeout');need(code==0,'command_nonzero');need(len(raw)<=MAX_OUTPUT,'command_output_cap');return raw
 def get(self,label,resource,*names,namespace=NS,selector=None):
  argv=self.k+['-n',namespace,'get',resource,*names]
  if selector:argv+=['-l',selector]
  return json.loads(self.command(label,argv+['-o','json']))
 def exec_driver(self,label,pod,container,python,raw):
  return json.loads(self.command(label,self.k+['-n',NS,'exec','-i',pod,'-c',container,'--',python,'-'],35,input=raw))
 def capture(self,prefix,initial_deps,initial_pods,digest):
  app=self.get(prefix+'-application','application','verdify-prod-dark',namespace='argocd')
  need(app['metadata']['uid']==self.initial_app['metadata']['uid'] and app.get('operation') is None and app['status']['health']['status']=='Healthy' and app['status']['sync']['status']=='Synced' and app['status']['sync']['revision']==self.a.release_sha and app['status']['operationState']['phase']=='Succeeded','application_not_settled')
  deps=self.get(prefix+'-deployments','deployments');dm=verify_deployments(initial_deps,deps,digest,self.api_digest)
  prior=by_name(initial_pods['items']);critical=[p for p in prior.values() if p['metadata']['name']=='verdify-db-0' or p['metadata'].get('labels',{}).get('app.kubernetes.io/component') in ('ingestor',)]
  need(len(critical)==2,'initial_critical_inventory');current=self.get(prefix+'-critical-pods','pods',*[p['metadata']['name'] for p in critical]);pm=by_name(items(current));need(set(pm)=={p['metadata']['name'] for p in critical},'critical_inventory')
  for old in critical:
   p=pm[old['metadata']['name']];need(state_fingerprint(p)==state_fingerprint(old) and conditions_ready(p) and not p['metadata'].get('deletionTimestamp'),'critical_pod_state_changed')
  sts=self.get(prefix+'-database-statefulset','statefulset','verdify-db');db=pm['verdify-db-0'];need(any(x['kind']=='StatefulSet' and x['uid']==sts['metadata']['uid'] for x in db['metadata']['ownerReferences']),'db_owner')
  selected={}
  for comp,count,ctr,dig in [('mcp',2,'mcp',digest),('api',2,'api',self.api_digest),('hermes-iris',1,'hermes-iris',HERMES)]:
   data=self.get(prefix+'-'+comp+'-pods','pods',selector='app.kubernetes.io/component='+comp);ps=data['items'];need(len(ps)==count,'owning_pod_count')
   old_uids={p['metadata']['uid'] for p in prior.values() if p['metadata'].get('labels',{}).get('app.kubernetes.io/component')==comp}
   rs_seen={}
   for p in ps:
    pod_ready(p,ctr,dig)
    if comp=='mcp':
     need(p['metadata']['uid'] in old_uids and state_fingerprint(p)==state_fingerprint(prior[p['metadata']['name']]),'accepted_mcp_pod_changed')
    else:need(p['metadata']['uid'] not in old_uids,'old_rollout_pod')
    owner=[o for o in p['metadata'].get('ownerReferences',[]) if o.get('controller') is True and o['kind']=='ReplicaSet'];need(len(owner)==1,'pod_owner')
    ref=owner[0]
    if ref['name'] not in rs_seen:rs_seen[ref['name']]=self.get(prefix+'-'+comp+'-rs-'+str(len(rs_seen)),'replicaset',ref['name'])
    rs=rs_seen[ref['name']];need(rs['metadata']['uid']==ref['uid'] and any(o.get('controller') is True and o['kind']=='Deployment' and o['uid']==dm['verdify-'+comp]['metadata']['uid'] for o in rs['metadata'].get('ownerReferences',[])),'replicaset_owner')
   selected[comp]=ps
  eps=self.get(prefix+'-mcp-endpoints','endpointslices',selector='kubernetes.io/service-name=verdify-mcp')
  observed={};expected={p['metadata']['uid']:p['status']['podIP'] for p in selected['mcp']}
  for sl in eps['items']:
   for ep in sl.get('endpoints',[]):
    target=ep.get('targetRef',{});need(target.get('kind')=='Pod' and target.get('namespace')==NS and ep.get('conditions',{}).get('ready') is True,'mcp_endpoint_not_ready')
    need(target['uid'] not in observed,'duplicate_endpoint');observed[target['uid']]=ep['addresses'][0];need(len(ep['addresses'])==1,'endpoint_address_count')
  need(observed==expected,'mcp_endpoint_identity')
  return {'mcp':selected['mcp'],'api':selected['api'],'hermes':selected['hermes-iris'][0],'critical':pm,'application':app}
 def run(self):
  a=self.a;need(re.fullmatch('[0-9a-f]{40}',a.release_sha) is not None,'release_sha_shape');need(re.fullmatch('[0-9a-f]{64}',a.ci_receipt_sha256) is not None,'ci_receipt_hash_shape')
  need(not self.out.exists(),'fresh_output_required');self.out.mkdir(mode=0o700);self.owned_out=True
  controls=pathlib.Path(__file__).parent;paths={'expectations':controls/'runtime-expectations.json','mcp_driver':controls/'runtime-mcp-readonly.py','hermes_driver':controls/'runtime-hermes-readonly.py','api_driver':controls/'runtime-api-readonly.py','api_ci_receipt':a.api_ci_receipt,'ci_receipt':a.ci_receipt,**{n:BASE/'initial'/n for n in ('application.json','deployments.json','pods.json')}}
  inputs={k:p.read_bytes() for k,p in paths.items()}
  for key in ('expectations','mcp_driver','hermes_driver','api_driver'):need(sha(inputs[key])==INPUT_PINS[paths[key].name],'driver_input_pin')
  expect=json.loads(inputs['expectations']);need(sha(inputs['ci_receipt'])==a.ci_receipt_sha256,'ci_receipt_hash')
  for n,h in expect['initial'].items():need(sha(inputs[n])==h,'initial_hash')
  ci=json.loads(inputs['ci_receipt']);need(ci['status']=='SOURCE_GATE_FIVE_BUILDS_AND_PIN_PUBLISHER_VERIFIED' and ci['source_revision']==SOURCE and ci['workflow_uid']=='f2083616-e793-4994-bd3b-9a48b1fbb376','source_ci_binding')
  image=ci['images']['mcp'];need(image['source-revision']==image['resolved-revision']==SOURCE and re.fullmatch('sha256:[0-9a-f]{64}',image['digest']) is not None,'ci_mcp_source_digest');digest=image['digest'][7:]
  need(re.fullmatch('[0-9a-f]{64}',a.api_ci_receipt_sha256) is not None and sha(inputs['api_ci_receipt'])==a.api_ci_receipt_sha256,'api_ci_receipt_hash')
  api_ci=json.loads(inputs['api_ci_receipt']);need(api_ci['status']=='SOURCE_GATE_TWO_BUILDS_AND_PIN_PUBLISHER_VERIFIED' and api_ci['source_revision']==API_SOURCE and api_ci['workflow_uid']==a.api_workflow_uid,'api_source_ci_binding')
  api_image=api_ci['images']['api'];need(api_image['source-revision']==api_image['resolved-revision']==API_SOURCE and re.fullmatch('sha256:[0-9a-f]{64}',api_image['digest']) is not None,'ci_api_source_digest');self.api_digest=api_image['digest'][7:]
  previous={n:(BASE/'runtime-01'/n).read_bytes() for n in expect['previous_runtime']}
  need(all(sha(raw)==expect['previous_runtime'][n] for n,raw in previous.items()),'previous_runtime_hash')
  prev_receipt=json.loads(previous['verified.json']);need(prev_receipt['status']=='POST_ROLLOUT_RUNTIME_CUSTODY_PASSED' and prev_receipt['source_sha']==SOURCE and prev_receipt['mcp_digest']==digest,'previous_runtime_scope')
  prev_records={r['phase']:r for r in prev_receipt['records']}
  for n,raw in previous.items():
   if n.endswith('.stdout'):need(prev_records[n[:-7]]['returncode']==0 and prev_records[n[:-7]]['stdout_sha256']==sha(raw),'previous_record_binding')
  for n,h in expect['smoke_files'].items():need(sha((a.source_worktree/n).read_bytes())==h,'smoke_source_hash')
  self.initial_app=json.loads(previous['after-application.stdout']);initial_deps=json.loads(previous['after-deployments.stdout'])
  initial_pods={'items':sum((items(json.loads(previous[n])) for n in ('after-critical-pods.stdout','after-mcp-pods.stdout','after-hermes-iris-pods.stdout')),[])}
  need(len({p['metadata']['uid'] for p in initial_pods['items']})==7,'previous_pod_inventory');api_digest='sha256:'+self.api_digest
  for name,raw in inputs.items():(self.out/(name+'.input')).write_bytes(raw)
  for name,raw in previous.items():(self.out/('previous-'+name)).write_bytes(raw)
  (self.out/'runtime-readback.py').write_bytes(pathlib.Path(__file__).read_bytes())
  dump(self.out/'attempt-start.json',{'status':'STARTED','source':SOURCE,'release_sha':a.release_sha,'mcp_digest':digest,'api_source_sha':API_SOURCE,'api_digest':self.api_digest,'previous_runtime_sha256':expect['previous_runtime'],'input_sha256':{k:sha(v) for k,v in inputs.items()},'driver_sha256':sha(pathlib.Path(__file__).read_bytes()),'automatic_retries':0,'limits':{'overall_seconds':480,'metadata_step_seconds':25,'http_step_seconds':35,'smoke_seconds':120,'device_seconds':180,'output_bytes_each':MAX_OUTPUT}})
  # The unchanged smoke selects the kubeconfig current context; validate it first.
  context=self.command('kube-context',['kubectl','--kubeconfig',str(a.kubeconfig),'config','current-context']).decode().strip();need(context=='vallery','smoke_context')
  pre=self.capture('before',initial_deps,initial_pods,digest)
  for cm_name,expected in {**expect['hermes_cm'],**expect['other_source_cm']}.items():
   cm=self.get('cm-'+cm_name,'configmap',cm_name);need({k:sha(v.encode()) for k,v in cm['data'].items()}==expected,'source_configmap_hash')
  mcp_results=[]
  for i,p in enumerate(sorted(pre['mcp'],key=lambda x:x['metadata']['name'])):
   result=self.exec_driver('mcp-readonly-'+str(i),p['metadata']['name'],'mcp','python',inputs['mcp_driver']);need(result.get('status')=='MCP_READONLY_RUNTIME_PASSED','mcp_runtime_failed');mcp_results.append({'pod':p['metadata']['name'],'uid':p['metadata']['uid'],'result':result})
  api_results=[]
  for i,p in enumerate(sorted(pre['api'],key=lambda x:x['metadata']['name'])):
   result=self.exec_driver('api-readonly-'+str(i),p['metadata']['name'],'api','python',inputs['api_driver']);need(result.get('status')=='API_MODEL_ATTRIBUTION_READONLY_PASSED','api_runtime_failed');api_results.append({'pod':p['metadata']['name'],'uid':p['metadata']['uid'],'result':result})
  hp=pre['hermes'];hermes=self.exec_driver('hermes-files',hp['metadata']['name'],'hermes-iris','python3',inputs['hermes_driver']);need(hermes.get('status')=='HERMES_SOURCE_OWNED_FILES_MATCH','hermes_files_failed')
  seed=self.command('hermes-seed-log',self.k+['-n',NS,'logs',hp['metadata']['name'],'-c','seed-config','--limit-bytes=65536'],25);need(len(seed)<65536,'seed_log_truncated')
  rows=[json.loads(x) for x in seed.splitlines() if x.startswith(b'{')];need(len(rows)==1 and rows[0].get('schema')=='verdify-iris-inventory-v1' and rows[0].get('sha256')==expect['seed_home_files'] and rows[0].get('learned_skill_preserved') is True and b'seeded /opt/data/config.yaml from verdify-hermes-iris-config' in seed,'seed_log_proof')
  env=os.environ.copy();env['KUBECONFIG']=str(a.kubeconfig)
  script=str(a.source_worktree/'scripts/k3s-smoke.sh')
  smoke=self.command('supported-smoke',['bash',script,'smoke','--namespace',NS,'--timeout','10','--expected-api-sha',API_SOURCE,'--expected-api-digest',api_digest],120,env=env)
  need(b'passed=9 failed=0' in smoke and b'RESULT: GREEN' in smoke,'smoke_not_nine_green')
  device=self.command('supported-device-monitor',['bash',script,'device-monitor','--namespace',NS,'--timeout','10'],180,env=env)
  need(b'EXACTLY ONE ESP32 writer connection observed' in device and b'passed=1 failed=0' in device and b'RESULT: GREEN' in device,'device_not_singleton')
  post=self.capture('after',initial_deps,initial_pods,digest)
  need({p['metadata']['uid']:state_fingerprint(p) for p in pre['mcp']}=={p['metadata']['uid']:state_fingerprint(p) for p in post['mcp']} and {p['metadata']['uid']:state_fingerprint(p) for p in pre['api']}=={p['metadata']['uid']:state_fingerprint(p) for p in post['api']} and state_fingerprint(pre['hermes'])==state_fingerprint(post['hermes']),'rollout_pods_changed_during_readback')
  need(all(p.read_bytes()==inputs[k] for k,p in paths.items()),'inputs_changed')
  need(all((BASE/'runtime-01'/n).read_bytes()==raw for n,raw in previous.items()),'previous_runtime_changed')
  need(all(sha((a.source_worktree/n).read_bytes())==h for n,h in expect['smoke_files'].items()),'smoke_source_changed')
  dump(self.out/'verified.json',{'status':'POST_ROLLOUT_RUNTIME_CUSTODY_PASSED','source_sha':SOURCE,'release_sha':a.release_sha,'ci_receipt_sha256':a.ci_receipt_sha256,'mcp_digest':digest,'deployment_uids_preserved':15,'unchanged_deployment_specs':13,'unrelated_deployment_specs_unchanged':12,'accepted_mcp_deployment_and_pods_unchanged':True,'critical_pods_and_container_states_unchanged':2,'mcp':mcp_results,'api':api_results,'api_source_sha':API_SOURCE,'api_digest':self.api_digest,'api_ci_receipt_sha256':a.api_ci_receipt_sha256,'effective_model_config_sha256':expect['hermes_cm']['verdify-hermes-iris-config']['config.yaml'],'hermes':{'pod':hp['metadata']['name'],'uid':hp['metadata']['uid'],'files':hermes,'seed':rows[0]},'smoke_checks':9,'exactly_one_device_writer_observed':True,'actual_scorecard_calls':0,'provider_calls':0,'natural_cycle_verified':False,'gateway_live_schema_registry_introspected':False,'new_gateway_process_verified':True,'argo_exact_four_resource_operation_proof':'separate_ROOT_dispatcher_receipt_required','automatic_retries':0,'records':self.records})
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',type=pathlib.Path,required=True);p.add_argument('--ci-receipt',type=pathlib.Path,required=True);p.add_argument('--ci-receipt-sha256',required=True);p.add_argument('--api-ci-receipt',type=pathlib.Path,required=True);p.add_argument('--api-ci-receipt-sha256',required=True);p.add_argument('--api-workflow-uid',required=True);p.add_argument('--release-sha',required=True);p.add_argument('--source-worktree',type=pathlib.Path,required=True);p.add_argument('--kubeconfig',type=pathlib.Path,default=pathlib.Path('/Users/jason/.kube/config'));a=p.parse_args();r=Runner(a)
 try:
  r.run();dump(a.out/'attempt-result.json',{'status':'PASSED','verified_sha256':sha((a.out/'verified.json').read_bytes()),'automatic_retries':0});print(json.dumps({'status':'PASSED','out':str(a.out)}));return 0
 except Exception as e:
  result={'status':'FAILED','phase':r.phase,'code':str(e) if isinstance(e,Refusal) else type(e).__name__,'raw_error_values_retained':False,'automatic_retries':0,'records':r.records}
  if r.owned_out:dump(a.out/'attempt-result.json',result)
  print(json.dumps({k:v for k,v in result.items() if k!='records'}));return 1
if __name__=='__main__':raise SystemExit(main())
