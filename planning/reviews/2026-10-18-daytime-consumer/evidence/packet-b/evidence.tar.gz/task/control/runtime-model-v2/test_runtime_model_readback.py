"""Bounded pure source/readback regressions; no subprocess or native operations."""
import ast,copy,hashlib,importlib.util,json,pathlib,unittest
from unittest.mock import patch
BASE=pathlib.Path('/private/tmp/verdify-daytime-consumer-20261018');CONTROL=BASE/'control/runtime-model-v2'
s=importlib.util.spec_from_file_location('runtime_model',CONTROL/'runtime-readback.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
class Readback(unittest.TestCase):
 def setUp(self):
  self.block=patch.object(m.subprocess,'Popen',side_effect=AssertionError('native forbidden'));self.block.start();self.addCleanup(self.block.stop)
  self.before=json.loads((BASE/'runtime-01/after-deployments.stdout').read_bytes())
  self.pods=sum((m.items(json.loads((BASE/'runtime-01'/n).read_bytes())) for n in ('after-critical-pods.stdout','after-mcp-pods.stdout','after-hermes-iris-pods.stdout')),[])
 def successor(self):
  new=copy.deepcopy(self.before);by=m.by_name(new['items']);c=m.container(by['verdify-api'],'api');c['image']='registry.vallery.net/verdifyconsultancy/verdify-api@sha256:'+'a'*64
  next(e for e in c['env'] if e['name']=='VERDIFY_PLANNER_MODEL_LABEL')['value']=m.MODEL_LABEL
  by['verdify-hermes-iris']['spec']['template']['metadata']['annotations']['verdify.io/hermes-profile-revision']=m.PROFILE
  for name,n in [('verdify-mcp',2),('verdify-api',2),('verdify-hermes-iris',1)]:
   by[name]['status'].update({k:n for k in ('replicas','updatedReplicas','readyReplicas','availableReplicas')});by[name]['status']['observedGeneration']=by[name]['metadata']['generation']
  return new
 def verify(self,v):return m.verify_deployments(self.before,v,m.MCP_DIGEST,'a'*64)
 def test_exact_api_and_hermes_changes_preserve_all_uids(self):self.assertEqual(len(self.verify(self.successor())),15)
 def test_api_label_required(self):
  v=self.successor();next(e for e in m.container(m.by_name(v['items'])['verdify-api'],'api')['env'] if e['name']=='VERDIFY_PLANNER_MODEL_LABEL')['value']='old'
  with self.assertRaises(m.Refusal):self.verify(v)
 def test_no_extra_api_env(self):
  v=self.successor();m.container(m.by_name(v['items'])['verdify-api'],'api')['env'].append({'name':'UNRELATED','value':'x'})
  with self.assertRaises(m.Refusal):self.verify(v)
 def test_mcp_never_rolls_or_changes_spec(self):
  for key in ('image','env'):
   v=self.successor();c=m.container(m.by_name(v['items'])['verdify-mcp'],'mcp')
   if key=='image':c['image']='changed'
   else:c['env'].append({'name':'OTHER','value':'1'})
   with self.subTest(key=key),self.assertRaises(m.Refusal):self.verify(v)
 def test_inventory_or_upstream_image_change_refused(self):
  for key in ('inventory','image'):
   v=self.successor();h=m.by_name(v['items'])['verdify-hermes-iris']
   if key=='inventory':h['spec']['template']['metadata']['annotations']['verdify.io/iris-inventory-revision']='changed'
   else:m.container(h,'hermes-iris')['image']='changed'
   with self.assertRaises(m.Refusal):self.verify(v)
 def test_other_deployment_uid_or_spec_refused(self):
  for key in ('uid','spec','extra'):
   v=self.successor();d=m.by_name(v['items'])['verdify-ingestor']
   if key=='uid':d['metadata']['uid']='changed'
   elif key=='spec':d['spec']['replicas']=2
   else:v['items'].append(copy.deepcopy(v['items'][0]))
   with self.assertRaises(m.Refusal):self.verify(v)
 def test_rollout_incomplete_refused(self):
  for name in ('verdify-api','verdify-hermes-iris'):
   v=self.successor();m.by_name(v['items'])[name]['status']['updatedReplicas']=0
   with self.assertRaises(m.Refusal):self.verify(v)
 def test_current_mcp_ready_and_state_refusals(self):
  p=next(p for p in self.pods if p['metadata'].get('labels',{}).get('app.kubernetes.io/component')=='mcp');m.pod_ready(p,'mcp',m.MCP_DIGEST)
  for key in ('empty','restart','deleting','laststate'):
   q=copy.deepcopy(p)
   if key=='empty':q['status']['containerStatuses']=[]
   elif key=='restart':q['status']['containerStatuses'][0]['restartCount']=1
   elif key=='deleting':q['metadata']['deletionTimestamp']='now'
   else:q['status']['containerStatuses'][0]['lastState']={'terminated':{'exitCode':1}}
   with self.assertRaises(m.Refusal):m.pod_ready(q,'mcp',m.MCP_DIGEST)
 def test_seed_exit_required(self):
  p=copy.deepcopy(next(p for p in self.pods if p['metadata'].get('labels',{}).get('app.kubernetes.io/component')=='hermes-iris'));m.pod_ready(p,'hermes-iris',m.HERMES)
  p['status']['initContainerStatuses'][0]['state']['terminated']['exitCode']=1
  with self.assertRaises(m.Refusal):m.pod_ready(p,'hermes-iris',m.HERMES)
 def test_pinned_inputs_and_previous_runtime(self):
  for name,h in m.INPUT_PINS.items():self.assertEqual(m.sha((CONTROL/name).read_bytes()),h)
  e=json.loads((CONTROL/'runtime-expectations.json').read_bytes())
  for name,h in e['previous_runtime'].items():self.assertEqual(m.sha((BASE/'runtime-01'/name).read_bytes()),h)
  root=pathlib.Path('/private/tmp/verdify-daytime-consumer-source-20261018')
  for name,h in e['smoke_files'].items():self.assertEqual(m.sha((root/name).read_bytes()),h)
  self.assertEqual(e['hermes_cm']['verdify-hermes-iris-config']['config.yaml'][:12],m.PROFILE)
  self.assertFalse(any(x.endswith('/SKILL.md') for x in e['installed_hermes_files']))
 def test_native_drivers_no_product_import_or_scorecard(self):
  for name in ('runtime-mcp-readonly.py','runtime-hermes-readonly.py','runtime-api-readonly.py'):
   tree=ast.parse((CONTROL/name).read_text());mods={x.name for n in ast.walk(tree) if isinstance(n,ast.Import) for x in n.names};self.assertFalse(mods & {'mcp.server','planner_graph','ingestor','openai','asyncpg'})
  source=(CONTROL/'runtime-api-readonly.py').read_text();self.assertIn('http://127.0.0.1:8080/api/v1/public/planner-health',source);self.assertNotIn('OPENAI_API_KEY',source)
 def test_critical_fingerprint_detects_container_replacement(self):
  p=next(p for p in self.pods if p['metadata']['name']=='verdify-db-0');q=copy.deepcopy(p);q['status']['containerStatuses'][0]['containerID']='new';self.assertNotEqual(m.state_fingerprint(p),m.state_fingerprint(q))
if __name__=='__main__':unittest.main()
