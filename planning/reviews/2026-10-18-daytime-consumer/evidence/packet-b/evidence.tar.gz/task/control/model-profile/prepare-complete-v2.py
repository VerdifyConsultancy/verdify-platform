from pathlib import Path
import ast,difflib,hashlib,json,yaml
root=Path('/private/tmp/verdify-daytime-consumer-source-20261018')
base=Path('/private/tmp/verdify-daytime-consumer-20261018/control/model-profile')
out=base/'complete-v2';out.mkdir(exist_ok=False)
paths=['hermes/iris/config.yaml','deploy/k8s/components/hermes-iris/hermes-config.yaml','deploy/k8s/components/hermes-iris/hermes-iris.yaml','config/ai.yaml','deploy/k8s/vision/src/ai.yaml','api/main.py','deploy/k8s/base/api-deployment.yaml','tests/test_17_planner_health_surface.py','README.md']
old={p:(root/p).read_text() for p in paths}
new={p:(base/'draft'/p).read_text() for p in paths[:3]}
for p in paths[3:]:
 new[p]=old[p].replace('gpt-5.6-luna','gpt-6-luna').replace('GPT-5.6 Luna','GPT-6 Luna')
p='tests/test_17_planner_health_surface.py'
new[p]=new[p].replace('test_hermes_profile_pins_openai_gpt_5_6_luna_xhigh_at_the_runtime_key','test_hermes_profile_pins_openai_gpt_6_luna_xhigh_at_the_runtime_key').replace('test_planner_audit_metadata_and_current_docs_match_live_hermes_profile','test_planner_audit_metadata_and_readme_match_live_hermes_profile')
start=new[p].index('    current_docs = (',new[p].index('def test_planner_audit_metadata_and_readme_match_live_hermes_profile'))
end=new[p].index('\n\ndef test_api_public_planner_model_label',start)
new[p]=new[p][:start]+'''    # Model truth is the source-owned runtime profile, audit copies, README and
    # public API label. Installed prompt/playbook text is separately source-bound;
    # changing a model must not force an ingestor or inventory payload rollout.
    readme = (REPO_ROOT / "README.md").read_text()
    assert "GPT-6 Luna / xhigh" in readme
    assert "GPT-5.6 Luna" not in readme
'''+new[p][end:]
# Assert the two audit copies change only the planner model semantically.
for p in paths[3:5]:
 a=yaml.safe_load(old[p]);b=yaml.safe_load(new[p]);a['models']['planner']['model']='gpt-6-luna';assert a==b
assert new[paths[3]]==new[paths[4]]
# API implementation changes only its existing fallback label literal.
p='api/main.py';assert new[p]==old[p].replace('hermes-iris/custom:gpt-5.6-luna/xhigh','hermes-iris/custom:gpt-6-luna/xhigh')
# Deployment changes only the existing declarative environment label.
p='deploy/k8s/base/api-deployment.yaml';assert new[p]==old[p].replace('hermes-iris/custom:gpt-5.6-luna/xhigh','hermes-iris/custom:gpt-6-luna/xhigh')
for p in paths:
 dst=out/'draft'/p;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_text(new[p])
patch=''.join(''.join(difflib.unified_diff(old[p].splitlines(True),new[p].splitlines(True),fromfile='a/'+p,tofile='b/'+p)) for p in paths)
(out/'complete-model-profile.patch').write_text(patch)
# Run only four existing source/config tests from their AST, without importing
# test modules, conftest, product services or touching any network/process.
class OverlayPath:
 def __init__(self,rel=''):self.rel=rel
 def __truediv__(self,item):return OverlayPath(str(Path(self.rel)/item))
 def read_text(self):return new[self.rel] if self.rel in new else (root/self.rel).read_text()
functions=['_hermes_config_documents','test_hermes_profile_pins_openai_gpt_6_luna_xhigh_at_the_runtime_key','test_planner_audit_metadata_and_readme_match_live_hermes_profile','test_api_public_planner_model_label_is_declarative_and_matches_active_profile','test_hermes_profile_revision_rolls_and_reseeds_on_config_change']
tree=ast.parse(new['tests/test_17_planner_health_surface.py'])
selected=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in functions]
assert len(selected)==len(functions)
ns={'yaml':yaml,'json':json,'hashlib':hashlib,'REPO_ROOT':OverlayPath(),'ACTIVE_PLANNER_MODEL_LABEL':'hermes-iris/custom:gpt-6-luna/xhigh'}
exec(compile(ast.Module(body=selected,type_ignores=[]),'<four-existing-source-tests>','exec'),ns)
for fn in functions[1:]:ns[fn]()
sha=lambda raw:hashlib.sha256(raw if isinstance(raw,bytes) else raw.encode()).hexdigest()
unchanged=['ingestor/iris_planner.py','scripts/planner-dry.py','tests/test_prompt_variants.py','docs/planner/greenhouse-playbook.md','deploy/k8s/components/hermes-iris/iris-inventory.yaml','deploy/k8s/components/hermes-iris-experiment/hermes-config.yaml']
unchanged=[p for p in unchanged if (root/p).is_file()]
receipt={'schema':'verdify-gpt6-luna-complete-source-draft-v2','status':'SOURCE_ONLY_FOUR_EXISTING_PROFILE_TESTS_PASSED','files':{p:{'old_sha256':sha(old[p]),'new_sha256':sha(new[p])} for p in paths},'patch_sha256':sha(patch),'new_effective_profile_sha256':sha(yaml.safe_load(new[paths[1]])['data']['config.yaml']),'new_profile_revision':'2261f5c1a236','api_model_label':'hermes-iris/custom:gpt-6-luna/xhigh','unchanged_boundary_sha256':{p:sha((root/p).read_bytes()) for p in unchanged},'focused_checks':functions[1:],'checks_method':'Existing source-only test function ASTs evaluated against the exact draft overlay; no full module/conftest/product imports. Full native CI remains ROOT.','native_calls':0,'provider_calls':0,'source_only':True,'runtime_proof_pending':True,'retained_legacy_text':'Installed ingestor prompt and playbook still contain old display-name prose; these payloads and their authoritative hashes are deliberately unchanged. Runtime model truth is profile and API health metadata.','required_runtime_resources':['ConfigMap/verdify-hermes-iris-config','Deployment/verdify-hermes-iris','Deployment/verdify-api'],'api_image_build_required':True,'hermes_upstream_image_change_required':False}
(out/'handoff.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'path':str(out),'files':len(paths),'patch_sha256':sha(patch),'handoff_sha256':sha((out/'handoff.json').read_bytes()),'focused_existing_tests':4,'profile_sha256':receipt['new_effective_profile_sha256']},indent=2))
