import copy, datetime as dt, importlib.util, json, pathlib, unittest
p=pathlib.Path(__file__).with_name('emit.py');s=importlib.util.spec_from_file_location('emit',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
BASE=pathlib.Path('/private/tmp/verdify-daytime-consumer-20261018')
class Tests(unittest.TestCase):
 def app(self):return json.loads((BASE/'initial/application.json').read_text())
 def make(self,a):return m.build_patch(a,a['metadata']['uid'],a['metadata']['resourceVersion'],'Succeeded','1'*40)
 def test_actual_saved_terminal_app_exact_patch(self):
  p=self.make(self.app());op=p[-1]['value'];self.assertEqual(op['sync']['resources'],m.RESOURCES);self.assertIs(op['sync']['prune'],False);self.assertEqual(p[0]['path'],'/metadata/uid');self.assertEqual(p[1]['path'],'/metadata/resourceVersion');self.assertEqual(p[-2],{'op':'add','path':'/status/operationState','value':None})
 def test_current_operation_refused(self):
  a=self.app();a['operation']={'sync':{}}
  with self.assertRaises(ValueError):self.make(a)
 def test_nonterminal_phase_refused(self):
  a=self.app();a['status']['operationState']['phase']='Running'
  with self.assertRaises(ValueError):self.make(a)
 def test_uid_rv_mismatch_refused(self):
  a=self.app()
  for uid,rv in [('11111111-1111-1111-1111-111111111111',a['metadata']['resourceVersion']),(a['metadata']['uid'],'1')]:
   with self.assertRaises(ValueError):m.build_patch(a,uid,rv,'Succeeded','1'*40)
 def test_placeholder_revision_refused(self):
  a=self.app()
  with self.assertRaises(ValueError):m.build_patch(a,a['metadata']['uid'],a['metadata']['resourceVersion'],'Succeeded','TBD')
 def test_source_or_namespace_drift(self):
  for field,val in [('path','other'),('targetRevision','other')]:
   a=self.app();a['spec']['source'][field]=val
   with self.assertRaises(ValueError):self.make(a)
 def idle(self):
  now=dt.datetime.now(dt.timezone.utc);uid='11111111-1111-1111-1111-111111111111';v={'schema':'hermes-idle-readback-v2','pod_uid':uid,'captured_at':now.isoformat(),'health_http_status':200,'health':{'status':'ok','platform':'hermes-agent','gateway_state':'running','active_agents':0,'updated_at':now.isoformat(),'platforms':{'api_server':{}},'pid':32},'delivery_ledger':{'readonly':True,'complete':True,'captured_at':now.isoformat(),'rows_examined':0,'window_minutes':180,'pending_without_run_id':0,'unresolved_run_ids':[]},'run_statuses':[],'incoming_dispatch_frozen':False};return v,now,uid
 def test_idle_snapshot_honest_race(self):
  v,n,u=self.idle();self.assertTrue(m.validate_idle(v,n,u)['restart_race_remains'])
 def test_persistent_old_zero_is_not_current_idle_proof(self):
  v,n,u=self.idle();v['health']['updated_at']='2026-10-11T22:15:45.870281+00:00'
  out=m.validate_idle(v,n,u);self.assertTrue(out['health_non_authoritative']);self.assertFalse(out['health_activity_used_as_idle_proof']);self.assertFalse(out['current_exhaustive_idle_proven']);self.assertEqual(out['health_reported_active_agents'],0)
 def test_stale_health_fields_do_not_replace_live_known_run_status(self):
  v,n,u=self.idle();v['health']['active_agents']=3;v['health']['updated_at']=None
  v['delivery_ledger']['unresolved_run_ids']=['r'];v['run_statuses']=[{'run_id':'r','http_status':200,'status':'completed','captured_at':n.isoformat()}]
  self.assertEqual(m.validate_idle(v,n,u)['terminal_run_statuses'],1)
  v['run_statuses'][0]['status']='running'
  with self.assertRaises(ValueError):m.validate_idle(v,n,u)
 def test_stale_http_or_ledger_capture_refused(self):
  for part in ('captured_at','delivery_ledger'):
   v,n,u=self.idle()
   if part=='captured_at':v[part]='2000-01-01T00:00:00Z'
   else:v[part]['captured_at']='2000-01-01T00:00:00Z'
   with self.assertRaises(ValueError):m.validate_idle(v,n,u)
 def test_unknown_pending_or_incomplete_ledger_refused(self):
  for field,value in [('pending_without_run_id',1),('complete',False),('rows_examined',201)]:
   v,n,u=self.idle();v['delivery_ledger'][field]=value
   with self.assertRaises(ValueError):m.validate_idle(v,n,u)
 def test_health_http_failure_and_false_freeze_claim_refused(self):
  v,n,u=self.idle();v['health_http_status']=503
  with self.assertRaises(ValueError):m.validate_idle(v,n,u)
  v,n,u=self.idle();v['incoming_dispatch_frozen']=True
  with self.assertRaises(ValueError):m.validate_idle(v,n,u)
 def test_missing_run_or404_refused(self):
  v,n,u=self.idle();v['delivery_ledger']['unresolved_run_ids']=['r']
  with self.assertRaises(ValueError):m.validate_idle(v,n,u)
  v['run_statuses']=[{'run_id':'r','http_status':404,'status':'completed','captured_at':n.isoformat()}]
  with self.assertRaises(ValueError):m.validate_idle(v,n,u)
 def model_fixture(self):
  data=json.loads((BASE/'render-after/render.json').read_text());old=data['items'] if isinstance(data,dict) else data
  new=copy.deepcopy(old)
  cm=next(x for x in new if x['kind']=='ConfigMap' and x['metadata']['name']=='verdify-hermes-iris-config')
  raw=cm['data']['config.yaml'];self.assertIn('default: "gpt-5.6-luna"',raw)
  cm['data']['config.yaml']=raw.replace('default: "gpt-5.6-luna"','default: "gpt-6-luna"').replace('GPT-5.6 Luna','GPT-6 Luna')
  h=m.sha(cm['data']['config.yaml'].encode())
  dep=next(x for x in new if x['kind']=='Deployment' and x['metadata']['name']=='verdify-hermes-iris')
  dep['spec']['template']['metadata']['annotations']['verdify.io/hermes-profile-revision']=h[:12]
  api=next(x for x in new if x['kind']=='Deployment' and x['metadata']['name']=='verdify-api')
  m.ctr(api,'api')['image']='registry.vallery.net/verdifyconsultancy/verdify-api@sha256:'+'a'*64
  next(e for e in m.ctr(api,'api')['env'] if e['name']=='VERDIFY_PLANNER_MODEL_LABEL')['value']='hermes-iris/custom:gpt-6-luna/xhigh'
  return old,new,h
 def validate(self,old,new,h):return m.validate_render(m.inventory(old),m.inventory(new),h,'a'*64)
 def test_actual_full_render_model_only(self):
  old,new,h=self.model_fixture();r=self.validate(old,new,h)
  self.assertEqual(r['new_model'],'gpt-6-luna');self.assertEqual(r['unchanged_inventory_revision'],'5733c1c6b35d')
  self.assertEqual(r['rendered_object_count'],129);self.assertEqual(r['unchanged_rendered_objects'],126)
 def test_exact_three_selector_never_mcp_or_hook(self):
  self.assertEqual([(x['kind'],x['name']) for x in m.RESOURCES],[('ConfigMap','verdify-hermes-iris-config'),('Deployment','verdify-api'),('Deployment','verdify-hermes-iris')])
 def test_profile_other_semantics_refused(self):
  for oldval,newval in [('reasoning_effort: xhigh','reasoning_effort: low'),('provider: "custom"','provider: "other"'),('https://api.openai.com/v1','https://wrong.example/v1')]:
   old,new,h=self.model_fixture();cm=next(x for x in new if x['kind']=='ConfigMap' and x['metadata']['name']=='verdify-hermes-iris-config');raw=cm['data']['config.yaml'];self.assertIn(oldval,raw)
   cm['data']['config.yaml']=raw.replace(oldval,newval);h=m.sha(cm['data']['config.yaml'].encode());dep=next(x for x in new if x['kind']=='Deployment' and x['metadata']['name']=='verdify-hermes-iris');dep['spec']['template']['metadata']['annotations']['verdify.io/hermes-profile-revision']=h[:12]
   with self.subTest(oldval=oldval),self.assertRaises(ValueError):self.validate(old,new,h)
 def test_wrong_model_and_profile_hash_refused(self):
  old,new,h=self.model_fixture()
  with self.assertRaises(ValueError):self.validate(old,new,'a'*64)
  cm=next(x for x in new if x['kind']=='ConfigMap' and x['metadata']['name']=='verdify-hermes-iris-config');cm['data']['config.yaml']=cm['data']['config.yaml'].replace('gpt-6-luna','gpt-6-sol');h=m.sha(cm['data']['config.yaml'].encode())
  with self.assertRaises(ValueError):self.validate(old,new,h)
 def test_readiness_and_inventory_payload_refused(self):
  for name,key in [('verdify-hermes-iris-config','tool-readiness.py'),('verdify-iris-inventory','SOUL.md')]:
   old,new,h=self.model_fixture();cm=next(x for x in new if x['kind']=='ConfigMap' and x['metadata']['name']==name);cm['data'][key]+='changed'
   with self.subTest(name=name),self.assertRaises(ValueError):self.validate(old,new,h)
 def test_mcp_and_hermes_runtime_other_change_refused(self):
  for name in ['verdify-mcp','verdify-hermes-iris']:
   old,new,h=self.model_fixture();dep=next(x for x in new if x['kind']=='Deployment' and x['metadata']['name']==name);dep['spec']['template']['spec']['containers'][0]['image']='unexpected'
   with self.subTest(name=name),self.assertRaises(ValueError):self.validate(old,new,h)
 def test_inventory_revision_and_profile_revision_refused(self):
  for annot in ['verdify.io/iris-inventory-revision','verdify.io/hermes-profile-revision']:
   old,new,h=self.model_fixture();dep=next(x for x in new if x['kind']=='Deployment' and x['metadata']['name']=='verdify-hermes-iris');dep['spec']['template']['metadata']['annotations'][annot]='0'*12
   with self.subTest(annot=annot),self.assertRaises(ValueError):self.validate(old,new,h)
 def test_duplicate_yaml_key_refused(self):
  old,new,h=self.model_fixture();cm=next(x for x in new if x['kind']=='ConfigMap' and x['metadata']['name']=='verdify-hermes-iris-config');cm['data']['config.yaml']+='\nmodel: {default: gpt-6-luna}\n';h=m.sha(cm['data']['config.yaml'].encode())
  with self.assertRaisesRegex(ValueError,'duplicate_profile_yaml_key'):self.validate(old,new,h)
 def test_added_object_or_config_key_refused(self):
  old,new,h=self.model_fixture();new.append({'apiVersion':'v1','kind':'ConfigMap','metadata':{'name':'unrelated'},'data':{}})
  with self.assertRaises(ValueError):self.validate(old,new,h)
  old,new,h=self.model_fixture();cm=next(x for x in new if x['kind']=='ConfigMap' and x['metadata']['name']=='verdify-hermes-iris-config');cm['data']['unrelated']='changed'
  with self.assertRaises(ValueError):self.validate(old,new,h)
 def test_api_wrong_digest_or_extra_env_refused(self):
  for mode in ['digest','label','extra_env','wave']:
   old,new,h=self.model_fixture();api=next(x for x in new if x['kind']=='Deployment' and x['metadata']['name']=='verdify-api');c=m.ctr(api,'api')
   if mode=='digest':c['image']='registry.vallery.net/verdifyconsultancy/verdify-api@sha256:'+'b'*64
   elif mode=='label':next(e for e in c['env'] if e['name']==m.MODEL_ENV)['value']='hermes-iris/custom:gpt-6-luna/low'
   elif mode=='extra_env':c['env'].append({'name':'UNRELATED','value':'1'})
   else:api['metadata'].setdefault('annotations',{})['argocd.argoproj.io/sync-wave']='10'
   with self.subTest(mode=mode),self.assertRaises(ValueError):self.validate(old,new,h)
 def test_current_mcp_pin_must_be_accepted_source(self):
  old,new,h=self.model_fixture()
  for objs in (old,new):
   mcp=next(x for x in objs if x['kind']=='Deployment' and x['metadata']['name']=='verdify-mcp');m.ctr(mcp,'mcp')['image']='registry.vallery.net/verdifyconsultancy/verdify-mcp@sha256:'+'b'*64
  with self.assertRaisesRegex(ValueError,'accepted_mcp_pin'):self.validate(old,new,h)
 def test_secret_or_duplicate_render_refused(self):
  with self.assertRaises(ValueError):m.inventory([{'apiVersion':'v1','kind':'Secret','metadata':{'name':'x'}}])
  obj={'apiVersion':'v1','kind':'ConfigMap','metadata':{'name':'x'}}
  with self.assertRaises(ValueError):m.inventory([obj,obj])
if __name__=='__main__':unittest.main()
