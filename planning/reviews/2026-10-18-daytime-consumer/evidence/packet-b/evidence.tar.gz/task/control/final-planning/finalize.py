#!/usr/bin/env python3
"""Offline receipt-bound planning/report finalizer; writes a new private output only."""
import argparse
import copy
import datetime as dt
import difflib
import hashlib
import json
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
BASE = HERE.parents[1]
MCP_SOURCE = 'b814f35e228fcb35c11593c47ea1e021e5fd73de'
MODEL_SOURCE = '182691082420466dc1c5b39bae2fd84f49f38dbf'
MCP_DIGEST = 'ae8a367035a3ae8a06ab2384bc166f444b3decad0da21e5c70e53e76203d9c73'
PROFILE = '2261f5c1a236202b3bfccedd82f1284f50ab27445767dcb09439a92a8d58b56b'
REVIEW = 'planning/reviews/2026-10-18-daytime-consumer'
ROLES = {'source_ci', 'initial_rollout', 'initial_runtime', 'release_ci', 'daytime',
         'graph_before', 'database', 'model_source_ci', 'model_rollout', 'model_release_ci',
         'model_runtime', 'model_runtime_terminal', 'consumer', 'consumer_terminal', 'consumer_start'}
SCOPE = 'This read-only qualification does not prove natural-cycle use, complete daytime coverage, causal efficacy, or crop safety.'
NEXT410 = ('Define a supported observation/freshness contract and collect a prospective complete recorded daytime window; '
           'preserve the incomplete October 16/17 history. Observe intended outcome consumption in a naturally scheduled '
           'ordinary planner cycle, separately from the accepted bounded read/model qualification. Measure that new '
           'cycle before comparing cost. Reuse the installed getter and accepted delivery; keep physical efficacy, '
           'crop sensing and crop safety on their own evidence.')
NEXT775 = ('Pull the prospective observation/freshness packet, natural ordinary-consumer observation and authentic '
           'scientific/physical inputs as they become concrete. Reuse accepted getter, S3B and bounded consumer '
           'receipts; preserve negative/incomplete outcomes, the 40-hour budget and original 22–34h estimates. '
           'Do not repeat accepted delivery, infer remaining hours or close unfinished acceptance.')

class Refusal(ValueError): pass

def need(ok, code):
    if not ok: raise Refusal(code)

def sha(raw): return hashlib.sha256(raw).hexdigest()
def js(x): return json.dumps(x, indent=2, ensure_ascii=False) + '\n'
def h64(x): return isinstance(x, str) and re.fullmatch('[0-9a-f]{64}', x) is not None

def read_inputs(manifest):
    need(manifest.get('schema') == 'daytime-final-planning-inputs/v1', 'input_schema')
    need(manifest.get('status') == 'ready_actual_receipts', 'input_not_ready')
    refs = manifest['receipts']; need(set(refs) == ROLES, 'receipt_roles')
    values, raw = {}, {}
    for role, ref in refs.items():
        need(set(ref) == {'path','sha256'} and h64(ref['sha256']), 'receipt_reference')
        p = Path(ref['path']); need(p.is_absolute() and p.is_file() and not p.is_symlink(), 'receipt_file')
        need(p.stat().st_size <= 2 * 1024 * 1024, 'receipt_size')
        raw[role] = p.read_bytes(); need(sha(raw[role]) == ref['sha256'], 'receipt_hash_' + role)
        values[role] = json.loads(raw[role])
    return values, raw

def exact_rollout(value, revision, expected, status):
    need(value['status'] == status and value['revision'] == revision and value['hooks'] == 0 and value['prune'] is False, 'rollout_status')
    resources = value['resources']
    need(len(resources) == len(expected) and {(r.get('group',''),r['kind'],r['name'],r['namespace']) for r in resources} == expected, 'rollout_scope')
    need(all(r['status'] == 'Synced' and r['syncPhase'] == 'Sync' for r in resources), 'rollout_results')

def release_ci(value, revision):
    need(value['status'] == 'DIRECT_TERMINAL_VALIDATE_ONLY_MAIN_CI_PASSED' and value['source_revision'] == revision, 'release_ci_source')
    need(value['actual_pods'] == 1 and value['actual_build_pods'] == 0 and value['all_eight_build_flags_false'] is True and value['all_declared_containers_zero_exit_zero_restarts'] is True, 'release_ci_completion')

def validate(v, raw):
    ci = v['source_ci']; mci = v['model_source_ci']; rt = v['model_runtime']; c = v['consumer']; graph = v['graph_before']
    need(ci['status'] == 'SOURCE_GATE_FIVE_BUILDS_AND_PIN_PUBLISHER_VERIFIED' and ci['source_revision'] == MCP_SOURCE and ci['images']['mcp']['digest'] == 'sha256:'+MCP_DIGEST, 'source_ci')
    need(mci['status'] == 'SOURCE_GATE_TWO_BUILDS_AND_PIN_PUBLISHER_VERIFIED' and mci['source_revision'] == MODEL_SOURCE, 'model_ci')
    api = mci['images']['api']; need(api['source-revision'] == MODEL_SOURCE and api['resolved-revision'] == MODEL_SOURCE and re.fullmatch('sha256:[0-9a-f]{64}',api['digest']), 'model_api_image')
    need(rt['status'] == 'POST_ROLLOUT_RUNTIME_CUSTODY_PASSED' and rt['source_sha'] == MCP_SOURCE and rt['mcp_digest'] == MCP_DIGEST and rt['api_source_sha'] == MODEL_SOURCE and rt['api_digest'] == api['digest'].split(':')[1], 'model_runtime_source')
    need(rt['ci_receipt_sha256'] == sha(raw['source_ci']) and rt['api_ci_receipt_sha256'] == sha(raw['model_source_ci']) and rt['effective_model_config_sha256'] == PROFILE, 'runtime_receipt_binding')
    need(rt['deployment_uids_preserved'] == 15 and rt['unchanged_deployment_specs'] == 13 and rt['unrelated_deployment_specs_unchanged'] == 12 and rt['critical_pods_and_container_states_unchanged'] == 2 and rt['accepted_mcp_deployment_and_pods_unchanged'] is True, 'runtime_preservation')
    need(rt['smoke_checks'] == 9 and rt['exactly_one_device_writer_observed'] is True and rt['new_gateway_process_verified'] is True and rt['natural_cycle_verified'] is False and rt['provider_calls'] == 0 and rt['actual_scorecard_calls'] == 0, 'runtime_scope')
    old = v['initial_runtime']
    need(old['status'] == 'POST_ROLLOUT_RUNTIME_CUSTODY_PASSED' and old['source_sha'] == MCP_SOURCE and old['mcp_digest'] == MCP_DIGEST and old['ci_receipt_sha256'] == sha(raw['source_ci']), 'initial_runtime')
    need(old['deployment_uids_preserved'] == 15 and old['unchanged_deployment_specs'] == 13 and old['critical_pods_and_container_states_unchanged'] == 4 and old['smoke_checks'] == 9 and old['exactly_one_device_writer_observed'] is True, 'initial_runtime_scope')
    need(old['hermes']['uid'] != rt['hermes']['uid'] and {p['uid'] for p in old['mcp']} == {p['uid'] for p in rt['mcp']} and len(rt['mcp']) == 2, 'runtime_pods')
    for role, target in [('model_runtime_terminal','model_runtime'),('consumer_terminal','consumer')]:
        need(v[role]['status'] == 'PASSED' and v[role]['verified_sha256'] == sha(raw[target]) and v[role]['automatic_retries'] == 0, 'terminal_'+role)
    exact_rollout(v['initial_rollout'],old['release_sha'],{('', 'ConfigMap','verdify-iris-inventory','verdify-prod'),('apps','Deployment','verdify-mcp','verdify-prod'),('apps','Deployment','verdify-hermes-iris','verdify-prod')},'EXACT_THREE_RESOURCE_OPERATION_SUCCEEDED')
    exact_rollout(v['model_rollout'],rt['release_sha'],{('', 'ConfigMap','verdify-hermes-iris-config','verdify-prod'),('', 'ConfigMap','verdify-vision-src','verdify-prod'),('apps','Deployment','verdify-api','verdify-prod'),('apps','Deployment','verdify-hermes-iris','verdify-prod')},'EXACT_FOUR_RESOURCE_OPERATION_SUCCEEDED')
    release_ci(v['release_ci'],old['release_sha']); release_ci(v['model_release_ci'],rt['release_sha'])
    need(c['status'] == 'TWO_BOUNDED_ORDINARY_CONSUMERS_PASSED' and c['source'] == MCP_SOURCE and c['image'] == MCP_DIGEST and c['provider_calls'] == 4 and c['actual_scorecard_calls'] == 2 and c['other_tools_dispatched'] == 0 and c['automatic_retries'] == 0, 'consumer_completion')
    need(c['all46_oct04_values_preserved'] is True and all(c[k] is False for k in ['daytime_complete_zero_proven','natural_cycle_verified','whole_issue_acceptance']), 'consumer_scope')
    start=v['consumer_start']; need(start['runtime_verified_sha256'] == sha(raw['model_runtime']) and start['input_sha256']['runtime'] == sha(raw['model_runtime']), 'consumer_runtime_link')
    cases = {x['date']:x for x in c['cases']}; need(len(c['cases']) == 2 and set(cases) == {'2026-10-04','2026-10-16'}, 'consumer_dates')
    for date,case in cases.items():
        need(case['provider_calls'] == 2 and case['scorecard_calls'] == 1 and type(case['output_tokens']) is int and 0 <= case['output_tokens'] <= 2000 and case['native_elapsed_seconds'] <= 90 and case['natural_cycle_verified'] is False and case['whole_issue_acceptance'] is False, 'consumer_case_bounds')
        i=case['interpretation']; need(i['night_date'] == date and i['scope_statement'] == SCOPE and all(i[k] is False for k in ['efficacy_proven','crop_safety_proven','complete_daytime_zero_proven','evidence_complete']), 'consumer_interpretation')
    i4=cases['2026-10-04']['interpretation']; i16=cases['2026-10-16']['interpretation']
    need(i4['availability'] == 'available' and i4['episode_count'] == 4 and i4['dispositions'] == {'effective':0,'ineffective':2,'blocked':0,'insufficient_evidence':2}, 'oct04_result')
    need(i16['availability'] == 'no_episodes' and i16['episode_count'] == 0 and i16['safety_gate_status'] == 'pending' and i16['daytime_dry_action_samples'] is None and i16['daytime_hold_admission_samples'] is None, 'oct16_result')
    need(c['total_output_tokens'] == sum(x['output_tokens'] for x in cases.values()), 'consumer_usage')
    d=v['daytime']; need(d['result_integrity_passed'] is True and d['prior_observed_counts_match'] is True and all(d[k] is False for k in ['complete_recorded_daytime_zero','continuous_physical_absence_proven','full_issue_acceptance']), 'daytime_scope')
    need(len(d['days'])==2, 'daytime_dates')
    for row,date,expected,missing,dry in zip(d['days'],['2026-10-16','2026-10-17'],[669,666],[25,23],[12,2]):
        need(row['local_date']==date and row['recorded_coverage']=='incomplete' and row['expected_solar_day_minutes']==expected and row['missing_climate_minutes']==row['missing_action_minutes']==missing and row['source_daytime_held_admission_minutes']==row['unknown_held_classification_minutes']==0 and row['known_ordinary_daytime_dehumidification_minutes']==dry and row['measured_zero_for_complete_recorded_minutes'] is None,'daytime_counts')
    need(graph['status']=='MATCH' and graph['errors']==[] and graph['source_revision']==MCP_SOURCE and [graph[k] for k in ['open_issues','canonical_records','open_acceptance_clauses','local_active_edges','total_active_edges','closed_predecessor_records']]==[47,93,143,26,27,24], 'before_graph')
    db=v['database']; need(db['status']=='INSTALLED_GETTER277_SOURCE_DATABASE_IDENTITY_VERIFIED','database_status')
    db=db['database']; need(db['database']=='verdify' and db['read_only']=='on' and db['ledger_count']==285 and db['ledger_max']==277 and db['postmaster']=='2026-09-29T00:40:56.280382+00:00','database_identity')
    funcs={x['identity']:x for x in db['functions']}; need(funcs['fn_realized_solar_night_dryout(date,date,text)']['source_sha256']=='578a07bed56714cd2dfe2308ca30ced1f6fc6916fd7db9d79630a7b82b261655' and funcs['fn_realized_solar_night_dryout(date,date,text)']['definition_sha256']=='89782089fd6ae3ecfeecdfbc1b730f6ab6a272c0da7b35ef562788eddbfa42c0' and funcs['fn_solar_phase(timestamp with time zone)']['source_sha256']=='62684cddbc97f5f89e61cdaa6646ee949e40073dd9fcb4ca89b26bd1334daddf','database_functions')
    return cases

def graph_text(g):
    return (f"The prepublication native snapshot at {g['checked_at']} (source `{g['source_revision']}`) matched "
            "47 open issues, 93 canonical records, 143 open acceptance clauses, 26 local active edges plus "
            "HA #878 → #981 (27 total), and 24 closed predecessor records. This update preserves those contracts "
            "and relationships. Publication-bound native conformance is recorded separately after ROOT commits "
            "and updates GitHub; this report does not assert a future final MATCH.")

def texts(v):
    ci=v['model_source_ci'];rt=v['model_runtime'];c=v['consumer'];op=v['model_rollout']
    model_ci=(f"Model source CI `{ci['workflow']}` / `{ci['workflow_uid']}` completed at {ci['finished_at']}: "
              f"the full source gate, API and orchestrator builds, and candidate publication passed. The qualified API "
              f"digest is `{rt['api_digest']}`. Only API was promoted from those two candidates; the orchestrator release pin was retained.")
    delivery=(f"Model release `{rt['release_sha']}` completed its exact four-resource selective operation at {op['finished_at']}: "
              "the Hermes profile ConfigMap, planner audit metadata in the vision ConfigMap, API Deployment and Hermes Deployment. "
              "It ran no hooks or migrations and did not prune. The subsequent actual runtime readback matched the new API source/image "
              f"and model label, and Hermes Pod `{rt['hermes']['uid']}` loaded the exact GPT-6 Luna/xhigh profile `{PROFILE}`. "
              "MCP stayed on its accepted image and same two Pods; all 15 Deployment UIDs, 12 unrelated Deployment specs and the "
              "critical DB/ingestor states were preserved. All 9 smoke checks passed and exactly 1 device writer was observed. "
              f"The normal model-release validation workflow `{v['model_release_ci']['workflow']}` completed at {v['model_release_ci']['finished_at']}. "
              "Source cache renewal is a fresh-process result, not live registry introspection or natural-cycle use.")
    consumer=("Two actual bounded ordinary-consumer cases passed using GPT-6 Luna/xhigh over Responses and the existing Iris audience. "
              "October 4 returned the same four complete 46-field rows as the prior installed-production custom read: two ineffective "
              "and two insufficient-evidence, none effective. October 16 returned no episodes, pending safety and NULL daytime counts. "
              f"There were exactly 2 authenticated scorecard reads and 4 provider requests, using {c['total_output_tokens']} output tokens "
              "in total, with no other tools dispatched or retries. The fixed structured scope statement and actual counts/NULLs passed; "
              "this is forced, bounded evidence consumption, not autonomous tool selection or a full Hermes gateway cycle.")
    db=(f"The bounded database metadata read at {v['database']['at']} confirms ledger 285/max 277, the original postmaster, "
        "and unchanged getter body/definition and solar helper. This is metadata readback at that timestamp, not a claim of full data parity. "
        "The selected operations contain no migration or data rewrite.")
    return {'MODEL_SOURCE_CI':model_ci,'MODEL_RELEASE_RUNTIME':delivery,'CONSUMER_RESULT':consumer,'DATABASE_RESULT':db,'GRAPH_RESULT':graph_text(v['graph_before'])}

def updates(draft,v,parts):
    u=copy.deepcopy(draft)
    coverage=draft['410']['baseline'].split('\n\n')[1]
    reader=("The optional default-off Iris scorecard reader from b814f35e is delivered at MCP digest "+MCP_DIGEST+". "
            "An explicit solar-night start date requests one bounded existing-getter read, preserving all 46 fields, NULLs, "
            "dispositions and confounds under the 500-episode/64-KiB limit. Iris retains 23 tools and outcome_kpi remains admin-only. "
            "The source-owned SOUL/inventory refresh is accepted; it requests prior-completed-night ordinary SUNRISE/SUNSET use.")
    model=("The separately authorized GPT-6 Luna/xhigh profile and truthful API label are delivered from source "+MODEL_SOURCE+
           ". The profile is "+PROFILE+"; installed prompt/playbook/inventory prose remains unchanged, including legacy model-name text. "
           "No new natural cycle was launched; natural-cycle cost and the 20% comparison baseline remain unknown.")
    for n in ['410','775']:
        prior=draft[n]['baseline'].split('\n\n')[0]
        detail=parts['CONSUMER_RESULT'] if n=='410' else 'The two actual GPT-6 Luna/xhigh bounded cases passed: October 4 remained two ineffective/two insufficient-evidence; October 16 remained empty/pending with NULL daytime counts. Exactly two ordinary reads and four provider calls were made, with no actions or retries.'
        nxt=NEXT410 if n=='410' else NEXT775
        u[n]['baseline']='\n\n'.join([prior,coverage,reader,model,detail,'Current execution allocation: '+('S3B follow-up' if n=='410' else 'ROLLUP')+'. Next action: '+nxt,graph_text(v['graph_before']) if n=='775' else 'Full #410 remains open: bounded source, runtime, ordinary read and model interpretation do not prove a natural planner cycle, complete daytime observation or physical efficacy.','Evidence: '+REVIEW+'/README.md. All acceptance clauses, states, parents, dependencies and original estimates remain unchanged.'])
        u[n]['next_action']=nxt
    u['410']['how'][3]='Reuse accepted actual Iris HTTP, source-owned Hermes refresh and separately bounded GPT-6 Luna interpretation. Observe a naturally scheduled ordinary-planner cycle separately and measure its cost before comparing. Preserve the distinction between safety, efficacy, incomplete coverage and crop safety; no universal VPD target or tuning follows.'
    u['410']['decision']='The existing Iris scorecard audience and user-authorized model export/upgrade have delivered the bounded ordinary-consumer path. No new credential or admin audience is needed. Full #410 stays open for prospective complete observation, natural use and physical/control evidence; do not repeat accepted delivery or infer missing historical values.'
    u['775']['how'][2]='Reuse completed P1/P2/P4, installed getter 277, ordinary MCP delivery, the authorized GPT-6 Luna upgrade and accepted bounded consumer proof. Pull prospective complete recorded daytime observation, natural planner use and authentic physical/input work. Retain ineffective, incomplete and empty results and original estimates.'
    u['775']['decision']='The requested bounded ordinary read/model packet and authorized live GPT-6 Luna upgrade are complete at their recorded scope. No additional user decision is identified here. Future physical/launch decisions require concrete scope; natural-cycle cost, complete historical coverage and full issue acceptance remain unproven.'
    return u

def protected(plan):
    p=copy.deepcopy(plan)
    for item in p['issues']:
        if item['issue_number'] in (410,775):
            for key in ('baseline','how','decision'): item.pop(key,None)
    for key in ('reviewed_at','source_revision','review_path'): p['execution_plan'].pop(key,None)
    for a in p['execution_plan']['allocations']:
        if a['issue_number'] in (410,775): a.pop('next_action',None)
    return p

def plan_update(original,u,reviewed_at,review_source):
    need(re.fullmatch('[0-9a-f]{40}',review_source) is not None,'review_revision')
    p=copy.deepcopy(original); changed=[]
    for i in p['issues']:
        n=str(i['issue_number'])
        if n in u:
            need(i['status']=='open','issue_not_open')
            for key in ('baseline','how','decision'): i[key]=u[n][key]
            changed.append(int(n))
    need(sorted(changed)==[410,775],'issue_inventory')
    for a in p['execution_plan']['allocations']:
        if str(a['issue_number']) in u: a['next_action']=u[str(a['issue_number'])]['next_action']
    p['execution_plan'].update(reviewed_at=reviewed_at,source_revision=review_source,review_path=REVIEW+'/README.md')
    need(protected(p)==protected(original),'unrelated_canonical_change')
    opened=[i for i in p['issues'] if i['status']=='open']
    need(len(p['issues'])==93 and len(opened)==47 and sum(len(i['acceptance']) for i in opened)==143,'canonical_counts')
    return p

def run(a):
    need(a.out.is_absolute() and a.out.resolve().is_relative_to(Path('/private/tmp')) and not a.out.resolve().is_relative_to(a.source_root.resolve()) and not a.out.exists(),'new_private_output_required')
    manifest_raw=a.inputs.read_bytes(); manifest=json.loads(manifest_raw);v,raw=read_inputs(manifest);validate(v,raw)
    backlog=a.source_root/'planning/backlog.yaml'; oldraw=backlog.read_bytes();need(sha(oldraw)==a.backlog_sha256,'backlog_changed')
    need(v['graph_before']['backlog_sha256']==sha(oldraw),'graph_before_backlog_binding')
    old=json.loads(oldraw);draft_raw=(BASE/'final-planning-draft/proposed-updates.json').read_bytes()
    need(sha(draft_raw)=='8e9c7c4e2eba88c3032c5b37a17e751a151793ad3107d099a8e9362463861c37','draft_changed')
    parts=texts(v);u=updates(json.loads(draft_raw),v,parts)
    now=dt.datetime.now(dt.timezone.utc).isoformat(); p=plan_update(old,u,now,a.review_source_sha)
    template=(HERE/'report-template.md').read_text();report=template
    for key,value in parts.items():report=report.replace('[['+key+']]',value)
    need('[[' not in report and not re.search(r'\[\[PENDING|Finish the pending',js(u)),'unfilled_report')
    sys.path.insert(0,str(a.source_root));from planning.schema import Backlog
    from planning.render import outputs,issue_body
    model=Backlog.model_validate(p); rendered=outputs(model);need(len(rendered)==7,'render_count')
    bodies={str(i.issue_number):issue_body(i,model) for i in model.issues if i.issue_number in (410,775)}
    # Ensure every other issue's rendered contract remains identical too.
    original_model=Backlog.model_validate(old)
    olditems={i.issue_number:i for i in original_model.issues}
    need(all(issue_body(i,model)==issue_body(olditems[i.issue_number],original_model) for i in model.issues if i.issue_number not in (410,775)),'unrelated_issue_body_change')
    files={'repo/planning/backlog.yaml':js(p),'proposed-updates.json':js(u),'repo/'+REVIEW+'/README.md':report,
           'repo/'+REVIEW+'/DEPENDENCIES.md':'# Graph custody\n\n'+parts['GRAPH_RESULT']+'\n',**{'repo/'+k:v for k,v in rendered.items()},**{'github-bodies/'+n+'.md':text for n,text in bodies.items()}}
    patch=[]
    for name,new in files.items():
        if not name.startswith('repo/'): continue
        rel=name[5:];path=a.source_root/rel;before=path.read_text() if path.is_file() else ''
        patch.extend(difflib.unified_diff(before.splitlines(keepends=True),new.splitlines(keepends=True),fromfile='a/'+rel,tofile='b/'+rel))
    files['canonical-generated.patch']=''.join(patch)
    need(backlog.read_bytes()==oldraw and all(Path(manifest['receipts'][r]['path']).read_bytes()==data for r,data in raw.items()),'inputs_changed')
    a.out.mkdir(mode=0o700)
    for name,text in files.items():
        path=a.out/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_text(text)
    handoff={'schema':'daytime-final-private-planning/v1','status':'ACTUAL_RECEIPT_BOUND_PRIVATE_OUTPUT_READY','created_at':now,'review_source_revision':a.review_source_sha,
             'input_manifest_sha256':sha(manifest_raw),'inputs':manifest['receipts'],'original_backlog_sha256':sha(oldraw),'driver_sha256':sha(Path(__file__).read_bytes()),'report_template_sha256':sha(template.encode()),
             'changed_issues':[410,775],'generated_views':7,'canonical_records':93,'open_issues':47,'open_acceptance_clauses':143,'active_edges_preserved':27,
             'all_protected_canonical_fields_equal':True,'all_unrelated_issue_bodies_equal':True,'natural_cycle_verified':False,'natural_cycle_cost_baseline':None,'postpublication_graph_claimed':False,
             'files':{name:sha(text.encode()) for name,text in files.items()},'source_edits':0,'git_operations':0,'github_writes':0,'native_operations':0}
    (a.out/'handoff.json').write_text(js(handoff))
    need(all(sha((a.out/name).read_bytes())==digest for name,digest in handoff['files'].items()),'output_readback')
    print(js({'status':handoff['status'],'out':str(a.out),'handoff_sha256':sha((a.out/'handoff.json').read_bytes())}).strip())

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source-root',type=Path,required=True);p.add_argument('--backlog-sha256',required=True);p.add_argument('--inputs',type=Path,required=True);p.add_argument('--review-source-sha',required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
    try:run(a);return 0
    except Exception as e: print(js({'status':'REFUSED','code':str(e) if isinstance(e,Refusal) else type(e).__name__}).strip());return 1
if __name__=='__main__':raise SystemExit(main())
