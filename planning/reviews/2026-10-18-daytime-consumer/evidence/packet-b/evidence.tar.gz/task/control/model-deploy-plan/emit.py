#!/usr/bin/env python3
"""Pure exact-two-resource model-profile Argo JSON-patch emitter. No network or subprocesses.
ROOT supplies fresh retained metadata and executes at most one reviewed patch.
A generated patch does not claim admission, submission, rollout or acceptance.
"""
import argparse, copy, datetime as dt, hashlib, json, pathlib, re, uuid
import yaml
OLD_PROFILE_SHA='51de00576417701fc4fed8fb03ec9a3f1bfbee5e4f5d057f25b763076c2a8b5f'
INVENTORY='5733c1c6b35d'
OLD_MODEL='gpt-5.6-luna'
NEW_MODEL='gpt-6-luna'
RESOURCES=[{'group':'','kind':'ConfigMap','name':'verdify-hermes-iris-config','namespace':'verdify-prod'},
           {'group':'apps','kind':'Deployment','name':'verdify-hermes-iris','namespace':'verdify-prod'}]
TERMINAL={'Succeeded','Failed','Error'}

def require(ok,code):
 if not ok:raise ValueError(code)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def load(path):return json.loads(path.read_text())
def key(obj):
 api=obj['apiVersion'];return (api.split('/')[0] if '/' in api else '',obj['kind'],obj['metadata']['name'],obj['metadata'].get('namespace','verdify-prod'))
def inventory(data):
 data=data.get('items') if isinstance(data,dict) else data
 require(isinstance(data,list),'render_list_required')
 out={}
 for obj in data:
  k=key(obj);require(k not in out,'duplicate_object');require(obj['kind']!='Secret','rendered_secret_forbidden');out[k]=obj
 return out
def tuple_of(r):return (r['group'],r['kind'],r['name'],r['namespace'])
def ctr(obj,name):
 matches=[x for x in obj['spec']['template']['spec']['containers'] if x['name']==name]
 require(len(matches)==1,'container_identity');return matches[0]
class UniqueLoader(yaml.SafeLoader):
 pass
def unique_mapping(loader,node,deep=False):
 loader.flatten_mapping(node)
 out={}
 for kn,vn in node.value:
  k=loader.construct_object(kn,deep=deep)
  require(k not in out,'duplicate_profile_yaml_key')
  out[k]=loader.construct_object(vn,deep=deep)
 return out
UniqueLoader.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG,unique_mapping)
def profile(raw):
 require(isinstance(raw,str) and len(raw.encode())<=65536,'profile_size_or_type')
 value=yaml.load(raw,Loader=UniqueLoader)
 require(isinstance(value,dict) and isinstance(value.get('model'),dict),'profile_mapping')
 return value
def canonical(value):return json.dumps(value,sort_keys=True,allow_nan=False,separators=(',',':'))
def validate_render(before,after,profile_sha256):
 require(re.fullmatch('[0-9a-f]{64}',profile_sha256) is not None,'profile_digest_shape')
 require(set(before)==set(after),'inventory_changed')
 changed={k for k in before if before[k]!=after[k]}
 require(changed=={tuple_of(r) for r in RESOURCES},'diff_not_exact_two')
 cmk,hk=[tuple_of(r) for r in RESOURCES]
 oldcm,newcm=before[cmk],after[cmk]
 require(set(oldcm['data'])==set(newcm['data'])=={'config.yaml','tool-readiness.py'},'profile_data_keys_changed')
 require({k for k in oldcm['data'] if oldcm['data'][k]!=newcm['data'][k]}=={'config.yaml'},'only_config_change_allowed')
 copycm=copy.deepcopy(newcm);copycm['data']['config.yaml']=oldcm['data']['config.yaml'];require(copycm==oldcm,'configmap_other_change')
 require(oldcm['metadata'].get('annotations',{}).get('argocd.argoproj.io/sync-wave','0')=='0','configmap_wave')
 oldraw,newraw=oldcm['data']['config.yaml'],newcm['data']['config.yaml']
 require(sha(oldraw.encode())==OLD_PROFILE_SHA,'old_profile_hash')
 require(sha(newraw.encode())==profile_sha256 and profile_sha256!=OLD_PROFILE_SHA,'new_profile_hash')
 oldprofile,newprofile=profile(oldraw),profile(newraw)
 require(oldprofile['model'].get('default')==OLD_MODEL and newprofile['model'].get('default')==NEW_MODEL,'exact_model_transition')
 comparison=copy.deepcopy(newprofile);comparison['model']['default']=OLD_MODEL
 require(canonical(comparison)==canonical(oldprofile),'profile_semantics_not_model_only')
 revision=profile_sha256[:12]
 oldh,newh=before[hk],after[hk]
 annot='verdify.io/hermes-profile-revision';inventory='verdify.io/iris-inventory-revision'
 require(oldh['spec']['template']['metadata']['annotations'][annot]==OLD_PROFILE_SHA[:12],'old_hermes_profile_revision')
 require(newh['spec']['template']['metadata']['annotations'][annot]==revision,'new_hermes_profile_revision')
 require(oldh['spec']['template']['metadata']['annotations'][inventory]==newh['spec']['template']['metadata']['annotations'][inventory]==INVENTORY,'inventory_revision_changed')
 copyh=copy.deepcopy(newh);copyh['spec']['template']['metadata']['annotations'][annot]=OLD_PROFILE_SHA[:12];require(copyh==oldh,'hermes_other_change')
 require(newh['spec']['replicas']==1 and newh['spec']['strategy']['type']=='Recreate','single_gateway')
 require(newh['metadata']['annotations']['argocd.argoproj.io/sync-wave']=='20','hermes_wave')
 return {'old_model':OLD_MODEL,'new_model':NEW_MODEL,'old_profile_sha256':OLD_PROFILE_SHA,
         'new_profile_sha256':profile_sha256,'old_profile_revision':OLD_PROFILE_SHA[:12],
         'new_profile_revision':revision,'unchanged_inventory_revision':INVENTORY,
         'rendered_object_count':len(before),'unchanged_rendered_objects':len(before)-2,
         'profile_semantic_changes':['model.default'],'profile_comments_are_nonsemantic':True}
def stamp(value):
 if isinstance(value,(int,float)) and not isinstance(value,bool):return dt.datetime.fromtimestamp(value,dt.timezone.utc)
 require(isinstance(value,str),'timestamp_type')
 parsed=dt.datetime.fromisoformat(value.replace('Z','+00:00'));require(parsed.tzinfo is not None,'timestamp_timezone');return parsed
def recent(value,now,seconds,code):
 age=(now-stamp(value)).total_seconds();require(-2<=age<=seconds,code)
def validate_idle(idle,now,hermes_uid):
 require(idle['schema']=='hermes-idle-readback-v2','idle_schema')
 require(idle['pod_uid']==hermes_uid and str(uuid.UUID(hermes_uid))==hermes_uid,'idle_pod_uid')
 recent(idle['captured_at'],now,60,'stale_idle_capture')
 require(idle['health_http_status']==200,'gateway_health_http')
 h=idle['health'];require(h.get('status')=='ok' and h.get('platform')=='hermes-agent','gateway_health')
 # Health is a fresh HTTP observation of persistent startup status, not a
 # heartbeat or the live API run registry. Its old zero cannot prove idleness.
 ledger=idle['delivery_ledger'];require(ledger['readonly'] is True and ledger['complete'] is True,'ledger_not_complete_readonly')
 recent(ledger['captured_at'],now,60,'stale_ledger_capture')
 require(type(ledger['rows_examined']) is int and 0<=ledger['rows_examined']<=200,'ledger_cap')
 require(ledger['window_minutes']==180,'ledger_window')
 require(ledger['pending_without_run_id']==0,'pending_without_run_id')
 require(set(ledger['unresolved_run_ids'])==set(x['run_id'] for x in idle['run_statuses']),'run_id_coverage')
 require(len(idle['run_statuses'])==len(set(x['run_id'] for x in idle['run_statuses']))<=20,'run_status_cap')
 for item in idle['run_statuses']:
  require(item['http_status']==200 and item['status'] in ('completed','failed','cancelled'),'run_not_terminal')
  recent(item['captured_at'],now,60,'stale_run_status')
 require(idle['incoming_dispatch_frozen'] is False,'no_freeze_claim')
 return {'health_snapshot_only':True,'health_non_authoritative':True,
         'health_updated_at_semantics':'persistent_startup_status_not_heartbeat',
         'health_reported_updated_at':h.get('updated_at'),'health_reported_active_agents':h.get('active_agents'),
         'health_activity_used_as_idle_proof':False,'current_exhaustive_idle_proven':False,
         'no_incoming_dispatch_freeze':True,'restart_race_remains':True,
         'gateway_pod_uid':hermes_uid,'health_reported_pid':h.get('pid'),
         'ledger_rows_examined':ledger['rows_examined'],
         'no_nonterminal_run_found_in_bounded_known_deliveries':True,
         'terminal_run_statuses':len(idle['run_statuses']),'run_status404_is_not_terminal':True}

def build_patch(app,uid,rv,phase,revision):
 require(re.fullmatch('[0-9a-f]{40}',revision) is not None,'main_revision_shape')
 require(str(uuid.UUID(uid))==uid and re.fullmatch('[0-9]+',rv) is not None,'app_identity_shape')
 require(app['apiVersion']=='argoproj.io/v1alpha1' and app['kind']=='Application','app_kind')
 m=app['metadata'];require(m['name']=='verdify-prod-dark' and m['namespace']=='argocd','app_name')
 require(m['uid']==uid and m['resourceVersion']==rv and not m.get('deletionTimestamp'),'app_identity')
 require(app.get('operation') is None,'active_application_operation')
 require(phase in TERMINAL and app['status']['operationState']['phase']==phase,'prior_operation_not_terminal')
 require(app['spec']['source']=={'path':'deploy/k8s/overlays/prod','repoURL':'https://github.com/VerdifyConsultancy/verdify-platform.git','targetRevision':'main'},'app_source')
 require(app['spec']['destination']=={'namespace':'verdify-prod','server':'https://kubernetes.default.svc'},'app_destination')
 patch=[{'op':'test','path':'/metadata/uid','value':uid},{'op':'test','path':'/metadata/resourceVersion','value':rv}]
 if 'operation' in app:patch.append({'op':'test','path':'/operation','value':None})
 # RV binds the absent operation field too; JSON Patch cannot test an absent path.
 patch += [{'op':'test','path':'/status/operationState/phase','value':phase},
           {'op':'add','path':'/status/operationState','value':None},
           {'op':'add','path':'/operation','value':{'initiatedBy':{'username':'laptop-root'},
              'sync':{'revision':revision,'prune':False,'resources':copy.deepcopy(RESOURCES)}}}]
 return patch

def main():
 p=argparse.ArgumentParser()
 for key in ('application','render_before','render_after','idle_evidence'):p.add_argument('--'+key.replace('_','-'),type=pathlib.Path,required=True)
 for key in ('expected_app_uid','expected_app_rv','expected_terminal_phase','expected_hermes_pod_uid','main_revision','profile_sha256'):p.add_argument('--'+key.replace('_','-'),required=True)
 p.add_argument('--out',type=pathlib.Path,required=True);a=p.parse_args()
 require(re.fullmatch('[0-9a-f]{64}',a.profile_sha256) is not None,'profile_digest_shape')
 require(not a.out.exists(),'fresh_output_required');now=dt.datetime.now(dt.timezone.utc)
 inputs={key:getattr(a,key) for key in ('application','render_before','render_after','idle_evidence')}
 bytes_before={k:v.read_bytes() for k,v in inputs.items()}
 patch=build_patch(json.loads(bytes_before['application']),a.expected_app_uid,a.expected_app_rv,a.expected_terminal_phase,a.main_revision)
 delta=validate_render(inventory(json.loads(bytes_before['render_before'])),inventory(json.loads(bytes_before['render_after'])),a.profile_sha256)
 idle=validate_idle(json.loads(bytes_before['idle_evidence']),now,a.expected_hermes_pod_uid)
 a.out.mkdir()
 for name,raw in bytes_before.items():(a.out/(name+'.json')).write_bytes(raw)
 (a.out/'patch.json').write_text(json.dumps(patch,indent=2)+'\n')
 receipt={'schema':'exact-two-resource-model-selective-plan-v1','status':'PREPARED_NOT_SUBMITTED',
  'created_at':now.isoformat(),'expires_at':(now+dt.timedelta(seconds=30)).isoformat(),
  'main_revision':a.main_revision,'application_uid':a.expected_app_uid,'application_resource_version':a.expected_app_rv,
  'prior_terminal_phase':a.expected_terminal_phase,'resources':RESOURCES,'render_delta':delta,'idle_admission':idle,
  'input_sha256':{k:sha(raw) for k,raw in bytes_before.items()},'driver_sha256':sha(pathlib.Path(__file__).read_bytes()),
  'patch_sha256':sha((a.out/'patch.json').read_bytes()),'native_calls':0,
  'execution_rule':'ROOT checks30s expiry then sends exactly one JSON patch to the named Application. Any rejection/uncertainty is retained; no automatic retry.',
  'rollback_rule':'Restore only the old source-owned model profile and matching profile revision in a separate reviewed source revision, preserving inventory5733 and the already accepted MCP pin. No full sync, hook, raw Deployment patch or automatic rollback is embedded.'}
 (a.out/'plan.json').write_text(json.dumps(receipt,indent=2)+'\n')
 require(all(fp.read_bytes()==bytes_before[k] for k,fp in inputs.items()),'input_changed_during_emission')
 print(json.dumps({'status':'PREPARED_NOT_SUBMITTED','path':str(a.out),'plan_sha256':sha((a.out/'plan.json').read_bytes())}))
if __name__=='__main__':main()
