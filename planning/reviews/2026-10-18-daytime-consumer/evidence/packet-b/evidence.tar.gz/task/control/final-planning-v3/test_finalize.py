"""Synthetic future-receipt regressions; no native or network operations."""
import copy,importlib.util,json,pathlib,tempfile,types,unittest,subprocess
from unittest import mock
HERE=pathlib.Path(__file__).parent
spec=importlib.util.spec_from_file_location('finalizer',HERE/'finalize.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
SOURCE=pathlib.Path('/private/tmp/verdify-daytime-consumer-source-20261018')

def fixtures():
    paths={'source_ci':'source-ci-verified.json','initial_rollout':'rollout/terminal-verified.json','initial_runtime':'runtime-01/verified.json','release_ci':'release-ci-verified.json','daytime':'daytime-native-01/verified.json','graph_before':'graph-before/verified.json','database':'database-final/verified.json'}
    raw={k:(m.BASE/v).read_bytes() for k,v in paths.items()};v={k:json.loads(data) for k,data in raw.items()}
    ci=copy.deepcopy(v['source_ci']);ci.update(status='SOURCE_GATE_TWO_BUILDS_AND_PIN_PUBLISHER_VERIFIED',source_revision=m.MODEL_SOURCE,workflow='synthetic-model-ci',workflow_uid='synthetic-model-uid');ci['images']['api'].update({'source-revision':m.MODEL_SOURCE,'resolved-revision':m.MODEL_SOURCE,'digest':'sha256:'+'a'*64});v['model_source_ci']=ci;raw['model_source_ci']=m.js(ci).encode()
    rt=copy.deepcopy(v['initial_runtime']);rt.update(api_source_sha=m.MODEL_SOURCE,api_digest='a'*64,api_ci_receipt_sha256=m.sha(raw['model_source_ci']),effective_model_config_sha256=m.PROFILE,release_sha='b'*40,unrelated_deployment_specs_unchanged=12,critical_pods_and_container_states_unchanged=2,accepted_mcp_deployment_and_pods_unchanged=True);rt['hermes']['uid']='synthetic-new-hermes';v['model_runtime']=rt;raw['model_runtime']=m.js(rt).encode()
    v['model_runtime_terminal']={'status':'PASSED','verified_sha256':m.sha(raw['model_runtime']),'automatic_retries':0}
    v['model_rollout']={'status':'EXACT_FOUR_RESOURCE_OPERATION_SUCCEEDED','revision':'b'*40,'finished_at':'2026-10-18T23:00:00Z','hooks':0,'prune':False,'resources':[{'group':g,'kind':k,'name':n,'namespace':'verdify-prod','status':'Synced','syncPhase':'Sync'} for g,k,n in [('', 'ConfigMap','verdify-hermes-iris-config'),('', 'ConfigMap','verdify-vision-src'),('apps','Deployment','verdify-api'),('apps','Deployment','verdify-hermes-iris')]]}
    v['model_release_ci']=copy.deepcopy(v['release_ci']);v['model_release_ci']['source_revision']='b'*40
    cases=[]
    for date,count in [('2026-10-04',4),('2026-10-16',0)]:
        i={'night_date':date,'availability':'available' if count else 'no_episodes','episode_count':count,'dispositions':{'effective':0,'ineffective':2 if count else 0,'blocked':0,'insufficient_evidence':2 if count else 0},'safety_gate_status':'incomplete' if count else 'pending','daytime_dry_action_samples':None,'daytime_hold_admission_samples':None,'scope_statement':m.SCOPE,**{k:False for k in ['efficacy_proven','crop_safety_proven','complete_daytime_zero_proven','evidence_complete']}}
        cases.append({'date':date,'interpretation':i,'provider_calls':2,'scorecard_calls':1,'output_tokens':100,'native_elapsed_seconds':30,'natural_cycle_verified':False,'whole_issue_acceptance':False})
    v['consumer']={'status':'TWO_BOUNDED_ORDINARY_CONSUMERS_PASSED','source':m.MCP_SOURCE,'image':m.MCP_DIGEST,'cases':cases,'provider_calls':4,'actual_scorecard_calls':2,'other_tools_dispatched':0,'automatic_retries':0,'all46_oct04_values_preserved':True,'daytime_complete_zero_proven':False,'natural_cycle_verified':False,'whole_issue_acceptance':False,'total_output_tokens':200};raw['consumer']=m.js(v['consumer']).encode()
    v['consumer_terminal']={'status':'PASSED','verified_sha256':m.sha(raw['consumer']),'automatic_retries':0}
    v['consumer_start']={'runtime_verified_sha256':m.sha(raw['model_runtime']),'input_sha256':{'runtime':m.sha(raw['model_runtime'])}}
    raw.update({k:m.js(value).encode() for k,value in v.items() if k not in raw});return v,raw

class Tests(unittest.TestCase):
    def setUp(self):self.no_process=mock.patch.object(subprocess,'run',side_effect=AssertionError('process forbidden'));self.no_process.start()
    def tearDown(self):self.no_process.stop()
    def test_complete_synthetic_receipts(self):v,r=fixtures();self.assertEqual(len(m.validate(v,r)),2)
    def test_refuses_failed_ci(self):
        v,r=fixtures();v['model_source_ci']['status']='FAILED'
        with self.assertRaises(m.Refusal):m.validate(v,r)
    def test_refuses_old_model_source(self):
        v,r=fixtures();v['model_source_ci']['source_revision']='182691082420466dc1c5b39bae2fd84f49f38dbf'
        with self.assertRaises(m.Refusal):m.validate(v,r)
    def test_refuses_failed_runtime(self):
        v,r=fixtures();v['model_runtime']['status']='FAILED'
        with self.assertRaises(m.Refusal):m.validate(v,r)
    def test_refuses_misbound_runtime(self):
        v,r=fixtures();v['consumer_start']['runtime_verified_sha256']='0'*64
        with self.assertRaises(m.Refusal):m.validate(v,r)
    def test_refuses_extra_resource(self):
        v,r=fixtures();v['model_rollout']['resources'].append(v['model_rollout']['resources'][0])
        with self.assertRaises(m.Refusal):m.validate(v,r)
    def test_refuses_missing_case(self):
        v,r=fixtures();v['consumer']['cases'].pop()
        with self.assertRaises(m.Refusal):m.validate(v,r)
    def test_refuses_invented_zero(self):
        v,r=fixtures();v['consumer']['cases'][1]['interpretation']['daytime_dry_action_samples']=0
        with self.assertRaises(m.Refusal):m.validate(v,r)
    def test_refuses_natural_claim(self):
        v,r=fixtures();v['consumer']['natural_cycle_verified']=True
        with self.assertRaises(m.Refusal):m.validate(v,r)
    def test_refuses_prose_scope_claim(self):
        v,r=fixtures();v['consumer']['cases'][0]['interpretation']['scope_statement']='This proves crop safety.'
        with self.assertRaises(m.Refusal):m.validate(v,r)
    def test_refuses_coverage_zero_claim(self):
        v,r=fixtures();v['daytime']['days'][0]['measured_zero_for_complete_recorded_minutes']=True
        with self.assertRaises(m.Refusal):m.validate(v,r)
    def test_preserves_canonical(self):
        v,r=fixtures();old=json.loads((SOURCE/'planning/backlog.yaml').read_text());u=m.updates(json.loads((m.BASE/'final-planning-draft/proposed-updates.json').read_text()),v,m.texts(v));new=m.plan_update(old,u,'2026-10-18','b'*40)
        self.assertEqual(m.protected(old),m.protected(new));self.assertNotIn('[[PENDING',m.js(new));self.assertIn('unknown',u['410']['baseline']);self.assertIn('separately after ROOT',u['775']['baseline'])
    def test_explicit_deferred_release_ci(self):
        v,r=fixtures();v['model_release_ci']=None;v['_deferred_receipts']={'model_release_ci':{'state':'recorded_later_in_custody','source_revision':v['model_runtime']['release_sha']}}
        self.assertEqual(len(m.validate(v,r)),2);self.assertIn('neither is claimed passed',m.texts(v)['MODEL_RELEASE_RUNTIME'])
    def test_deferred_release_requires_state(self):
        v,r=fixtures();v['model_release_ci']=None
        with self.assertRaises(m.Refusal):m.validate(v,r)
    def test_deferred_release_requires_actual_revision(self):
        v,r=fixtures();v['model_release_ci']=None;v['_deferred_receipts']={'model_release_ci':{'state':'recorded_later_in_custody','source_revision':'c'*40}}
        with self.assertRaises(m.Refusal):m.validate(v,r)
    def test_completed_and_deferred_conflict(self):
        v,r=fixtures();v['_deferred_receipts']={'model_release_ci':{'state':'recorded_later_in_custody','source_revision':v['model_runtime']['release_sha']}}
        with self.assertRaises(m.Refusal):m.validate(v,r)
    def test_deferred_manifest_read_and_render(self):
        v,r=fixtures()
        with tempfile.TemporaryDirectory(prefix='synthetic-deferred-planning-',dir='/private/tmp') as d:
            root=pathlib.Path(d);refs={}
            for name,raw in r.items():
                if name=='model_release_ci':refs[name]=None;continue
                p=root/(name+'.json');p.write_bytes(raw);refs[name]={'path':str(p),'sha256':m.sha(raw)}
            manifest=root/'inputs.json';manifest.write_text(m.js({'schema':'daytime-final-planning-inputs/v1','status':'ready_actual_receipts','receipts':refs,'deferred_receipts':{'model_release_ci':{'state':'recorded_later_in_custody','source_revision':'b'*40}}}))
            a=types.SimpleNamespace(out=root/'synthetic-output',source_root=SOURCE,inputs=manifest,backlog_sha256=m.sha((SOURCE/'planning/backlog.yaml').read_bytes()),review_source_sha='b'*40)
            m.run(a);h=json.loads((a.out/'handoff.json').read_text());self.assertIsNone(h['inputs']['model_release_ci']);self.assertEqual(h['deferred_receipts']['model_release_ci']['state'],'recorded_later_in_custody');self.assertIn('pending in this report',(a.out/'repo'/m.REVIEW/'README.md').read_text())
    def test_tiny_full_private_render(self):
        v,r=fixtures()
        with tempfile.TemporaryDirectory(prefix='synthetic-planning-',dir='/private/tmp') as d:
            root=pathlib.Path(d);refs={}
            for name,raw in r.items():p=root/(name+'.json');p.write_bytes(raw);refs[name]={'path':str(p),'sha256':m.sha(raw)}
            manifest=root/'inputs.json';manifest.write_text(m.js({'schema':'daytime-final-planning-inputs/v1','status':'ready_actual_receipts','receipts':refs}))
            a=types.SimpleNamespace(out=root/'synthetic-output',source_root=SOURCE,inputs=manifest,backlog_sha256=m.sha((SOURCE/'planning/backlog.yaml').read_bytes()),review_source_sha='b'*40)
            m.run(a);h=json.loads((a.out/'handoff.json').read_text());self.assertEqual(h['generated_views'],7);self.assertTrue(h['all_protected_canonical_fields_equal']);self.assertFalse(h['postpublication_graph_claimed']);report=(a.out/'repo'/m.REVIEW/'README.md').read_text();self.assertNotIn('[[',report);self.assertIn('no measured natural-cycle cost baseline',report)

if __name__=='__main__':unittest.main()
