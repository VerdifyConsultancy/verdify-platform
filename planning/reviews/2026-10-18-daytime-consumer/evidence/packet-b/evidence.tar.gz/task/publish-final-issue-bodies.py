import json,pathlib,subprocess,hashlib,sys
b=pathlib.Path('/private/tmp/verdify-daytime-consumer-20261018');root=pathlib.Path('/private/tmp/verdify-daytime-consumer-source-20261018');out=b/'github-final-bodies';out.mkdir(exist_ok=False);sys.path.insert(0,str(root));from planning.schema import load
from planning.render import issue_body,issue_title
p=load(root/'planning/backlog.yaml');issues={i.issue_number:i for i in p.issues};repo='VerdifyConsultancy/verdify-platform'
def gh(args):
 r=subprocess.run(['gh',*args],cwd=root,capture_output=True,timeout=30);assert r.returncode==0,r.stderr.decode();return r.stdout
for n in (410,775):
 current=gh(['api',f'repos/{repo}/issues/{n}']);(out/f'{n}-before.json').write_bytes(current);j=json.loads(current);original=json.loads((b/f'issue-{n}-before.json').read_bytes());assert j['state']=='open' and j['body']==original['body'] and j['title']==original['title'],'Concurrent issue body update requires reconciliation'
 new={'title':issue_title(issues[n]),'body':issue_body(issues[n],p)};f=out/f'{n}-payload.json';f.write_text(json.dumps(new)+'\n');r=gh(['api','--method','PATCH',f'repos/{repo}/issues/{n}','--input',str(f)]);(out/f'{n}-after.json').write_bytes(r);v=json.loads(r);assert v['body']==new['body'] and v['title']==new['title'] and v['state']=='open';print(json.dumps({'issue':n,'status':'UPDATED_OPEN','body_sha256':hashlib.sha256(v['body'].encode()).hexdigest()}))
