import pathlib,json,hashlib,subprocess,yaml
b=pathlib.Path('/private/tmp/verdify-daytime-consumer-20261018');r=pathlib.Path('/private/tmp/verdify-daytime-consumer-source-20261018')
def git(*a):return subprocess.check_output(['git',*a],cwd=r).decode().strip()
assert git('status','--porcelain')==''
s=json.loads((b/'model-source-ci-verified.json').read_text());assert s['status']=='SOURCE_GATE_TWO_BUILDS_AND_PIN_PUBLISHER_VERIFIED' and s['source_revision']=='56b316f3fda666b25665dfc0f791d6be6db0fa46'
subprocess.run(['git','fetch','origin','main'],cwd=r,check=True);subprocess.run(['git','merge','--ff-only','origin/main'],cwd=r,check=True)
k=yaml.safe_load((r/'deploy/k8s/overlays/prod/kustomization.yaml').read_text());im={x['name'].rsplit('/',1)[-1]:x for x in k['images']};assert im['verdify-api']['digest']==s['images']['api']['digest'] and im['verdify-experiment-v2-orchestrator']['digest']==s['images']['orchestrator']['digest']
(b/'model-candidate-readback.json').write_text(json.dumps({'candidate_commit':git('rev-parse','HEAD'),'api_digest':s['images']['api']['digest'],'source':s['source_revision'],'other_release_pins_not_promoted':True},indent=2)+'\n')
subprocess.run(['/Users/jason/repos/verdify-platform/.venv/bin/python','scripts/promote-release-pins.py','verdify-api','--receipt',str(b/'api-promotion-source.json')],cwd=r,check=True)
assert git('diff','--name-only')=='deploy/k8s/overlays/prod/release-pins.yaml';print(git('diff','--stat'))
