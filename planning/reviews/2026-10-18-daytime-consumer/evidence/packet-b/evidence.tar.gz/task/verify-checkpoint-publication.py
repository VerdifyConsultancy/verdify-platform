import pathlib,subprocess,json,hashlib,base64,concurrent.futures,urllib.parse,datetime
b=pathlib.Path('/private/tmp/verdify-daytime-consumer-20261018');r=pathlib.Path('/private/tmp/verdify-daytime-consumer-source-20261018');branch='codex/daytime-consumer-checkpoint-20261018';prefix='planning/reviews/2026-10-18-daytime-consumer-checkpoint/';repo='VerdifyConsultancy/verdify-platform'
def git(*a):return subprocess.check_output(['git',*a],cwd=r).decode().strip()
sha=git('rev-parse',branch);remote=git('ls-remote','origin','refs/heads/'+branch).split();assert remote[0]==sha
paths=git('ls-tree','-r','--name-only',sha,'--',prefix).splitlines();assert len(paths)==9

def verify(path):
 expected=subprocess.check_output(['git','show',sha+':'+path],cwd=r)
 raw=subprocess.check_output(['gh','api',f'repos/{repo}/contents/'+urllib.parse.quote(path,safe='/')+'?ref='+sha],cwd=r);j=json.loads(raw);assert j['encoding']=='base64' and j['path']==path;actual=base64.b64decode(j['content']);assert actual==expected
 return {'path':path,'bytes':len(actual),'sha256':hashlib.sha256(actual).hexdigest(),'github_blob_sha':j['sha'],'exact_remote_bytes':True}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as e:files=list(e.map(verify,paths))
v={'status':'CHECKPOINT_BRANCH_AND_ALL_NINE_REMOTE_FILES_VERIFIED','branch':branch,'commit':sha,'readme_url':f'https://github.com/{repo}/blob/{sha}/{prefix}README.md','files':files,'verified_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'main_not_mutated_by_checkpoint':True};(b/'checkpoint-publication.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps({k:v[k] for k in ['status','commit','readme_url']}))
