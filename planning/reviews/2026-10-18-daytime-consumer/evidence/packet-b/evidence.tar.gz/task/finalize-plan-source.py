import pathlib,json,hashlib,subprocess,datetime,copy
b=pathlib.Path('/private/tmp/verdify-daytime-consumer-20261018');r=pathlib.Path('/private/tmp/verdify-daytime-consumer-source-20261018')
base=json.loads((r/'planning/backlog.yaml').read_text());draft=json.loads((b/'final-planning-draft/repo/planning/backlog.yaml').read_text());assert hashlib.sha256((r/'planning/backlog.yaml').read_bytes()).hexdigest()=='eafcf1c5be8f36a43c7f9314fa20dba563fdef43432f2eb13a9de3a390b95c8c'
run=json.loads((b/'runtime-01/verified.json').read_text());assert run['status']=='POST_ROLLOUT_RUNTIME_CUSTODY_PASSED';ci=json.loads((b/'source-ci-verified.json').read_text());assert ci['status']=='SOURCE_GATE_FIVE_BUILDS_AND_PIN_PUBLISHER_VERIFIED'
# Root fills actual consumer outcome before this finalizer is run.
c=json.loads((b/'consumer-final-summary.json').read_text());assert c['root_reviewed'] is True
result_text=c['planning_summary']
new_action410='Specify a supported observation/freshness contract and collect a prospective complete recorded daytime window; October16/17 remain incomplete. Observe an ordinary natural planner cycle consuming the selected-night scorecard separately from the bounded qualification. Preserve ineffective/incomplete/empty evidence and advance physical efficacy/crop-sensing on its own acceptance; no getter rework, credential expansion or tuning.'
new_action775='Pull the prospective complete recorded daytime observation/freshness packet, natural ordinary-consumer observation and authentic scientific/physical inputs as ready. Reuse installed getter277 and verified source/release/read receipts. Preserve all existing acceptance, dependencies and original estimates; no whole-campaign completion claim.'
texts={410:'Installed b814f35e ordinary-reader source is released as MCP ae8a367035a3 under e545380a23129eb1830e9d6d804334f46f8fdcfe. Exact3 Argo resources succeeded with no hooks or DB change. Both new MCP replicas match source/module/image; new Hermes UIDb27182d8-088b-46ee-9e39-4bd9c7290069 seeded SOUL11a0fdc4 and inventory5733c1c6b35d, preserving learned skills/configuration. All9smoke checks pass and exactly1ESP32 connection is observed;15DeploymentUIDs/13other specs and4critical Pod states preserved. Existing Iris inventory is23tools; admin outcome remains denied. '+result_text,
775:'Completed next bounded packet: actual daytime assessment remains incomplete (25/23 missing minute buckets); qualified b814f35e MCP reader delivered under e545380a, exact3 selective resources, both replicas/source/auth checked and source-owned Iris inventory5733c1c6b35d refreshed.9smoke/1device checks pass; DB/API/ingestor states preserved. '+result_text}
for i,row in enumerate(draft['issues']):
 num=row.get('issue_number') or row.get('number')
 # Canonical rows use issue_number? Resolve below independently.
 if num not in (410,775):continue
 row['baseline']=texts[num]+'\n\nDaytime Oct16:644/669recorded,25missing,0knownheld,12ordinarydry; Oct17:643/666recorded,23missing,0knownheld,2ordinarydry. Complete recorded zero remains NULL both dates; no backfill or continuous physical absence claim. Installed277 prior20fixture parity and2673clone readback proofs remain accepted at original scope; October4 actual outcomes ineffective2/insufficient2; no positive efficacy.\n\nEvidence: planning/reviews/2026-10-18-daytime-consumer/README.md. Both issues remain open, all acceptance clauses and graph relationships unchanged.'
for x in draft['execution_plan']['allocations']:
 if x.get('issue_number')==410:x['next_action']=new_action410
 if x.get('issue_number')==775:x['next_action']=new_action775
# Preserve key names by using known source fields below; refuse pending placeholders.
draft['execution_plan']['reviewed_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();draft['execution_plan']['source_revision']='e545380a23129eb1830e9d6d804334f46f8fdcfe';draft['execution_plan']['review_path']='planning/reviews/2026-10-18-daytime-consumer'
raw=json.dumps(draft,indent=2,ensure_ascii=False)+'\n';assert '[[PENDING' not in raw
(r/'planning/backlog.yaml').write_text(raw)
subprocess.run(['/Users/jason/repos/verdify-platform/.venv/bin/python','-m','planning.render'],cwd=r,check=True)
print('Canonical source rendered; root must inspect exact diff and report before commit.')
