import urllib.request,urllib.error,os,json
class RefuseRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*a,**kw):raise ValueError('redirect')
try:
 opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),RefuseRedirect())
 req=urllib.request.Request('https://api.openai.com/v1/models/gpt-6-luna',headers={'Authorization':'Bearer '+os.environ['OPENAI_API_KEY']})
 with opener.open(req,timeout=10) as r:
  assert r.status==200;raw=r.read(65537);assert len(raw)<65536;j=json.loads(raw);assert j['id']=='gpt-6-luna';print(json.dumps({'status':'REQUESTED_MODEL_VISIBLE','model_id':j['id'],'http_status':r.status,'generation_calls':0,'historical_payload_sent':False}))
except urllib.error.HTTPError as e:
 print(json.dumps({'status':'FAILED','http_status':e.code,'generation_calls':0}));raise SystemExit(1)
except Exception as e:
 print(json.dumps({'status':'FAILED','error_type':type(e).__name__,'generation_calls':0}));raise SystemExit(1)
