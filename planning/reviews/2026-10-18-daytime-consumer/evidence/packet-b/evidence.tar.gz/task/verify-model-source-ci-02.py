import pathlib,json,hashlib,subprocess,sys,datetime,re
base=pathlib.Path('/private/tmp/verdify-daytime-consumer-20261018');root=pathlib.Path('/private/tmp/verdify-daytime-consumer-source-20261018');dirs=[base/'model-source-ci-02'];source='56b316f3fda666b25665dfc0f791d6be6db0fa46';uid='410c5d3a-6bbe-4aaf-89bb-c3cecce0dd2f';name='verdify-platform-ci-87whm';wfile=next((dirs[0]).glob('workflow-final-*.json'));w=json.loads(wfile.read_bytes());assert w['metadata']['uid']==uid and w['metadata']['name']==name and w['status']['phase']=='Succeeded'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def params(n,key):return {x['name']:x.get('value') for x in n.get(key,{}).get('parameters',[])}
def git(*args):return subprocess.check_output(['git',*args],cwd=root).strip()
tree=git('rev-parse',source+'^{tree}').decode();pods=[n for n in w['status']['nodes'].values() if n['type']=='Pod'];assert {n['displayName'] for n in pods}=={'classify-push(0)','build-api','build-orchestrator','pin-digests'} and len(pods)==4
proofs=[];images={}
for n in pods:
 assert n['phase']=='Succeeded';suffix=n['id'].rsplit('-',1)[-1];candidates=[]
 for d in dirs:
  for p in d.glob('*-'+suffix+'-summary-*.json'):
   v=json.loads(p.read_bytes())
   if v['phase']=='Succeeded':candidates.append((p,v))
 assert candidates,n['displayName'];sp,s=candidates[-1];cs=s['init']+s['containers'];assert len(cs)>=3 and all(c['restartCount']==0 and c['state'].get('terminated',{}).get('exitCode')==0 for c in cs)
 raws=[p for d in dirs for p in d.glob(s['name']+'-*.json') if '-summary-' not in p.name];actual=[]
 for p in raws:
  v=json.loads(p.read_bytes())
  if v.get('metadata',{}).get('uid')==s['uid'] and v.get('status',{}).get('phase')=='Succeeded':actual.append((p,v))
 assert actual;pp,pod=actual[-1];assert any(r['uid']==uid for r in pod['metadata'].get('ownerReferences',[]));declared=pod['spec'].get('initContainers',[])+pod['spec']['containers'];assert {c['name'] for c in cs}=={c['name'] for c in declared};logs=[p for d in dirs for p in d.glob(s['name']+'-main-*.log')];assert logs;lp=max(logs,key=lambda p:p.stat().st_size);raw=lp.read_bytes();assert sha(lp) in lp.name
 entry={'step':n['displayName'],'pod':s['name'],'pod_uid':s['uid'],'node':s['node'],'terminal_summary':str(sp.relative_to(base)),'terminal_summary_sha256':sha(sp),'terminal_pod':str(pp.relative_to(base)),'terminal_pod_sha256':sha(pp),'main_log':str(lp.relative_to(base)),'main_log_sha256':sha(lp),'main_log_bytes':len(raw),'all_declared_containers_zero_exit_zero_restarts':True,'observed_images':{c['name']:c['imageID'] for c in cs}}
 if n['displayName'].startswith('classify-push'):
  assert b'ALL GATES GREEN' in raw;outputs=params(n,'outputs');assert outputs['mode']=='build';impact=json.loads(outputs['path-impact-receipt']);assert impact==json.loads((base/'model-source-impact-02/receipt.json').read_bytes());entry['path_impact']=impact
 elif n['displayName'].startswith('build-'):
  i=params(n,'inputs');o=params(n,'outputs');assert i['revision']==source and o['source-revision']==o['resolved-revision']==source and o['resolved-tree']==tree and o['short-sha']==source[:12] and o['source-url']=='https://github.com/VerdifyConsultancy/verdify-platform' and o['output-contract-version']=='agent-fleet.repo-build.outputs/2';assert o['dockerfile-sha256']=='sha256:'+hashlib.sha256(subprocess.check_output(['git','show',source+':'+i['dockerfile']],cwd=root)).hexdigest();assert re.fullmatch('sha256:[0-9a-f]{64}',o['digest']);assert o['image-ref']=='registry.vallery.net/'+i['image']+'@'+o['digest'];assert o['digest'].encode() in raw;entry['build_inputs']=i;entry['outputs']=o;images[n['displayName'].removeprefix('build-')]=o
 else:
  assert b'Skipping superseded release' not in raw and b'-> zot digests' in raw;entry['candidate_publisher_log_verified']=True
 proofs.append(entry)
result={'status':'SOURCE_GATE_TWO_BUILDS_AND_PIN_PUBLISHER_VERIFIED','workflow':name,'workflow_uid':uid,'source_revision':source,'source_tree':tree,'finished_at':w['status']['finishedAt'],'workflow_file':str(wfile.relative_to(base)),'workflow_sha256':sha(wfile),'profile_set':['api','orchestrator'],'images':images,'pods':proofs,'scope':'existing native full gate, two actual impacted serial builds, managed candidate publisher; only API promotion intended; no DB migration or production mutation by this receipt','candidate_commit':'fresh remote readback remains required','production_applied':False,'verified_at':datetime.datetime.now(datetime.timezone.utc).isoformat()};out=base/'model-source-ci-verified.json';out.open('x').write(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'images':{k:v['digest'] for k,v in images.items()},'pods':len(proofs)}))
