# Daytime coverage and ordinary outcome consumer — 2026-10-18

The recorded daytime assessment is complete and its result is incomplete coverage. The ordinary MCP reader is delivered. Jason also requested upgrading live Iris and this qualification to GPT-6 Luna. Model release and actual qualification results are recorded below. **#410 and #775 remain open.**

## Recorded daytime coverage

One bounded read-only transaction inspected the complete selected October16/17 stored input against the installed migration277 solar clock and classifier. No historical rows were altered.

| America/Denver solar day | Expected minutes | Recorded valid minutes | Missing minute buckets | Known held admissions | Ordinary dry action minutes | Complete recorded zero |
|---|---:|---:|---:|---:|---:|---|
| October16 | 669 | 644 | 25 | 0 | 12 | NULL |
| October17 | 666 | 643 | 23 | 0 | 2 | NULL |

The 48 missing buckets are shared climate/action gaps, not96 separate gaps. Longest consecutive gaps are3/1 buckets; these do not measure a continuous physical outage. No observed held classification or explicit hold marker was unknown. Snapshot records have no per-relay freshness guarantee and can default absent equipment to false. Neither the observed zeros nor typed rows prove every controller tick, continuous physical absence or crop safety. No interpolation, resampling, backfill or zero substitution was used. Science independently checked the source, native result and derived acceptance.

## Delivered ordinary MCP path

Source `b814f35e228fcb35c11593c47ea1e021e5fd73de` adds the default-off `scorecard(target_date, include_realized_dryout=False)` input and a typed nested result. Opt-in uses the explicit date as solar-night **start** date, distinct from calendar-day scorecard metrics. Default calls make no extra getter query.

The selected read uses the existing getter and ordinary identity in a READ ONLY transaction within the unchanged15-second fence. It preserves all46 columns, NULLs, dispositions and confounds. A501-row sentinel rejects more than500 episodes; a64-KiB evidence cap rejects oversized results without truncation. Empty/all-null daytime counts remain NULL. Safety status is distinct from effectiveness and crop safety.

Native source CI `verdify-platform-ci-bgf2f` / `f2083616-e793-4994-bd3b-9a48b1fbb376` succeeded20:10:56UTC: full gate, five selected serial image builds and candidate publisher; all7 actual Pods' declared containers exited0 without restarts. Only MCP was promoted, digest `ae8a367035a3ae8a06ab2384bc166f444b3decad0da21e5c70e53e76203d9c73`.

Release `e545380a23129eb1830e9d6d804334f46f8fdcfe` selectively applied exactly MCP Deployment, Iris inventory ConfigMap and Hermes Deployment. All3 results succeeded; no hooks, migration, prune or other resource selection. Both new MCP replicas matched image/source/module hashes; Iris new process `b27182d8-088b-46ee-9e39-4bd9c7290069` seeded inventory5733c1c6b35d and intended SOUL. This refresh matters because installed Hermes keepalive/reconnect do not re-register cached tool schemas. All9 smoke checks passed and exactly1ESP32 writer connection was observed. All15 Deployment UIDs,13other Deployment specs and4 critical DB/API/ingestor Pod states stayed unchanged. Normal release CI `bq2rq` succeeded20:25:23UTC with its actual validation Pod and full logs retained.

The source-owned SOUL requests one prior-completed-night read in ordinary non-experiment SUNRISE/SUNSET work, reuses it, and preserves unavailable/negative/incomplete results. The existing Iris audience retains23 tools; `outcome_kpi` stays admin-only and denied to Iris. No credential, audience, ACL, getter or schema change was required.

## Authorized GPT-6 Luna upgrade

The initial bounded model export was rejected by automatic approval review before process creation. Jason then explicitly authorized the selected historical payload and requested **both live Iris and qualification use GPT-6 Luna**. The original unexecuted v2 and the rejection remain retained; this is not an automatic retry.

[Official model guidance](https://developers.openai.com/api/docs/models/gpt-6-luna) and the [Responses migration guidance](https://developers.openai.com/api/docs/guides/migrate-to-responses) were fetched. The existing Hermes image already resolves the direct OpenAI URL to its Responses adapter. Its public source was captured and reviewed. Existing account model metadata returned HTTP200 for `gpt-6-luna`; no generation or greenhouse payload was sent in that availability check.

Source `182691082420466dc1c5b39bae2fd84f49f38dbf` changes the live model default and API model label/audit copies. It preserves `xhigh`, provider/endpoint, tool limits, credential references and upstream Hermes image. The effective profile hash is `2261f5c1a236202b3bfccedd82f1284f50ab27445767dcb09439a92a8d58b56b`, revision2261f5c1a236. The installed ingestor prompt, playbook, inventory and experiment profile are unchanged; their old model-name prose is retained legacy text, not runtime model truth. The current README, declarative API label and canonical profile agree. Vision/embedding settings are unchanged; the vision ConfigMap only mirrors planner audit metadata.

[[MODEL_SOURCE_CI]]

[[MODEL_RELEASE_RUNTIME]]

## Actual bounded consumer acceptance

[[CONSUMER_RESULT]]

The qualification permits exactly one actual authenticated scorecard call per selected historical night and two Responses requests per case, at most800+1200 output tokens, `store:false`, no action dispatcher,90-second process deadline and no automatic retries. It uses the shipped Iris preamble and actual public MCP schema, with strict input, output, source, image and Pod identity guards. Encrypted reasoning is retained only in memory for stateless continuation, never published. A final summary must match actual counts/dispositions/NULLs and fixed scope text; safety pass cannot become efficacy/crop-safety/complete-daytime proof.

This is bounded ordinary MCP/model consumption. It does **not** establish an autonomous natural planner cycle, a full Hermes gateway run, physical efficacy or complete daytime observation. The captured gateway API uses full configured action toolsets and has no enforced per-run read-only filter; no full gateway run or controller action was launched for qualification.

## Prior accepted repair and preserved database

[Installed getter277 repair](../2026-10-18-getter-timeout-fix/README.md) remains accepted at its prior boundary. Actual October16 returned0rows/pending in11.816649s. October4 custom/generic calls returned the same4 full46-column rows in11.269874/4.966761s:2ineffective and2insufficient-evidence, none effective. The clone3.174204s result is not installed-production timing. Its20 native full-row parity cases,2673 genuine clone readback relations and original failures remain preserved and were not requalified here.

Final bounded database metadata confirms ledger285/max277, original postmaster, getter body/definition and solar helper unchanged. No migration or data rewrite occurred.

## Graph and next execution

[[GRAPH_RESULT]]

All acceptance clauses, issue states, parents, dependencies, priorities and effort estimates remain unchanged. Original S3B40h and22–34h selected estimates plus at least6h reserve are planning values, not remaining or measured effort.

1. Specify a supported observation/freshness contract and collect a prospective complete recorded daytime window. Preserve the incomplete October16/17 history.
2. Observe intended outcome consumption in a naturally scheduled ordinary planner cycle separately from this bounded qualification.
3. Advance authentic sensing, physical efficacy and crop-safety requirements on their own evidence. No tuning, universal VPD target, OTA or experiment follows from this packet.

No user decision remains pending unless an explicit failure/approval limitation is stated in the final receipt. Raw source, native logs, failed/unexecuted draft histories, CI, runtime, model and graph custody are published separately on the immutable evidence branch; terminal report CI and remote byte checks are recorded there to avoid a self-referential main-commit loop.
