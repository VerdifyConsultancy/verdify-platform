import subprocess,pathlib,json,hashlib
b=pathlib.Path('/private/tmp/verdify-daytime-consumer-20261018/hermes-model-transport-source');b.mkdir(exist_ok=False)
driver='''import pathlib,json,hashlib
base=pathlib.Path('/app')
found=[]
for root in [pathlib.Path('/app'),pathlib.Path('/opt/hermes'),pathlib.Path('/root/hermes')]:
 if (root/'run_agent.py').is_file():base=root;break
for name in ['agent/transports.py','agent/transports/__init__.py','agent/transports/codex_responses.py','agent/transports/openai_responses.py','hermes_constants.py']:
 p=base/name
 if p.is_file():
  raw=p.read_bytes();assert len(raw)<3000000;found.append({'path':str(p),'relative':name,'sha256':hashlib.sha256(raw).hexdigest(),'source':raw.decode()})
print(json.dumps({'base':str(base),'files':found}))
''';k=['kubectl','--kubeconfig','/Users/jason/.kube/config','--context','vallery','--request-timeout=15s','-n','verdify-prod'];r=subprocess.run(k+['exec','-i','verdify-hermes-iris-d955b7b4c-kdbq4','-c','hermes-iris','--','python3','-'],input=driver.encode(),capture_output=True,timeout=25);(b/'stdout.json').write_bytes(r.stdout);(b/'stderr').write_bytes(r.stderr);assert r.returncode==0;j=json.loads(r.stdout)
for f in j['files']:
 p=b/f['relative'];p.parent.mkdir(parents=True,exist_ok=True);p.write_text(f['source']);assert hashlib.sha256(p.read_bytes()).hexdigest()==f['sha256']
print(json.dumps({'base':j['base'],'files':[{'relative':f['relative'],'sha256':f['sha256']} for f in j['files']]}))
