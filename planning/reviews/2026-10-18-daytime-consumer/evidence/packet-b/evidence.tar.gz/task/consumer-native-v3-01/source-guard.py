import hashlib,json,os,pathlib,sys
expected={'/app/mcp/server.py': 'd8926ec1bca28c10cd0109b62238b395a3d233158879e51dbb073acdc7372a9f', '/app/verdify_schemas/realized_dryout.py': '7364d30ddea52fc5d5588f174b95de67c70a966224a5746c33f1838ba7586479', '/app/verdify_schemas/mcp_responses.py': 'edccf0a7740421aaeaa9b402e446c769fc1cd4b3fbfdc646e13cb83d1e3b82ee'}
try:
 actual={p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest() for p in expected}
 ok=actual==expected and os.environ.get("VERDIFY_GIT_SHA")=="b814f35e228fcb35c11593c47ea1e021e5fd73de"
 print(json.dumps({"status":"SOURCE_MATCH" if ok else "FAILED","source_sha":"b814f35e228fcb35c11593c47ea1e021e5fd73de","module_sha256":actual}))
 sys.exit(0 if ok else 1)
except Exception as e:
 print(json.dumps({"status":"FAILED","error_type":type(e).__name__}));sys.exit(1)
