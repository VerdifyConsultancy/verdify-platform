import hashlib,json,os,pathlib,sys
paths=['/etc/verdify/hermes-config/config.yaml','/opt/data/config.yaml']
try:
 if os.environ.get('HERMES_HOME')!='/opt/data':raise ValueError('home')
 if any(os.environ.get(k) for k in ['HERMES_MODEL','OPENAI_MODEL','HERMES_PROVIDER','OPENAI_BASE_URL','HERMES_REASONING_EFFORT']):raise ValueError('override')
 hashes={}
 for name in paths:
  p=pathlib.Path(name)
  if p.stat().st_size>200000:raise ValueError('size')
  hashes[name]=hashlib.sha256(p.read_bytes()).hexdigest()
 if any(h!='2261f5c1a236202b3bfccedd82f1284f50ab27445767dcb09439a92a8d58b56b' for h in hashes.values()):raise ValueError('hash')
 print(json.dumps({'status':'EFFECTIVE_PROFILE_MATCH','file_sha256':hashes,'model_env_overrides_present':[]}))
except Exception as e:
 print(json.dumps({'status':'FAILED','error_type':type(e).__name__}));sys.exit(1)
