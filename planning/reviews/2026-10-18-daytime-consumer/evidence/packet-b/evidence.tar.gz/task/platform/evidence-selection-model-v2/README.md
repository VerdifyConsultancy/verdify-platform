# Final model-upgrade evidence custody selection

Prepared source only. ROOT executes after the real selected attempts and final CI are terminal. No packaging, native call, publication, or acceptance is performed by these helpers. Earlier source helpers, drafts, failures, and receipts remain unchanged.

`selection.expanded-draft.json` extends the earlier explicit selection with the actual user authority, official-document references, model availability metadata, captured public Hermes model/transport source, source CI99648, model source/drafts and accepted initial runtime. It preserves all initial source/release, daytime, DB, graph and failure custody. Its `required_roots_when_complete` names ROOT's intended model promotion/release/render/rollout/runtime, two-case consumer-v3, final DB/graph/report/publication paths. These future roots are required only when ROOT finalizes, not assumed present or successful now.

Copy `completion-bindings.template.json` to a new file and fill it from retained evidence. Set `status` to `READY_FOR_BINDING` only after ROOT has checked the actual fields, hashes, and complete attempt selection. The review flags are operator custody assertions, not a new user approval gate. Terminal failed or incomplete outcomes may be archived honestly; they cannot be labeled passed. For a later case never started after a first-case failure, use the actual overall terminal receipt with outcome `incomplete` and its precise evidence, not a fabricated per-case receipt.

Each terminal role binds an exact regular receipt, SHA256, actual terminal field, exact assertions, and complete narrowly scoped attempt directories. Source/report roles bind exact bytes and review. Add exact model-release and report-CI Workflow name/namespace/UID/revision evidence when it exists. The three existing Workflows are fixed:

- source `verdify-platform-ci-bgf2f` / `f2083616-e793-4994-bd3b-9a48b1fbb376`
- initial release `verdify-platform-ci-bq2rq` / `ec8026c4-6986-4443-8559-c1931b4c754a`
- model source `verdify-platform-ci-99648` / `c1b8cc6d-88ed-456d-b105-dde24c2bf903`

ROOT's new top-level scripts, actual successors, and frozen failed attempts not already under selected `platform`, `control`, or `science` directories must be named in `additional_evidence`, with exact hashes and any whole attempt directories. No root-wide wildcard or arbitrary new credential exception is used.

Run `finalize-selection.py --bindings <filled-file> --bindings-sha256 <actual-sha256> --output-dir <fresh-directory-outside-taskbase>`. This produces the complete bound selection and a receipt. It does not package it or establish workload success. No actual finalizer invocation has run during preparation.

Because the complete work is likely to exceed one packet's unchanged 128 MiB ceiling, then run `split-selection.py --selection <bound-selection.json> --selection-sha256 <actual-sha256> --output-dir <another-fresh-directory-outside-taskbase>`. It creates two exact-file policies and one `union-index.json`:

- Packet A: initial MCP source CI, initial release CI, rollout/runtime, original daytime/DB/graph and associated initial source evidence.
- Packet B: model source/release/report CI, upgrade source/authority, model rollout/runtime, consumer-v3, final DB/graph/publication and newer helper evidence.

Every selected file belongs to the union. Only the exact required DSN provenance render (2.48 MB) and small bound final/context receipts are shared; logs and original artifacts are not duplicated gratuitously. Each policy remains subject to the original helper's 32 MiB per-file, 128 MiB selected/expanded, 10,000-member and depth2 archive guards. If either packet exceeds a limit, the splitter refuses; it does not raise limits or drop original proof. The index binds every file's bytes/SHA256/packet mapping plus both policy hashes. Archive and manifest hashes stay null until ROOT actually packages and verifies them; no completed archive is implied by the index.

Use the unchanged `/private/tmp/verdify-package-daytime-consumer-evidence-v1.py` on each bound policy. Preserve exact raw input bytes. The original scanner handles credentials, Kubernetes object ownership, nested archives, and full package readback; the selection/splitter is not a substitute for it or ROOT's independent final credential scan. The fixed raw Node/metrics and two fixture-tree exclusions, including descendants and caches, remain intact. No credential exception was added. A narrow scan of 14 explicitly captured public provider-source/authority/availability files passed with zero exceptions; this is not a whole-task scan.

Preparation checks: 20 small synthetic finalizer tests and seven synthetic split/refusal tests pass. The current metadata-only preview is incomplete and may grow: A 99,298,203 bytes, B 23,834,966 bytes, unique 120,585,997 bytes. Final ROOT execution recomputes exact selection, all file hashes, per-packet limits and immutable readback before producing policies. No package or native work has run here.
