#!/usr/bin/env python3
"""Bind exact retained completion receipts; no packaging, recursive scan or native calls.
ROOT fills the reviewed binding file after actual outcomes exist. A ready selection
means complete custody selection only, not workload success or publication approval.
"""
from __future__ import annotations
import argparse,copy,hashlib,json,os,re,stat
from pathlib import Path,PurePosixPath
BASE=Path('/private/tmp/verdify-daytime-consumer-20261018')
PACKAGER=Path('/private/tmp/verdify-package-daytime-consumer-evidence-v1.py')
PACKAGER_SHA='675c713d10a35f7fd57a967d4656338ce7af38b654f7f7cb13e33267043d5e49'
DRAFT_SHA='5f0bbe39f2aba8fc51b049038538ffb8ff8adc42a2574bbe2daae3e90f7c4cee'
MAX_FILE=32*1024*1024
EXCLUDED={'initial/nodes.json','initial/metrics.json','platform/check-root','platform/iris-inventory-check-root'}
TERMINAL_ROLES={'original_source_ci','original_release_ci','original_rollout','original_runtime','model_source_ci','model_release_ci','model_rollout','model_runtime','consumer_oct04','consumer_oct16','final_database_identity','final_native_graph','final_report_ci'}
SOURCE_ROLES={'model_promotion_source','model_release_source','final_publication_source','final_report'}
ROLES=TERMINAL_ROLES|SOURCE_ROLES
FIXED_CI={'original_source_ci':('b814f35e228fcb35c11593c47ea1e021e5fd73de','f2083616-e793-4994-bd3b-9a48b1fbb376'),'original_release_ci':('e545380a23129eb1830e9d6d804334f46f8fdcfe','ec8026c4-6986-4443-8559-c1931b4c754a'),'model_source_ci':('56b316f3fda666b25665dfc0f791d6be6db0fa46','410c5d3a-6bbe-4aaf-89bb-c3cecce0dd2f')}
class Refusal(Exception):pass
def need(ok,code):
 if not ok:raise Refusal(code)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def canonical(v):return (json.dumps(v,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
def pairs(items):
 result={}
 for k,v in items:need(k not in result,'duplicate_key');result[k]=v
 return result
def decode(raw):return json.loads(raw,object_pairs_hook=pairs,parse_constant=lambda _:(_ for _ in ()).throw(Refusal('nonfinite_json')))
def rel(value):
 need(isinstance(value,str) and value and '\\' not in value and '\x00' not in value,'relative_path_shape')
 p=PurePosixPath(value);need(not p.is_absolute() and all(x not in ('','.','..') for x in value.split('/')),'unsafe_relative_path')
 need(not any(x=='__pycache__' for x in p.parts) and not value.endswith(('.pyc','.pyo')),'excluded_cache')
 need(not any(value==x or value.startswith(x+'/') for x in EXCLUDED),'excluded_input')
 return value
def resolve(base,value,kind=None):
 value=rel(value);p=base
 for part in PurePosixPath(value).parts:p/=part;need(not p.is_symlink(),'symlink_path')
 need(p.exists(),'input_missing')
 if kind=='file':need(stat.S_ISREG(p.lstat().st_mode),'not_regular_file')
 elif kind=='dir':need(p.is_dir(),'not_directory')
 return p
def read(p):
 st=p.lstat();need(stat.S_ISREG(st.st_mode) and st.st_size<=MAX_FILE,'not_bounded_regular_file')
 fd=os.open(p,os.O_RDONLY|getattr(os,'O_NOFOLLOW',0))
 with os.fdopen(fd,'rb') as f:
  before=os.fstat(f.fileno());raw=f.read(MAX_FILE+1);after=os.fstat(f.fileno())
 sig=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
 need(len(raw)<=MAX_FILE and sig(st)==sig(before)==sig(after)==sig(p.lstat()),'input_changed')
 return raw
def get_field(value,keys):
 need(isinstance(keys,list) and keys and all(isinstance(k,str) and k for k in keys),'field_path_shape')
 for key in keys:need(isinstance(value,dict) and key in value,'asserted_field_missing');value=value[key]
 return value
def receipt(base,entry,reads):
 need(isinstance(entry,dict) and re.fullmatch('[0-9a-f]{64}',entry.get('sha256','')),'receipt_binding_shape')
 name=rel(entry['path']);p=resolve(base,name,'file');raw=read(p);need(sha(raw)==entry['sha256'],'receipt_hash')
 reads[name]=raw;return raw

def build(base,draft,binding):
 need(draft.get('status')=='draft_not_ready' and draft.get('taskbase')==str(base),'draft_scope')
 need(binding.get('schema')=='daytime-consumer-completion-bindings/v3' and binding.get('taskbase')==str(base),'binding_scope')
 need(binding.get('status')=='READY_FOR_BINDING','binding_not_ready')
 need(binding.get('selection_reviewed_by_root') is True and binding.get('all_attempts_included_reviewed_by_root') is True,'selection_review_not_complete')
 need(set(binding.get('roles',{}))==ROLES,'required_completion_roles')
 need(binding.get('credential_exceptions_added',0)==0,'no_new_credential_exceptions')
 need(not draft.get('public_metadata_hash_exceptions'),'unexpected_metadata_exceptions')
 result=copy.deepcopy(draft);includes=set(result['include']);required=set(result['required_files']);reads={};observations={}
 for name in draft.get('required_roots_when_complete',[]):
  path=resolve(base,name);includes.add(name)
  if path.is_file():required.add(name)
 for role,entry in binding['roles'].items():
  need(isinstance(entry,dict) and entry.get('reviewed_by_root') is True,'receipt_not_reviewed')
  raw=receipt(base,entry,reads);required.add(entry['path']);includes.add(entry['path'])
  dirs=entry.get('attempt_directories_to_include',[]);need(isinstance(dirs,list),'attempt_directories_shape')
  if role in TERMINAL_ROLES:
   need(entry.get('terminal') is True and entry.get('outcome') in ('passed','failed','incomplete','refused'),'nonterminal_completion')
   value=decode(raw);assertions=entry.get('assertions');need(isinstance(assertions,list) and assertions,'missing_terminal_assertion')
   for assertion in assertions:
    observed=get_field(value,assertion['field']);need(observed==assertion['equals'],'receipt_assertion')
   # A fresh reviewed terminal outcome must have a non-running terminal indicator in the actual receipt.
   terminal=entry.get('terminal_indicator');need(isinstance(terminal,dict),'missing_terminal_indicator')
   observed=get_field(value,terminal['field']);need(observed==terminal['equals'],'terminal_indicator_mismatch')
   need(isinstance(observed,str) and observed and not re.search(r'PENDING|RUNNING|STARTED|NOT_READY|UNBOUND|UNKNOWN',observed,re.I),'nonterminal_indicator')
   need(re.search(r'PASS|VERIFIED|SUCCEEDED|MATCH|COMPLETE|FAIL|REFUS|ERROR',observed,re.I) is not None,'unrecognized_terminal_indicator')
   if entry['outcome']=='passed':need(not re.search(r'FAIL|ERROR|REFUS|INCOMPLETE',observed,re.I) and re.search(r'PASS|VERIFIED|SUCCEEDED|MATCH|COMPLETE',observed,re.I),'contradictory_pass_outcome')
   if role in FIXED_CI:
    source,uid=FIXED_CI[role];need(value.get('source_revision')==source and value.get('workflow_uid')==uid,'fixed_ci_scope')
   if role.startswith('consumer_'):need(dirs,'consumer_attempt_custody_required')
   observations[role]={'path':entry['path'],'sha256':entry['sha256'],'outcome':entry['outcome'],'terminal_indicator':observed}
  else:observations[role]={'path':entry['path'],'sha256':entry['sha256'],'classification':'source_or_report_custody_only'}
  for name in dirs:resolve(base,name,'dir');includes.add(name)
 # Fixed source declarations plus newly supplied actual task Workflow identities; never a wildcard.
 identities={};proofs=[]
 for entry in binding.get('workflow_evidence',[]):
  need(entry.get('reviewed_by_root') is True,'workflow_not_reviewed');raw=receipt(base,entry,reads);obj=decode(raw)
  need(obj.get('kind')=='Workflow' and obj.get('apiVersion')=='argoproj.io/v1alpha1','workflow_kind')
  meta=obj['metadata'];identity={k:meta.get(k) for k in ('namespace','name','uid')}
  need(identity==entry.get('identity') and identity['namespace']=='agent-fleet-ci' and re.fullmatch(r'verdify-platform-ci-[a-z0-9]+',identity['name'] or '') and re.fullmatch(r'[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}',identity['uid'] or ''),'workflow_identity')
  need(meta.get('labels',{}).get('agent-fleet.vallery.net/repo')=='verdifyconsultancy-verdify-platform','foreign_workflow_repo')
  params=[x['value'] for x in obj['spec']['arguments']['parameters'] if x['name']=='revision']
  need(len(params)==1 and params[0]==entry.get('source_revision') and re.fullmatch('[0-9a-f]{40}',params[0]),'workflow_source')
  key=(identity['namespace'],identity['name']);need(key not in identities,'duplicate_workflow');identities[key]=identity
  proofs.append({k:entry[k] for k in ('path','sha256','identity','source_revision')});required.add(entry['path']);includes.add(entry['path'])
 fixed={(x['namespace'],x['name']):x for x in draft['workflow_identities']}
 need(all(identities.get(k)==v for k,v in fixed.items()),'missing_fixed_workflow_binding')
 known_uids={v['uid'] for v in identities.values()}
 for role in ('original_source_ci','original_release_ci','model_source_ci','model_release_ci','final_report_ci'):
  value=decode(reads[binding['roles'][role]['path']]);need(value.get('workflow_uid') in known_uids,'ci_receipt_workflow_unbound')
 for entry in binding.get('additional_evidence',[]):
  need(entry.get('reviewed_by_root') is True,'additional_evidence_not_reviewed');receipt(base,entry,reads);required.add(entry['path']);includes.add(entry['path'])
  for name in entry.get('attempt_directories_to_include',[]):resolve(base,name,'dir');includes.add(name)
 for name in includes:resolve(base,name)
 for name in required:
  p=resolve(base,name,'file')
  if name not in reads:reads[name]=read(p)
 need(all(read(resolve(base,name,'file'))==raw for name,raw in reads.items()),'inputs_changed_during_binding')
 result.update(status='ready_for_packaging',include=sorted(includes),required_files=sorted(required),workflow_identities=list(identities.values()),workflow_identity_evidence=proofs,completion_observations=observations,pending_before_execution=[],completion_scope='Custody bindings reviewed; packaging scanner/size limits still run independently. Failed originals remain included; no workload acceptance or publication authorization asserted.')
 return result,reads

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--bindings',type=Path,required=True);p.add_argument('--bindings-sha256',required=True);p.add_argument('--output-dir',type=Path,required=True);a=p.parse_args()
 draft_path=Path(__file__).with_name('selection.expanded-draft.json');raw=read(draft_path);need(sha(raw)==DRAFT_SHA,'draft_hash');need(sha(read(PACKAGER))==PACKAGER_SHA,'packager_changed')
 binds_raw=read(a.bindings);need(sha(binds_raw)==a.bindings_sha256,'bindings_hash')
 out=a.output_dir.absolute();need(not out.exists() and not out.is_symlink() and not out.resolve().is_relative_to(BASE.resolve()),'fresh_external_output_required')
 result,reads=build(BASE,decode(raw),decode(binds_raw))
 need(read(draft_path)==raw and read(a.bindings)==binds_raw and sha(read(PACKAGER))==PACKAGER_SHA,'controls_changed')
 out.mkdir(mode=0o700)
 for name,value in [('selection.json',result),('completion-binding-receipt.json',{'schema':'daytime-consumer-selection-completion/v3','status':'SELECTION_BOUND_NOT_PACKAGED','draft_sha256':sha(raw),'bindings_sha256':sha(binds_raw),'helper_sha256':sha(read(Path(__file__))),'packager_sha256':PACKAGER_SHA,'bound_files':{k:sha(v) for k,v in reads.items()},'packaging_executed':False,'native_calls':0,'publication_authorized_by_helper':False})]:
  with (out/name).open('xb') as f:os.chmod(out/name,0o600);f.write(canonical(value))
 print(json.dumps({'status':'SELECTION_BOUND_NOT_PACKAGED','selection_sha256':sha(read(out/'selection.json')),'out':str(out)}))
if __name__=='__main__':
 try:main()
 except Exception as e:print(json.dumps({'status':'REFUSED','code':str(e) if isinstance(e,Refusal) else type(e).__name__,'raw_values_printed':False}));raise SystemExit(1)
