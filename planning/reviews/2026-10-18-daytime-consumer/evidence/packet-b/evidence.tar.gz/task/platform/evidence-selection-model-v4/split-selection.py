#!/usr/bin/env python3
"""Offline exact-file split of final bound selection into two unchanged-limit packets.
No packaging/scanning/native/Git/publication. ROOT executes only after all captures
are terminal. The index preserves every selected file and shared-context mapping.
"""
import argparse,copy,hashlib,importlib.util,json,os,pathlib,stat
BASE=pathlib.Path('/private/tmp/verdify-daytime-consumer-20261018')
HELPER=pathlib.Path('/private/tmp/verdify-package-daytime-consumer-evidence-v2.py')
HELPER_SHA='ea53bf6af1cafe2fefe657ef79747799e51fc937d479e378605dc3a41c0838cf'
# A owns initial MCP/source/release proof. B owns model/final/consumer proof.
A_ROOTS={'source-ci','release-ci','ci-checkpoint-01','release-ci-checkpoint-01','initial','render-before','render-after','rollout','runtime-01','http-initial','daytime-native-01','database-identity','database-final','graph-before','iris-source','hermes-api-source','hermes-mcp-source','source-impact','report-draft','final-planning-draft'}
A_FILES={'COORDINATOR_STATE.json','candidate-readback.json','capture-initial.py','check-hermes-idle-health.py','check-idle-ledger-pilot.py','collect-ci.py','consumer-input-oct04.json','consumer-input-oct16.json','dispatch-rollout.py','github-checkpoint-after.json','github-checkpoint-before.json','github-inflight-comment.json','issue-410-before.json','issue-775-before.json','main-before.json','mcp-promotion-source.json','prepare-release-source.py','read-database-identity.py','read-graph-before.py','read-hermes-api-source.py','read-hermes-mcp-source.py','read-http-initial.py','read-mounted-model.py','read-mounted-model-v2.py','read-mounted-model-v3.py','release-ci-checkpoint.json','release-ci-discovery.json','release-ci-verified.json','run-daytime-coverage.py','source-ci-discovery.json','source-ci-verified.json','source-validation-verified.json','verify-source-ci.py','verify-validation-ci.py'}
A_CONTROL_DIRS={'deploy-plan','deploy-plan-v2','packaging'}
class Refusal(Exception):pass
def need(ok,code):
 if not ok:raise Refusal(code)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def canonical(v):return (json.dumps(v,indent=2,sort_keys=True,allow_nan=False)+'\n').encode()
def owner(name):
 parts=pathlib.PurePosixPath(name).parts
 if parts[0] in A_ROOTS or name in A_FILES:return 'A'
 if parts[0]=='control' and len(parts)>1 and (parts[1] in A_CONTROL_DIRS or (len(parts)==2 and not parts[1].startswith('model-'))):return 'A'
 if parts[0]=='platform' and len(parts)>1 and 'model' not in parts[1] and parts[1]!='provider-public-source-narrow-scan.json':return 'A'
 return 'B'
def load_helper():
 need(sha(HELPER.read_bytes())==HELPER_SHA,'packager_changed');s=importlib.util.spec_from_file_location('fixed_packager',HELPER);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m

def collect(m,base,includes):
 files={};skips={}
 def visit(path,name):
  reason=m.excluded(name)
  if reason:skips[name]=reason;return
  s=path.lstat();need(not stat.S_ISLNK(s.st_mode),'symlink_in_selection')
  if stat.S_ISDIR(s.st_mode):
   for child in sorted(path.iterdir()):visit(child,name+'/'+child.name)
  else:
   need(stat.S_ISREG(s.st_mode) and s.st_size<=m.MAX_FILE,'file_type_or_limit');files[name]=path;need(len(files)<=2*m.MAX_MEMBERS,'union_member_limit')
 for name in includes:
  name=m.relname(name);p=base
  for part in pathlib.PurePosixPath(name).parts:p/=part;need(not p.is_symlink(),'symlink_in_selection')
  need(p.exists(),'selected_path_missing');visit(p,name)
 need(files and sum(p.stat().st_size for p in files.values())<=2*m.MAX_TOTAL,'union_size_limit')
 return dict(sorted(files.items())),skips

def partition(m,files,shared):
 need(shared<=set(files),'shared_context_missing')
 packets={k:sorted({n for n in files if owner(n)==k}|shared) for k in ('A','B')}
 need(set(packets['A'])|set(packets['B'])==set(files),'union_coverage')
 sizes={k:sum(files[n].stat().st_size for n in names) for k,names in packets.items()}
 for k,names in packets.items():need(len(names)<=m.MAX_MEMBERS and sizes[k]<=m.MAX_TOTAL,'packet_'+k+'_exceeds_unchanged_limit')
 return packets,sizes

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--selection',type=pathlib.Path,required=True);p.add_argument('--selection-sha256',required=True);p.add_argument('--output-dir',type=pathlib.Path,required=True);a=p.parse_args();m=load_helper()
 raw=m.read_regular(a.selection)[0];need(sha(raw)==a.selection_sha256,'selection_hash');full=m.decode(raw);m.validate_policy(full,BASE)
 need(not full.get('public_metadata_hash_exceptions'),'no_unreviewed_extra_exceptions');need(full.get('completion_observations'),'not_completion_bound')
 out=a.output_dir.absolute();need(not out.exists() and not out.is_symlink() and not out.resolve().is_relative_to(BASE.resolve()),'fresh_external_output_required')
 files,skips=collect(m,BASE,full['include']);need(set(full['required_files'])<=set(files),'required_input_missing')
 # Exact DSN source is mandatory in each unchanged packager, despite its2.48MB size.
 # Shared completion receipt hashes give each packet final context, without duplicate logs.
 shared={m.DSN_REFERENCE_SOURCE,'model-upgrade-user-authorization.json','model-upgrade-docs-and-authority.json'}|{v['path'] for v in full['completion_observations'].values()}
 packets,sizes=partition(m,files,shared)
 need(sha(m.read_regular(files[m.DSN_REFERENCE_SOURCE])[0])==m.DSN_REFERENCE_SOURCE_SHA256,'dsn_source_hash')
 inventory=[];fingerprints={}
 for name,path in files.items():
  data,fp=m.read_regular(path);fingerprints[name]=fp;inventory.append({'path':name,'bytes':len(data),'sha256':sha(data),'packets':[k for k,names in packets.items() if name in names]})
 union_sha=sha(canonical(inventory));policies={}
 for key,names in packets.items():
  policy=copy.deepcopy(full);policy.update(include=names,required_files=sorted((set(full['required_files'])&set(names))|shared),packet_id=key,packet_scope='Initial MCP source and release' if key=='A' else 'Model upgrade and final consumer/publication custody',union_file_inventory_sha256=union_sha,split_from_selection_sha256=sha(raw),cross_packet_context='Completion receipt context shared; some referenced raw evidence is in the other indexed packet. No acceptance or publication inferred.')
  m.validate_policy(policy,BASE);policies[key]=canonical(policy)
 final_files,final_skips=collect(m,BASE,full['include']);need(list(final_files)==list(files) and final_skips==skips,'inventory_changed')
 need(all(m.fingerprint(files[n].lstat())==fp for n,fp in fingerprints.items()),'source_changed_during_index')
 need(m.read_regular(a.selection)[0]==raw and sha(HELPER.read_bytes())==HELPER_SHA,'controls_changed')
 index={'schema':'daytime-consumer-two-packet-union/v1','status':'EXACT_UNION_BOUND_NOT_PACKAGED','taskbase':str(BASE),'source_selection_sha256':sha(raw),'packager_sha256':HELPER_SHA,'splitter_sha256':sha(pathlib.Path(__file__).read_bytes()),'union_file_inventory_sha256':union_sha,'unique_files':len(files),'unique_bytes':sum(v['bytes'] for v in inventory),'shared_context_files':sorted(shared),'packets':{k:{'selection_file':'selection-'+k.lower()+'.json','selection_sha256':sha(policies[k]),'files':len(packets[k]),'bytes':sizes[k],'unchanged_total_limit':m.MAX_TOTAL,'unchanged_per_file_limit':m.MAX_FILE,'archive_path':None,'archive_sha256':None,'manifest_sha256':None} for k in packets},'files':inventory,'exclusions':skips,'union_complete':True,'original_bytes_rewritten':False,'packaging_executed':False,'publication_authorized_by_helper':False}
 out.mkdir(mode=0o700)
 for name,data in [(f'selection-{k.lower()}.json',v) for k,v in policies.items()]+[('union-index.json',canonical(index))]:
  with (out/name).open('xb') as f:os.chmod(out/name,0o600);f.write(data)
 print(json.dumps({'status':index['status'],'out':str(out),'union_index_sha256':sha(canonical(index)),'packet_bytes':sizes,'packaging_executed':False}))
if __name__=='__main__':
 try:main()
 except Exception as e:print(json.dumps({'status':'REFUSED','code':str(e) if isinstance(e,Refusal) else type(e).__name__,'raw_values_printed':False}));raise SystemExit(1)
