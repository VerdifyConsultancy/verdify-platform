import importlib.util,pathlib,tempfile,types,unittest
p=pathlib.Path(__file__).with_name('split-selection.py');s=importlib.util.spec_from_file_location('splitter',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
class Tests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(dir='/private/tmp');self.b=pathlib.Path(self.tmp.name);self.addCleanup(self.tmp.cleanup);self.files={}
  for name in ['source-ci/original-failed.log','release-ci/final.log','model-source-ci/final.log','consumer-native-v3-01/failed-original.log','render-before/render.json','final-publication-source.json']:
   p=self.b/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b'12345');self.files[name]=p
  self.limits=types.SimpleNamespace(MAX_MEMBERS=10000,MAX_TOTAL=128);self.shared={'render-before/render.json','final-publication-source.json'}
 def test_union_preserves_failed_and_final(self):
  packets,sizes=m.partition(self.limits,self.files,self.shared);self.assertEqual(set(packets['A'])|set(packets['B']),set(self.files));self.assertEqual(set(packets['A'])&set(packets['B']),self.shared);self.assertIn('source-ci/original-failed.log',packets['A']);self.assertIn('consumer-native-v3-01/failed-original.log',packets['B']);self.assertEqual(sizes,{'A':20,'B':20})
 def test_over_packet_refuses_no_relaxation(self):
  self.limits.MAX_TOTAL=19
  with self.assertRaisesRegex(m.Refusal,'packet_A_exceeds_unchanged_limit'):m.partition(self.limits,self.files,self.shared)
 def test_unknown_new_proof_kept_in_b(self):self.assertEqual(m.owner('new-root-final-helper.py'),'B')
 def test_missing_shared_refuses(self):
  with self.assertRaisesRegex(m.Refusal,'shared_context_missing'):m.partition(self.limits,self.files,self.shared|{'absent'})
 def test_member_limit_refuses(self):
  self.limits.MAX_MEMBERS=3
  with self.assertRaisesRegex(m.Refusal,'unchanged_limit'):m.partition(self.limits,self.files,self.shared)
 def test_exclusion_before_symlink(self):
  real=m.load_helper();(self.b/'platform').mkdir();(self.b/'platform/check-root').symlink_to('/not-traversed',target_is_directory=True)
  files,skips=m.collect(real,self.b,['platform','source-ci']);self.assertEqual(set(files),{'source-ci/original-failed.log'});self.assertIn('platform/check-root',skips)
 def test_nonexcluded_symlink_refused(self):
  real=m.load_helper();(self.b/'other').symlink_to('/not-traversed',target_is_directory=True)
  with self.assertRaisesRegex(m.Refusal,'symlink_in_selection'):m.collect(real,self.b,['other'])
if __name__=='__main__':unittest.main()
