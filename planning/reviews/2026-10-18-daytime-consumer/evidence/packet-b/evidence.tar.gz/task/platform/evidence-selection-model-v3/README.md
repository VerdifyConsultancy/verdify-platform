# Corrected model-CI custody successor

This source-only successor preserves the entire v2 helper/draft/test history. It changes only the current model source-CI role to source `56b316f3fda666b25665dfc0f791d6be6db0fa46`, Workflow `verdify-platform-ci-87whm`, UID `410c5d3a-6bbe-4aaf-89bb-c3cecce0dd2f`, independently read from retained discovery SHA `67a2da9c033abbbea1ae7b791d153151942a2944abbff03b5501c0049966b5d1`. It does not claim current CI success.

Original source18269 Workflow99648 is retained as Failed at20:36:13Z, before image builds, with its complete `model-source-ci` directory and exact terminal Workflow SHA `bc3371b31530738bbfc59a0da775670cffd008e27cf47084c35107b1c1a8dbd8`. The new `model-source-ci-02` complete directory is required at finalization. Both Workflow identities stay in the scanner policy; old logs and proofs are never relabeled or overwritten.

The expanded draft also selects `model-source-impact-02`, new discovery, and ROOT's exact promotion/rollout helpers. Effective profile2261 and four-object rollout scope are unchanged. New runtime-model-v3 and canonical-finalizer-v2 source files are automatically included under the already-selected `control` directory.

Fill this directory's unbound template from actual receipts. Run this directory's `finalize-selection.py` with its exact input hash as described in the preserved v2 README. Then reuse **unchanged** `../evidence-selection-model-v2/split-selection.py` SHA `c0790a51008670f3dc02a33aed4a8702b0e35c783d8b12898757f2c87f73308d`; the new model-source-ci-02 and failed model-source-ci both go in packet B. All per-packet/file/member/archive limits, exclusions and the underlying packager remain unchanged. The final union index preserves every original and successor selected byte.

No actual finalizer, split, package, native operation or publication is run here. Final model CI/runtime/consumer acceptance remains unclaimed until ROOT supplies actual accepted receipts.
