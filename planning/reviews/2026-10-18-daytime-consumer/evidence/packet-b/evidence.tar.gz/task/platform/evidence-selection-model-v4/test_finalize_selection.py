"""Tiny synthetic binding/refusal tests; never load or scan actual task evidence."""
import copy,importlib.util,json,pathlib,tempfile,unittest
P=pathlib.Path(__file__).with_name('finalize-selection.py')
s=importlib.util.spec_from_file_location('finalizer',P);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
class Tests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(prefix='selection-fixture-',dir='/private/tmp');self.b=pathlib.Path(self.tmp.name);self.addCleanup(self.tmp.cleanup)
  (self.b/'attempt').mkdir();self.roles={};self.workflows=[]
  for i,(role,(source,uid)) in enumerate(m.FIXED_CI.items()):
   identity={'namespace':'agent-fleet-ci','name':'verdify-platform-ci-test'+str(i),'uid':uid}
   name='wf'+str(i)+'.json';obj={'apiVersion':'argoproj.io/v1alpha1','kind':'Workflow','metadata':{**identity,'labels':{'agent-fleet.vallery.net/repo':'verdifyconsultancy-verdify-platform'}},'spec':{'arguments':{'parameters':[{'name':'revision','value':source}]}}}
   self.write(name,obj);self.workflows.append({'path':name,'sha256':m.sha((self.b/name).read_bytes()),'identity':identity,'source_revision':source,'reviewed_by_root':True})
  for role in m.ROLES:
   data={'status':'PASSED'}
   if role in m.FIXED_CI:data.update(zip(('source_revision','workflow_uid'),m.FIXED_CI[role]))
   elif role in ('model_release_ci','final_report_ci'):data['workflow_uid']=self.workflows[0]['identity']['uid']
   name=role+'.json';self.write(name,data)
   self.roles[role]={'path':name,'sha256':m.sha((self.b/name).read_bytes()),'reviewed_by_root':True,'terminal':True,'outcome':'passed','terminal_indicator':{'field':['status'],'equals':'PASSED'},'assertions':[{'field':['status'],'equals':'PASSED'}],'attempt_directories_to_include':['attempt']}
  self.d={'status':'draft_not_ready','taskbase':str(self.b),'include':['attempt'],'required_files':[],'workflow_identities':[x['identity'] for x in self.workflows],'public_metadata_hash_exceptions':[]}
  self.v={'schema':'daytime-consumer-completion-bindings/v4','status':'READY_FOR_BINDING','taskbase':str(self.b),'selection_reviewed_by_root':True,'all_attempts_included_reviewed_by_root':True,'roles':self.roles,'workflow_evidence':self.workflows,'additional_evidence':[]}
 def write(self,name,obj):(self.b/name).write_bytes(m.canonical(obj))
 def run_build(self):return m.build(self.b,self.d,self.v)
 def refuse(self,code):
  with self.assertRaisesRegex(m.Refusal,'^'+code+'$'):self.run_build()
 def test_complete_custody(self):
  result,reads=self.run_build();self.assertEqual(result['status'],'ready_for_packaging');self.assertEqual(set(result['completion_observations']),m.ROLES);self.assertTrue(reads)
 def test_unbound_status(self):self.v['status']='UNBOUND_DO_NOT_PACKAGE';self.refuse('binding_not_ready')
 def test_contradictory_failed_pass(self):
  e=self.roles['model_runtime'];self.write(e['path'],{'status':'FAILED'});e['sha256']=m.sha((self.b/e['path']).read_bytes());e['assertions'][0]['equals']=e['terminal_indicator']['equals']='FAILED';self.refuse('contradictory_pass_outcome')
 def test_unbound_review(self):self.v['selection_reviewed_by_root']=False;self.refuse('selection_review_not_complete')
 def test_missing_role(self):self.roles.pop('model_runtime');self.refuse('required_completion_roles')
 def test_null_role(self):self.roles['model_runtime']=None;self.refuse('receipt_not_reviewed')
 def test_hash_mutation(self):self.roles['model_runtime']['sha256']='0'*64;self.refuse('receipt_hash')
 def test_false_assertion(self):self.roles['model_runtime']['assertions'][0]['equals']='WRONG';self.refuse('receipt_assertion')
 def test_running_actual_receipt(self):
  e=self.roles['model_runtime'];self.write(e['path'],{'status':'RUNNING'});e['sha256']=m.sha((self.b/e['path']).read_bytes());e['assertions'][0]['equals']=e['terminal_indicator']['equals']='RUNNING';self.refuse('nonterminal_indicator')
 def test_pending_path_missing(self):self.d['required_roots_when_complete']=['future'];self.refuse('input_missing')
 def test_explicit_excluded(self):self.d['include'].append('initial/nodes.json');self.refuse('excluded_input')
 def test_excluded_descendant(self):self.d['include'].append('platform/check-root/somefile');self.refuse('excluded_input')
 def test_symlink_parent(self):
  (self.b/'link').symlink_to(self.b/'attempt',target_is_directory=True);self.d['include'].append('link');self.refuse('symlink_path')
 def test_path_escape(self):self.roles['model_runtime']['path']='../outside';self.refuse('unsafe_relative_path')
 def test_unknown_workflow_identity(self):self.workflows[0]['identity']['uid']='0'*36;self.refuse('workflow_identity')
 def test_foreign_repo(self):
  e=self.workflows[0];d=json.loads((self.b/e['path']).read_bytes());d['metadata']['labels']['agent-fleet.vallery.net/repo']='other';self.write(e['path'],d);e['sha256']=m.sha((self.b/e['path']).read_bytes());self.refuse('foreign_workflow_repo')
 def test_original_failed_model_source_cannot_be_current(self):
  e=self.roles['model_source_ci'];d=json.loads((self.b/e['path']).read_bytes());d.update(source_revision='182691082420466dc1c5b39bae2fd84f49f38dbf',workflow_uid='c1b8cc6d-88ed-456d-b105-dde24c2bf903');self.write(e['path'],d);e['sha256']=m.sha((self.b/e['path']).read_bytes());self.refuse('fixed_ci_scope')
 def test_unbound_ci_workflow(self):
  e=self.roles['final_report_ci'];d=json.loads((self.b/e['path']).read_bytes());d['workflow_uid']='unknown';self.write(e['path'],d);e['sha256']=m.sha((self.b/e['path']).read_bytes());self.refuse('ci_receipt_workflow_unbound')
 def test_failed_original_is_honest(self):
  e=self.roles['consumer_oct04'];self.write(e['path'],{'status':'FAILED'});e['sha256']=m.sha((self.b/e['path']).read_bytes());e['assertions'][0]['equals']=e['terminal_indicator']['equals']='FAILED';e['outcome']='failed'
  result,_=self.run_build();self.assertEqual(result['completion_observations']['consumer_oct04']['outcome'],'failed')
 def test_new_exception_rejected(self):self.v['credential_exceptions_added']=1;self.refuse('no_new_credential_exceptions')
 def test_duplicate_json(self):
  with self.assertRaisesRegex(m.Refusal,'duplicate_key'):m.decode(b'{"a":1,"a":2}')
if __name__=='__main__':unittest.main()
