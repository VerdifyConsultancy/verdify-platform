from pathlib import Path
import hashlib
b=Path('/private/tmp/verdify-daytime-consumer-20261018/control');src=b/'deploy-plan-v2/emit.py';d=b/'model-deploy-plan';d.mkdir(exist_ok=False)
text=src.read_text();assert hashlib.sha256(src.read_bytes()).hexdigest()=='998b669662258605a109f0d06e47ef16dceee84c31ad3b61ea5aafa02f1a04da'
text=text.replace('Pure exact-three-resource Argo JSON-patch emitter.','Pure exact-two-resource model-profile Argo JSON-patch emitter.')
text=text.replace('import argparse, copy, datetime as dt, hashlib, json, pathlib, re, uuid','import argparse, copy, datetime as dt, hashlib, json, pathlib, re, uuid\nimport yaml')
a=text.index("OLD_MCP=");z=text.index("TERMINAL=",a)
text=text[:a]+'''OLD_PROFILE_SHA='51de00576417701fc4fed8fb03ec9a3f1bfbee5e4f5d057f25b763076c2a8b5f'
INVENTORY='5733c1c6b35d'
OLD_MODEL='gpt-5.6-luna'
NEW_MODEL='gpt-6-luna'
RESOURCES=[{'group':'','kind':'ConfigMap','name':'verdify-hermes-iris-config','namespace':'verdify-prod'},
           {'group':'apps','kind':'Deployment','name':'verdify-hermes-iris','namespace':'verdify-prod'}]
'''+text[z:]
a=text.index('def validate_render(');z=text.index('def stamp(',a)
text=text[:a]+'''class UniqueLoader(yaml.SafeLoader):
 pass
def unique_mapping(loader,node,deep=False):
 loader.flatten_mapping(node)
 out={}
 for kn,vn in node.value:
  k=loader.construct_object(kn,deep=deep)
  require(k not in out,'duplicate_profile_yaml_key')
  out[k]=loader.construct_object(vn,deep=deep)
 return out
UniqueLoader.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG,unique_mapping)
def profile(raw):
 require(isinstance(raw,str) and len(raw.encode())<=65536,'profile_size_or_type')
 value=yaml.load(raw,Loader=UniqueLoader)
 require(isinstance(value,dict) and isinstance(value.get('model'),dict),'profile_mapping')
 return value
def canonical(value):return json.dumps(value,sort_keys=True,allow_nan=False,separators=(',',':'))
def validate_render(before,after,profile_sha256):
 require(re.fullmatch('[0-9a-f]{64}',profile_sha256) is not None,'profile_digest_shape')
 require(set(before)==set(after),'inventory_changed')
 changed={k for k in before if before[k]!=after[k]}
 require(changed=={tuple_of(r) for r in RESOURCES},'diff_not_exact_two')
 cmk,hk=[tuple_of(r) for r in RESOURCES]
 oldcm,newcm=before[cmk],after[cmk]
 require(set(oldcm['data'])==set(newcm['data'])=={'config.yaml','tool-readiness.py'},'profile_data_keys_changed')
 require({k for k in oldcm['data'] if oldcm['data'][k]!=newcm['data'][k]}=={'config.yaml'},'only_config_change_allowed')
 copycm=copy.deepcopy(newcm);copycm['data']['config.yaml']=oldcm['data']['config.yaml'];require(copycm==oldcm,'configmap_other_change')
 require(oldcm['metadata'].get('annotations',{}).get('argocd.argoproj.io/sync-wave','0')=='0','configmap_wave')
 oldraw,newraw=oldcm['data']['config.yaml'],newcm['data']['config.yaml']
 require(sha(oldraw.encode())==OLD_PROFILE_SHA,'old_profile_hash')
 require(sha(newraw.encode())==profile_sha256 and profile_sha256!=OLD_PROFILE_SHA,'new_profile_hash')
 oldprofile,newprofile=profile(oldraw),profile(newraw)
 require(oldprofile['model'].get('default')==OLD_MODEL and newprofile['model'].get('default')==NEW_MODEL,'exact_model_transition')
 comparison=copy.deepcopy(newprofile);comparison['model']['default']=OLD_MODEL
 require(canonical(comparison)==canonical(oldprofile),'profile_semantics_not_model_only')
 revision=profile_sha256[:12]
 oldh,newh=before[hk],after[hk]
 annot='verdify.io/hermes-profile-revision';inventory='verdify.io/iris-inventory-revision'
 require(oldh['spec']['template']['metadata']['annotations'][annot]==OLD_PROFILE_SHA[:12],'old_hermes_profile_revision')
 require(newh['spec']['template']['metadata']['annotations'][annot]==revision,'new_hermes_profile_revision')
 require(oldh['spec']['template']['metadata']['annotations'][inventory]==newh['spec']['template']['metadata']['annotations'][inventory]==INVENTORY,'inventory_revision_changed')
 copyh=copy.deepcopy(newh);copyh['spec']['template']['metadata']['annotations'][annot]=OLD_PROFILE_SHA[:12];require(copyh==oldh,'hermes_other_change')
 require(newh['spec']['replicas']==1 and newh['spec']['strategy']['type']=='Recreate','single_gateway')
 require(newh['metadata']['annotations']['argocd.argoproj.io/sync-wave']=='20','hermes_wave')
 return {'old_model':OLD_MODEL,'new_model':NEW_MODEL,'old_profile_sha256':OLD_PROFILE_SHA,
         'new_profile_sha256':profile_sha256,'old_profile_revision':OLD_PROFILE_SHA[:12],
         'new_profile_revision':revision,'unchanged_inventory_revision':INVENTORY,
         'rendered_object_count':len(before),'unchanged_rendered_objects':len(before)-2,
         'profile_semantic_changes':['model.default'],'profile_comments_are_nonsemantic':True}
'''+text[z:]
text=text.replace("'main_revision','mcp_digest'","'main_revision','profile_sha256'")
text=text.replace("require(re.fullmatch('[0-9a-f]{64}',a.mcp_digest) is not None,'qualified_digest_shape')","require(re.fullmatch('[0-9a-f]{64}',a.profile_sha256) is not None,'profile_digest_shape')")
text=text.replace(")),a.mcp_digest)",")),a.profile_sha256)")
text=text.replace("'exact-three-resource-selective-plan-v2'","'exact-two-resource-model-selective-plan-v1'")
text=text.replace("'rollback_rule':'Use old source-owned SOUL/inventory/revision and old MCP release pin in a separate reviewed source revision. Reusing an old rendered hook/fullsync is forbidden; no deployment patch rollback is embedded.'","'rollback_rule':'Restore only the old source-owned model profile and matching profile revision in a separate reviewed source revision, preserving inventory5733 and the already accepted MCP pin. No full sync, hook, raw Deployment patch or automatic rollback is embedded.'")
assert 'a.mcp_digest' not in text
(d/'emit.py').write_text(text)
(d/'idle-ledger.sql').write_bytes((b/'deploy-plan-v2/idle-ledger.sql').read_bytes())
print(d,hashlib.sha256((d/'emit.py').read_bytes()).hexdigest())
