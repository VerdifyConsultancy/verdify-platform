import pathlib,json,hashlib,subprocess
b=pathlib.Path('/private/tmp/verdify-daytime-consumer-20261018');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();j=json.loads((b/'platform/actual-completion-bindings-01/completion-bindings.actual-draft.json').read_bytes())
for role,name,uid,rev,dirname,out in [
 ('historical_model_release_ci','verdify-platform-ci-dslbn','5422fa2a-2d13-405a-afb8-45fddcbca593','12e3cd6e01ee6e2e3a989ce2e78d2c9e30f09ffe','model-release-ci','model-release-ci-initial-verified.json'),
 ('model_release_ci','verdify-platform-ci-6l8w9','fd2e81ec-ac60-4525-be14-d02a056f0438','1f132f20eea07ab57c5d705a9bd626ac6fe72faf','model-release-ci-02','model-release-ci-verified.json'),
 ('final_report_ci','verdify-platform-ci-hp5dw','ee2a9d27-5236-426d-b39d-abe9f24b2f3e','af46d263352d6403201a4642378197e9ca00303c','report-ci','report-ci-verified.json')]:
 p=b/out;v=json.loads(p.read_bytes());assert v['status']=='DIRECT_TERMINAL_VALIDATE_ONLY_MAIN_CI_PASSED' and v['source_revision']==rev and v['workflow_uid']==uid
 j['roles'][role]={'path':out,'sha256':sha(p),'reviewed_by_root':True,'terminal':True,'outcome':'passed','terminal_indicator':{'field':['status'],'equals':v['status']},'assertions':[{'field':['source_revision'],'equals':rev},{'field':['workflow_uid'],'equals':uid},{'field':['actual_build_pods'],'equals':0}],'attempt_directories_to_include':[dirname]}
for group in [j['roles'].values(),j['additional_evidence'],j['workflow_evidence']]:
 for v in group:
  assert sha(b/v['path'])==v['sha256'];v['reviewed_by_root']=True
for n in ['acceptance-summary.json','prepare-final-custody-bindings.py','model-render-refusal-review.json','prepare-model-rollout-03.py','prepare-runtime-model-execution.py','prepare-runtime-model-execution-02.py','read-database-final-model.py','COORDINATOR_STATE.json','verify-final-remote-custody.py','install-custody-materials.py','ingress-readonly-01/public-metadata.json','final-application.json','final-live-status.json']:
 p=b/n;j['additional_evidence'].append({'path':n,'sha256':sha(p),'reviewed_by_root':True,'attempt_directories_to_include':[]})
j['additional_evidence'].append({'path':'control/ingress-source-scope.json','sha256':sha(b/'control/ingress-source-scope.json'),'reviewed_by_root':True,'attempt_directories_to_include':['ingress-readonly-01']})
j.update(status='READY_FOR_BINDING',selection_reviewed_by_root=True,all_attempts_included_reviewed_by_root=True);j.pop('pending_terminal_roles',None);p=b/'completion-bindings.final.json';p.open('x').write(json.dumps(j,indent=2)+'\n');print(sha(p))
