#!/usr/bin/env python3
"""Offline, single-source main delivery verifier. Never contacts Git, registry or cluster.

Run only after ROOT has captured the terminal workflow and each stage's terminal
Pod plus main log. Snapshot union preserves earlier Pods through 60-second GC.
Writes a NEW receipt, including all attempts/errors on failure; never edits inputs.
Only main logs are provided by the capture helper. Init/wait proof is metadata.
"""
import argparse
import datetime as dt
import hashlib
import json
import pathlib
import re
import sys

SOURCE = 'd298f1ecca8249a3898339045e69dc08e7a85ab1'
TREE = '28e904335de8e7d2837c0bfa8cb84d68bf2adb43'
WF = 'verdify-platform-ci-whvn7'
UID = 'a4330c3b-5c97-46c2-a886-b07d0da0b13c'
TEMPLATE_SHA = '42cd73d9876d207387c7daebebc719e7f64cec6830eb3bc3724513a19934444b'
STAGES = ['classify-push', 'build-mcp', 'build-ingestor', 'build-lab-publisher', 'pin-digests']
IMPACT = {'mode': 'build', 'api': 'false', 'mcp': 'true', 'ingestor': 'true', 'planner': 'false',
          'migrate': 'false', 'orchestrator': 'false', 'setpoint-server': 'false', 'lab-publisher': 'true'}
BUILDS = {
    'build-mcp': ('mcp/Dockerfile', 'verdifyconsultancy/verdify-mcp', '0fab57634ac98002857152bfb937eba86c0178e09658f8c5a03b12a71b1e2f2f'),
    'build-ingestor': ('ingestor/Dockerfile', 'verdifyconsultancy/verdify-ingestor', 'd5b56e49f594423d4b7666d9ae5c2f8fb75ebc9e9f8d5822861ac43fe8d0f3e4'),
    'build-lab-publisher': ('scripts/Dockerfile.lab-publisher', 'verdifyconsultancy/verdify-lab-publisher-k3s', '11ad799558c59aad901a5ae7e58f59098f658a780db1f842424211c2804ae670'),
}
LIMIT_DEFAULT = {'requests': {'cpu': '100m', 'memory': '128Mi'}, 'limits': {'cpu': '500m', 'memory': '512Mi'}}
DIGEST = re.compile(r'sha256:[0-9a-f]{64}')
STAMP = re.compile(r'^[0-9]{8}T[0-9]{12}Z-capture\.json$')


def sha(b):
    return hashlib.sha256(b).hexdigest()


def params(obj):
    items = obj.get('parameters', [])
    if len({x['name'] for x in items}) != len(items):
        raise ValueError('duplicate parameter name')
    return {x['name']: x.get('value') for x in items}


def time(value):
    return dt.datetime.fromisoformat(value.replace('Z', '+00:00'))


def subset(expected, observed):
    """Argo adds empty fields and inherited metadata; require every owner field."""
    if isinstance(expected, dict):
        return isinstance(observed, dict) and all(k in observed and subset(v, observed[k]) for k, v in expected.items())
    if isinstance(expected, list):
        return isinstance(observed, list) and len(expected) == len(observed) and all(subset(a, b) for a, b in zip(expected, observed))
    return expected == observed


def resolve(value, inputs):
    if isinstance(value, dict):
        return {k: resolve(v, inputs) for k, v in value.items()}
    if isinstance(value, list):
        return [resolve(v, inputs) for v in value]
    if isinstance(value, str):
        value = value.replace('{{workflow.uid}}', inputs['_workflow_uid']).replace('{{workflow.creationTimestamp}}', inputs['_workflow_creation_timestamp'])
        return re.sub(r'\{\{inputs\.parameters\.([^}]+)\}\}', lambda m: str(inputs[m[1]]), value)
    return value


class Check:
    def __init__(self, root, receipt):
        self.root, self.r, self.loaded = root, receipt, {}

    def ok(self, condition, message):
        if not condition:
            self.r['errors'].append(message)
        return bool(condition)

    def read(self, path, *, json_value=True):
        path = path.resolve()
        if path not in self.loaded:
            b = path.read_bytes()
            self.loaded[path] = b
            self.r['inputs'].append({'path': str(path), 'bytes': len(b), 'sha256': sha(b)})
        b = self.loaded[path]
        return json.loads(b) if json_value else b

    def log(self, row, pod_name):
        name = row.get('log_path')
        if not name:
            return None
        if not self.ok(pathlib.Path(name).name == name and name == f"{pod_name}-{row.get('log_sha256')}.main.log", 'unsafe or non-hash-addressed main log name'):
            return None
        b = self.read(self.root / name, json_value=False)
        if not self.ok(row.get('log_read_exit') == 0 and row.get('log_bytes') == len(b) and row.get('log_sha256') == sha(b), f'{pod_name}: main log length/hash/read failure'):
            return None
        return b


def verify(c, template_path, impact_path):
    r, root = c.r, c.root
    template = c.read(template_path)
    c.ok(sha(c.loaded[template_path.resolve()]) == TEMPLATE_SHA, 'owner main template bytes changed')
    expected_templates = {t['name']: t for t in template['spec']['templates']}
    c.ok(all(len(group) == 1 for group in expected_templates['main']['steps']), 'owner main stages are not serial')
    impact = c.read(impact_path)
    c.ok(impact.get('source') == SOURCE and impact.get('impact') == IMPACT, 'preselected main path-impact differs')
    captures = sorted(p for p in root.glob('*-capture.json') if STAMP.fullmatch(p.name))
    c.ok(bool(captures), 'no chronological capture sets')
    stamps = {p.name.removesuffix('-capture.json') for p in captures}
    c.ok({p.name.removesuffix('-workflow.private.json') for p in root.glob('*-workflow.private.json')} == stamps, 'orphan/missing chronological workflow snapshot')
    c.ok({p.name.removesuffix('-pods.private.json') for p in root.glob('*-pods.private.json')} == stamps, 'orphan/missing chronological Pod snapshot')
    nodes, pod_records, summaries, workflow_records, stored = {}, {}, {}, [], {}
    # Inventory every snapshot before interpreting terminal success. No latest-only shortcut.
    for cp in captures:
        stamp = cp.name.removesuffix('-capture.json')
        summary = c.read(cp)
        wf = c.read(root / (stamp + '-workflow.private.json'))
        pods = c.read(root / (stamp + '-pods.private.json'))
        c.ok(isinstance(pods, list), f'{stamp}: Pod snapshot is not a list')
        c.ok(summary.get('name') == WF and summary.get('uid') == UID, f'{stamp}: summary workflow identity')
        c.ok(wf['metadata'].get('name') == WF and wf['metadata'].get('uid') == UID and wf['metadata'].get('namespace') == 'agent-fleet-ci', f'{stamp}: raw workflow identity')
        c.ok(params(wf['spec'].get('arguments', {})).get('revision') == SOURCE, f'{stamp}: workflow source revision')
        c.ok(wf['spec'].get('workflowTemplateRef') == {'name': 'verdify-platform-ci'}, f'{stamp}: workflow template reference')
        c.ok(summary.get('phase') == wf.get('status', {}).get('phase'), f'{stamp}: summary/raw phase mismatch')
        workflow_records.append((stamp, wf))
        for key, n in wf.get('status', {}).get('nodes', {}).items():
            c.ok(n.get('id') == key, f'{stamp}: node key/id mismatch')
            nodes.setdefault(key, []).append((stamp, n))
        for key, value in wf.get('status', {}).get('storedTemplates', {}).items():
            if key in stored:
                c.ok(stored[key] == value, f'{stamp}: stored template changed within workflow: {key}')
            stored[key] = value
        by_uid = {p['metadata']['uid']: p for p in pods}
        c.ok(len(by_uid) == len(pods), f'{stamp}: duplicate Pod UID')
        summary_uids = [p.get('uid') for p in summary.get('pods', [])]
        c.ok(set(summary_uids) == set(by_uid) and len(summary_uids) == len(by_uid), f'{stamp}: summary/raw Pod set differs')
        for p in pods:
            uid = p['metadata']['uid']
            pod_records.setdefault(uid, []).append((stamp, p))
        for row in summary.get('pods', []):
            uid = row.get('uid')
            summaries.setdefault(uid, []).append((stamp, row))
            p = by_uid.get(uid)
            if p:
                c.ok(row.get('name') == p['metadata']['name'], f'{stamp}: summary Pod name mismatch')
                c.ok(row.get('phase') == p['status'].get('phase'), f'{stamp}: summary Pod phase mismatch')
                for group, key in [('init', 'initContainerStatuses'), ('containers', 'containerStatuses')]:
                    actual = [{k: x.get(k) for k in ['name', 'state', 'restartCount', 'imageID']} for x in p['status'].get(key, [])]
                    c.ok(row.get(group) == actual, f'{stamp}: summary {group} differs from raw Pod')
                c.log(row, p['metadata']['name'])  # hash every retained partial and terminal log
    r['snapshot_count'] = len(captures)
    r['workflow_policy_history'] = [{'capture': stamp, 'podGC': wf['spec'].get('podGC')} for stamp, wf in workflow_records]
    if not workflow_records:
        return
    final = workflow_records[-1][1]
    r['workflow'] = {k: final.get('status', {}).get(k) for k in ('phase', 'startedAt', 'finishedAt')}
    r['workflow']['name'], r['workflow']['uid'] = WF, UID
    r['last_capture'] = str(captures[-1])
    c.ok(final.get('status', {}).get('phase') == 'Succeeded' and bool(final.get('status', {}).get('finishedAt')), 'workflow is not terminal Succeeded')
    r['non_success_node_history'] = [
        {'id': key, 'type': n.get('type'), 'displayName': n.get('displayName'), 'phase': n.get('phase'), 'capture': stamp}
        for key, history in nodes.items() for stamp, n in history if n.get('phase') in ('Failed', 'Error', 'Omitted')
    ]
    r['workload_non_success_observed'] = any(x['phase'] in ('Failed', 'Error') for x in r['non_success_node_history']) or final.get('status', {}).get('phase') in ('Failed', 'Error')
    c.ok(not r['non_success_node_history'], 'workflow has retained failed/error/omitted node history')
    for name, expected in expected_templates.items():
        c.ok(subset(expected, stored.get('namespaced/verdify-platform-ci/' + name)), f'actual stored owner template differs: {name}')
    pod_nodes = {key: history for key, history in nodes.items() if any(n.get('type') == 'Pod' for _, n in history)}
    r['pod_node_count'] = len(pod_nodes)
    # Exact authenticated node-id annotation joins, never templateName or guessed Pod name.
    joins = {}
    for uid, history in pod_records.items():
        ids = set()
        for stamp, p in history:
            md = p['metadata']
            node_id = md.get('annotations', {}).get('workflows.argoproj.io/node-id')
            ids.add(node_id)
            c.ok(md.get('namespace') == 'agent-fleet-ci' and md.get('labels', {}).get('workflows.argoproj.io/workflow') == WF, f'{uid}: Pod namespace/workflow label')
            owners = [o for o in md.get('ownerReferences', []) if o.get('controller')]
            c.ok(len(owners) == 1 and owners[0].get('uid') == UID and owners[0].get('name') == WF and owners[0].get('kind') == 'Workflow', f'{uid}: Pod controller ownership')
        c.ok(len(ids) == 1 and None not in ids, f'{uid}: missing or changing node-id annotation')
        node_id = next(iter(ids))
        joins.setdefault(node_id, []).append(uid)
        c.ok(node_id in pod_nodes, f'{uid}: Pod has no retained type:Pod node')
    stage_rows = {}
    for node_id, history in pod_nodes.items():
        n = history[-1][1]
        stage = re.sub(r'\([0-9]+\)$', '', n.get('displayName', ''))
        row = {'node_id': node_id, 'stage': stage, 'displayName': n.get('displayName'),
               'phase_history': [{'capture': stamp, 'phase': x.get('phase')} for stamp, x in history],
               'startedAt': n.get('startedAt'), 'finishedAt': n.get('finishedAt'), 'phase': n.get('phase'), 'pods': []}
        r['attempts'].append(row)
        stage_rows.setdefault(stage, []).append(row)
        c.ok(stage in STAGES, f'{node_id}: unexpected executed stage {stage}')
        c.ok(n.get('phase') == 'Succeeded' and n.get('outputs', {}).get('exitCode') == '0' and bool(n.get('finishedAt')), f'{node_id}: node not terminal success/exit0')
        c.ok(all(x.get('type') == 'Pod' for _, x in history), f'{node_id}: node type changed')
        c.ok(len(joins.get(node_id, [])) == 1, f'{node_id}: expected exactly one retained Pod UID')
        inputs, outputs = params(n.get('inputs', {})), params(n.get('outputs', {}))
        resolved_inputs = dict(inputs, _workflow_uid=UID, _workflow_creation_timestamp=final['metadata']['creationTimestamp'])
        c.ok(inputs.get('revision') == SOURCE, f'{stage}: node input source')
        if stage in BUILDS:
            c.ok(n.get('templateRef') == {'name': 'repo-build', 'template': 'build'}, f'{stage}: repo-build templateRef')
            actual_template = stored.get('namespaced/repo-build/build', {})
        else:
            actual_template = stored.get('namespaced/verdify-platform-ci/' + ('validate' if stage == 'classify-push' else stage), {})
        main_log = None
        for pod_uid in joins.get(node_id, []):
            ph = pod_records[pod_uid]
            terminal = [(stamp, p) for stamp, p in ph if p['status'].get('phase') in ('Succeeded', 'Failed')]
            p = terminal[-1][1] if terminal else ph[-1][1]
            pr = {'uid': pod_uid, 'name': p['metadata']['name'], 'phase': p['status'].get('phase'),
                  'node': p['spec'].get('nodeName'), 'terminal_capture': terminal[-1][0] if terminal else None,
                  'phase_history': [{'capture': stamp, 'phase': snap['status'].get('phase')} for stamp, snap in ph],
                  'containers': [], 'terminal_main_logs': []}
            row['pods'].append(pr)
            if any(snap['status'].get('phase') == 'Failed' for _, snap in ph):
                r['workload_non_success_observed'] = True
            c.ok(all(snap['status'].get('phase') != 'Failed' for _, snap in ph), f'{pod_uid}: prior failed Pod phase')
            expected_init_names = {x['name'] for x in actual_template.get('initContainers', [])}
            c.ok(expected_init_names.issubset({x['name'] for x in p['spec'].get('initContainers', [])}), f'{pod_uid}: owning-template init container missing')
            if not terminal:
                r['evidence_gaps'].append({'node_id': node_id, 'pod_uid': pod_uid, 'missing': 'terminal Pod and complete init/main/wait statuses', 'latest_captured_phase': p['status'].get('phase')})
            c.ok(bool(terminal) and p['status'].get('phase') == 'Succeeded', f'{pod_uid}: no retained successful terminal Pod')
            fixed_spec = {k: v for k, v in ph[0][1]['spec'].items() if k != 'nodeName'}
            c.ok(all({k: v for k, v in x['spec'].items() if k != 'nodeName'} == fixed_spec for _, x in ph), f'{pod_uid}: Pod spec changed beyond scheduler node assignment')
            assigned_nodes = {x['spec']['nodeName'] for _, x in ph if x['spec'].get('nodeName')}
            c.ok(len(assigned_nodes) == 1 and p['spec'].get('nodeName') in assigned_nodes, f'{pod_uid}: missing/changing node assignment')
            for spec_key, status_key in [('initContainers', 'initContainerStatuses'), ('containers', 'containerStatuses')]:
                declared = p['spec'].get(spec_key, [])
                statuses = p['status'].get(status_key, [])
                c.ok({x['name'] for x in declared} == {x['name'] for x in statuses} and len(declared) == len(statuses), f'{pod_uid}: {status_key} cardinality')
                for container in declared:
                    name = container['name']
                    states = [s for _, snap in ph for s in snap['status'].get(status_key, []) if s['name'] == name]
                    s = next((s for s in statuses if s['name'] == name), {})
                    term = s.get('state', {}).get('terminated', {})
                    cr = {'name': name, 'group': spec_key, 'image': container.get('image'), 'imageID': s.get('imageID'),
                          'resources': container.get('resources', {}), 'terminal': term, 'restart_counts': sorted({x.get('restartCount', -1) for x in states})}
                    pr['containers'].append(cr)
                    c.ok(bool(term) and term.get('exitCode') == 0 and bool(term.get('finishedAt')), f'{pod_uid}/{name}: terminal exit not zero')
                    if any(x.get('state', {}).get('terminated', {}).get('exitCode', 0) != 0 for x in states):
                        r['workload_non_success_observed'] = True
                    c.ok(all(x.get('state', {}).get('terminated', {}).get('exitCode', 0) == 0 for x in states), f'{pod_uid}/{name}: prior nonzero terminal status')
                    c.ok(bool(states) and all(s.get('restartCount') == 0 and not s.get('lastState', {}).get('terminated') for s in states), f'{pod_uid}/{name}: restart/previous termination history')
                    image_id = s.get('imageID', '')
                    observed = DIGEST.findall(image_id)
                    c.ok(len(observed) == 1, f'{pod_uid}/{name}: missing immutable observed imageID')
                    declared_digest = DIGEST.findall(container.get('image', ''))
                    if declared_digest:
                        c.ok(declared_digest == observed, f'{pod_uid}/{name}: requested/observed image digest mismatch')
                    expected_c = actual_template.get('container') if name == 'main' else next((x for x in actual_template.get('initContainers', []) if x.get('name') == name), None)
                    if expected_c:
                        c.ok(container.get('image') == resolve(expected_c['image'], resolved_inputs), f'{pod_uid}/{name}: stored-template image differs')
                        resources = resolve(expected_c.get('resources', {}), resolved_inputs) or LIMIT_DEFAULT
                        # The owning repo-build podSpecPatch replaces these two profiles.
                        if stage in BUILDS and name in ('test', 'kaniko-build'):
                            prefix = 'test' if name == 'test' else 'kaniko'
                            resources = {'requests': {'cpu': inputs[prefix + '_cpu_request'], 'memory': inputs[prefix + '_memory_request']},
                                         'limits': {'cpu': inputs[prefix + '_cpu_limit'], 'memory': inputs[prefix + '_memory_limit']}}
                            if name == 'kaniko-build':
                                resources['requests']['ephemeral-storage'] = inputs['kaniko_ephemeral_request']
                                resources['limits']['ephemeral-storage'] = inputs['kaniko_ephemeral_limit']
                        c.ok(container.get('resources', {}) == resources, f'{pod_uid}/{name}: owning effective resource profile differs')
                        expected_command = resolve(expected_c.get('command', []), resolved_inputs)
                        command = container.get('command', [])
                        if command and command[0] == '/var/run/argo/argoexec':
                            c.ok('--' in command, f'{pod_uid}/{name}: missing emissary separator')
                            command = command[command.index('--') + 1:] if '--' in command else []
                        c.ok(command == expected_command and container.get('args', []) == resolve(expected_c.get('args', []), resolved_inputs), f'{pod_uid}/{name}: stored-template command/args differ')
                        for env in resolve(expected_c.get('env', []), resolved_inputs):
                            actual_env = [e for e in container.get('env', []) if e.get('name') == env['name']]
                            c.ok(actual_env == [env], f'{pod_uid}/{name}: owner environment binding differs: ' + env['name'])
            c.ok({'main', 'wait'}.issubset({x['name'] for x in p['spec'].get('containers', [])}), f'{pod_uid}: main/wait absent')
            for stamp, summary in summaries.get(pod_uid, []):
                sm = next((x for x in summary.get('containers', []) if x['name'] == 'main'), {})
                if sm.get('state', {}).get('terminated') and summary.get('log_path') and summary.get('log_read_exit') == 0:
                    b = c.log(summary, pr['name'])
                    if b is not None:
                        pr['terminal_main_logs'].append({'capture': stamp, 'path': summary['log_path'], 'bytes': len(b), 'sha256': sha(b)})
                        main_log = b
            if not pr['terminal_main_logs']:
                r['evidence_gaps'].append({'node_id': node_id, 'pod_uid': pod_uid, 'missing': 'complete main log bound to main termination', 'retained_partial_log_count': sum(bool(s.get('log_path')) for _, s in summaries.get(pod_uid, []))})
            c.ok(bool(pr['terminal_main_logs']), f'{pod_uid}: no hash-bound main log captured after main termination')
        if stage == 'classify-push':
            c.ok(inputs.get('classify-push') == 'true', 'validation was not main path classification')
            c.ok(inputs.get('base-revision') == params(final['spec'].get('arguments', {})).get('before-revision'), 'validation base revision differs from triggering main before-revision')
            c.ok(all(outputs.get(k) == v for k, v in IMPACT.items()), 'actual classification does not equal three selected images')
            receipt = json.loads(outputs.get('path-impact-receipt', '{}'))
            c.ok(receipt.get('schema') == 'verdify.path-impact/v1' and receipt.get('source_revision') == SOURCE and receipt.get('mode') == 'build', 'path-impact source/schema')
            c.ok(receipt.get('base_revision') == inputs.get('base-revision'), 'path-impact base revision differs')
            c.ok(receipt.get('profiles') == ['mcp', 'ingestor', 'lab-publisher'], 'path-impact profiles differ')
            r['path_impact'] = receipt
            c.ok(main_log is not None and re.search(rb'(?m)^ALL GATES GREEN\r?$', main_log) is not None, 'terminal validation log lacks ALL GATES GREEN')
            r['all_gates_green'] = main_log is not None and re.search(rb'(?m)^ALL GATES GREEN\r?$', main_log) is not None
        elif stage in BUILDS:
            dockerfile, image, docker_sha = BUILDS[stage]
            expected_inputs = {'repo': 'https://github.com/VerdifyConsultancy/verdify-platform.git', 'revision': SOURCE,
                'dockerfile': dockerfile, 'context': '.', 'image': image, 'test': '', 'docker_target': '',
                'allowed_publish_scopes': 'verdifyconsultancy', 'kaniko_memory_limit': '4Gi', 'kaniko_ephemeral_limit': '40Gi',
                'build_arg_1_name': '' if stage == 'build-lab-publisher' else 'GIT_SHA',
                'build_arg_1_value': '' if stage == 'build-lab-publisher' else SOURCE, 'build_arg_2_name': '', 'build_arg_2_value': ''}
            c.ok(all(inputs.get(k) == v for k, v in expected_inputs.items()), f'{stage}: build inputs differ')
            expected_outputs = {'source-revision': SOURCE, 'resolved-revision': SOURCE, 'resolved-tree': TREE,
                'source-url': 'https://github.com/VerdifyConsultancy/verdify-platform', 'short-sha': SOURCE[:12],
                'output-contract-version': 'agent-fleet.repo-build.outputs/2', 'dockerfile-sha256': 'sha256:' + docker_sha}
            c.ok(all(outputs.get(k) == v for k, v in expected_outputs.items()), f'{stage}: source/tree/build output contract differs')
            digest = outputs.get('digest', '')
            c.ok(bool(DIGEST.fullmatch(digest)) and outputs.get('image-ref') == 'registry.vallery.net/' + image + '@' + digest, f'{stage}: artifact digest/image-ref mismatch')
            c.ok(json.loads(outputs.get('source-closure', '{}')) == {'schema': 'agent-fleet.vallery.net/repo-build-source-closure/v4', 'image': image, 'status': 'not-applicable'}, f'{stage}: source-closure scope changed')
            c.ok(outputs.get('source-released-at') == final['metadata']['creationTimestamp'], f'{stage}: source release time differs from workflow source timestamp')
            r['build_outputs'][stage] = outputs
        elif stage == 'pin-digests':
            r['pin_inputs'] = inputs
            text = main_log.decode('utf-8', errors='strict') if main_log is not None else ''
            if 'Skipping superseded release:' in text:
                outcome = 'SUPERSEDED_NO_PIN'
            elif 'digests unchanged (e.g. deploy-only push rebuilt identical images); nothing to pin' in text:
                outcome = 'UNCHANGED_NO_PIN'
            elif re.search(r'(?m)^.*[0-9a-f]{7,40}\.\.[0-9a-f]{7,40}\s+HEAD -> main\s*$', text) and f'gitops(pin): verdify images {SOURCE[:12]} -> zot digests sha256:' in text:
                outcome = 'PUSH_REPORTED_GIT_DIFF_NOT_YET_INDEPENDENTLY_VERIFIED'
            else:
                outcome = 'UNPROVEN_PIN_OUTCOME'
            r['pin_outcome'] = outcome
            c.ok(outcome == 'PUSH_REPORTED_GIT_DIFF_NOT_YET_INDEPENDENTLY_VERIFIED', 'pin source was superseded/unchanged or push outcome is not proven')
    for stage in STAGES:
        c.ok(len(stage_rows.get(stage, [])) == 1, f'{stage}: not exactly one executed attempt; all attempts retained')
    if all(len(stage_rows.get(stage, [])) == 1 for stage in STAGES):
        ordered = [stage_rows[s][0] for s in STAGES]
        for previous, following in zip(ordered, ordered[1:]):
            c.ok(bool(previous.get('finishedAt')) and bool(following.get('startedAt')) and time(previous['finishedAt']) <= time(following['startedAt']), f"non-serial stage times: {previous['stage']} -> {following['stage']}")
    expected_pin = {'revision': SOURCE, 'api-ref': '', 'migrate-ref': '', 'orchestrator-ref': '',
                    'mcp-ref': r['build_outputs'].get('build-mcp', {}).get('image-ref'),
                    'ingestor-ref': r['build_outputs'].get('build-ingestor', {}).get('image-ref')}
    c.ok(r.get('pin_inputs') == expected_pin and all(expected_pin[k] for k in ('mcp-ref', 'ingestor-ref')), 'pin input vector must select only actual MCP and ingestor outputs')
    r['expected_candidate_changes'] = ['mcp', 'ingestor']
    r['published_not_promoted'] = ['mcp', 'ingestor', 'lab-publisher']


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--capture-dir', type=pathlib.Path, required=True)
    ap.add_argument('--template', type=pathlib.Path, default=pathlib.Path('/private/tmp/verdify-s3b-main-template.json'))
    ap.add_argument('--impact', type=pathlib.Path, default=pathlib.Path('/Users/jason/maintenance/verdify-s3b-execution-20261018/main-impact-readback.json'))
    ap.add_argument('--output', type=pathlib.Path, required=True, help='NEW private JSON file; existing output is never overwritten')
    args = ap.parse_args()
    r = {'schema': 'verdify.s3b.main-delivery-offline/v1', 'status': 'EVIDENCE_INCOMPLETE_OR_CONTRACT_MISMATCH',
         'checked_at': dt.datetime.now(dt.timezone.utc).isoformat(), 'expected_source': SOURCE, 'expected_tree': TREE,
         'verifier_sha256': sha(pathlib.Path(__file__).read_bytes()), 'inputs': [], 'attempts': [], 'errors': [], 'evidence_gaps': [], 'build_outputs': {},
         'workload_non_success_observed': False, 'reader_exception': None,
         'limits': {'native_execution': False, 'registry_readback': False, 'candidate_git_diff_verified': False,
                    'release_pins_unchanged_verified': False, 'production_lab_handpin_unchanged_verified': False,
                    'live_state_verified': False, 'production_deployment_claimed': False,
                    'verification_errors_do_not_relabel_workflow_or_workload': True,
                    'same_tree_pr_cannot_substitute_main_terminal_metadata': True, 'init_and_wait_logs_available': False, 'main_logs_and_all_container_metadata_only': True}}
    # Reserve output before reading; a previous failure/success can never be replaced.
    with args.output.open('x', encoding='utf-8') as output:
        try:
            verify(Check(args.capture_dir.resolve(), r), args.template, args.impact)
        except Exception as exc:
            # No raw exception/log/command strings: retained inputs carry complete evidence.
            r['reader_exception'] = type(exc).__name__
            r['errors'].append('offline verification exception: ' + type(exc).__name__)
        if r['reader_exception']:
            r['status'] = 'OFFLINE_READER_ERROR_NO_WORKLOAD_CONCLUSION'
        elif r['workload_non_success_observed']:
            r['status'] = 'WORKLOAD_NON_SUCCESS_OBSERVED'
        elif not r['errors']:
            r['status'] = 'MAIN_CI_AND_THREE_IMAGE_OUTPUTS_VERIFIED_GIT_AND_LIVE_CHECKS_SEPARATE'
        output.write(json.dumps(r, indent=2, sort_keys=True) + '\n')
        output.flush()
    print(json.dumps({'status': r['status'], 'errors': r['errors'], 'receipt': str(args.output),
                      'receipt_sha256': sha(args.output.read_bytes())}, indent=2))
    return 0 if not r['errors'] else 1


if __name__ == '__main__':
    sys.exit(main())
