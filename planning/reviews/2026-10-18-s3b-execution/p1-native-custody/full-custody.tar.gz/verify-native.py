#!/usr/bin/env python3
"""Offline-only P1 native custody verification; never submits or retries work.

Inputs are immutable ROOT captures and independently reviewed source manifests.
Creates one NEW output directory. Failed original records are never rewritten.
"""

import argparse
import base64
import binascii
import hashlib
import json
import math
import re
from datetime import datetime
from pathlib import Path, PurePosixPath

VARIANTS = ("original", "deleted_consumer", "inverted_consumer")
MARKERS = {"process_result", "artifact", "artifact_manifest", "qualification_result"}
HEX = re.compile(r"[0-9a-f]{64}\Z")
ADMITTED_SOURCE = "e844a40976068e93b52420e2d536eb230078ec5c"


def need(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        need(key not in result, "duplicate JSON key")
        result[key] = value
    return result


def decode_json(raw):
    return json.loads(raw, object_pairs_hook=unique_object)


def read(path, cap=64 * 1024 * 1024):
    need(path.is_file() and path.stat().st_size <= cap, f"missing or oversized input: {path.name}")
    return path.read_bytes()


def safe_path(value):
    need(isinstance(value, str) and value and "\\" not in value and "\0" not in value, "invalid artifact path")
    parts = PurePosixPath(value)
    need(not parts.is_absolute() and all(x not in (".", "..", "") for x in value.split("/")), "unsafe artifact path")
    need(parts.as_posix() == value, "noncanonical artifact path")
    return value


def verify_log(raw, extraction, plan, expected_source, out):
    artifacts, entries, events = {}, {}, []
    final_manifests, results = [], []
    total = 0
    phase = "processes"
    for line in raw.splitlines():
        stripped = line.strip()
        if not stripped.startswith(b"{"):
            need(not any(('"' + key + '"').encode() in line for key in MARKERS), "prefixed or truncated custody record")
            continue
        try:
            item = decode_json(stripped)
        except (ValueError, UnicodeDecodeError) as exc:
            raise ValueError("malformed JSON log line") from exc
        if not isinstance(item, dict) or not MARKERS.intersection(item):
            continue
        if "process_result" in item:
            need(set(item) == {"process_result"} and phase == "processes", "unexpected process record ordering")
            events.append(item["process_result"])
        elif "artifact" in item:
            need(set(item) == {"artifact", "base64"} and phase in ("processes", "artifacts"), "unexpected artifact ordering")
            phase = "artifacts"
            entry = item["artifact"]
            need(set(entry) == {"path", "bytes", "sha256"}, "unexpected artifact descriptor")
            name = safe_path(entry["path"])
            need(name not in artifacts and isinstance(entry["bytes"], int) and entry["bytes"] >= 0, "duplicate/invalid artifact")
            need(isinstance(entry["sha256"], str) and HEX.fullmatch(entry["sha256"]), "invalid artifact hash")
            try:
                data = base64.b64decode(item["base64"], validate=True)
            except (binascii.Error, ValueError, TypeError) as exc:
                raise ValueError("invalid artifact base64") from exc
            need(len(data) == entry["bytes"] and sha(data) == entry["sha256"], "artifact byte/hash mismatch")
            total += len(data)
            need(total <= 16 * 1024 * 1024, "decoded custody exceeds 16 MiB")
            target = out / "artifacts" / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
            artifacts[name], entries[name] = data, entry
        elif "artifact_manifest" in item:
            need(set(item) == {"artifact_manifest"} and phase == "artifacts", "missing/duplicate manifest")
            phase = "manifest"
            final_manifests.append(item["artifact_manifest"])
        elif "qualification_result" in item:
            need(set(item) == {"qualification_result"} and phase == "manifest", "missing/duplicate final result")
            phase = "result"
            results.append(item["qualification_result"])
    need(phase == "result" and len(final_manifests) == len(results) == 1, "incomplete artifact/result stream")
    need(final_manifests[0] == [entries[name] for name in sorted(entries)], "full artifact manifest differs from emitted files")
    need("receipt.json" in artifacts and "process-results.json" in artifacts, "missing required result artifact")
    receipt = decode_json(artifacts["receipt.json"])
    records = decode_json(artifacts["process-results.json"])
    need(receipt == results[0], "final receipt differs from retained receipt")
    need(records == events, "retained process results differ from emitted records")
    need(receipt.get("format") == "verdify-fog-vent-native-v1" and receipt.get("status") == "PASSED", "native receipt did not pass")
    need("failure" not in receipt and receipt.get("expected_source") == expected_source, "failed or wrong-source receipt")
    expected_receipt = {
        "deadline_s": 600, "original_expected": 56, "negative_expected": 8,
        "original_passed": 56, "negative_completed": 8, "process_count": 74,
        "firmware_changed": False, "physical_acceptance": False, "device_or_database_calls": 0,
        "corpus_prefix_coverage": "27/48 UNPROVEN; no row-wise credit added",
    }
    for key, value in expected_receipt.items():
        need(receipt.get(key) == value, f"receipt mismatch: {key}")
    need(isinstance(receipt.get("platform"), str) and receipt["platform"].startswith("Linux"), "native platform is not Linux")
    need(isinstance(receipt.get("python"), str) and receipt["python"], "missing Python provenance")
    need(len(records) == 74 and len({r["name"] for r in records}) == 74, "missing/duplicate process inventory")
    for record in records:
        need(record.get("timed_out") is False, "process timeout retained; cannot qualify")
        elapsed = record.get("elapsed_s")
        need(isinstance(elapsed, (int, float)) and math.isfinite(elapsed) and elapsed >= 0, "invalid process elapsed time")
        for stream in ("stdout", "stderr"):
            data = artifacts.get(f"{record['name']}.{stream}")
            need(data is not None and len(data) == record[f"{stream}_bytes"] and sha(data) == record[f"{stream}_sha256"], "process output custody mismatch")
    need(sum(r["elapsed_s"] for r in records) <= 600, "process time exceeds native overall bound")
    by_name = {r["name"]: r for r in records}
    compiler = receipt["compiler"]
    need(compiler["path"].startswith("/") and compiler["resolved_path"].startswith("/") and HEX.fullmatch(compiler["sha256"]), "missing compiler binary provenance")
    meta = {
        "source-head": ["git", "rev-parse", "HEAD"],
        "source-status": ["git", "status", "--porcelain", "--untracked-files=no"],
        "compiler-version": [compiler["path"], "--version"],
        "compiler-target": [compiler["path"], "-dumpmachine"],
        **{f"compiler-program-{name}": [compiler["path"], f"-print-prog-name={name}"] for name in ("cc1plus", "as", "ld")},
    }
    for name, command in meta.items():
        need(by_name[name]["command"] == command and by_name[name]["returncode"] == 0, "metadata command failed/mismatched")
        need(not artifacts[f"{name}.stderr"], "metadata command stderr requires review")
        if name != "source-status":
            need(bool(artifacts[f"{name}.stdout"]), "empty metadata provenance")
    need(artifacts["source-head.stdout"] == (expected_source + "\n").encode(), "actual checkout head mismatch")
    need(artifacts["source-status.stdout"] == b"", "tracked source was modified")
    programs = receipt["compiler_programs"]
    need([r["name"] for r in programs] == ["cc1plus", "as", "ld"], "compiler program inventory mismatch")
    need(all(r["path"].startswith("/") and HEX.fullmatch(r["sha256"]) for r in programs), "invalid compiler program hash")
    # Independently supplied source manifests, never declarations only from the log.
    source_rows = extraction["source_files"]
    need(len({r["path"] for r in source_rows}) == len(source_rows), "duplicate expected source path")
    expected_inputs = {r["path"]: r["sha256"] for r in source_rows}
    extra = (
        "scripts/fog_vent_consumer.py", "scripts/qualify_fog_vent_consumer.py",
        "tests/fixtures/fog_vent_consumer.cpp.in", "tests/test_fog_vent_consumer.py",
    )
    for path in extra:
        expected_inputs[path] = plan["source_inputs_sha256"][path]
    for path, expected_hash in expected_inputs.items():
        data = artifacts.get("source-inputs/" + safe_path(path))
        need(data is not None and sha(data) == expected_hash, "actual source-input bytes differ from ROOT manifest")
    scenarios, selections, negatives = extraction["scenario_names"], extraction["selection_modes"], extraction["negative_witnesses"]
    need(len(scenarios) == 28 and len(set(scenarios)) == 28, "expected 28 distinct scenarios")
    need(selections == ["snapshot", "legacy"] and negatives == ["gate_true_open_close", "gate_true_open_open"], "scenario selection inventory drift")
    base_manifest = {k: v for k, v in extraction.items() if k not in {"state", "source_base", "generated_variants"}}
    expected_order = list(meta)
    binary_rows = receipt["binary_artifacts"]
    need([r["variant"] for r in binary_rows] == list(VARIANTS), "binary variant inventory mismatch")
    native_root, native_out = None, None
    for variant, binary_row in zip(VARIANTS, binary_rows, strict=True):
        need(binary_row["bytes"] > 0 and HEX.fullmatch(binary_row["sha256"]), "invalid fixture binary custody")
        need(binary_row["retention"] == "digest only; nondeployable native fixture", "unexpected binary retention")
        cpp = artifacts[f"{variant}.cpp"]
        need(sha(cpp) == extraction["generated_variants"][variant], "generated C++ differs from reviewed source")
        expected_manifest = dict(base_manifest, variant=variant, source_commit=expected_source,
                                 template_sha256=expected_inputs["tests/fixtures/fog_vent_consumer.cpp.in"],
                                 generated_cpp_sha256=sha(cpp))
        need(decode_json(artifacts[f"{variant}.source-manifest.json"]) == expected_manifest, "native fragment/source manifest mismatch")
        name = f"compile-{variant}"
        command = by_name[name]["command"]
        need(len(command) == 8 and command[:4] == [compiler["path"], "-std=c++17", "-O0", "-I"] and command[6] == "-o", "unexpected compile command")
        need(command[4].endswith("/firmware/lib") and command[5].endswith(f"/{variant}.cpp") and command[7].endswith(f"/{variant}.bin"), "compile path mismatch")
        current_root, current_out = command[4][:-len("/firmware/lib")], str(PurePosixPath(command[5]).parent)
        need(current_root.startswith("/") and current_out.startswith("/"), "native paths must be absolute")
        if native_root is None:
            native_root, native_out = current_root, current_out
        need((current_root, current_out) == (native_root, native_out), "native source/output path changed")
        need(command[7] == f"{native_out}/{variant}.bin" and by_name[name]["returncode"] == 0, "compile failed or binary path changed")
        expected_order.append(name)
        for scenario in scenarios if variant == "original" else negatives:
            for selection in selections:
                name = f"{variant}-{scenario}-{selection}"
                expected_order.append(name)
                expected_code = 0 if variant == "original" else 1
                record = by_name[name]
                need(record["command"] == [f"{native_out}/{variant}.bin", scenario, selection], "scenario command mismatch")
                need(record["returncode"] == expected_code, "wrong scenario exit")
                need(artifacts[f"{name}.stdout"] == f"SCENARIO_COMPLETE name={scenario} selection={selection} exit={expected_code}\n".encode(), "missing exact scenario completion")
                stderr = artifacts[f"{name}.stderr"]
                if expected_code:
                    need(re.fullmatch(rb"BEHAVIOR_ASSERT selected_consumer_request line=\d+\n", stderr), "causal negative failed for wrong behavior")
                else:
                    need(stderr == b"", "positive scenario stderr")
    need([r["name"] for r in records] == expected_order, "process order or exact inventory differs")
    expected_artifacts = {"receipt.json", "process-results.json"}
    expected_artifacts.update("source-inputs/" + p for p in expected_inputs)
    expected_artifacts.update(f"{v}.{suffix}" for v in VARIANTS for suffix in ("cpp", "source-manifest.json"))
    expected_artifacts.update(f"{name}.{stream}" for name in expected_order for stream in ("stdout", "stderr"))
    need(set(artifacts) == expected_artifacts, "missing/unexpected artifact, including any retained binary")
    return {"status": "NATIVE_CONTENT_VERIFIED", "source_revision": expected_source,
            "artifact_count": len(artifacts), "decoded_bytes": total, "process_count": 74,
            "compiles": 3, "positive_completions": 56, "exact_causal_negative_completions": 8,
            "timeouts": 0, "receipt_sha256": sha(artifacts["receipt.json"]),
            "artifact_manifest_sha256": sha(json.dumps(final_manifests[0], sort_keys=True, separators=(",", ":")).encode()),
            "source_input_files": len(expected_inputs), "native_root": native_root,
            "toolchain_and_fixture_binary_hash_scope": "Reported by the source-bound native driver; binary bytes were not emitted or independently rehashed offline"}


def verify_outer(capture_dir, log_path, raw, source, image, workflow_uid, pod_uid, expected_check, plan):
    capture_bytes = read(capture_dir / "capture-latest.json")
    capture = decode_json(capture_bytes)
    need(capture["uid"] == workflow_uid and capture["phase"] == "Succeeded", "workflow is not the expected successful terminal")
    stamp = datetime.fromisoformat(capture["at"]).strftime("%Y%m%dT%H%M%S%fZ")
    workflow_bytes = read(capture_dir / f"{stamp}-workflow.private.json")
    pods_bytes = read(capture_dir / f"{stamp}-pods.private.json")
    workflow, pods = decode_json(workflow_bytes), decode_json(pods_bytes)
    need(workflow["metadata"]["uid"] == workflow_uid and workflow["metadata"]["name"] == capture["name"], "raw workflow identity mismatch")
    need(workflow["kind"] == "Workflow" and workflow["status"]["phase"] == "Succeeded" and workflow["status"].get("finishedAt"), "raw workflow not terminal successful")
    pod_nodes = [n for n in workflow["status"]["nodes"].values() if n.get("type") == "Pod"]
    need(pod_nodes and all(n.get("phase") == "Succeeded" for n in pod_nodes), "type:Pod workflow node incomplete/failed")
    # This admitted workflow contains one check and three orchestration Pods.
    # Retain/check every attempt, including any failed retry node; no last-only view.
    need(sorted(n.get("templateName", "") for n in pod_nodes)
         == ["conclusion", "enforce-conclusion", "prepare", "run-check"],
         "unexpected or duplicate native attempt/orchestration Pod")
    need(len({p["metadata"]["uid"] for p in pods}) == len(pods), "duplicate captured Pod")
    # Argo v2 Pod names include the template name; the node-id annotation is
    # the authoritative binding to status.nodes, not equality of Pod and node names.
    pod_node_ids = [p["metadata"].get("annotations", {}).get("workflows.argoproj.io/node-id") for p in pods]
    need(len(set(pod_node_ids)) == len(pod_node_ids) and None not in pod_node_ids,
         "missing/duplicate Pod node-id annotations")
    need({n["id"] for n in pod_nodes} == set(pod_node_ids), "missing/unexpected type:Pod workflow custody")
    selected = [p for p in pods if p["metadata"]["uid"] == pod_uid]
    need(len(selected) == 1, "exact native Pod missing")
    for pod in pods:
        owners = [o for o in pod["metadata"].get("ownerReferences", []) if o.get("controller") is True]
        need(len(owners) == 1 and owners[0]["uid"] == workflow_uid and owners[0]["kind"] == "Workflow", "Pod controller mismatch")
        need(pod["status"]["phase"] == "Succeeded" and pod["spec"].get("nodeName"), "Pod not terminal/scheduled")
        for definitions, statuses in (("initContainers", "initContainerStatuses"), ("containers", "containerStatuses")):
            desired = [c["name"] for c in pod["spec"].get(definitions, [])]
            actual = pod["status"].get(statuses, [])
            need(len(actual) == len(desired) and {c["name"] for c in actual} == set(desired), "missing container terminal status")
            for status in actual:
                terminal = status.get("state", {}).get("terminated", {})
                need(status.get("restartCount") == 0 and terminal.get("exitCode") == 0 and terminal.get("finishedAt"), "init/main/wait nonzero/restarted/incomplete")
        need({"main", "wait"} <= {c["name"] for c in pod["status"]["containerStatuses"]}, "missing main/wait status")
    pod = selected[0]
    node_id = pod["metadata"]["annotations"]["workflows.argoproj.io/node-id"]
    node = next(n for n in pod_nodes if n["id"] == node_id)
    need(node.get("templateName") == "run-check", "selected Pod is not the single native check")
    outputs = [p for p in node.get("outputs", {}).get("parameters", []) if p.get("name") == "result"]
    need(len(outputs) == 1, "missing/duplicate command result parameter")
    command_result = decode_json(outputs[0]["value"])
    need(command_result.get("name") == expected_check and type(command_result.get("exit_code")) is int
         and command_result["exit_code"] == 0, "native command result failed even if wrapper exited zero")
    summary = [p for p in capture["pods"] if p["uid"] == pod_uid]
    need(len(summary) == 1 and summary[0]["name"] == pod["metadata"]["name"], "capture summary Pod mismatch")
    summary = summary[0]
    need(summary["log_read_exit"] == 0 and summary["log_bytes"] == len(raw) and summary["log_sha256"] == sha(raw), "full main log capture mismatch")
    need((capture_dir / safe_path(summary["log_path"])).resolve() == log_path.resolve(), "wrong hash-addressed log selected")
    main_spec = next(c for c in pod["spec"]["containers"] if c["name"] == "main")
    main = next(c for c in pod["status"]["containerStatuses"] if c["name"] == "main")
    bounds = plan["bounds"]
    expected_resources = {
        "requests": {"cpu": bounds["cpu_request"], "memory": bounds["memory_request"], "ephemeral-storage": "4Gi"},
        "limits": {"cpu": bounds["cpu_limit"], "memory": bounds["memory_limit"], "ephemeral-storage": "12Gi"},
    }
    need(main_spec.get("resources") == expected_resources, "native resources differ from admitted profile")
    wait_spec = next(c for c in pod["spec"]["containers"] if c["name"] == "wait")
    wait_status = next(c for c in pod["status"]["containerStatuses"] if c["name"] == "wait")
    need(main_spec["image"] == image, "submitted native image differs from expected digest")
    need(main.get("imageID", "").removeprefix("docker-pullable://") == image
         or main.get("imageID", "").removeprefix("containerd://") == image.split("@")[-1], "actual native imageID differs from expected digest")
    # Bind the source requested by the workflow as well as the driver's git output.
    params = workflow["spec"].get("arguments", {}).get("parameters", [])
    checks_params = [p for p in params if p.get("name") == "checks_json"]
    need(len(checks_params) == 1, "missing/duplicate checks_json parameter")
    checks = decode_json(checks_params[0]["value"])
    need(isinstance(checks, list) and len(checks) == 1 and checks[0].get("name") == expected_check,
         "workflow declared extra or different check")
    if "image" in checks[0]:
        need(checks[0]["image"] == image, "workflow check image differs from admitted image")
    matching = [p for p in params if p.get("name") in {"revision", "source_revision", "source_sha", "git_revision", "commit_sha"} and p.get("value") == source]
    need(len(matching) == 1, "workflow exact source parameter absent/ambiguous; inspect supported schema")
    return {"status": "OUTER_WORKFLOW_POD_VERIFIED", "workflow_uid": workflow_uid, "pod_uid": pod_uid,
            "workflow_name": capture["name"], "node": pod["spec"]["nodeName"], "image": image,
            "image_id": main["imageID"], "source_parameter": matching[0]["name"],
            "native_check_name": expected_check, "native_command_exit_code": command_result["exit_code"],
            "native_check_attempts": 1,
            "successful_type_pod_nodes": len(pod_nodes), "resources": main_spec.get("resources", {}),
            "resource_profile_basis": "Reviewed native-plan CPU/memory plus ROOT-admitted template ephemeral requests4Gi/limits12Gi",
            "wait_sidecar": {"effective_resources_from_pod": wait_spec.get("resources", {}),
                             "image": wait_spec["image"], "image_id": wait_status.get("imageID"),
                             "exit_code": wait_status["state"]["terminated"]["exitCode"],
                             "restarts": wait_status["restartCount"]},
            "capture_sha256": sha(capture_bytes), "workflow_capture_sha256": sha(workflow_bytes),
            "pods_capture_sha256": sha(pods_bytes), "main_log_sha256": sha(raw)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for option in ("capture-dir", "log", "source-manifest", "native-plan", "output-dir"):
        parser.add_argument("--" + option, type=Path, required=True)
    for option in ("expected-source", "expected-image", "workflow-uid", "pod-uid", "expected-check"):
        parser.add_argument("--" + option, required=True)
    args = parser.parse_args()
    need(bool(re.fullmatch(r"[0-9a-f]{40}", args.expected_source)), "full source SHA required")
    need(args.expected_source == ADMITTED_SOURCE, "source differs from this verifier's admitted revision")
    need(bool(re.fullmatch(r"[^\s@]+@sha256:[0-9a-f]{64}", args.expected_image)), "digest-bound image required")
    args.output_dir.mkdir(parents=True, exist_ok=False)
    result = {"schema": "verdify-s3b-independent-native-custody-v1", "status": "FAILED",
              "native_execution_performed": False, "source_revision": args.expected_source,
              "whole_639_acceptance": False, "physical_acceptance": False,
              "prefix_coverage": "27/48 UNPROVEN; no row-wise credit added"}
    try:
        source_bytes, plan_bytes = read(args.source_manifest, 1048576), read(args.native_plan, 1048576)
        extraction, plan = decode_json(source_bytes), decode_json(plan_bytes)
        manifest_path = "planning/reviews/2026-10-18-s3b-execution/p1-fog-consumer/source-extraction.json"
        need(sha(source_bytes) == plan["source_inputs_sha256"][manifest_path], "ROOT manifests do not bind one another")
        raw = read(args.log)
        result.update(main_log_sha256=sha(raw), main_log_bytes=len(raw),
                      source_manifest_sha256=sha(source_bytes), native_plan_sha256=sha(plan_bytes))
        result["content"] = verify_log(raw, extraction, plan, args.expected_source, args.output_dir)
        result["outer"] = verify_outer(args.capture_dir.resolve(), args.log, raw, args.expected_source,
                                       args.expected_image, args.workflow_uid, args.pod_uid,
                                       args.expected_check, plan)
        result["status"] = "NAMED_SYNTHETIC_CONSUMER_NATIVE_CUSTODY_VERIFIED"
    except Exception as exc:
        result["failure"] = {"type": type(exc).__name__, "message": str(exc)}
    (args.output_dir / "verification.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"status": result["status"], "receipt": str(args.output_dir / "verification.json")}))
    return 0 if result["status"] == "NAMED_SYNTHETIC_CONSUMER_NATIVE_CUSTODY_VERIFIED" else 1


if __name__ == "__main__":
    raise SystemExit(main())
