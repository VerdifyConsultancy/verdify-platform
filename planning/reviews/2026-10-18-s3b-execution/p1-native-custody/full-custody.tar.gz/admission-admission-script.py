#!/usr/bin/env python3
"""ROOT-only P1 admission. Default read-only; --submit creates ONE Workflow once.
Existing template retries remain inherited: one check is NOT a one-Pod promise.
No polling, retry loop, secret reads, credentials or shared-object modifications.
"""
import argparse, concurrent.futures, datetime as dt, decimal, hashlib, json, os, pathlib, re, subprocess, sys, time
D=decimal.Decimal
NS='agent-fleet-ci'
TEMPLATE='repo-validate-568985cdbf6b4e3f'
TUID='09f8d5e5-68bf-484e-b5a3-1181d1a1ee50'
TSHA='568985cdbf6b4e3fdec9724f096b9816e18ace2a0b001bc52dfe9fb6e417246e'
IMAGE='registry.vallery.net/jvallery/agents-ci-tools@sha256:7d61fca39280efb3b26419a111609f4713f3a1cc54b736a7af624fdf03c8f0e6'
HANDBACK_SHA='1a4129864cf8d9f42bd851baf0557df8a203a5fee96dca7d06da5f703e0127d8'
CONTROLLER_SHA='98d7221e2310c6a261c07a6f4001951db63399a3274ebce50398a81339b2b3a4'
PLAN='planning/reviews/2026-10-18-s3b-execution/p1-fog-consumer/native-plan.json'
INPUTS={
 'scripts/fog_vent_consumer.py':'f251494df91df86329ebe349a33fda8be1fdfc3e7525a4ce6862320fff9c7f81',
 'scripts/qualify_fog_vent_consumer.py':'a93d69d4c5984da3ffd314f6cf626dda22e4eaab3c8bc7b478ee31443cfd3600',
 'tests/fixtures/fog_vent_consumer.cpp.in':'4b340f2bc2bb8664297f5192604a128218b96c4e94ac0df8a3544b27d85be653',
 'tests/test_fog_vent_consumer.py':'55cafaafd3ba2581d47261c02aa7168cd4198f125f7b9dad6cd3f5aefea43d16',
 'planning/reviews/2026-10-18-s3b-execution/p1-fog-consumer/source-extraction.json':'dba56ecaeca944d3e02433ffd8901c32161409a6232b8ff333391853d45423e5'}
K=['kubectl','--context','vallery','--request-timeout=20s']
def sha(b): return hashlib.sha256(b).hexdigest()
def canonical(x): return json.dumps(x,sort_keys=True,separators=(',',':')).encode()
def need(ok,why):
 if not ok: raise ValueError(why)
def now(): return dt.datetime.now(dt.timezone.utc)
def stamp(x): return dt.datetime.fromisoformat(x.replace('Z','+00:00'))
def qty(v):
 m=re.fullmatch(r'([+-]?(?:\d+(?:\.\d*)?|\.\d+))(n|u|m|Ki|Mi|Gi|Ti|Pi|Ei|k|K|M|G|T|P|E)?',str(v));need(m is not None,'unsupported resource quantity')
 scales={'n':D('1e-9'),'u':D('1e-6'),'m':D('.001'),'Ki':D(1024),'Mi':D(1024**2),'Gi':D(1024**3),'Ti':D(1024**4),'Pi':D(1024**5),'Ei':D(1024**6),'k':D(1000),'K':D(1000),'M':D(10**6),'G':D(10**9),'T':D(10**12),'P':D(10**15),'E':D(10**18)}
 return D(m[1])*scales.get(m[2],D(1))
def effective(p,kind,resource):
 s=p.get('spec',p);ordinary=sum((qty(c.get('resources',{}).get(kind,{}).get(resource,'0')) for c in s.get('containers',[])),D(0));side=peak=D(0)
 for c in s.get('initContainers',[]):
  amount=qty(c.get('resources',{}).get(kind,{}).get(resource,'0'))
  if c.get('restartPolicy')=='Always': side+=amount;peak=max(peak,side)
  else: peak=max(peak,side+amount)
 return max(ordinary+side,peak)+qty((s.get('overhead') or {}).get(resource,'0'))
def run(cmd,timeout=30):
 p=subprocess.run(cmd,capture_output=True,timeout=timeout)
 need(p.returncode==0,'command failed: '+str(cmd[:5])+'; rc='+str(p.returncode)+'; stderr_sha256='+sha(p.stderr))
 return p.stdout
def get(args): return json.loads(run(K+args))
def sanitize_pods(x):
 return {'items':[{'metadata':{k:p['metadata'][k] for k in ['name','namespace','uid','resourceVersion','creationTimestamp','deletionTimestamp','labels','ownerReferences'] if k in p['metadata']},'spec':{**{k:p.get('spec',{}).get(k) for k in ['nodeName','nodeSelector','affinity','tolerations','overhead','priorityClassName','serviceAccountName']},**{k:[{f:c[f] for f in ['name','image','resources','restartPolicy'] if f in c} for c in p.get('spec',{}).get(k,[])] for k in ['containers','initContainers']}},'status':{k:p.get('status',{}).get(k) for k in ['phase','startTime','conditions']}} for p in x['items']]}
def quota_applies(q):
 need(not q['spec'].get('scopes'),'unreviewed quota scopes')
 es=q['spec'].get('scopeSelector',{}).get('matchExpressions',[])
 if not es:return True
 need(len(es)==1 and es[0].get('scopeName')=='PriorityClass' and es[0].get('values')==['agent-fleet-ci-foreign'] and es[0].get('operator') in ['In','NotIn'],'unreviewed quota selector')
 return es[0]['operator']=='NotIn'
def resource_guards(data,t):
 defaults=data['limitrange']['items'];need(len(defaults)==1,'LimitRange inventory changed')
 need(defaults[0]['metadata']['uid']=='67b45f02-d6a0-4e1e-8f7b-9a894d8c8bf0','LimitRange identity changed')
 need(defaults[0]['spec']=={'limits':[{'default':{'cpu':'500m','memory':'512Mi'},'defaultRequest':{'cpu':'100m','memory':'128Mi'},'type':'Container'}]},'resource defaults changed')
 need(sha(canonical(data['controller'].get('data',{})))==CONTROLLER_SHA,'controller defaults changed')
 check=next(v for v in t['spec']['templates'] if v['name']=='run-check')
 need(check['nodeSelector']=={'agentfleet.vallery.net/runner-eligible':'true'},'selector changed')
 # Existing Argo wait/init plus LimitRange defaults are included. No changes to them.
 regular=[{'name':'main','resources':check['container']['resources']},{'name':'wait','resources':{'requests':{'cpu':'100m','memory':'128Mi'},'limits':{'cpu':'500m','memory':'512Mi'}}}]
 expected={'spec':{'containers':regular,'initContainers':[{'resources':regular[1]['resources']},{'resources':regular[1]['resources']}]}}
 req={r:effective(expected,'requests',r) for r in ['cpu','memory','ephemeral-storage']};lim={r:effective(expected,'limits',r) for r in req}
 # Check current real Pods for executor/default drift; never persist env/credentials.
 samples=[]
 for p in data['pods']['items']:
  cs=p.get('spec',{}).get('containers',[])
  if any(c['name']=='main' and c.get('image')==IMAGE and c.get('resources')==check['container']['resources'] for c in cs) and p['metadata'].get('namespace')==NS:
   need({c['name'] for c in cs}=={'main','wait'},'unexpected check sidecar')
   for r in req:
    need(effective(p,'requests',r)==req[r] and effective(p,'limits',r)==lim[r],'actual check Pod resource defaults differ')
   samples.append(p['metadata']['uid'])
 need(samples,'no current matching check Pod to bind injected resource defaults')
 # Four serial stages; conservatively reserve whole initial four-Pod envelope.
 # Inherited replacement retry is serial; ROOT watches/aborts unexpected retries.
 envelope={'requests.cpu':req['cpu']+D('.6'),'requests.memory':req['memory']+qty('768Mi'),'limits.cpu':lim['cpu']+D(3),'limits.memory':lim['memory']+qty('3Gi'),'pods':D(4),'requests.ephemeral-storage':req['ephemeral-storage'],'limits.ephemeral-storage':lim['ephemeral-storage']}
 checked=[]
 for q in data['quota']['items']:
  if not quota_applies(q):continue
  hard=q['status']['hard'];used=q['status'].get('used',{})
  need(hard==q['spec']['hard'],'quota status stale')
  for key,val in hard.items():
   need(key in envelope,'unreviewed applicable quota field '+key)
   need(qty(val)-qty(used.get(key,'0'))>=envelope[key],'quota headroom '+key)
  checked.append(q['metadata']['name'])
 need(checked,'missing applicable quota')
 metrics={m['metadata']['name']:m for m in data['node_metrics']['items']};rows=[]
 for n in data['nodes']['items']:
  if n['metadata'].get('labels',{}).get('agentfleet.vallery.net/runner-eligible')!='true':continue
  name=n['metadata']['name'];need(not n['spec'].get('unschedulable') and not n['spec'].get('taints'),'eligible worker scheduling changed: '+name)
  c={x['type']:x['status'] for x in n['status']['conditions']};need(c.get('Ready')=='True' and all(c.get(k)=='False' for k in ['MemoryPressure','DiskPressure','PIDPressure']),'node health: '+name)
  metric=metrics[name];age=(now()-stamp(metric['timestamp'])).total_seconds();need(0<=age<120,'stale node metric: '+name)
  ps=[p for p in data['pods']['items'] if p.get('spec',{}).get('nodeName')==name and p['status']['phase'] not in ['Succeeded','Failed']]
  request={r:sum((effective(p,'requests',r) for p in ps),D(0)) for r in req};limits={r:sum((effective(p,'limits',r) for p in ps),D(0)) for r in req};a=n['status']['allocatable'];usage=metric['usage']
  # Existing ROOT operator margins, not a change to estate reservation policy.
  need(qty(a['cpu'])-request['cpu']-req['cpu']>=1,'CPU scheduler margin: '+name)
  need(qty(a['memory'])-request['memory']-req['memory']>=qty('4Gi'),'memory request margin: '+name)
  need(qty(a['memory'])-qty(usage['memory'])-lim['memory']>=qty('4Gi'),'working-set margin: '+name)
  need(qty(a['cpu'])-qty(usage['cpu'])-lim['cpu']>=1,'CPU working margin: '+name)
  need(qty(a['ephemeral-storage'])-request['ephemeral-storage']-req['ephemeral-storage']>=qty('4Gi'),'ephemeral request margin: '+name)
  need(qty(a['pods'])-len(ps)>=4,'Pod scheduler margin: '+name)
  rows.append({'node':name,'uid':n['metadata']['uid'],'metric_timestamp':metric['timestamp'],'requests':{k:str(v) for k,v in request.items()},'limits_report_only':{k:str(v) for k,v in limits.items()},'usage':usage,'allocatable':a,'active_pods':len(ps)})
 need(rows,'no eligible workers')
 return {'workers':rows,'applicable_quotas':checked,'pod_requests':{k:str(v) for k,v in req.items()},'pod_limits':{k:str(v) for k,v in lim.items()},'quota_envelope':{k:str(v) for k,v in envelope.items()},'matching_actual_pod_uids':samples,'limits_overcommit_not_treated_as_scheduler_requests':True,'ephemeral_actual_free_bytes_not_proven':True}
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--source',required=True);ap.add_argument('--base-revision',default='541c11ad0786e00e50e45f52ca4828173ddc58c2');ap.add_argument('--repo-dir',required=True);ap.add_argument('--handback',required=True);ap.add_argument('--output-dir',required=True);ap.add_argument('--workflow-name',required=True);ap.add_argument('--submit',action='store_true');a=ap.parse_args()
 need(re.fullmatch('[0-9a-f]{40}',a.source) and re.fullmatch('[0-9a-f]{40}',a.base_revision),'full source/base required');need(re.fullmatch(r'verdify-s3b-p1-[a-z0-9-]{1,40}',a.workflow_name),'scoped stable workflow name required')
 os.umask(0o077);o=pathlib.Path(a.output_dir);o.mkdir(parents=True,exist_ok=False);started=now();record={'status':'STARTED','at':started.isoformat(),'source':a.source,'submission_requested':a.submit,'submission_attempted':False,'failure':None}
 def save(name,x): (o/name).write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
 try:
  (o/'admission-script.py').write_bytes(pathlib.Path(__file__).read_bytes());hb=pathlib.Path(a.handback).read_bytes();need(sha(hb)==HANDBACK_SHA,'actual Agents handback mismatch');h=json.loads(hb);need(h['consumer_window']=='one bounded serial Verdify qualification then normalPRCI; existing supported paths/admission, no controller/catalog/DB/prod/provider changes','handback scope mismatch');need(0<=(now()-stamp(h['at'])).total_seconds()<7200,'handback stale');(o/'agents-handback.json').write_bytes(hb)
  def gitblob(path):return run(['git','-C',a.repo_dir,'show',a.source+':'+path])
  for path,digest in INPUTS.items():need(sha(gitblob(path))==digest,'reviewed source input changed: '+path)
  plan_bytes=gitblob(PLAN);need(sha(plan_bytes)=='cfb884f510ec9dda0bb03649824f10f9b2d5d9181b4f6205bda40461ac9a0e36','reviewed native plan changed');plan=json.loads(plan_bytes);need(plan['source_inputs_sha256']==INPUTS,'plan input manifest changed')
  # Read-only public metadata proof that exact GitHub commit is fetchable by existing init.
  remote=json.loads(run(['gh','api','repos/VerdifyConsultancy/verdify-platform/commits/'+a.source,'--jq','{sha:.sha,tree:.commit.tree.sha}']));need(remote['sha']==a.source,'remote source mismatch');save('remote-source.json',remote)
  calls={'template':['-n',NS,'get','workflowtemplate',TEMPLATE,'-o','json'],'alias':['-n',NS,'get','workflowtemplate','repo-validate','-o','json'],'quota':['-n',NS,'get','resourcequota','-o','json'],'limitrange':['-n',NS,'get','limitrange','-o','json'],'nodes':['get','nodes','-o','json'],'pods':['get','pods','-A','--field-selector=status.phase!=Succeeded,status.phase!=Failed','-o','json'],'node_metrics':['get','--raw','/apis/metrics.k8s.io/v1beta1/nodes'],'pod_metrics':['get','--raw','/apis/metrics.k8s.io/v1beta1/namespaces/'+NS+'/pods'],'controller':['-n',NS,'get','cm','argo-workflows-workflow-controller-configmap','-o','json'],'semaphore':['-n',NS,'get','cm','agent-fleet-ci-concurrency','-o','json'],'workflows':['-n',NS,'get','workflow','-l','workflows.argoproj.io/completed!=true','-o','json']}
  data={}
  with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
   futures={pool.submit(get,v):k for k,v in calls.items()}
   for fut in concurrent.futures.as_completed(futures):
    key=futures[fut];value=fut.result()
    if key=='pods':value=sanitize_pods(value)
    if key=='workflows':value={'items':[{'metadata':{k:w['metadata'].get(k) for k in ['name','uid','creationTimestamp','labels']},'status':{k:w.get('status',{}).get(k) for k in ['phase','startedAt','finishedAt']}} for w in value['items']]}
    data[key]=value;save(key+'.private.json',value)
  t=data['template'];need(t['metadata']['uid']==TUID and sha(canonical(t['spec']))==TSHA,'versioned template changed');need(sha(canonical(data['alias']['spec']))==TSHA,'enabled template alias changed');need(data['semaphore'].get('data',{}).get('repo-validate')=='16','shared semaphore changed')
  capacity=resource_guards(data,t);save('capacity.json',capacity)
  command=plan['check']['command'].replace('__ROOT_ADMITTED_FULL_COMMIT__',a.source);need(command.count(a.source)==1 and 'timeout 660s ' in command,'unexpected native command');check={'name':plan['check']['name'],'command':command}
  manifest={'apiVersion':'argoproj.io/v1alpha1','kind':'Workflow','metadata':{'name':a.workflow_name,'namespace':NS,'labels':{'agent-fleet.vallery.net/repo':'verdify-platform'},'annotations':{'verdify.ai/qualification-source':a.source,'verdify.ai/qualification-scope':'s3b-p1-synthetic-actual-fog-consumer-no-prefix-or-physical-credit'}},'spec':{'workflowTemplateRef':{'name':TEMPLATE},'arguments':{'parameters':[{'name':'repo','value':'https://github.com/VerdifyConsultancy/verdify-platform.git'},{'name':'revision','value':a.source},{'name':'base_revision','value':a.base_revision},{'name':'checks_json','value':json.dumps([check])}]},'activeDeadlineSeconds':900,'podGC':{'strategy':'OnPodCompletion','deleteDelayDuration':'3600s'}}};save('workflow.json',manifest)
  retry=next(x for x in t['spec']['templates'] if x['name']=='run-check')['retryStrategy'];record.update(status='ADMITTED_NOT_SUBMITTED',admission_at=now().isoformat(),handback_sha256=sha(hb),source_inputs_sha256=INPUTS,template_uid=TUID,template_spec_sha256=TSHA,image=IMAGE,inherited_retry_strategy=retry,actual_check_count=1,possible_multiple_pod_attempts=True,root_must_watch_and_abort_unexpected_retry=True,whole_workflow_deadline_seconds=900,command_deadline_seconds=660,manifest_sha256=sha((o/'workflow.json').read_bytes()),command_sha256=sha(command.encode()),service_account='argo-ci-workflow',token_mount_not_overridden_or_claimed_absent=True,existing_git_fetch_identity_unchanged=True,full_prefix_or_physical_acceptance=False)
  save('admission.json',record)
  # One create only, no implicit retry. Unknown create outcomes require exact-name readback.
  if a.submit:
   need((now()-started).total_seconds()<110,'admission too old; do not submit')
   for m in data['node_metrics']['items']:need(0<=(now()-stamp(m['timestamp'])).total_seconds()<120,'metrics aged before create')
   record['submission_attempted']=True;save('attempt-start.json',record)
   created=get(['create','-f',str(o/'workflow.json'),'-o','json']);save('created.private.json',created);need(created['metadata']['name']==a.workflow_name and created['metadata']['namespace']==NS,'created workflow binding mismatch');record.update(status='SUBMITTED_TERMINAL_UNVERIFIED',workflow_uid=created['metadata']['uid'],workflow_name=created['metadata']['name'])
 except Exception as e:
  record.update(status='FAILED_OR_CREATE_OUTCOME_UNKNOWN' if record['submission_attempted'] else 'REFUSED',failure={'type':type(e).__name__,'message':str(e)[:1000]});raise
 finally:
  record['finished_at']=now().isoformat();save('result.json',record)
  print(json.dumps({'status':record['status'],'receipt':str(o/'result.json'),'failure':record['failure']}))
if __name__=='__main__':main()
