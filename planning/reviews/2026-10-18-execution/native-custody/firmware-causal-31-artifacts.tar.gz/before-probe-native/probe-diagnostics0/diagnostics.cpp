
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <string>
#if __has_include("probe_validity.h")
#include "probe_validity.h"
#endif
using std::isnan;
#define id(x) x
struct Sensor { float state = 0.0f; };
uint32_t clock_ms;
uint32_t millis() { return clock_ms; }
uint32_t last_case_ms, last_north_ms, last_west_ms, last_south_ms, last_east_ms;
Sensor case_temperature, case_humidity;
Sensor north_wall_temperature, north_wall_humidity, vpd_north;
Sensor west_wall_temperature, west_wall_humidity, vpd_west;
Sensor south_wall_temperature, south_wall_humidity, vpd_south;
Sensor east_wall_temperature, east_wall_humidity, vpd_east;
float active_count() {
const uint32_t now = millis();
const uint32_t STALE = 300000;
auto ok = [&](uint32_t ts){ return ts > 0 && (now - ts) < STALE; };
int n = 0;
if(ok(id(last_north_ms))) n++;
if(ok(id(last_west_ms)))  n++;
if(ok(id(last_south_ms))) n++;
if(ok(id(last_east_ms)))  n++;
return (float)n;
}
std::string probe_status() {
uint32_t now = millis();
const uint32_t STALE_MS = 120000;
char result[96];
size_t n = 0;
result[0] = '\0';
struct { const char* name; uint32_t last; } probes[] = {
  {"Case", id(last_case_ms)},
  {"North", id(last_north_ms)},
  {"West", id(last_west_ms)},
  {"South", id(last_south_ms)},
  {"East", id(last_east_ms)}
};
bool all_ok = true;
auto append = [&](const char* s) {
  while (*s != '\0' && n + 1 < sizeof(result)) {
    result[n++] = *s++;
  }
  result[n] = '\0';
};
for(auto &p : probes){
  if(p.last == 0 || (now - p.last) > STALE_MS){
    if(!all_ok) append(", ");
    append(p.name);
    append(" STALE");
    all_ok = false;
  }
}
return all_ok ? std::string("OK") : std::string(result);
}
int main(int argc, char** argv) {
  if (argc != 22) return 64;
  clock_ms = uint32_t(std::strtoul(argv[1], nullptr, 10));
  struct Fields { uint32_t* last; Sensor* temp; Sensor* rh; Sensor* vpd; } fields[] = {
    {&last_case_ms, &case_temperature, &case_humidity, nullptr},
    {&last_north_ms, &north_wall_temperature, &north_wall_humidity, &vpd_north},
    {&last_west_ms, &west_wall_temperature, &west_wall_humidity, &vpd_west},
    {&last_south_ms, &south_wall_temperature, &south_wall_humidity, &vpd_south},
    {&last_east_ms, &east_wall_temperature, &east_wall_humidity, &vpd_east}
  };
  for (int i = 0; i < 5; ++i) {
    const int pos = 2 + i * 4;
    *fields[i].last = uint32_t(std::strtoul(argv[pos], nullptr, 10));
    fields[i].temp->state = std::strtof(argv[pos + 1], nullptr);
    fields[i].rh->state = std::strtof(argv[pos + 2], nullptr);
    if (fields[i].vpd) fields[i].vpd->state = std::strtof(argv[pos + 3], nullptr);
  }
  std::cout << int(active_count()) << "|" << probe_status() << "\n";
}
