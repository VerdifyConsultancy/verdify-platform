import datetime,hashlib,json,pathlib,subprocess,sys
name,uid,directory=sys.argv[1:]; out=pathlib.Path(directory); out.mkdir(parents=True,exist_ok=True)
k=['kubectl','--context','vallery','--request-timeout=20s','-n','agent-fleet-ci']; now=datetime.datetime.now(datetime.timezone.utc); stamp=now.strftime('%Y%m%dT%H%M%S%fZ')
def fetch(args):return json.loads(subprocess.check_output(k+args,text=True,timeout=25))
w=fetch(['get','workflow',name,'-o','json']);assert w['metadata']['uid']==uid
pods=fetch(['get','pods','-l','workflows.argoproj.io/workflow='+name,'-o','json'])['items']
(out/f'{stamp}-workflow.private.json').write_text(json.dumps(w,indent=2)+'\n');(out/f'{stamp}-pods.private.json').write_text(json.dumps(pods,indent=2)+'\n')
s={'at':now.isoformat(),'name':name,'uid':uid,'phase':w.get('status',{}).get('phase'),'startedAt':w.get('status',{}).get('startedAt'),'finishedAt':w.get('status',{}).get('finishedAt'),'pod_nodes':[{key:n.get(key) for key in ['id','name','displayName','type','phase','startedAt','finishedAt','message','outputs']} for n in w.get('status',{}).get('nodes',{}).values() if n.get('type')=='Pod'],'pods':[]}
for p in pods:
 row={'name':p['metadata']['name'],'uid':p['metadata']['uid'],'phase':p['status']['phase'],'node':p['spec'].get('nodeName'),'resources':{c['name']:c.get('resources',{}) for c in p['spec']['containers']},'init':[{key:c.get(key) for key in ['name','state','restartCount','imageID']} for c in p['status'].get('initContainerStatuses',[])],'containers':[{key:c.get(key) for key in ['name','state','restartCount','imageID']} for c in p['status'].get('containerStatuses',[])]}
 main=next((c for c in p['status'].get('containerStatuses',[]) if c['name']=='main'),None)
 if main and (main.get('state',{}).get('running') or main.get('state',{}).get('terminated')):
  result=subprocess.run(k+['logs',p['metadata']['name'],'-c','main'],capture_output=True,timeout=25)
  row['log_read_exit']=result.returncode
  if result.returncode==0:
   assert len(result.stdout)<=64*1024*1024; digest=hashlib.sha256(result.stdout).hexdigest();target=out/f"{p['metadata']['name']}-{digest}.main.log";target.write_bytes(result.stdout);row.update(log_path=target.name,log_bytes=len(result.stdout),log_sha256=digest)
   row['last_lines']=[line[:400] for line in result.stdout.decode(errors='replace').splitlines() if not line.startswith(('{"artifact"','{"process_result"','{"artifact_manifest"','{"qualification_result"'))][-4:]
 s['pods'].append(row)
(out/f'{stamp}-capture.json').write_text(json.dumps(s,indent=2)+'\n');(out/'capture-latest.json').write_text(json.dumps(s,indent=2)+'\n');print(json.dumps(s,indent=2))
