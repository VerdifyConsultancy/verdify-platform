import pathlib,json,subprocess,hashlib,tarfile,io,datetime,shutil,re
base=pathlib.Path('/Users/jason/maintenance/verdify-getter-mcp-20261018');root=pathlib.Path('/Users/jason/.codex/worktrees/verdify-getter-mcp-20261018/verdify-platform');out=root/'planning/reviews/2026-10-18-getter-mcp-release/custody'
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=root,text=True).strip()
assert git('branch','--show-current')=='codex/getter-mcp-evidence-20261018';assert git('rev-parse','origin/main')=='be7a91406226016e4c68629fe2e2c86bfe99571c';assert json.loads((base/'planning-main-verification.json').read_text())['status']=='DIRECT_TERMINAL_MAIN_VALIDATION_PASSED'
out.mkdir(exist_ok=True)
private_inventory={'COORDINATOR_STATE.json','nodes-admission-before.json','ci-workflows-before.json','ci-node6-resource-readback.json','mcp-rollout-admission.json','initial-summary.json'}
files=[(p,'captures/'+str(p.relative_to(base))) for p in sorted(base.rglob('*')) if p.is_file() and str(p.relative_to(base)) not in private_inventory]
# Publish only the capacity/pressure fields actually used; broad cluster inventory and unrelated tenant names remain private.
admission=json.loads((base/'mcp-rollout-admission.json').read_text())
capacity={'at':admission['at'],'context':admission['context'],'namespace':admission['namespace'],'expected_surge':admission['expected_surge'],'nodes':[{k:n.get(k) for k in ['node','allocatable','unschedulable','taints','conditions']} for n in admission['nodes']],'scope':'Derived capacity/pressure only; raw Node annotations and unrelated workload/CI identities remain in private operator custody.'}
capacity_file=out/'capacity-admission-summary.json';capacity_file.write_text(json.dumps(capacity,indent=2)+'\n');files.append((capacity_file,'derived/capacity-admission-summary.json'))
for name in ['verdify-mcp-runtime-qualify.py','verdify-getter-verify-main-validation.py','verdify-getter-reconcile-github.py','verdify-s3b-capture-workflow.py','verdify-getter-update-plan.py','verdify-getter-package-evidence.py']:
 p=pathlib.Path('/private/tmp')/name;files.append((p,'readers/'+name))
manifest=[];empty_json=[];metadata_whitelist=json.loads((base/'archive-guard-adjudication.json').read_text())['exact_metadata_whitelist']
def guard(x):
 if isinstance(x,dict):
  assert x.get('kind')!='Secret','Secret object excluded'
  if isinstance(x.get('env'),list):
   for e in x['env']:
    if re.search(r'(TOKEN|PASSWORD|PRIVATE_KEY|CLIENT_SECRET|ACCESS_KEY|AUTHORIZATION)',e.get('name',''),re.I) and e.get('value'):
     assert e['name'] in metadata_whitelist and sha(str(e['value']).encode())==metadata_whitelist[e['name']]['sha256'],'Literal credential-like environment excluded'
  for v in x.values():guard(v)
 elif isinstance(x,list):
  for v in x:guard(v)
archive=out/'full-custody.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for p,name in files:
  b=p.read_bytes()
  if p.suffix=='.json':
   if b.strip():guard(json.loads(b))
   else:empty_json.append(name)
  assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----',b),'Private key PEM excluded'
  m=tarfile.TarInfo(name);m.mode=0o644;m.size=len(b);m.mtime=0;t.addfile(m,io.BytesIO(b));manifest.append({'path':name,'bytes':len(b),'sha256':sha(b)})
with tarfile.open(archive,'r:gz') as t:
 assert len(t.getmembers())==len(manifest)
 for m in manifest:
  b=t.extractfile(m['path']).read();assert len(b)==m['bytes'] and sha(b)==m['sha256']
index={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'byte_preserving_readback':True,'member_count':len(manifest),'uncompressed_member_bytes':sum(m['bytes'] for m in manifest),'scope':'All task-specific original SQL/CI/rollout/runtime/GitHub evidence; broad unrelated cluster inventory remains private, with derived capacity proof included.','private_inventory_excluded':sorted(private_inventory),'empty_original_json_read_files_preserved':empty_json,'members':manifest};(out/'archive-manifest.json').write_text(json.dumps(index,indent=2)+'\n')
for src,dst in [('release-main-verification.json','release-main-verification.json'),('planning-main-verification.json','planning-main-verification.json'),('github-canonical/verification.json','github-graph-verification.json'),('planning-publication-admission.json','planning-publication-admission.json')]:shutil.copyfile(base/src,out/dst)
publication={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'destination':'https://github.com/VerdifyConsultancy/verdify-platform','visibility':'public','scope':'This getter/MCP sprint report, production Pod/workflow identifiers, image/source hashes, readonly SQL plans/timings, rollout/authentication/smoke receipts, raw diagnostic/CI logs and final CI receipts','user_explicit_authorization':'Authorize public publication of this sprint’s report and full evidence','archive_sha256':index['sha256'],'archive_members':len(manifest),'no_raw_Secret_objects_literal_credential_env_or_private_key_PEM_admitted':True,'credential_values_exported_by_runtime_auth_probes':False,'completed_CI':['release PR987','release-main7b48a210','planning-mainbe7a9140'],'scope_limits':['No genuine episode result, positive admin outcome transport or planner consumption','Installed getter unchanged; candidate and resolved-stage timeouts retained','All47 issues remain open;143 clauses and27 active edges unchanged']};(out/'publication-review.json').write_text(json.dumps(publication,indent=2)+'\n')
p=root/'planning/reviews/2026-10-18-getter-mcp-release/README.md';s=p.read_text();s+='''
## Final custody publication

The release PR, release-main and planning-main validation completed successfully with direct terminal validation Pod/container exit0/restarts0 and full `ALL GATES GREEN` main logs. Both automatic main validations selected mode `validate`, all eight image-build flags false; no additional images or production change followed the documentation publication. [Release-main receipt](custody/release-main-verification.json), [planning-main receipt](custody/planning-main-verification.json), [canonical/native graph readback](custody/github-graph-verification.json).

The [complete byte-preserving archive](custody/full-custody.tar.gz) and [per-member hash manifest](custody/archive-manifest.json) retain original queries, successes/timeouts, chronological CI/rollout captures, service/projection and smoke/device outputs, source reviews and verifier scripts. Jason explicitly approved public publication of this sprint's report and full raw evidence. Credential scanning and the remote exact-byte archive readback are recorded in the final campaign handoff; credential values and Kubernetes Secret data are not exported. This custody-only branch creates no additional main validation or production release.
''';p.write_text(s);print(json.dumps({k:index[k] for k in ['bytes','sha256','member_count','uncompressed_member_bytes']}))
