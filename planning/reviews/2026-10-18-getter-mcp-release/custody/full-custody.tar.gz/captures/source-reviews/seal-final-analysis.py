from pathlib import Path
import hashlib,json
from datetime import datetime,timezone
D=Path('/private/tmp/verdify-410-timeout-diagnosis-20261018')
B=Path('/Users/jason/maintenance/verdify-getter-mcp-20261018')
def sha(b):return hashlib.sha256(b).hexdigest()
def docs(b):
 text=b.decode(); dec=json.JSONDecoder();out=[]
 while text.strip():
  text=text.lstrip();v,n=dec.raw_decode(text);out.append(v);text=text[n:]
 return out
specs=[('getter-plan-01','01-same-night-no-analyze.sql',0),('getter-plan-02','02-old-body-vs-bounds-inline-no-analyze.sql',0),('getter-candidate-03','03-one-candidate-readonly.sql',3),('getter-isolate-04a','04a-source-scans-and-intervals.sql',0),('getter-isolate-04b','04b-resolved-all-columns.sql',3),('getter-isolate-04c','04c-first64-helper-microread.sql',0)]
evidence=[]
for name,query,rc in specs:
 p=B/name;rbytes=(p/'receipt.json').read_bytes();r=json.loads(rbytes);q=(p/'query.sql').read_bytes();out=(p/'stdout').read_bytes();err=(p/'stderr').read_bytes()
 assert q==(D/query).read_bytes()
 assert sha(q)==r['query_sha256'] and sha(out)==r['stdout_sha256'] and len(out)==r['stdout_bytes']
 assert sha(err)==r['stderr_sha256'] and len(err)==r['stderr_bytes']
 assert r['exit']==rc and r['same_database_container_state'] is True
 assert r['before']==r['after'] and r['before']['uid']=='b1fa2c0e-a995-481f-a29f-4cfaad4e697b'
 assert len(r['before']['containers'])==1 and r['before']['containers'][0]['restartCount']==0 and r['before']['containers'][0]['ready'] is True
 parsed=docs(out);assert parsed[0]['passed']==1 and parsed[0]['read_only']=='on'
 assert parsed[0]['postmaster_started_at']=='2026-09-29T00:40:56.280382+00:00'
 row={'attempt':name,'retained_directory':str(p),'query_sha256':sha(q),'receipt_sha256':sha(rbytes),'stdout_sha256':sha(out),'stderr_sha256':sha(err),'exit_code':rc,'started_at':r['start'],'finished_at':r['end'],'identity_guard_passed':True,'same_database_container_state':True}
 if rc:
  assert len(parsed)==1 and b'canceling statement due to statement timeout' in err
  row.update(status='STATEMENT_TIMEOUT_2S',result_rows_returned=False,elapsed_query_completion_clock_available=False)
 else:
  assert err==b''
  if '04' in name:
   assert len(parsed)==2
   row.update(status='BOUNDED_STAGE_COMPLETED',counts=parsed[1]['counts'],server_statement_elapsed_ms=parsed[1]['query_elapsed_ms'])
  else:row.update(status='EXPLAIN_WITHOUT_ANALYZE_COMPLETED',json_documents=len(parsed))
 evidence.append(row)
plan=json.loads((D/'observed-plan-comparison.json').read_text())
result={
 'schema_version':1,'status':'FINITE_DIAGNOSIS_COMPLETE_GETTER_UNREPAIRED','created_at':datetime.now(timezone.utc).isoformat(),
 'scope':{'issue':410,'source_revision':'c8cbc74266bd155db2c73ad495e19299d7b6555c','greenhouse':'vallery','night_date':'2026-10-16','source_window_utc':['2026-10-16T06:00:00Z','2026-10-18T06:00:00Z'],'statement_timeout_ms':2000,'lock_timeout_ms':500,'read_only':True,'database_pod_uid':'b1fa2c0e-a995-481f-a29f-4cfaad4e697b','postmaster_started_at':'2026-09-29T00:40:56.280382+00:00','function_definition_count_guarded':13,'migration_ledger_count_guarded':8},
 'evidence_integrity':'All six query files match actual captured query.sql bytes; stdout/stderr bytes and hashes match original receipts; all fresh guards passed and exact before/after database container metadata remained equal with Ready and zero restarts.',
 'attempts':evidence,
 'planner_findings':{
  'confirmed':'Materialized one-row bounds prevents literal timestamp pruning in original source plan. Sole NOT MATERIALIZED change exposes literal bounds and prunes each window scan to one chunk; historical seed remains its existing 14-chunk SkipScan.',
  'baseline_direct_body_matches_original_getter_plan_except_numeric_estimates':True,
  'baseline_operator_nodes':252,'candidate_operator_nodes':101,
  'baseline_estimated_total_cost':77632.82,'candidate_estimated_total_cost':5380.99,
  'baseline_planning_ms':657.626,'candidate_planning_ms':12.436,
  'jit_enabled':False,'planning_improvement_is_execution_cure':False,
  'comparison_sha256':sha((D/'observed-plan-comparison.json').read_bytes()),
  'candidate_bound_body_sha256':'70e4638b118ca6572e40a2808cc3d06d493054c7d9e846666def4252cc08730c'},
 'executor_findings':[
  'The one actual candidate full query still timed out at 2 seconds and returned no episode result.',
  'A consumed every climate_minute, action_minute, and setpoint_intervals field via materialized full-row JSON and byte-count aggregates: 2785 climate minutes, 2785 action minutes, 5628 intervals, 214.317 ms server statement elapsed.',
  'B consumed all 25 resolved fields and timed out at 2 seconds before any episode/daytime/response work was requested. Remaining cost reproduces in the resolved prefix, including its joins and per-minute helpers.',
  'C consumed the first 64 genuine climate minute rows and relevant band/house/solar/AH helper outputs without interval/action/response joins: 64 selected rows, 64 helper rows, 24162 evaluated JSON bytes, 149.637 ms server statement elapsed.'
 ],
 'limits':[
  'Cannot partition the resolved stage cost between interval joins, helper evaluation, planner choices, and forcing overhead from these probes.',
  'Do not linearly extrapolate 64 helper samples to 2785 minutes. C forces fallback helper values even where the full getter might satisfy COALESCE from readback.',
  'No complete installed-getter or candidate episode output, solar-night efficacy verdict, daytime admission count, or physical causal conclusion was obtained.',
  'EXPLAIN estimates are not measured execution costs. Reported statement clocks include planning and the diagnostic aggregate/serialization work.',
  'No byte-for-byte runtime parity is established: existing DISTINCT ON timestamp ties and floating aggregate order remain underdetermined; current-season and historical readback fallback semantics must be preserved.',
  'No installed function, migration, schema, production setting, credential, or device state was changed by this diagnosis.'
 ],
 'preservation':{'all_original_attempts_and_failures_unmodified':True,'original_getter_pilot_timeout_directory':'/Users/jason/maintenance/verdify-s3b-execution-20261018/p3-pilot-20261016-01','candidate_timeout_preserved':True,'resolved_timeout_preserved':True,'historical_plan_comparison_pending_text_preserved':True,'new_queries_after_04c':False},
 'next_followup':'Separate performance follow-up: preserve the demonstrated NOT MATERIALIZED pruning improvement, select a narrowly evidenced resolved-stage optimization, and validate unchanged cardinality, timestamp-tie, solar, historical readback/current-season fallback and negative/incomplete verdict semantics before an immutable new migration. No getter migration is part of the current MCP release.',
 'acceptance':{'getter_repaired':False,'issue_410_complete':False,'episode_acceptance':False,'mcp_release_acceptance_substituted':False,'diagnosis_stopped':True}
}
p=D/'final-bounded-diagnosis.json';assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'path':str(p),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size,'all_six_retained_attempts_verified':True}))
