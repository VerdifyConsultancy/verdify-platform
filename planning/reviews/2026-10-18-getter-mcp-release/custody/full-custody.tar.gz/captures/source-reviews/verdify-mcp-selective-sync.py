import subprocess,json,pathlib,datetime,sys,hashlib
revision=sys.argv[1];assert len(revision)==40 and all(x in '0123456789abcdef' for x in revision)
b=pathlib.Path('/Users/jason/maintenance/verdify-getter-mcp-20261018');out=b/'mcp-selective-sync';out.mkdir(exist_ok=False)
k=['kubectl','--context','vallery','--request-timeout=20s'];resource={'group':'apps','kind':'Deployment','name':'verdify-mcp','namespace':'verdify-prod'}
def get(*a):return json.loads(subprocess.check_output(k+list(a),timeout=25))
a=get('-n','argocd','get','application','verdify-prod-dark','-o','json');assert a['metadata']['uid']=='cae977c6-dcd1-42aa-a526-dc9ff2bd8c69';assert not a.get('operation');assert a.get('status',{}).get('operationState',{}).get('phase') in [None,'Succeeded','Failed','Error'];assert a['spec']['source']['targetRevision']=='main';assert not a['spec'].get('syncPolicy',{}).get('automated')
d=get('-n','verdify-prod','get','deployment','verdify-mcp','-o','json');assert d['spec']['replicas']==2;assert d['spec']['template']['spec']['containers'][0]['image'].endswith('@sha256:cf26b0dff29ea37cfb90889c7abdf4890a6cf7696b467363ec877fc45dcd306c')
for name,value in [('application-before.json',a),('mcp-deployment-before.json',d),('jobs-before.json',get('-n','verdify-prod','get','jobs','-o','json')),('pods-before.json',get('-n','verdify-prod','get','pods','-o','json'))]:
 (out/name).write_text(json.dumps(value,indent=2)+'\n')
operation={'initiatedBy':{'username':'laptop-root'},'sync':{'revision':revision,'prune':False,'resources':[resource]}}
patch=[{'op':'test','path':'/metadata/uid','value':a['metadata']['uid']},{'op':'test','path':'/metadata/resourceVersion','value':a['metadata']['resourceVersion']},{'op':'add','path':'/status/operationState','value':None},{'op':'add','path':'/operation','value':operation}]
(out/'exact-operation.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'patch':patch,'scope':'reviewed migration/hook-independent MCP-only fallback; no full sync; no automatic retry'},indent=2)+'\n')
r=subprocess.run(k+['-n','argocd','patch','application','verdify-prod-dark','--type=json','-p',json.dumps(patch),'-o','json'],capture_output=True,timeout=25);(out/'patch-stdout.json').write_bytes(r.stdout);(out/'patch-stderr').write_bytes(r.stderr);assert r.returncode==0,{'returncode':r.returncode,'stderr_bytes':len(r.stderr)};v=json.loads(r.stdout);assert v['operation']==operation
observed=get('-n','argocd','get','application','verdify-prod-dark','-o','json');(out/'application-immediate.json').write_text(json.dumps(observed,indent=2)+'\n');actual=observed.get('status',{}).get('operationState');
if actual:
 assert actual.get('operation',{}).get('sync',{}).get('resources')==[resource], 'Unexpected operation selector: stop; no retry'
 assert actual['operation']['sync']['revision']==revision
print(json.dumps({'submitted_once':True,'application_uid':a['metadata']['uid'],'revision':revision,'resources':[resource],'operationState':{k:actual.get(k) for k in ['phase','startedAt','finishedAt']} if actual else None}))
