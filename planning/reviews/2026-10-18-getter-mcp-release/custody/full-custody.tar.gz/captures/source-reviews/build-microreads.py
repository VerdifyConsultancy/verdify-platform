from pathlib import Path
import hashlib, json
D=Path('/private/tmp/verdify-410-timeout-diagnosis-20261018')
original=(D/'03-one-candidate-readonly.sql').read_text()
assert hashlib.sha256(original.encode()).hexdigest()=='77fd3df153bc561b3d9d49f7fedebf33bbf0b123ce6f57bd0048067970374dcd'
guard=original[original.index('BEGIN READ ONLY;'):original.index('WITH bounded AS MATERIALIZED (')]
body=original[original.index('WITH bounds AS NOT MATERIALIZED ('):]

def make(name, cutoff, tables, scope):
    prefix=body[:body.index(cutoff)]
    assert prefix.endswith('),\n')
    additions=[]
    for table in tables:
        additions.append(f'{table}_force_all AS MATERIALIZED (\n SELECT to_jsonb(r) AS row_json FROM {table} r\n)')
    counts=[]
    for table in tables:
        counts.append(f"'{table}', (SELECT jsonb_build_object('rows', count(*),\n 'evaluated_row_json_bytes', COALESCE(sum(octet_length(row_json::text)),0))\n FROM {table}_force_all)")
    additions.append("micro_counts AS MATERIALIZED (\n SELECT jsonb_build_object(\n"+',\n'.join(counts)+") AS counts\n)")
    additions.append("completion_clock AS MATERIALIZED (\n SELECT counts, statement_timestamp() AS query_started_at,\n clock_timestamp() AS query_finished_at FROM micro_counts\n)")
    sql=("-- Separately selected finite stage microread; not a getter retry or repaired getter.\n"
         "-- Same Oct16/two-day window; every selected CTE column consumed as JSON bytes.\n"
         "-- Counts only, no episode verdict; 2s statement / 500ms lock timeout.\n"+
         guard.replace('candidate_execution_identity_guard',name+'_identity_guard')+
         prefix+',\n'.join(additions)+f"\nSELECT jsonb_build_object('kind','{name}',\n 'night_date','2026-10-16','scope','{scope}',\n 'source_prefix_sha256','{hashlib.sha256(prefix.encode()).hexdigest()}',\n 'counts',counts,'query_started_at',query_started_at,'query_finished_at',query_finished_at,\n 'query_elapsed_ms',extract(epoch FROM (query_finished_at-query_started_at))*1000)\nFROM completion_clock;\nROLLBACK;\n")
    path=D/(name+'.sql'); path.write_text(sql)
    result={'path':str(path),'sha256':hashlib.sha256(sql.encode()).hexdigest(),'bytes':len(sql.encode()),'source_prefix_sha256':hashlib.sha256(prefix.encode()).hexdigest(),'tables':tables,'scope':scope}
    print(json.dumps(result))
    return result

A=make('04a-source-scans-and-intervals','resolved AS (',['climate_minute','action_minute','setpoint_intervals'],'raw_scans_minute_aggregates_and_setpoint_intervals_without_helpers')
B=make('04b-resolved-all-columns','classified AS (',['resolved'],'resolved_prefix_including_helpers_and_intervals_without_episode_response')
(D/'04-ab-plan.json').write_text(json.dumps({'schema_version':1,'kind':'finite_stage_microread_plan','executed_by_agent':False,'stage_A':A,'stage_B':B,'statement_timeout_ms':2000,'lock_timeout_ms':500,'production_data_statements_per_file':1,'metadata_guard_statements_per_file':1,'expected_output_json_documents_per_success':2,'outer_timeout_seconds':15,'max_output_bytes':65536,'date':'2026-10-16','window_start':'2026-10-16T06:00:00Z','window_end':'2026-10-18T06:00:00Z','bounds_change':'NOT MATERIALIZED only','climate_and_action_minute_max_rows':2880,'setpoint_intervals_bound':'Only source window snapshots plus <=2 source historical seeds; window snapshot row count is not externally capped. 2s timeout applies. Historical seeds preserve existing DISTINCT ON semantics.','resolved_bound':'<=2880 climate minutes with pinned <=1-row helper contracts and nonoverlapping source intervals; actual count is reported, not preasserted as acceptance.','forcing':'MATERIALIZED to_jsonb(full row), then aggregate sum(octet_length(row_json::text)); every selected field must be evaluated, no row values emitted.','sequencing':'ROOT runs A, then selects B; optional C is separately prepared only if B times out and A completed. Total at most three data statements. A timeout stops this branch until ROOT chooses remaining diagnostic need.','limitations':['No measured getter parity or episode verdict.','Aggregate bytes are forcing evidence and counts only, not result integrity hashes.','Different query projection may alter planner choices; stage time is not exact original total time.','No runtime repair or migration authorized.']},indent=2)+'\n')
