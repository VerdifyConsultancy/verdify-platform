#!/usr/bin/env python3
"""Read/qualify only the installed outcome projection; never import the service.

ROOT sends this source to the existing Pod's `python -` stdin. Required args:
  --expected-source-sha256 HEX
Optional genuine packet may be passed as --genuine-json-b64 BASE64 with
--genuine-json-sha256 HEX, or ROOT may prepend a single data-only assignment
`GENUINE_INPUT_B64 = <repr(base64_ascii)>` before these unchanged script bytes
and pass the same --genuine-json-sha256. Seal the exact submitted source/input.
Packet JSON: {"query_receipt_sha256": HEX, "episodes": [captured actual rows]}.
This is installed-code projection qualification, NOT authenticated dispatch,
planner consumption, a new SQL result, or complete issue acceptance.
"""
import argparse
import ast
import base64
import copy
import hashlib
import json
import os
import pathlib
import platform
import re
import sys
import time

MAX_INPUT = 1024 * 1024
MAX_SOURCE = 2 * 1024 * 1024
MAX_OUTPUT = 2 * 1024 * 1024
SOURCE = pathlib.Path('/app/mcp/server.py')

def sha(value):
    return hashlib.sha256(value).hexdigest()

def require(condition, message):
    if not condition:
        raise ValueError(message)

def json_bytes(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()

def run():
    started = time.monotonic()
    parser = argparse.ArgumentParser()
    parser.add_argument('--expected-source-sha256', required=True)
    parser.add_argument('--genuine-json-b64', default='')
    parser.add_argument('--genuine-json-sha256', default='')
    args = parser.parse_args()
    require(re.fullmatch('[0-9a-f]{64}', args.expected_source_sha256), 'expected source hash required')
    require(SOURCE.stat().st_size <= MAX_SOURCE, 'source size exceeds cap')
    source = SOURCE.read_bytes()
    require(sha(source) == args.expected_source_sha256, 'installed source hash mismatch')
    tree = ast.parse(source, filename=str(SOURCE))
    functions = [n for n in tree.body if isinstance(n, ast.AsyncFunctionDef) and n.name == 'outcome_kpi']
    require(len(functions) == 1, 'outcome_kpi definition count differs')
    assignments = [n for n in ast.walk(functions[0]) if isinstance(n, ast.Assign) and any(
        ast.unparse(target) == "vpd_policy['realized_solar_night_dryout']" for target in n.targets)]
    require(len(assignments) == 1, 'projection assignment count differs')
    assignment = assignments[0]
    require(len(assignment.targets) == 1, 'unexpected chained assignment')
    code = compile(ast.Module(body=[assignment], type_ignores=[]), str(SOURCE), 'exec')
    assignment_source = ast.get_source_segment(source.decode(), assignment)

    def project(rows):
        supplied = copy.deepcopy(rows)
        namespace = {'dryout': supplied, 'vpd_policy': {}, '__builtins__': {
            'sum': sum, 'max': max, 'any': any, 'all': all}}
        exec(code, namespace)  # Exact hash-bound repository assignment only.
        result = namespace['vpd_policy']['realized_solar_night_dryout']
        require(result['episodes'] == rows and supplied == rows, 'projection changed episode rows')
        return result

    def episode(status):
        return {'safety_gate_status': status, 'dryout_disposition': 'insufficient_evidence',
                'daytime_dry_action_samples': None, 'daytime_hold_admission_samples': None,
                'evidence_status': 'incomplete', 'confound_reasons': ['synthetic_missing_outdoor_ah'],
                'observed_indoor_ah_delta_10_20m_g_m3': None}

    cases = [([], 'pending'), (['pass'], 'pass'), (['pass', 'pass'], 'pass'),
             (['fail'], 'fail'), (['pass', 'incomplete', 'fail'], 'fail'),
             (['incomplete'], 'incomplete'), (['pass', 'incomplete'], 'incomplete'),
             (['unknown'], 'incomplete'), ([None], 'incomplete'),
             (['pass', None], 'incomplete')]
    regression = []
    for statuses, expected in cases:
        rows = [episode(status) for status in statuses]
        result = project(rows)
        actual = result['safety_gate_status']
        passed = actual == expected and result['dispositions']['effective'] == 0
        regression.append({'input_safety_statuses': statuses, 'expected': expected,
                           'actual': actual, 'passed': passed, 'synthetic': True,
                           'original_rows_preserved': result['episodes'] == rows,
                           'effective_disposition_count': result['dispositions']['effective']})
    genuine = {'provided': False, 'qualification': 'NO_GENUINE_QUERY_RESULT_SUPPLIED'}
    embedded = globals().get('GENUINE_INPUT_B64', '')
    require(not (embedded and args.genuine_json_b64), 'multiple genuine input sources')
    encoded = embedded or args.genuine_json_b64
    if encoded:
        require(isinstance(encoded, str) and len(encoded) <= (MAX_INPUT + 2) // 3 * 4, 'input encoded size exceeds cap')
        raw = base64.b64decode(encoded, validate=True)
        require(len(raw) <= MAX_INPUT, 'input size exceeds cap')
        require(re.fullmatch('[0-9a-f]{64}', args.genuine_json_sha256) and sha(raw) == args.genuine_json_sha256, 'genuine input hash mismatch')
        packet = json.loads(raw, parse_constant=lambda value: (_ for _ in ()).throw(ValueError('nonfinite JSON')))
        require(isinstance(packet, dict) and set(packet) == {'query_receipt_sha256', 'episodes'}, 'genuine packet shape')
        require(re.fullmatch('[0-9a-f]{64}', packet['query_receipt_sha256']), 'query receipt hash required')
        rows = packet['episodes']
        require(isinstance(rows, list) and len(rows) <= 500 and all(isinstance(r, dict) for r in rows), 'episode row bound/shape')
        result = project(rows)
        counts = {}
        for field in ['daytime_dry_action_samples', 'daytime_hold_admission_samples']:
            values = [r.get(field) for r in rows]
            complete = bool(values) and all(type(v) is int and v >= 0 for v in values)
            counts[field] = {'input_values': values, 'availability': 'present_on_all_supplied_rows' if complete else 'unknown',
                             'acceptance_value': max(values) if complete else None,
                             'actual_projection_value': result[field],
                             'coverage_or_measured_zero_not_proven_by_projection': True}
        genuine = {'provided': True, 'input_sha256': sha(raw),
                   'query_receipt_sha256': packet['query_receipt_sha256'],
                   'query_receipt_independently_verified_by_this_process': False,
                   'input_rows_sha256': sha(json_bytes(rows)), 'row_count': len(rows),
                   'original_rows_preserved': result['episodes'] == rows,
                   'actual_installed_projection': result, 'daytime_count_availability': counts,
                   'distinguishes_prior_false_pass': bool(rows) and all(r.get('safety_gate_status') != 'fail' for r in rows)
                       and any(r.get('safety_gate_status') != 'pass' for r in rows),
                   'actual_query_execution_or_coverage_revalidated': False}
    else:
        require(not args.genuine_json_sha256, 'hash supplied without genuine input')
    report = {'schema': 'verdify-410-installed-projection-v1',
              'status': 'PASSED' if all(x['passed'] for x in regression) else 'REGRESSION_FAILED',
              'qualification_scope': 'INSTALLED_CODE_PROJECTION_ONLY',
              'source_path': str(SOURCE), 'actual_source_sha256': sha(source),
              'assignment_source_sha256': sha(assignment_source.encode()),
              'assignment_lines': [assignment.lineno, assignment.end_lineno],
              'runtime': {'python': sys.version, 'executable': sys.executable,
                          'implementation': platform.python_implementation(), 'platform': sys.platform,
                          'uid': os.getuid(), 'pid': os.getpid()},
              'synthetic_regressions': regression, 'genuine': genuine,
              'service_imported': False, 'network_or_database_called': False,
              'authenticated_dispatch_verified': False, 'planner_consumption_verified': False,
              'whole_issue_acceptance': False, 'elapsed_seconds': round(time.monotonic() - started, 6)}
    output = json_bytes(report)
    require(len(output) <= MAX_OUTPUT, 'output exceeds cap')
    print(output.decode())
    return 0 if report['status'] == 'PASSED' else 1

if __name__ == '__main__':
    try:
        sys.exit(run())
    except Exception as exc:
        print(json.dumps({'schema': 'verdify-410-installed-projection-v1', 'status': 'REFUSED_OR_FAILED',
                          'failure_type': type(exc).__name__, 'message': str(exc)[:500],
                          'authenticated_dispatch_verified': False,
                          'planner_consumption_verified': False, 'whole_issue_acceptance': False}))
        sys.exit(1)
