from pathlib import Path
import hashlib,json
D=Path('/private/tmp/verdify-410-timeout-diagnosis-20261018')
original=(D/'03-one-candidate-readonly.sql').read_text()
assert hashlib.sha256(original.encode()).hexdigest()=='77fd3df153bc561b3d9d49f7fedebf33bbf0b123ce6f57bd0048067970374dcd'
guard=original[original.index('BEGIN READ ONLY;'):original.index('WITH bounded AS MATERIALIZED (')]
body=original[original.index('WITH bounds AS NOT MATERIALIZED ('):]
prefix=body[:body.index('action_rows AS (')]
assert prefix.endswith('),\n')
query='''helper_sample AS MATERIALIZED (
 SELECT * FROM climate_minute ORDER BY bucket LIMIT 64
),
helper_evaluated AS MATERIALIZED (
 SELECT jsonb_build_object(
   'climate',to_jsonb(c),
   'solar_phase',public.fn_solar_phase(c.bucket),
   'band_temp_low',b.temp_low,
   'house_vpd_low',h.house_vpd_low,
   'indoor_ah_g_m3',public.fn_absolute_humidity_g_m3(c.temp_f,c.rh_pct),
   'outdoor_ah_g_m3',public.fn_absolute_humidity_g_m3(c.outdoor_temp_f,c.outdoor_rh_pct)
 ) AS row_json
 FROM helper_sample c
 CROSS JOIN LATERAL public.fn_band_setpoints(c.bucket) b
 CROSS JOIN LATERAL public.fn_house_vpd_control_band(c.bucket) h
),
micro_counts AS MATERIALIZED (
 SELECT jsonb_build_object(
 'selected_climate_minutes',(SELECT count(*) FROM helper_sample),
 'helper_result_rows',count(*),
 'evaluated_row_json_bytes',COALESCE(sum(octet_length(row_json::text)),0)
 ) AS counts FROM helper_evaluated
),
completion_clock AS MATERIALIZED (
 SELECT counts,statement_timestamp() AS query_started_at,
 clock_timestamp() AS query_finished_at FROM micro_counts
)
SELECT jsonb_build_object('kind','04c-first64-helper-microread',
 'night_date','2026-10-16','sample_limit',64,
 'scope','first_64_real_climate_minutes_helpers_without_readback_intervals_or_response',
 'counts',counts,'query_started_at',query_started_at,'query_finished_at',query_finished_at,
 'query_elapsed_ms',extract(epoch FROM (query_finished_at-query_started_at))*1000)
FROM completion_clock;
ROLLBACK;
'''
sql=('''-- CONDITIONAL: ROOT may select once only if B times out after A completes.
-- First <=64 genuine climate minute buckets in the exact Oct16 source window.
-- Relevant helper values and all selected climate fields consumed, counts only.
-- No readback joins: fallback values deliberately forced even if snapshot exists.
-- Thus this is a helper microcost, not the exact original per-minute call count.
'''+guard.replace('candidate_execution_identity_guard','04c_helper_microread_identity_guard')+prefix+query)
p=D/'04c-first64-helper-microread.sql';p.write_text(sql)
print(json.dumps({'path':str(p),'sha256':hashlib.sha256(sql.encode()).hexdigest(),'bytes':len(sql.encode()),'source_prefix_sha256':hashlib.sha256(prefix.encode()).hexdigest()}))
