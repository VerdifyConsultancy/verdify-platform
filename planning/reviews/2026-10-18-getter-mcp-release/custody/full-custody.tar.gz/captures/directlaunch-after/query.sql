BEGIN READ ONLY;
SET LOCAL statement_timeout='2s'; SET LOCAL lock_timeout='500ms'; SET LOCAL idle_in_transaction_session_timeout='10s'; SET LOCAL max_parallel_workers_per_gather=0; SET LOCAL work_mem='4MB';
SELECT json_build_object('state',(SELECT row_to_json(s) FROM (SELECT experiment_id::text, protocol_version, experiment_kind,
       lifecycle_status, execution_phase, admission_state,
       component_enabled, lease_generation, revision_bundle_sha256,
       firmware_revision, config_revision, registry_revision, grid_revision,
       design_lock_sha256, open_exposure_count
  FROM public.fn_experiment_v2_api_status('45039c86-c1d9-52f6-a0a9-d94a17bc4b14'::uuid)) s),'attempt',(SELECT row_to_json(a) FROM (SELECT authorization_id::text, attempt_number,
       revision_bundle_sha256, attempt_failed, attempt_superseded,
       resolution_kind, emergency_recovery_complete,
       proof_receipt_id::text
  FROM public.fn_experiment_v2_direct_proof_attempt_status('45039c86-c1d9-52f6-a0a9-d94a17bc4b14'::uuid)) a));
ROLLBACK;
