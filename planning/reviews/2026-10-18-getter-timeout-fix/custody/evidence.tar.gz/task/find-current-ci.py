import json,subprocess,pathlib,sys,re
revision,output=sys.argv[1:];assert re.fullmatch('[0-9a-f]{40}',revision);raw=subprocess.check_output(['kubectl','--context','vallery','--request-timeout=15s','-n','agent-fleet-ci','get','workflows','-l','agent-fleet.vallery.net/repo=verdifyconsultancy-verdify-platform,workflows.argoproj.io/completed=false','-o','json'],timeout=20);matches=[]
for w in json.loads(raw)['items']:
 p={x['name']:x.get('value') for x in w['spec'].get('arguments',{}).get('parameters',[])}
 if p.get('revision')==revision:matches.append(w)
assert len(matches)==1,(revision,len(matches));w=matches[0];pathlib.Path(output).open('x').write(json.dumps(w,indent=2)+'\n');print(json.dumps({'name':w['metadata']['name'],'uid':w['metadata']['uid'],'phase':w.get('status',{}).get('phase'),'revision':revision}))
