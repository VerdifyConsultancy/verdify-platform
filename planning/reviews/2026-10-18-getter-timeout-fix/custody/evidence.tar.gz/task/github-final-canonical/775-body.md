# Campaign: trustworthy greenhouse outcomes → qualified pilot → evidence-backed control

Campaign: #775 · Stage: **C0 — Measurement and incident truth** · Priority: P0 · Effort: L · Accountable role: Evidence/data lead.

Roles name execution responsibilities and preserve existing assignees. This contract supersedes conflicting historical sequencing; prior comments and receipts remain evidence.

## Current state and next action

The selected getter repair is installed and its ordinary-role result path is verified. Source 8d7ff1a2 passed the full native gate and three selected builds; release-pin commit 8c224302 promoted only migrate. The owning plan/apply Jobs and exact poststate prove migration 277 plus its MCP seal/receipt, with prior ledger and captured ordinary authority/study state preserved. Actual ordinary calls completed within the unchanged 15-second budget: the original October 16 window returned zero rows/pending; the selected October 4 custom/generic calls returned the same four 46-column rows, with two ineffective and two insufficient-evidence dispositions. Neither clone timing nor narrow safety status is being presented as physical efficacy or full issue acceptance. Post-migration HTTP readiness and the existing 23-tool Iris inventory/denial passed on both unchanged MCP replicas; smoke9/9, exactly one ESP32 connection, all15 Deployment specs/UIDs and the six serving Pod/container identities were verified. Argo comparison is Synced/Healthy at8c224302; the new migration is proved by its separate owning Jobs, not the old Argo operation.

Current execution allocation: ROLLUP. Next action: Advance the remaining measured daytime evidence, intended outcome-consumer route, authentic scientific inputs and physical/recovery work. Reuse the installed getter and accepted MCP/S3B receipts; retain negative and inconclusive outcomes, unchanged acceptance edges and the original effort estimates without inferring remaining hours.

The retained 18:13:18 UTC native graph matched the canonical plan: 47 open issues, 143 open acceptance clauses, 26 local plus HA #878 → #981 active edges (27 total), 24 closed predecessor records, matching parent/open-subissue links and no cycle in the captured graph. The current publication retains final source-bound native conformance in its custody receipt. Preserve original 22–34h/40h estimates without inferring remaining hours.

Evidence: planning/reviews/2026-10-18-getter-timeout-fix/README.md. Previously accepted S3B/MCP work and historical failures remain intact. Acceptance clauses, states, parentage and dependencies remain unchanged.

## What

Own the current campaign contract, accepted-scope ledger and bounded execution cadence across all open issues through an evidence-backed pilot decision.

## Why

A completed preparation packet, healthy runtime or bounded clone proof does not finish an issue or the campaign. Current planning must identify the actual technical and empirical gaps, preserve accepted work and avoid repeated proof or unnecessary full-issue gates.

## How / implementation strategy

1. Maintain one current status-aware contract per issue with matching native dependencies and no parent-as-blocker loops.
2. Preserve original S3 estimates as historical planning and the S3B 40-hour budget / 22–34h selected estimates plus at least 6h reserve. Record completed bounded packets separately from full issue acceptance and measured effort.
3. Reuse completed P1 native/P2 admission/P4 custody, accepted MCP release and the installed getter 277. Advance measured daytime coverage, intended admin/planner outcome consumption and physical/input gaps while retaining ineffective, incomplete and empty results and avoiding repeated accepted delivery.

## Source touchpoints

- `planning`
- `PROJECT_BOARD.md`
- `MILESTONES.md`
- `EPICS.md`
- `LANES.md`
- `SPRINTS.md`

## Dependencies and scope

No in-repository parent; any external ownership is recorded in this contract. Parentage is a roll-up, not a blocking dependency.

No in-repository predecessor. External blockers, when present, are recorded in the current state and reviewed native graph. Pull according to stage priority and the concrete safety/physical conditions below; no blanket human gate is implied.

## Acceptance and validation

- [ ] Each current open issue has a disposition, accountable role, next action and actual remaining acceptance.
- [ ] Native active graph equals planning source and is acyclic with no parent-as-blocker loops.
- [ ] The bounded pilot ends in a reproducible result, including inconclusive/no-benefit if warranted.

## Delivery and real end-state verification

Close the roll-up only when each in-scope child has its own acceptance receipt or an explicit, linked scope decision. A closed child is evidence of its stated boundary, not proof of a broader product claim.

## Rollback and evidence preservation

Preserve child receipts and closed history. Replan explicitly when evidence fails; do not waive a safety invariant, reopen a locked draw, or call an incomplete campaign complete.

## Decisions / physical boundary

No old credential or two-message approval is pending. Future physical window, exact design/launch and measurement-scope decisions should be raised only with concrete ready packets; not as a blanket planning gate.

## Child deliverables

- [ ] #778 — Investigate September 4 hot/dry peak and three-hour wetting interruption (closed; see recorded disposition)
- [ ] #779 — Re-run historical planner comparisons on a fixed sensor panel and fixed target contract (closed; see recorded disposition)
- [ ] #780 — Score as-of outdoor forecasts against outdoor truth and separate indoor response (closed; see recorded disposition)
- [ ] #781 — Commission a claim-safe water and electricity endpoint contract (closed; see recorded disposition)
- [ ] #581 — Complete the bounded AI-admission pilot and publish a decision (open; see recorded disposition)
- [ ] #644 — Integrate exact-SHA, path-aware and device-safe delivery receipts (closed; see recorded disposition)
- [ ] #427 — Prove active Hermes/MCP recovery and truthful non-authoritative worker health (closed; see recorded disposition)
- [ ] #75 — Observability program: prove actionable health from source through device (open; see recorded disposition)
- [ ] #218 — Durability program: recoverable backups, measured RPO/RTO and safe HA option (open; see recorded disposition)
- [ ] #359 — Control program: truthful crop corridors before evidence-led tuning (open; see recorded disposition)
- [ ] #214 — Prove crop-deviation trigger → valid plan on the sole operational planner path (closed; see recorded disposition)
- [ ] #350 — Irrigation program: topology truth, overwatering protection and commissioned wall feed (open; see recorded disposition)
- [ ] #16 — Hardware program: commission only the sensing and equipment justified by evidence (open; see recorded disposition)
- [ ] #174 — Rehome only current Verdify admin surfaces to global SSO, fail closed (closed; see recorded disposition)
- [ ] #14 — Twin program: qualify declared oracle coverage before using divergence as a gate (open; see recorded disposition)
- [ ] #638 — Unify future manifest/vector wire schema and content identity offline (closed; see recorded disposition)
- [ ] #586 — Qualify a future atomic firmware policy engine with crash-safe recovery (closed; see recorded disposition)
- [ ] #786 — Decide whether a deterministic forecast comparator merits a new study (open; see recorded disposition)
- [ ] #787 — Decide and scope a measured heating/overnight/resource study (open; see recorded disposition)

## Campaign references

[Current plan](https://github.com/VerdifyConsultancy/verdify-platform/blob/main/planning/README.md) · [Dependency graph](https://github.com/VerdifyConsultancy/verdify-platform/blob/main/planning/DEPENDENCIES.md) · [Validated source](https://github.com/VerdifyConsultancy/verdify-platform/blob/main/planning/backlog.yaml).

Original issue bodies and metadata are retained in [the October 17 before-images](https://github.com/VerdifyConsultancy/verdify-platform/blob/main/planning/reviews/2026-10-17-replan/before-open-issues.json) and [the original campaign snapshot](https://github.com/VerdifyConsultancy/verdify-platform/blob/main/planning/archive/2026-09-05/issues.json). Closed issue history and comments remain intact. Planning does not perform a deployment, device change, random draw or experiment launch.
