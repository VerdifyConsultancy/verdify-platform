"""Finite read-only named Workflow/Pod and assigned-node admission snapshot."""
import datetime,json,pathlib,subprocess,hashlib
O=pathlib.Path('/private/tmp/verdify-getter-fix-20261018/ci-queue-diagnosis-01')
O.mkdir(exist_ok=False)
def get(args,name):
 p=subprocess.run(['kubectl','--context','vallery','--request-timeout=15s',*args,'-o','json'],capture_output=True,timeout=20)
 (O/(name+'.private.json')).write_bytes(p.stdout);(O/(name+'.stderr')).write_bytes(p.stderr)
 if p.returncode:raise RuntimeError(name+': '+str(p.returncode))
 return json.loads(p.stdout)
w=get(['-n','agent-fleet-ci','get','workflow','verdify-platform-ci-26nj4'],'workflow')
assert w['metadata']['uid']=='74fa9db5-5fd2-4a52-abf5-6a210ec8c49f'
p=get(['-n','agent-fleet-ci','get','pods','-l','workflows.argoproj.io/workflow=verdify-platform-ci-26nj4'],'pods')
c=get(['-n','agent-fleet-ci','get','configmap','agent-fleet-ci-concurrency'],'concurrency')
nodes=sorted({x['spec']['nodeName'] for x in p['items'] if x['spec'].get('nodeName')})
node_records=[]
for name in nodes:
 n=get(['get','node',name],'node-'+name)
 metric=subprocess.run(['kubectl','--context','vallery','--request-timeout=15s','get','--raw','/apis/metrics.k8s.io/v1beta1/nodes/'+name],capture_output=True,timeout=20)
 (O/('node-'+name+'-metrics.private.json')).write_bytes(metric.stdout);(O/('node-'+name+'-metrics.stderr')).write_bytes(metric.stderr)
 node_records.append({'name':name,'allocatable':n['status']['allocatable'],'conditions':[{k:x.get(k) for k in ['type','status','reason','lastTransitionTime']} for x in n['status']['conditions']], 'unschedulable':n['spec'].get('unschedulable',False),'metrics':json.loads(metric.stdout) if metric.returncode==0 else {'unavailable_exit':metric.returncode}})
s=w.get('status',{})
summary={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'workflow_name':w['metadata']['name'],'uid':w['metadata']['uid'],'phase':s.get('phase'),'started_at':s.get('startedAt'),'synchronization':s.get('synchronization'),'semaphore_capacity':c.get('data',{}).get('repo-validate'),'nodes':[{k:v.get(k) for k in ['id','displayName','type','phase','message','startedAt','finishedAt']} for v in s.get('nodes',{}).values()],'pods':[],'assigned_nodes':node_records,'mutations':0}
for pod in p['items']:
 summary['pods'].append({'name':pod['metadata']['name'],'uid':pod['metadata']['uid'],'created_at':pod['metadata']['creationTimestamp'],'node':pod['spec'].get('nodeName'),'phase':pod['status']['phase'],'conditions':pod['status'].get('conditions',[]),'init_statuses':pod['status'].get('initContainerStatuses',[]),'container_statuses':pod['status'].get('containerStatuses',[]),'resources':{'init':{x['name']:x.get('resources') for x in pod['spec'].get('initContainers',[])},'containers':{x['name']:x.get('resources') for x in pod['spec'].get('containers',[])}}})
summary['evidence']={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(O.glob('*.private.json'))}
(O/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'at':summary['at'],'phase':summary['phase'],'semaphore_capacity':summary['semaphore_capacity'],'nodes':summary['nodes'],'pods':[{'name':x['name'],'node':x['node'],'phase':x['phase'],'init':[{k:y.get(k) for k in ['name','state','restartCount']} for y in x['init_statuses']],'main':[{k:y.get(k) for k in ['name','state','restartCount']} for y in x['container_statuses']]} for x in summary['pods']],'assigned_nodes':node_records,'summary_sha256':hashlib.sha256((O/'summary.json').read_bytes()).hexdigest()},indent=2))
