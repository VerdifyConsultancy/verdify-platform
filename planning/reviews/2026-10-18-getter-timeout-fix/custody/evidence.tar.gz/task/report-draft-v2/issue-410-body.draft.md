# Measure realized solar-night dry-out before changing the controller

Campaign: #775 · Stage: **C6 — Evidence-led control and irrigation** · Priority: P1 · Effort: L · Accountable role: Control lead.

Roles name execution responsibilities and preserve existing assignees. This contract supersedes conflicting historical sequencing; prior comments and receipts remain evidence.

## Current state and next action

Migration 277 is installed through the owning migrate-only plan/apply Jobs from qualified source 8d7ff1a2 and release-pin commit 8c224302. Corrected native workflow 26nj4 completed successfully with five Pods, all declared containers exiting zero without restarts, and three exact-source images; only migrate was promoted. The plan changed no captured state. Apply added exactly the runner-stamped 277 row, replaced the getter body and advanced the MCP seal/receipt; prior ledger rows, ordinary receipts and captured role/security/study metadata were preserved. Twenty native full-46-column synthetic parity cases and 2,673 genuine clone readback relations support the rewrite; original failures and the separate limits of those proofs remain retained.

The actual ordinary MCP LOGIN/attester path on the two unchanged replicas returned the original October 16 window in 11.816649 seconds with zero rows and pending status. The explicitly selected October 4 window returned four rows in 11.269874 seconds with a custom plan and 4.966761 seconds with a generic plan; all 46 values matched across those separate historical snapshots. Two episodes are complete/ineffective and two are incomplete/insufficient-evidence; none is effective. The configured 15-second timeout was unchanged. The earlier 3.174204-second clone candidate result is not an installed-production timing. Observed daylight had zero hold samples, but complete daytime coverage, positive admin dispatch and planner consumption are not proved. Runtime HTTP/smoke evidence is being finalized separately by ROOT.

Current execution allocation: S3B follow-up. Next action: Use the installed validity-bearing results to complete a bounded daytime-coverage assessment and verify the intended admin/planner consumption paths through existing approved identities. Distinguish observed zero holds from complete measured absence, preserve ineffective/incomplete outcomes, and keep crop-sensing and physical-efficacy requirements explicit. Reuse the accepted getter delivery; no repair retry, new credential or broader audience is required by this checkpoint.

Evidence: planning/reviews/2026-10-18-getter-timeout-fix/README.md. All three acceptance clauses and completion edges remain open and unchanged; this completes the bounded getter repair, not the broader scientific/control issue.

## What

Deliver validity-bearing solar-night moisture-removal episodes and a measured effective/ineffective/blocked/insufficient-evidence disposition.

## Why

Projected gain, a fixed clock window and a few favorable nights cannot establish reliable greenhouse-wide dry-out or justify a Vanda watering program.

## How / implementation strategy

1. Reuse the installed migration 277, native parity and exact ledger/seal/receipt evidence. Preserve original failures, full 46-column results, NULL and tie behavior, helper cardinality and solar/response semantics; do not repeat the completed repair to claim broader acceptance.
2. Reuse the accepted MCP-only release and actual installed ordinary-role getter results on both replicas. Verify positive outcome-tool dispatch through an existing approved admin identity and separately qualify the intended planner consumption path; do not silently add the admin-only tool to Iris or expand credentials/audiences for proof.
3. Preserve episode dispositions, confounds and evidence status. Require actual available complete daytime evidence for measured-zero held admission; legacy empty/null0 is unknown for acceptance. Keep solar, heat2, wind/dwell/temperature safeguards and ordinary daytime dehumidification.
4. Qualify an explicitly scoped ordinary-planner input route separately; outcome_kpi is admin-only and absent from Iris context. Physical efficacy, crop safety and tuning need their own evidence.

## Source touchpoints

- `db/migrations`
- `firmware`
- `research/planner-efficacy`
- `mcp`
- `scripts`

## Dependencies and scope

Parent: #359. Parentage is a roll-up, not a blocking dependency.

Predecessor records: #371 (closed), #419 (closed), #424 (closed). Open records gate the stated bounded deliverable; closed records retain their original disposition and are not active blockers. Preparation may proceed earlier.

## Acceptance and validation

- [ ] Episodes use device solar semantics, never fixed 02:00–06:00, and incomplete/confounded episodes cannot be PASS.
- [ ] Solar-day held-temperature admission is zero while ordinary daytime dehumidification remains correctly distinguished.
- [ ] Planner/MCP sees realized validity-bearing outcomes and explicit disposition, not a universal VPD target or a crop-safety claim without sensing.

## Delivery and real end-state verification

Deliver the smallest complete owner change, use enforced checks and the existing supported delivery path, then verify the issue-specific end state. Heavy tests/builds run in admitted k3s workloads. Source or CI success does not establish runtime, physical or scientific acceptance.

## Rollback and evidence preservation

Keep original extraction and definitions immutable; supersede with a new version and compare hashes. Never rewrite locked assignments, outcomes or an earlier analysis to improve a result.

## Decisions / physical boundary

The authorized getter repair is installed and ordinary-role behavior is verified within the existing 15-second product fence. No new credential, admin audience, planner access, controller tuning, physical experiment or OTA was created. Remaining daytime, consumer-route, sensing and physical acceptance is explicit; the repair is not a new approval gate for bounded follow-up work.

## Campaign references

[Current plan](https://github.com/VerdifyConsultancy/verdify-platform/blob/main/planning/README.md) · [Dependency graph](https://github.com/VerdifyConsultancy/verdify-platform/blob/main/planning/DEPENDENCIES.md) · [Validated source](https://github.com/VerdifyConsultancy/verdify-platform/blob/main/planning/backlog.yaml).

Original issue bodies and metadata are retained in [the October 17 before-images](https://github.com/VerdifyConsultancy/verdify-platform/blob/main/planning/reviews/2026-10-17-replan/before-open-issues.json) and [the original campaign snapshot](https://github.com/VerdifyConsultancy/verdify-platform/blob/main/planning/archive/2026-09-05/issues.json). Closed issue history and comments remain intact. Planning does not perform a deployment, device change, random draw or experiment launch.
