# Getter 277 installed repair and real outcome readback

The bounded getter timeout repair is installed, and actual ordinary MCP role calls now return results within the unchanged 15-second product limit. The original October 16 night remains empty/pending. The deliberately selected October 4 historical window returns four episodes: two complete but ineffective, and two incomplete with insufficient evidence. No episode is classified effective. This finishes the selected repair and result-path proof; #410 and #775 remain open.

## Actual delivery

The first source attempt `16d13f64` and workflow `5vzfd` failed the full gate because the new forward migration was missing from the historical baseline-stamp exception. Correction `8d7ff1a2829c246600da4f15027121e9c7193913` retained the already-qualified SQL and seals. Workflow `verdify-platform-ci-26nj4`, UID `74fa9db5-5fd2-4a52-abf5-6a210ec8c49f`, completed at 18:59:57 UTC. All five actual Pods have complete zero-exit, zero-restart container custody. The normal pipeline built ingestor, migrate and lab-publisher; only migrate was promoted by `8c2243020e82f52fbdf3169278715302f7688edf`.

The delivered migrate image is `registry.vallery.net/verdifyconsultancy/verdify-migrate@sha256:0bdb10cfd458de4b1bd4e201024efbf19aa724e0087cf5dcf88ce02c9a0043ae`. The owning plan Job UID `acb9cac5-d4fa-41dc-b3e1-ee5d95cddda8` completed without changing captured state. The separate apply Job UID `288535fc-7290-4954-bf65-ea206eb5ea5b` completed with both containers exiting zero and no restarts. Its runner stamped migration 277 at 19:03:05.611609 UTC. No full Application sync or unrelated bootstrap/study hook was used for this operation.

Exact poststate comparison permits only the new 277 ledger row, getter body/definition and MCP computed/stored boundary. All 284 prior ledger rows remain exact; the new count is 285. Captured ordinary receipts, role metadata, memberships/settings and study state match. Getter metadata other than its body is preserved. This is a scoped metadata/source comparison, not an all-table or whole-database proof; password evidence is presence-only plus source/role custody, not verifier-value equality.

| Bound source | SHA256 |
|---|---|
| Migration 277 | `a8a0bc063bd655d2e96dd3d424768169edb4ea714c7a1b51dca2b41cc39b29a1` |
| Getter body | `578a07bed56714cd2dfe2308ca30ced1f6fc6916fd7db9d79630a7b82b261655` |
| Installed definition | `89782089fd6ae3ecfeecdfbc1b730f6ab6a272c0da7b35ef562788eddbfa42c0` |
| MCP computed boundary and stored receipt | `1cd20508c9196bf9758d7df40ae699e6b83aefccb91a4c5242492f7993f6eb02` |

## Installed ordinary-role results

These measurements use the actual ordinary MCP LOGIN and attester on the two unchanged MCP replicas, in three separately captured read-only repeatable-read sessions. They are not clone measurements or owner-only ad-hoc candidate queries.

| Night | Prepared plan | Actual getter time | Result |
|---|---|---:|---|
| October 16 | Custom | 11.816649 s | 0 rows; pending |
| October 4 | Custom | 11.269874 s | 4 rows: 2 ineffective, 2 insufficient-evidence |
| October 4 | Generic | 4.966761 s | The same 4 rows, exact equality across all 46 fields |

The configured timeout remains 15,000 ms. No timeout was increased. The narrow safety field for the four historical rows is pass while evidence completeness remains two complete/two incomplete; that field does not turn the incomplete episodes into accepted scientific evidence. The October 16 empty result remains pending. These are finite measured calls, not a repeated-load latency guarantee or all-plan-mode proof for every date.

## Qualification and original limits

The rewrite preserves the 46-column contract, historical seed/tie semantics, grouped-event MAX, NULL-event stop behavior, both inner helper cardinalities and the scientific tail. Twenty actual native synthetic old/new full-row cases passed. A same-snapshot genuine clone relation comparison retained all 2,673 readback rows and found zero EXCEPT ALL differences, including NULL and duplicate multiplicity. These are complementary proofs: synthetic helpers do not prove physical behavior, and the readback relation deliberately excludes the helper/scientific tail.

The separate clone candidate B timing of 3.174204 seconds is retained as qualification evidence only. It is not advertised as installed production latency. Full original real-data reference calls timed out at 15 and 30 seconds, so no successful complete original real-data rowset exists. Candidate A/B four-row equality used separate historical snapshots. Original 2-second failures, the first fixture-runner syntax failure and the first full CI failure remain unchanged.

Before installation, the original October 16 source-body result had 2,785 climate/action/resolved minutes and 750 selected solar-night minutes, with zero active, demand or admitted minutes and no null served VPD. This supported a genuine empty result rather than missing all source input. Daylight observations contained zero hold-action samples and 12/2 ordinary dry-action samples across October 16/17, but complete daytime coverage was not established. Do not infer complete measured absence from those counts.

## Remaining work and publication boundary

ROOT is finalizing the post-migration HTTP, smoke, single-writer and runtime readback. Add that receipt here; this draft does not claim it completed. The getter repair itself and its ordinary-role result proof are complete and should not be queued again.

The next work is a bounded daytime-coverage assessment and the intended outcome-consumer route. Positive admin tool dispatch and ordinary-planner consumption are still unverified. Use existing approved identities and preserve the current audience boundary; this checkpoint does not require new credentials or silently expose the admin-only outcome tool to Iris. Physical efficacy, crop safety and missing sensing require their own evidence. The four real rows provide negative/incomplete results, not a controller-tuning or watering recommendation.

The retained 18:13:18 UTC native graph matched 47 open issues, 143 open acceptance clauses, 26 local plus HA #878 → #981 active edges, 24 closed predecessor records, exact open parent/subissue links and an acyclic captured graph. Final publication should refresh conformance after only #410/#775 baseline/how/decision wording changes. States, acceptance clauses, dependencies, assignees and priorities remain unchanged. Preserve the original 22–34h/40h estimates without inventing remaining hours.
