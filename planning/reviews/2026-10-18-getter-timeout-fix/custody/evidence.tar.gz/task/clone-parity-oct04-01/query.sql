-- One preselected complete adjacent-day window. ROOT executes once, no retry/expansion.
-- Calendar completeness is not a claim of telemetry coverage or efficacy.
BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY;
SET LOCAL statement_timeout='2s';
SET LOCAL temp_file_limit='64MB';
SET LOCAL lock_timeout='500ms';
SET LOCAL idle_in_transaction_session_timeout='10s';
SET LOCAL max_parallel_workers_per_gather=0;
SET LOCAL work_mem='4MB';
SET LOCAL TimeZone='UTC';
WITH expected_functions(name,sha) AS (VALUES
('fn_absolute_humidity_g_m3','c14ce18c1811fec25416262983126072deca690991c3b60df73b69d08fb13c92'),
('fn_band_setpoints','58a0e95e646a5de45c022438546608e1677adad000800c6784e0f6316241b281'),
('fn_center_band_setpoints','718de2d0507b4dc0adc86b8b8fdc6e93be0008a3b0041c320b8ac97eff45aaea'),
('fn_crop_band_value','e5682cb83e81c57ee44254c555d775e4f7dedf1078af3ba98ccc97f71c03d9e0'),
('fn_current_season','c35ff6fc0aa046b208da7ff7a9f03a9fcba658d0ed652c01b08f0b826e544130'),
('fn_diurnal_interp','002befc3228b8484c5bd130039ea375d987044ee53a83d3b2d6626cce37f1978'),
('fn_hermite_phase','f9642002e69bbac2d1a2dc7f9a19fb069ea86295c995713eaf37c8efa2e164fb'),
('fn_house_vpd_control_band','7aad695981e7883e562a93a1a2dceaf55a1a5bb17ccf4007748a9c851069279e'),
('fn_realized_solar_night_dryout','b9626fd5882392bcf00c080550b6ab5000cc5ed8a63ea8dceb806e76aae6d3a6'),
('fn_solar_phase','960f6e4c435ce534db8956630bd32408a3d1294362b2aef44c018189d250e715'),
('fn_solar_sunrise_hour','66795353790f6678c02f8f6af5e6d576fe8177714b07a679925360bd1f851d51'),
('fn_solar_sunset_hour','227310e3542f7e0bc06f0639724a72444a8366320cb30da07ecfc01f185a9c79'),
('fn_zone_vpd_targets','71109e38a269c68d9d1112ad4e6cf60a5efaba15b49045b1ef119a6ba658e1ff')
), expected_ledger(filename,sha) AS (VALUES
('db/migrations/145-vanda-band-and-join-fix.sql','c599744bc497a0c6bc5c39644a17eeeec7b658fc4b1081afcf65aa94e6818f35'),
('db/migrations/164-zone-vpd-targets-solar-repoint.sql','078c7e1afe025c3fa14d8ec39d422707a1f22867844959bce526907cacb0b262'),
('db/migrations/165-band-solar-noon-repoint.sql','2cdf3d6b657e2e8d1c95ebb73cc724bc9f8465a95b0e4c5e74a6deb0c9d46bed'),
('db/migrations/170-band-harmonic-smooth-curve.sql','f3e93f7df52ad899ea192ed90849a36ec79b7bc7f86a487a28d5af53024ef49b'),
('db/migrations/172-smooth-solar-phase.sql','bf0c60dc6f3553be395c32a22bdd5d1c00f3addfd689aa1def3f796db6db431e'),
('db/migrations/181-serve-band-target-one-source.sql','7992b80335450c5851545d9695811f54c20df780ec18c5ee95f2a15b888fe67a'),
('db/migrations/186-noaa-solar-phase-parity.sql','9e1e33b5005e183a35d84dd9b41d96b4d535faa99945d7ae6c89b196d4569e28'),
('db/migrations/191-realized-solar-night-dryout-episodes.sql','9aea5b0f7878df3a585884743a4d5eaf8b989c39f18cd09698e9b4973394c211')
), verdict AS (
 SELECT current_database()='verdify_rehearsal'
  AND current_user='postgres' AND session_user='postgres'
  AND current_setting('transaction_read_only')='on'
  AND pg_postmaster_start_time()='2026-10-12T18:37:06.874379+00:00'::timestamptz
  AND DATE '2026-10-16' <= (now() AT TIME ZONE 'America/Denver')::date - 2
  AND (SELECT count(*)=13 AND bool_and(
       encode(sha256(convert_to(pg_get_functiondef(p.oid),'UTF8')),'hex')=e.sha
       AND pg_get_userbyid(p.proowner)='verdify' AND p.proconfig IS NULL)
    FROM expected_functions e JOIN pg_namespace n ON n.nspname='public'
    JOIN pg_proc p ON p.pronamespace=n.oid AND p.proname=e.name AND p.prokind='f')
  AND (SELECT count(*)=8 AND bool_and(m.sha256=e.sha)
    FROM expected_ledger e JOIN public.schema_migrations m
      ON m.source='db/migrations' AND m.filename=e.filename) AS ok
)
SELECT json_build_object('kind','pilot_identity_guard','passed',1/(CASE WHEN ok THEN 1 ELSE 0 END),
 'identity_receipt_sha256','970852793d4ab0648c6b5cf8b52a5139df9f83bb7c3fa20594253fef83296388','night_date','2026-10-16',
 'database',current_database(),'postmaster_started_at',pg_postmaster_start_time(),
 'captured_at',clock_timestamp(), 'read_only',current_setting('transaction_read_only')) FROM verdict;

-- Independent cloned-data parity date; original production Oct16 pilot unchanged.
SET LOCAL statement_timeout='15s';
\timing on
WITH bounded AS MATERIALIZED (SELECT * FROM public.fn_realized_solar_night_dryout(DATE '2026-10-04',DATE '2026-10-04','vallery') ORDER BY episode_started_at,episode_id LIMIT 501) SELECT jsonb_build_object('kind','reference','date','2026-10-04','row_count',count(*),'overflow',count(*)>500,'rows',coalesce(jsonb_agg(to_jsonb(b) ORDER BY episode_started_at,episode_id),'[]'::jsonb)) FROM bounded b;
WITH bounded AS MATERIALIZED (SELECT * FROM (WITH bounds AS NOT MATERIALIZED (
    SELECT
        DATE '2026-10-04'::timestamp AT TIME ZONE 'America/Denver' AS start_ts,
        (DATE '2026-10-04' + 2)::timestamp AT TIME ZONE 'America/Denver' AS end_ts
),
climate_minute AS (
    SELECT
        date_trunc('minute', c.ts) AS bucket,
        avg(c.temp_avg)::double precision AS temp_f,
        avg(c.vpd_avg)::double precision AS vpd_kpa,
        avg(c.rh_avg)::double precision AS rh_pct,
        avg(c.outdoor_temp_f)::double precision AS outdoor_temp_f,
        avg(c.outdoor_rh_pct)::double precision AS outdoor_rh_pct
    FROM public.climate c
    CROSS JOIN bounds b
    WHERE c.greenhouse_id = 'vallery'::text
      AND c.ts >= b.start_ts
      AND c.ts < b.end_ts
      AND c.temp_avg IS NOT NULL
      AND c.vpd_avg IS NOT NULL
      AND c.rh_avg IS NOT NULL
    GROUP BY date_trunc('minute', c.ts)
),
action_rows AS (
    SELECT
        date_trunc('minute', l.ts) AS bucket,
        l.climate_action,
        l.priority_axis,
        NULLIF(
            l.source_system_state -> 'climate_moisture_exchange' ->> 'action',
            ''
        ) AS mx_action,
        NULLIF(
            l.source_system_state -> 'climate_moisture_exchange' ->> 'reason',
            ''
        ) AS mx_reason,
        COALESCE((l.relay_truth ->> 'vent')::boolean, false) AS vent_on,
        COALESCE((l.relay_truth ->> 'fan1')::boolean, false)
            OR COALESCE((l.relay_truth ->> 'fan2')::boolean, false) AS fan_on,
        COALESCE((l.relay_truth ->> 'heat1')::boolean, false) AS heat1_on,
        COALESCE((l.relay_truth ->> 'heat2')::boolean, false) AS heat2_on,
        COALESCE((l.relay_truth ->> 'fog')::boolean, false)
            OR COALESCE((l.relay_truth ->> 'mister_south')::boolean, false)
            OR COALESCE((l.relay_truth ->> 'mister_west')::boolean, false)
            OR COALESCE((l.relay_truth ->> 'mister_center')::boolean, false)
            AS wet_relay_on,
        l.relay_truth ?& ARRAY[
            'vent', 'fan1', 'fan2', 'heat1', 'heat2',
            'fog', 'mister_south', 'mister_west', 'mister_center'
        ]::text[] AS relay_evidence_present,
        COALESCE(
            (l.source_system_state -> 'climate_moisture_exchange'
                ->> 'hold_required')::boolean,
            false
        ) OR COALESCE((
            l.source_system_state -> 'climate_moisture_exchange' ->> 'reason'
                = 'vent_plus_heat_hold'
        ), false) AS hold_flavor
    FROM public.climate_action_log l
    CROSS JOIN bounds b
    WHERE l.greenhouse_id = 'vallery'::text
      AND l.ts >= b.start_ts
      AND l.ts < b.end_ts
),
classified_action_rows AS (
    SELECT
        a.*,
        (
            a.relay_evidence_present
            AND
            (a.priority_axis = 'vpd' OR a.climate_action = 'DEHUM_VENT')
            AND (
                (a.climate_action = 'DEHUM_VENT' AND a.vent_on AND a.fan_on)
                OR (a.mx_action = 'heat_assist' AND a.heat1_on)
                OR (
                    a.mx_reason = 'vent_plus_heat_hold'
                    AND a.vent_on AND a.fan_on AND a.heat1_on
                )
            )
        ) AS dry_action_admitted,
        (
            a.relay_evidence_present
            AND a.hold_flavor
            AND a.climate_action = 'DEHUM_VENT'
            AND a.vent_on
            AND a.fan_on
            AND a.heat1_on
        ) AS hold_action_admitted
    FROM action_rows a
),
action_minute AS (
    SELECT
        bucket,
        true AS action_sample_present,
        mode() WITHIN GROUP (ORDER BY climate_action) AS climate_action,
        mode() WITHIN GROUP (ORDER BY priority_axis) AS priority_axis,
        mode() WITHIN GROUP (ORDER BY mx_action) AS mx_action,
        mode() WITHIN GROUP (ORDER BY mx_reason) AS mx_reason,
        bool_or(vent_on) AS vent_on,
        bool_or(fan_on) AS fan_on,
        bool_or(heat1_on) AS heat1_on,
        bool_or(heat2_on) AS heat2_on,
        bool_or(wet_relay_on) AS wet_relay_on,
        bool_and(relay_evidence_present) AS relay_evidence_complete,
        bool_or(dry_action_admitted) AS dry_action_admitted,
        bool_or(hold_action_admitted) AS hold_action_admitted,
        mode() WITHIN GROUP (
            ORDER BY COALESCE(mx_reason, mx_action, climate_action)
        ) FILTER (WHERE dry_action_admitted) AS dry_admission_reason
    FROM classified_action_rows
    GROUP BY bucket
),
setpoint_event_rows AS (
    SELECT s.greenhouse_id, s.parameter, s.ts, s.value::double precision AS value
    FROM public.setpoint_snapshot s
    CROSS JOIN bounds b
    WHERE s.greenhouse_id = 'vallery'::text
      AND s.parameter IN ('temp_low', 'vpd_low')
      AND s.ts >= b.start_ts
      AND s.ts < b.end_ts

    UNION ALL

    (SELECT DISTINCT ON (s.greenhouse_id, s.parameter)
        s.greenhouse_id, s.parameter, s.ts, s.value::double precision
     FROM public.setpoint_snapshot s
     CROSS JOIN bounds b
     WHERE s.greenhouse_id = 'vallery'::text
       AND s.parameter IN ('temp_low', 'vpd_low')
       AND s.ts < b.start_ts
     ORDER BY s.greenhouse_id, s.parameter, s.ts DESC)
),
setpoint_events AS (
    SELECT greenhouse_id, parameter, ts, max(value)::double precision AS value
    FROM setpoint_event_rows
    GROUP BY greenhouse_id, parameter, ts
),
readback_points AS (
    SELECT bucket AS ts, NULL::text AS parameter FROM climate_minute
    UNION ALL SELECT ts, parameter FROM setpoint_events
),
readback_timeline AS (
    SELECT ts, parameter,
      max(ts) FILTER (WHERE parameter='temp_low') OVER (
        ORDER BY ts GROUPS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS temp_ts,
      max(ts) FILTER (WHERE parameter='vpd_low') OVER (
        ORDER BY ts GROUPS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS vpd_ts
    FROM readback_points
),
readback_climate AS (
    SELECT ts AS bucket, temp_ts, vpd_ts FROM readback_timeline WHERE parameter IS NULL
),
resolved AS MATERIALIZED (
    SELECT
        c.*,
        public.fn_solar_phase(c.bucket) AS solar_phase,
        COALESCE(temp_readback.value, b.temp_low) AS served_temp_low,
        COALESCE(vpd_readback.value, h.house_vpd_low) AS served_vpd_low,
        public.fn_absolute_humidity_g_m3(c.temp_f, c.rh_pct) AS indoor_ah_g_m3,
        public.fn_absolute_humidity_g_m3(c.outdoor_temp_f, c.outdoor_rh_pct)
            AS outdoor_ah_g_m3,
        COALESCE(a.action_sample_present, false) AS action_sample_present,
        a.climate_action,
        a.priority_axis,
        a.mx_action,
        a.mx_reason,
        COALESCE(a.vent_on, false) AS vent_on,
        COALESCE(a.fan_on, false) AS fan_on,
        COALESCE(a.heat1_on, false) AS heat1_on,
        COALESCE(a.heat2_on, false) AS heat2_on,
        COALESCE(a.wet_relay_on, false) AS wet_relay_on,
        COALESCE(a.relay_evidence_complete, false) AS relay_evidence_complete,
        COALESCE(a.dry_action_admitted, false) AS dry_action_admitted,
        COALESCE(a.hold_action_admitted, false) AS hold_action_admitted,
        a.dry_admission_reason
    FROM climate_minute c
    JOIN readback_climate rb USING (bucket)
    CROSS JOIN LATERAL public.fn_band_setpoints(c.bucket) b
    CROSS JOIN LATERAL public.fn_house_vpd_control_band(c.bucket) h
    LEFT JOIN setpoint_events temp_readback
      ON temp_readback.greenhouse_id = 'vallery'::text
     AND temp_readback.parameter = 'temp_low' AND temp_readback.ts = rb.temp_ts
    LEFT JOIN setpoint_events vpd_readback
      ON vpd_readback.greenhouse_id = 'vallery'::text
     AND vpd_readback.parameter = 'vpd_low' AND vpd_readback.ts = rb.vpd_ts
    LEFT JOIN action_minute a USING (bucket)
),
classified AS (
    SELECT
        r.*,
        CASE
            WHEN (r.bucket AT TIME ZONE 'America/Denver')::time < time '12:00'
                THEN (r.bucket AT TIME ZONE 'America/Denver')::date - 1
            ELSE (r.bucket AT TIME ZONE 'America/Denver')::date
        END AS night_date,
        r.solar_phase >= 2.0 AS is_solar_night,
        r.vpd_kpa < r.served_vpd_low AS dry_demand,
        r.vpd_kpa < r.served_vpd_low OR r.dry_action_admitted AS episode_active
    FROM resolved r
),
daytime_admission AS (
    SELECT
        (bucket AT TIME ZONE 'America/Denver')::date AS local_date,
        count(*) FILTER (WHERE dry_action_admitted)::int AS dry_action_samples,
        count(*) FILTER (WHERE hold_action_admitted)::int AS hold_action_samples
    FROM action_minute
    WHERE public.fn_solar_phase(bucket) < 2.0
    GROUP BY (bucket AT TIME ZONE 'America/Denver')::date
),
night_ordered AS (
    SELECT
        c.*,
        lag(episode_active) OVER (
            PARTITION BY night_date ORDER BY bucket
        ) AS previous_episode_active,
        lag(bucket) OVER (
            PARTITION BY night_date ORDER BY bucket
        ) AS previous_bucket
    FROM classified c
    WHERE is_solar_night
      AND night_date BETWEEN DATE '2026-10-04' AND DATE '2026-10-04'
),
night_tagged AS (
    SELECT
        n.*,
        sum(CASE
            WHEN episode_active
             AND (
                 previous_episode_active IS DISTINCT FROM true
                 OR previous_bucket IS NULL
                 OR bucket - previous_bucket > interval '2 minutes'
             )
            THEN 1 ELSE 0
        END) OVER (
            PARTITION BY night_date ORDER BY bucket
            ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
        )::bigint AS episode_id
    FROM night_ordered n
),
episodes AS (
    SELECT
        night_date,
        episode_id,
        min(bucket) AS episode_started_at,
        max(bucket) + interval '1 minute' AS episode_ended_at,
        extract(epoch FROM (max(bucket) + interval '1 minute' - min(bucket))) / 60.0
            AS duration_min,
        count(*)::int AS sample_minutes,
        COALESCE(max(extract(epoch FROM (bucket - previous_bucket))) FILTER (
            WHERE previous_episode_active IS TRUE
        ), 0)::int AS max_climate_gap_s,
        count(*) FILTER (WHERE dry_demand)::int AS below_served_low_minutes,
        count(*) FILTER (
            WHERE action_sample_present AND relay_evidence_complete
        )::int AS action_evidence_minutes,
        count(*) FILTER (WHERE dry_action_admitted)::int AS admitted_minutes,
        count(*) FILTER (WHERE hold_action_admitted)::int AS hold_admitted_minutes,
        mode() WITHIN GROUP (
            ORDER BY dry_admission_reason
        ) FILTER (WHERE dry_action_admitted) AS admission_reason,
        avg(indoor_ah_g_m3)::double precision AS indoor_ah_avg_g_m3,
        avg(outdoor_ah_g_m3)::double precision AS outdoor_ah_avg_g_m3,
        avg(indoor_ah_g_m3 - outdoor_ah_g_m3)::double precision
            AS ah_advantage_avg_g_m3,
        min(indoor_ah_g_m3 - outdoor_ah_g_m3)::double precision
            AS ah_advantage_min_g_m3,
        count(outdoor_ah_g_m3)::int AS outdoor_evidence_minutes,
        min(served_temp_low)::double precision AS served_temp_floor_f,
        min(temp_f)::double precision AS min_temp_f,
        min(temp_f - served_temp_low)::double precision
            AS min_temp_floor_margin_f,
        count(*) FILTER (WHERE vent_on)::int AS vent_minutes,
        count(*) FILTER (WHERE fan_on)::int AS fan_minutes,
        count(*) FILTER (WHERE heat1_on)::int AS heat1_minutes,
        count(*) FILTER (WHERE heat2_on)::int AS heat2_minutes,
        count(*) FILTER (WHERE wet_relay_on)::int AS wet_relay_minutes
    FROM night_tagged
    WHERE episode_active
    GROUP BY night_date, episode_id
),
with_response AS (
    SELECT
        e.*,
        before.vpd_kpa AS vpd_before_kpa,
        before.temp_f AS temp_before_f,
        before.samples AS before_samples,
        before.indoor_ah_g_m3 AS indoor_ah_before_g_m3,
        before.ah_samples AS before_ah_samples,
        after.vpd_kpa AS vpd_after_kpa,
        after.temp_f AS temp_after_f,
        after.samples AS after_samples,
        after.indoor_ah_g_m3 AS indoor_ah_after_g_m3,
        after.ah_samples AS after_ah_samples,
        after.wet_relay_minutes AS response_wet_relay_minutes,
        after.response_max_gap_s,
        after.min_temp_floor_margin_f AS response_min_temp_floor_margin_f,
        next_sample.solar_phase AS next_solar_phase,
        next_sample.vpd_kpa AS next_vpd_kpa,
        next_sample.served_vpd_low AS next_served_vpd_low,
        next_sample.temp_f AS next_temp_f,
        next_sample.served_temp_low AS next_served_temp_low,
        next_sample.indoor_ah_g_m3 - next_sample.outdoor_ah_g_m3
            AS next_ah_advantage_g_m3,
        next_sample.bucket AS next_bucket,
        COALESCE(d.dry_action_samples, 0)::int AS daytime_dry_action_samples,
        COALESCE(d.hold_action_samples, 0)::int
            AS daytime_hold_admission_samples
    FROM episodes e
    LEFT JOIN LATERAL (
        SELECT
            avg(c.vpd_kpa)::double precision AS vpd_kpa,
            avg(c.temp_f)::double precision AS temp_f,
            count(*)::int AS samples,
            avg(c.indoor_ah_g_m3)::double precision AS indoor_ah_g_m3,
            count(c.indoor_ah_g_m3)::int AS ah_samples,
            count(*) FILTER (WHERE c.wet_relay_on)::int AS wet_relay_minutes
        FROM resolved c
        -- Outcome baseline is the first five measured minutes of the demand
        -- episode, not the preceding in-band period.  Compare that realized
        -- onset with the observed 10-20 minute window.
        WHERE c.bucket >= e.episode_started_at
          AND c.bucket < e.episode_started_at + interval '5 minutes'
    ) before ON true
    LEFT JOIN LATERAL (
        SELECT
            avg(c.vpd_kpa)::double precision AS vpd_kpa,
            avg(c.temp_f)::double precision AS temp_f,
            count(*)::int AS samples,
            avg(c.indoor_ah_g_m3)::double precision AS indoor_ah_g_m3,
            count(c.indoor_ah_g_m3)::int AS ah_samples,
            count(*) FILTER (WHERE c.wet_relay_on)::int AS wet_relay_minutes,
            min(c.temp_f - c.served_temp_low)::double precision
                AS min_temp_floor_margin_f,
            CASE
                WHEN count(*) = 0 THEN 600
                ELSE greatest(
                    extract(epoch FROM (
                        min(c.bucket)
                        - (e.episode_started_at + interval '10 minutes')
                    ))::int,
                    COALESCE(max(extract(epoch FROM (
                        c.bucket - c.previous_response_bucket
                    ))) FILTER (
                        WHERE c.previous_response_bucket IS NOT NULL
                    ), 0)::int,
                    extract(epoch FROM (
                        e.episode_started_at + interval '20 minutes'
                        - (max(c.bucket) + interval '1 minute')
                    ))::int
                )
            END AS response_max_gap_s
        FROM (
            SELECT
                response.*,
                lag(response.bucket) OVER (ORDER BY response.bucket)
                    AS previous_response_bucket
            FROM resolved response
            WHERE response.bucket
                    >= e.episode_started_at + interval '10 minutes'
              AND response.bucket
                    < e.episode_started_at + interval '20 minutes'
        ) c
    ) after ON true
    LEFT JOIN LATERAL (
        SELECT s.*
        FROM resolved s
        WHERE s.bucket >= e.episode_ended_at
        ORDER BY s.bucket
        LIMIT 1
    ) next_sample ON true
    LEFT JOIN LATERAL (
        -- A night owns both adjacent daylight windows: the local-date hours
        -- before sunset and the following local-date hours after sunrise.
        SELECT
            COALESCE(sum(dry_action_samples), 0)::int AS dry_action_samples,
            COALESCE(sum(hold_action_samples), 0)::int AS hold_action_samples
        FROM daytime_admission
        WHERE local_date IN (e.night_date, e.night_date + 1)
    ) d ON true
)
SELECT
    r.night_date,
    r.episode_id,
    r.episode_started_at,
    r.episode_ended_at,
    round(r.duration_min::numeric, 1)::double precision AS duration_min,
    CASE WHEN r.admitted_minutes > 0 THEN 'admitted' ELSE 'blocked' END
        AS admission_status,
    r.admission_reason,
    CASE
        WHEN r.admitted_minutes > 0 THEN NULL
        WHEN r.action_evidence_minutes < greatest(1, r.sample_minutes / 2)
            THEN 'action_evidence_missing'
        WHEN r.outdoor_evidence_minutes < greatest(1, r.sample_minutes / 2)
            THEN 'outdoor_evidence_missing'
        WHEN r.ah_advantage_avg_g_m3 <= 0 THEN 'no_outdoor_ah_advantage'
        WHEN r.min_temp_floor_margin_f <= 0 THEN 'temperature_floor'
        ELSE 'controller_no_admission'
    END AS block_reason,
    CASE
        WHEN r.next_bucket IS NULL THEN 'telemetry_incomplete'
        WHEN r.next_bucket - r.episode_ended_at > interval '2 minutes'
            THEN 'telemetry_gap'
        WHEN r.next_solar_phase < 2.0 THEN 'sunrise'
        WHEN r.below_served_low_minutes > 0
          AND r.next_vpd_kpa >= r.next_served_vpd_low THEN 'vpd_recovered'
        WHEN r.next_temp_f <= r.next_served_temp_low THEN 'temperature_floor'
        WHEN r.next_ah_advantage_g_m3 <= 0 THEN 'outdoor_advantage_lost'
        ELSE 'controller_stopped'
    END AS stop_reason,
    r.sample_minutes,
    round((100.0 * r.sample_minutes / NULLIF(ceil(r.duration_min), 0))::numeric, 1)
        ::double precision AS climate_coverage_pct,
    r.max_climate_gap_s,
    r.below_served_low_minutes,
    r.action_evidence_minutes,
    r.hold_admitted_minutes,
    round((100.0 * r.action_evidence_minutes / NULLIF(r.sample_minutes, 0))::numeric, 1)::double precision
        AS action_coverage_pct,
    round(r.indoor_ah_avg_g_m3::numeric, 2)::double precision,
    round(r.outdoor_ah_avg_g_m3::numeric, 2)::double precision,
    round(r.ah_advantage_avg_g_m3::numeric, 2)::double precision,
    round(r.ah_advantage_min_g_m3::numeric, 2)::double precision,
    round(r.indoor_ah_before_g_m3::numeric, 2)::double precision,
    round(r.indoor_ah_after_g_m3::numeric, 2)::double precision,
    round((r.indoor_ah_after_g_m3 - r.indoor_ah_before_g_m3)::numeric, 2)
        ::double precision,
    round(r.served_temp_floor_f::numeric, 2)::double precision,
    round(r.min_temp_f::numeric, 2)::double precision,
    round(r.min_temp_floor_margin_f::numeric, 2)::double precision,
    round(r.vpd_before_kpa::numeric, 3)::double precision,
    round(r.vpd_after_kpa::numeric, 3)::double precision,
    round((r.vpd_after_kpa - r.vpd_before_kpa)::numeric, 3)::double precision,
    round((r.temp_after_f - r.temp_before_f)::numeric, 2)::double precision,
    round((100.0 * r.vent_minutes / NULLIF(r.sample_minutes, 0))::numeric, 1)::double precision,
    round((100.0 * r.fan_minutes / NULLIF(r.sample_minutes, 0))::numeric, 1)::double precision,
    round((100.0 * r.heat1_minutes / NULLIF(r.sample_minutes, 0))::numeric, 1)::double precision,
    round((100.0 * r.heat2_minutes / NULLIF(r.sample_minutes, 0))::numeric, 1)::double precision,
    round((100.0 * r.wet_relay_minutes / NULLIF(r.sample_minutes, 0))::numeric, 1)::double precision,
    r.response_wet_relay_minutes,
    r.after_samples,
    r.response_max_gap_s,
    round(r.response_min_temp_floor_margin_f::numeric, 2)::double precision,
    r.daytime_dry_action_samples,
    r.daytime_hold_admission_samples,
    CASE
        WHEN r.daytime_hold_admission_samples > 0
          OR r.heat2_minutes > 0
          OR (
              r.admitted_minutes > 0
              AND r.min_temp_floor_margin_f <= 0
          )
          OR (
              r.admitted_minutes > 0
              AND r.response_min_temp_floor_margin_f <= 0
          )
            THEN 'fail'
        WHEN r.min_temp_floor_margin_f IS NULL
          OR r.response_min_temp_floor_margin_f IS NULL
            THEN 'incomplete'
        ELSE 'pass'
    END AS safety_gate_status,
    array_remove(ARRAY[
        CASE WHEN r.daytime_hold_admission_samples > 0
            THEN 'daytime_hold_admission' END,
        CASE WHEN r.heat2_minutes > 0 THEN 'heat2_forbidden' END,
        CASE
            WHEN r.admitted_minutes > 0
             AND r.min_temp_floor_margin_f <= 0
                THEN 'temperature_floor_breach'
        END,
        CASE
            WHEN r.admitted_minutes > 0
             AND r.response_min_temp_floor_margin_f <= 0
                THEN 'response_temperature_floor_breach'
        END
    ]::text[], NULL) AS gate_violations,
    array_remove(ARRAY[
        CASE WHEN r.admitted_minutes > 0 AND r.ah_advantage_min_g_m3 <= 0
            THEN 'no_positive_outdoor_ah_advantage' END,
        CASE WHEN r.wet_relay_minutes > 0 THEN 'simultaneous_wetting' END,
        CASE WHEN r.response_wet_relay_minutes > 0
            THEN 'response_window_wetting' END
    ]::text[], NULL) AS confound_reasons,
    CASE
        WHEN r.daytime_hold_admission_samples > 0
          OR r.heat2_minutes > 0
          OR (
              r.admitted_minutes > 0
              AND r.min_temp_floor_margin_f <= 0
          )
          OR (
              r.admitted_minutes > 0
              AND r.response_min_temp_floor_margin_f <= 0
          )
            THEN 'gate_failed'
        WHEN r.min_temp_floor_margin_f IS NULL
          OR r.response_min_temp_floor_margin_f IS NULL
          OR r.sample_minutes < ceil(r.duration_min * 0.8)
          OR r.max_climate_gap_s > 90
          OR r.response_max_gap_s > 90
          OR r.action_evidence_minutes < ceil(r.sample_minutes * 0.8)
          OR r.outdoor_evidence_minutes < ceil(r.sample_minutes * 0.5)
          OR r.before_samples < 4 OR r.after_samples < 8
          OR r.before_ah_samples < 4 OR r.after_ah_samples < 8
            THEN 'incomplete'
        WHEN (r.admitted_minutes > 0 AND r.ah_advantage_min_g_m3 <= 0)
          OR r.wet_relay_minutes > 0
          OR r.response_wet_relay_minutes > 0
            THEN 'confounded'
        ELSE 'complete'
    END AS evidence_status,
    CASE
        WHEN r.daytime_hold_admission_samples > 0
          OR r.heat2_minutes > 0
          OR (
              r.admitted_minutes > 0
              AND r.min_temp_floor_margin_f <= 0
          )
          OR (
              r.admitted_minutes > 0
              AND r.response_min_temp_floor_margin_f <= 0
          )
            THEN 'ineffective'
        WHEN r.min_temp_floor_margin_f IS NULL
          OR r.response_min_temp_floor_margin_f IS NULL
          OR r.sample_minutes < ceil(r.duration_min * 0.8)
          OR r.max_climate_gap_s > 90
          OR r.response_max_gap_s > 90
          OR r.action_evidence_minutes < ceil(r.sample_minutes * 0.8)
          OR r.outdoor_evidence_minutes < ceil(r.sample_minutes * 0.5)
          OR r.before_samples < 4 OR r.after_samples < 8
          OR r.before_ah_samples < 4 OR r.after_ah_samples < 8
            THEN 'insufficient_evidence'
        WHEN (r.admitted_minutes > 0 AND r.ah_advantage_min_g_m3 <= 0)
          OR r.wet_relay_minutes > 0
          OR r.response_wet_relay_minutes > 0
            THEN 'insufficient_evidence'
        WHEN r.admitted_minutes = 0 THEN 'blocked'
        WHEN r.ah_advantage_min_g_m3 > 0
         AND r.vpd_after_kpa - r.vpd_before_kpa >= 0.05
         AND r.indoor_ah_after_g_m3 - r.indoor_ah_before_g_m3 <= -0.05
            THEN 'effective'
        ELSE 'ineffective'
    END AS dryout_disposition
FROM with_response r
ORDER BY r.night_date, r.episode_started_at) candidate(night_date,episode_id,episode_started_at,episode_ended_at,duration_min,admission_status,admission_reason,block_reason,stop_reason,sample_minutes,climate_coverage_pct,max_climate_gap_s,below_served_low_minutes,action_evidence_minutes,hold_admitted_minutes,action_coverage_pct,indoor_ah_avg_g_m3,outdoor_ah_avg_g_m3,ah_advantage_avg_g_m3,ah_advantage_min_g_m3,indoor_ah_before_g_m3,indoor_ah_after_10_20m_g_m3,observed_indoor_ah_delta_10_20m_g_m3,served_temp_floor_f,min_temp_f,min_temp_floor_margin_f,vpd_before_kpa,vpd_after_10_20m_kpa,observed_vpd_delta_10_20m_kpa,observed_temp_delta_10_20m_f,vent_duty_pct,fan_duty_pct,heat1_duty_pct,heat2_duty_pct,wet_relay_duty_pct,response_wet_relay_minutes,response_sample_minutes,response_max_gap_s,response_min_temp_floor_margin_f,daytime_dry_action_samples,daytime_hold_admission_samples,safety_gate_status,gate_violations,confound_reasons,evidence_status,dryout_disposition) ORDER BY episode_started_at,episode_id LIMIT 501) SELECT jsonb_build_object('kind','timeline','date','2026-10-04','row_count',count(*),'overflow',count(*)>500,'rows',coalesce(jsonb_agg(to_jsonb(b) ORDER BY episode_started_at,episode_id),'[]'::jsonb)) FROM bounded b;
ROLLBACK;
