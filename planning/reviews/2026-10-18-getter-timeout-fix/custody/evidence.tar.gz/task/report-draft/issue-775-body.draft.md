# Campaign: trustworthy greenhouse outcomes → qualified pilot → evidence-backed control

Campaign: #775 · Stage: **C0 — Measurement and incident truth** · Priority: P0 · Effort: L · Accountable role: Evidence/data lead.

Roles name execution responsibilities and preserve existing assignees. This contract supersedes conflicting historical sequencing; prior comments and receipts remain evidence.

## Current state and next action

The selected getter follow-up has a semantics-preserving migration277 source candidate,20 passing native full46-column synthetic parity cases,2673 matching genuine clone readback relations, and an exact production body/receipt rollback rehearsal with unchanged state. The October16 source-body query completed with zero episodes because the captured solar night had zero demand; this is not proof of complete daytime coverage or a finished scientific outcome. The first full native CI5vzfd failed on the missing forward-successor baseline exception; correction8d7ff1a2 preserves the already-qualified277 SQL and seals, and workflow26nj4 is running at this draft checkpoint. Production installation and installed ordinary MCP behavior remain pending. Previously accepted S3B and MCP-only release receipts remain valid within their stated scopes.

Current execution allocation: ROLLUP. Next action: Finish the selected277 migration delivery and installed ordinary-role verification, then record only the measured getter outcome. Reuse accepted MCP and S3B receipts; retain the remaining authentic-input, measured daytime, planner-route and physical/recovery work without repeating accepted delivery or changing acceptance edges.

Fresh native graph at18:13:18UTC matched source16d13f64:47open issues,143 open acceptance clauses,26 local plusHA878→981 active edges (27 total),24 closed predecessor records, matching parent/open-subissue links and no cycle in the captured graph. The later8d7ff1a2 source correction does not edit planning. Preserve original22–34h/40h estimates without inferring remaining hours.

Evidence: planning/reviews/2026-10-18-getter-timeout-fix/README.md (draft pending final delivery receipts). Acceptance clauses, states, parentage and dependencies remain unchanged.

## What

Own the current campaign contract, accepted-scope ledger and bounded execution cadence across all open issues through an evidence-backed pilot decision.

## Why

A completed preparation packet, healthy runtime or bounded clone proof does not finish an issue or the campaign. Current planning must identify the actual technical and empirical gaps, preserve accepted work and avoid repeated proof or unnecessary full-issue gates.

## How / implementation strategy

1. Maintain one current status-aware contract per issue with matching native dependencies and no parent-as-blocker loops.
2. Preserve original S3 estimates as historical planning and the S3B 40-hour budget / 22–34h selected estimates plus at least 6h reserve. Record completed bounded packets separately from full issue acceptance and measured effort.
3. Reuse completed P1 native/P2 admission/P4 custody and accepted MCP release. Consume the sealed getter diagnosis before a separately selected immutable optimization; keep genuine outcomes, authenticated admin/planner route and physical/input gaps visible without repeating accepted delivery.

## Source touchpoints

- `planning`
- `PROJECT_BOARD.md`
- `MILESTONES.md`
- `EPICS.md`
- `LANES.md`
- `SPRINTS.md`

## Dependencies and scope

No in-repository parent; any external ownership is recorded in this contract. Parentage is a roll-up, not a blocking dependency.

No in-repository predecessor. External blockers, when present, are recorded in the current state and reviewed native graph. Pull according to stage priority and the concrete safety/physical conditions below; no blanket human gate is implied.

## Acceptance and validation

- [ ] Each current open issue has a disposition, accountable role, next action and actual remaining acceptance.
- [ ] Native active graph equals planning source and is acyclic with no parent-as-blocker loops.
- [ ] The bounded pilot ends in a reproducible result, including inconclusive/no-benefit if warranted.

## Delivery and real end-state verification

Close the roll-up only when each in-scope child has its own acceptance receipt or an explicit, linked scope decision. A closed child is evidence of its stated boundary, not proof of a broader product claim.

## Rollback and evidence preservation

Preserve child receipts and closed history. Replan explicitly when evidence fails; do not waive a safety invariant, reopen a locked draw, or call an incomplete campaign complete.

## Decisions / physical boundary

No old credential or two-message approval is pending. Future physical window, exact design/launch and measurement-scope decisions should be raised only with concrete ready packets; not as a blanket planning gate.

## Child deliverables

- [ ] #778 — Investigate September 4 hot/dry peak and three-hour wetting interruption (closed; see recorded disposition)
- [ ] #779 — Re-run historical planner comparisons on a fixed sensor panel and fixed target contract (closed; see recorded disposition)
- [ ] #780 — Score as-of outdoor forecasts against outdoor truth and separate indoor response (closed; see recorded disposition)
- [ ] #781 — Commission a claim-safe water and electricity endpoint contract (closed; see recorded disposition)
- [ ] #581 — Complete the bounded AI-admission pilot and publish a decision (open; see recorded disposition)
- [ ] #644 — Integrate exact-SHA, path-aware and device-safe delivery receipts (closed; see recorded disposition)
- [ ] #427 — Prove active Hermes/MCP recovery and truthful non-authoritative worker health (closed; see recorded disposition)
- [ ] #75 — Observability program: prove actionable health from source through device (open; see recorded disposition)
- [ ] #218 — Durability program: recoverable backups, measured RPO/RTO and safe HA option (open; see recorded disposition)
- [ ] #359 — Control program: truthful crop corridors before evidence-led tuning (open; see recorded disposition)
- [ ] #214 — Prove crop-deviation trigger → valid plan on the sole operational planner path (closed; see recorded disposition)
- [ ] #350 — Irrigation program: topology truth, overwatering protection and commissioned wall feed (open; see recorded disposition)
- [ ] #16 — Hardware program: commission only the sensing and equipment justified by evidence (open; see recorded disposition)
- [ ] #174 — Rehome only current Verdify admin surfaces to global SSO, fail closed (closed; see recorded disposition)
- [ ] #14 — Twin program: qualify declared oracle coverage before using divergence as a gate (open; see recorded disposition)
- [ ] #638 — Unify future manifest/vector wire schema and content identity offline (closed; see recorded disposition)
- [ ] #586 — Qualify a future atomic firmware policy engine with crash-safe recovery (closed; see recorded disposition)
- [ ] #786 — Decide whether a deterministic forecast comparator merits a new study (open; see recorded disposition)
- [ ] #787 — Decide and scope a measured heating/overnight/resource study (open; see recorded disposition)

## Campaign references

[Current plan](https://github.com/VerdifyConsultancy/verdify-platform/blob/main/planning/README.md) · [Dependency graph](https://github.com/VerdifyConsultancy/verdify-platform/blob/main/planning/DEPENDENCIES.md) · [Validated source](https://github.com/VerdifyConsultancy/verdify-platform/blob/main/planning/backlog.yaml).

Original issue bodies and metadata are retained in [the October 17 before-images](https://github.com/VerdifyConsultancy/verdify-platform/blob/main/planning/reviews/2026-10-17-replan/before-open-issues.json) and [the original campaign snapshot](https://github.com/VerdifyConsultancy/verdify-platform/blob/main/planning/archive/2026-09-05/issues.json). Closed issue history and comments remain intact. Planning does not perform a deployment, device change, random draw or experiment launch.
