# Measure realized solar-night dry-out before changing the controller

Campaign: #775 · Stage: **C6 — Evidence-led control and irrigation** · Priority: P1 · Effort: L · Accountable role: Control lead.

Roles name execution responsibilities and preserve existing assignees. This contract supersedes conflicting historical sequencing; prior comments and receipts remain evidence.

## Current state and next action

The selected getter correction is implemented in immutable migration277 at source16d13f64, followed by8d7ff1a2 correcting the historical baseline-stamp exception caught by the first full native gate. It preserves all46 outputs, upstream seed/tie semantics, NULL stop behavior, inner-helper cardinality and scientific expressions. Twenty native synthetic old/new full-row cases passed;2673 real clone readback relations matched exactly under one snapshot. Candidate B returned four October4 clone episodes in3174.204ms, equal to candidate A across all46 fields in separate read-only snapshots; no successful full original real-data result exists because its15s/30s attempts timed out.

The exact production migration and MCP receipt update passed inside a transaction that rolled back, followed by fresh unchanged-state readback. A source-body production October16 query returned zero episodes in3972.272ms client timing (3967.348ms server query elapsed), retaining2785 climate/action/resolved minutes and750 selected solar-night minutes with zero demand/admitted/active minutes and no null served VPD. Observed daylight had zero hold samples and12/2 ordinary dry-action samples, but complete daytime coverage is not established. These are candidate/rehearsal results, not installed-getter acceptance. The first main CI5vzfd failed and remains retained; corrected source8d7ff1a2 workflow26nj4 is running at this draft checkpoint. No277 installation or installed ordinary-role result is claimed. The prior MCP incomplete-status correction remains accepted.

Current execution allocation: S3B follow-up. Next action: Complete the exact-source native gate and migrate image, then run the reviewed owning migration-only plan/apply Jobs and verify the277 ledger, function and MCP receipt. Through the unchanged ordinary MCP identities, retain installed October16 and explicitly selected October4 full46-column results within the configured15-second budget, custom/generic planning, HTTP/role guards and runtime readback. Keep daytime completeness, positive admin/planner consumption and physical/crop claims open.

Evidence: planning/reviews/2026-10-18-getter-timeout-fix/README.md (draft pending final delivery receipts); prior planning/reviews/2026-10-18-getter-mcp-release/README.md remains unchanged. All three acceptance clauses and completion edges remain open and unchanged.

## What

Deliver validity-bearing solar-night moisture-removal episodes and a measured effective/ineffective/blocked/insufficient-evidence disposition.

## Why

Projected gain, a fixed clock window and a few favorable nights cannot establish reliable greenhouse-wide dry-out or justify a Vanda watering program.

## How / implementation strategy

1. Reuse the sealed six-session bounded diagnosis and preserve every original timeout. Date-bound pruning is demonstrated; resolved-stage interval/helper attribution remains incomplete. Qualify a minimal immutable migration with actual rowset/tie/fallback/solar/response parity before installing it.
2. Reuse the accepted MCP-only production release and installed projection/HTTP guard receipts. Genuine outcome payload and positive admin transport remain unverified; do not treat installed synthetic qualification as real greenhouse evidence or widen Iris/experiment access.
3. Preserve episode dispositions, confounds and evidence status. Require actual available complete daytime evidence for measured-zero held admission; legacy empty/null0 is unknown for acceptance. Keep solar, heat2, wind/dwell/temperature safeguards and ordinary daytime dehumidification.
4. Qualify an explicitly scoped ordinary-planner input route separately; outcome_kpi is admin-only and absent from Iris context. Physical efficacy, crop safety and tuning need their own evidence.

## Source touchpoints

- `db/migrations`
- `firmware`
- `research/planner-efficacy`
- `mcp`
- `scripts`

## Dependencies and scope

Parent: #359. Parentage is a roll-up, not a blocking dependency.

Predecessor records: #371 (closed), #419 (closed), #424 (closed). Open records gate the stated bounded deliverable; closed records retain their original disposition and are not active blockers. Preparation may proceed earlier.

## Acceptance and validation

- [ ] Episodes use device solar semantics, never fixed 02:00–06:00, and incomplete/confounded episodes cannot be PASS.
- [ ] Solar-day held-temperature admission is zero while ordinary daytime dehumidification remains correctly distinguished.
- [ ] Planner/MCP sees realized validity-bearing outcomes and explicit disposition, not a universal VPD target or a crop-safety claim without sensing.

## Delivery and real end-state verification

Deliver the smallest complete owner change, use enforced checks and the existing supported delivery path, then verify the issue-specific end state. Heavy tests/builds run in admitted k3s workloads. Source or CI success does not establish runtime, physical or scientific acceptance.

## Rollback and evidence preservation

Keep original extraction and definitions immutable; supersede with a new version and compare hashes. Never rewrite locked assignments, outcomes or an earlier analysis to improve a result.

## Decisions / physical boundary

The selected getter diagnosis and MCP-only release are executed within their recorded boundaries. No new credential, admin audience, planner expansion, migration, controller tuning, physical experiment or OTA was created. Remaining source/runtime/scientific acceptance stays explicit.

## Campaign references

[Current plan](https://github.com/VerdifyConsultancy/verdify-platform/blob/main/planning/README.md) · [Dependency graph](https://github.com/VerdifyConsultancy/verdify-platform/blob/main/planning/DEPENDENCIES.md) · [Validated source](https://github.com/VerdifyConsultancy/verdify-platform/blob/main/planning/backlog.yaml).

Original issue bodies and metadata are retained in [the October 17 before-images](https://github.com/VerdifyConsultancy/verdify-platform/blob/main/planning/reviews/2026-10-17-replan/before-open-issues.json) and [the original campaign snapshot](https://github.com/VerdifyConsultancy/verdify-platform/blob/main/planning/archive/2026-09-05/issues.json). Closed issue history and comments remain intact. Planning does not perform a deployment, device change, random draw or experiment launch.
