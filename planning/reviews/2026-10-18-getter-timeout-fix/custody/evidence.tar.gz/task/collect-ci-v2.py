import subprocess,json,pathlib,hashlib,sys,time,select,os,datetime
name,uid,dirname=sys.argv[1:];out=pathlib.Path(dirname);out.mkdir(parents=True,exist_ok=False);k=['kubectl','--context','vallery','--request-timeout=15s','-n','agent-fleet-ci'];deadline=time.monotonic()+900;decoder=json.JSONDecoder();buffer='';seen={};phases=[];lastwf=0;terminal=None

def save(label,data):
 raw=data if isinstance(data,bytes) else (json.dumps(data,indent=2)+'\n').encode();sha=hashlib.sha256(raw).hexdigest();p=out/(label+'-'+sha+('.log' if isinstance(data,bytes) else '.json'));p.write_bytes(raw);return {'path':p.name,'sha256':sha,'bytes':len(raw)}
def get(args):return json.loads(subprocess.check_output(k+args,timeout=20))
def pod(p,event='snapshot'):
 assert p['metadata'].get('labels',{}).get('workflows.argoproj.io/workflow')==name
 assert any(x['uid']==uid for x in p['metadata'].get('ownerReferences',[]))
 n=p['metadata']['name'];status=p.get('status',{});statussha=hashlib.sha256(json.dumps(status,sort_keys=True).encode()).hexdigest()
 if seen.get(n)==statussha:return
 seen[n]=statussha;save(n+'-'+event,p);main=next((x for x in status.get('containerStatuses',[]) if x['name']=='main'),None)
 if main and ('running' in main.get('state',{}) or 'terminated' in main.get('state',{})):
  r=subprocess.run(k+['logs',n,'-c','main'],capture_output=True,timeout=20)
  if r.returncode==0:
   assert len(r.stdout)<=64*1024*1024;save(n+'-main',r.stdout)
 save(n+'-summary',{'name':n,'uid':p['metadata']['uid'],'event':event,'phase':status.get('phase'),'node':p['spec'].get('nodeName'),'init':status.get('initContainerStatuses',[]),'containers':status.get('containerStatuses',[])})
 if main and 'terminated' in main.get('state',{}):print(json.dumps({'pod':n,'phase':status.get('phase'),'main_exit':main['state']['terminated']['exitCode'],'containers':[{ 'name':x['name'],'restartCount':x['restartCount'],'state':x['state']} for x in status.get('containerStatuses',[])]}),flush=True)
watch=subprocess.Popen(['kubectl','--context','vallery','--request-timeout=900s','-n','agent-fleet-ci']+['get','pods','-l','workflows.argoproj.io/workflow='+name,'--watch','--output-watch-events','-o','json'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
try:
 for p in get(['get','pods','-l','workflows.argoproj.io/workflow='+name,'-o','json'])['items']:pod(p)
 while time.monotonic()<deadline:
  if time.monotonic()-lastwf>12:
   w=get(['get','workflow',name,'-o','json']);assert w['metadata']['uid']==uid;save('workflow',w);phase=w.get('status',{}).get('phase');lastwf=time.monotonic()
   if not phases or phases[-1]!=phase:phases.append(phase);print(json.dumps({'workflow':name,'uid':uid,'phase':phase}),flush=True)
   if phase in ('Succeeded','Failed','Error') and terminal is None:terminal=time.monotonic()
  ready,_,_=select.select([watch.stdout],[],[],1)
  if ready:
   raw=os.read(watch.stdout.fileno(),1048576)
   if not raw:raise RuntimeError('PodWatchEnded')
   buffer+=raw.decode()
   while buffer.strip():
    buffer=buffer.lstrip()
    try:event,offset=decoder.raw_decode(buffer)
    except json.JSONDecodeError:break
    buffer=buffer[offset:]
    if event.get('object',{}).get('kind')=='Pod':pod(event['object'],event.get('type','event'))
  if terminal and time.monotonic()-terminal>5:break
 else:raise TimeoutError('CI custody deadline900s; no resubmit')
 final=get(['get','workflow',name,'-o','json']);save('workflow-final',final);(out/'result.json').write_text(json.dumps({'workflow':name,'uid':uid,'phase':final.get('status',{}).get('phase'),'pods_seen':list(seen),'finishedAt':final.get('status',{}).get('finishedAt'),'collector_finished':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n');print((out/'result.json').read_text(),flush=True)
finally:
 watch.terminate()
 try:watch.wait(timeout=5)
 except subprocess.TimeoutExpired:watch.kill();watch.wait()
