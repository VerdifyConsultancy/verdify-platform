import pathlib,json,hashlib,datetime,importlib.util,shutil
b=pathlib.Path('/private/tmp/verdify-getter-fix-20261018');helper=pathlib.Path('/private/tmp/verdify-package-getter277-evidence-v3.py');assert hashlib.sha256(helper.read_bytes()).hexdigest()=='a2ca2cc6004dea0a2d9f0afb845a7f375d28028fbb2c118ab226d1a007ec7eb4'
for n in ('release-main-ci-verified.json','planning-main-ci-verified.json'):
 assert json.load(open(b/n))['status']=='DIRECT_TERMINAL_VALIDATE_ONLY_MAIN_CI_PASSED'
assert json.load(open(b/'graph-final/verified.json'))['status']=='MATCH'
assert json.load(open(b/'installed-getter-results-verified.json'))['status']=='INSTALLED_ORDINARY_REAL_EPISODES_PASSED'
assert json.load(open(b/'runtime-after277-v2/result.json'))['status']=='RUNTIME_HTTP_SMOKE_WRITER_IDENTITIES_PASSED'
# Freeze additional guard/provenance receipts without copying intentional malicious synthetic guard fixtures.
for src in ['/private/tmp/verdify-getter277-dsn-classification.json','/private/tmp/verdify-getter277-dsn-reference-review-v2.json','/private/tmp/verdify-getter277-packaging-review-plan-v2.json','/private/tmp/verdify-getter277-packaging-review-plan-v3.json','/private/tmp/verdify-getter277-packaging-synthetic-verification.json']:
 p=pathlib.Path(src);target=b/'readers'/p.name
 if target.exists():assert target.read_bytes()==p.read_bytes()
 else:target.write_bytes(p.read_bytes())
includes=[];private=[]
for p in sorted(b.iterdir()):
 if p.name=='__pycache__':continue
 if p.name.startswith('prod-admission-before-'):
  safe={'admission.json','c0-metadata.json','config-metadata.json','secret-metadata.txt','db-service.json','db-endpoints.json','limits.json','quota.json','c0-contract.json'}
  for q in sorted(p.iterdir()):
   rel=str(q.relative_to(b))
   if q.name in safe:includes.append(rel)
   else:private.append({'path':rel,'reason':'broader duplicate namespace inventory; used derived admission and exact serving-source runtime proofs instead'})
 else:includes.append(p.name)
policy=json.load(open('/private/tmp/verdify-getter277-evidence-selection.draft.json'));policy.update(status='ready_for_packaging',include=includes,required_files=['source16d-render.json','native-fixtures-b-01/receipt.json','native-fixtures-b-02/receipt.json','corrected-source-ci-verified.json','release-main-ci-verified.json','planning-main-ci-verified.json','owning-plan-01/result.json','owning-apply-01/result.json','plan-state-unchanged.json','applied-state-verified.json','final-state-verified.json','owner-installed-receipt.json','installed-getter-results-verified.json','runtime-after277-v2/result.json','graph-final/verified.json','github-final-canonical/result.json'],pending_before_execution=[],public_metadata_hash_exceptions=[],additional_private_exclusions=private,prepared_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
policy['workflow_identities'] += [{'namespace':'agent-fleet-ci','name':'verdify-platform-ci-27skd','uid':'ebe640f4-f5d3-42ba-b650-aec9902ce7e0'},{'namespace':'agent-fleet-ci','name':'verdify-platform-ci-qcb4r','uid':'c856d50d-ac55-4a66-902d-26e2868cee19'}]
spec=importlib.util.spec_from_file_location('pack',helper);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);files,skips=m.select(b,includes)
raw=(json.dumps(policy,indent=2)+'\n').encode();path=pathlib.Path('/private/tmp/verdify-getter277-evidence-selection.ready-v2.json');path.open('xb').write(raw);print(json.dumps({'policy':str(path),'sha256':hashlib.sha256(raw).hexdigest(),'files':len(files),'bytes':sum(p.stat().st_size for p in files.values()),'built_in_exclusions':skips,'additional_private_exclusions':private}))
