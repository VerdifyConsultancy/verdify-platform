import pathlib,sys,json,re,hashlib,tarfile,io
base=pathlib.Path(sys.argv[1]);report=pathlib.Path(sys.argv[2]);findings=[];count=0;allowed_metadata=[]
patterns={'private_key':rb'-----BEGIN (?:RSA |OPENSSH |EC |DSA )?PRIVATE KEY-----','github_token':rb'\b(?:gh[pousr]_[A-Za-z0-9_]{30,}|github_pat_[A-Za-z0-9_]{40,})','slack_token':rb'\bxox[baprs]-[A-Za-z0-9-]{20,}','aws_key':rb'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b','dsn_with_password':rb'postgres(?:ql)?://[^\s/\x22\x27:]+:[^\s@\x22\x27]+@','literal_bearer':rb'Bearer [A-Za-z0-9._~+/=-]{24,}'}
def finding(path,kind,value):findings.append({'path':path,'kind':kind,'value_sha256':hashlib.sha256(value).hexdigest(),'value_bytes':len(value)})
def guard(v,path):
 if isinstance(v,dict):
  if v.get('kind')=='Secret':finding(path,'Kubernetes_Secret_object',b'kindSecret')
  if isinstance(v.get('env'),list):
   for e in v['env']:
    name=e.get('name','');value=e.get('value')
    if value and re.search('(TOKEN|PASSWORD|PRIVATE_KEY|CLIENT_SECRET|ACCESS_KEY|AUTHORIZATION)',name,re.I):
     # Only exact source-level metadata hashes are eligible; URL/path/policy identifiers require review.
     if name.endswith('_SHA256') and re.fullmatch('[0-9a-f]{64}',str(value)):allowed_metadata.append({'path':path,'name':name,'sha256':hashlib.sha256(str(value).encode()).hexdigest()})
     else:finding(path,'literal_credential_like_env:'+name,str(value).encode())
  for x in v.values():guard(x,path)
 elif isinstance(v,list):
  for x in v:guard(x,path)
def scan(raw,path,depth=0):
 global count
 count+=1
 for kind,pat in patterns.items():
  for m in re.finditer(pat,raw):finding(path,kind,m.group())
 if path.endswith('.json') and raw.strip():
  try:guard(json.loads(raw),path)
  except (ValueError,UnicodeDecodeError):pass
 if depth<2 and path.endswith(('.tar.gz','.tgz','.tar')):
  with tarfile.open(fileobj=io.BytesIO(raw),mode='r:*') as t:
   for m in t:
    assert m.isfile() or m.isdir()
    if m.isfile():assert m.size<16*1024*1024;scan(t.extractfile(m).read(),path+'!/'+m.name,depth+1)
for p in sorted(base.rglob('*')):
 if p.is_file() and p!=report:scan(p.read_bytes(),str(p.relative_to(base)))
report.write_text(json.dumps({'scanned_files_and_archive_members':count,'findings':findings,'metadata_hash_env':allowed_metadata,'raw_values_in_findings':False},indent=2)+'\n');print(json.dumps({'scanned':count,'findings':len(findings),'report':str(report)}))
