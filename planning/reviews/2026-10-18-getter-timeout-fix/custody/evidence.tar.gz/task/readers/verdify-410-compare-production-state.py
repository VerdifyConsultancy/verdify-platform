#!/usr/bin/env python3
"""Pure retained-receipt comparison; no database, kubectl, or network operations."""

import argparse
import copy
import hashlib
import json
import re
from datetime import datetime
from pathlib import Path

KINDS = {
    "context",
    "getter",
    "ledger",
    "ordinary_receipts",
    "mcp_receipt",
    "api_boundary",
    "ingestor_boundary",
    "mcp_boundary",
    "role_metadata",
    "memberships",
    "role_settings",
    "password_presence_only",
    "study",
}
OLD_DEF = "b9626fd5882392bcf00c080550b6ab5000cc5ed8a63ea8dceb806e76aae6d3a6"
OLD_BODY = "bec61355ba78a87e361a87882645199c5497a1a7235144b6391842da307598ba"
NEW_DEF = "89782089fd6ae3ecfeecdfbc1b730f6ab6a272c0da7b35ef562788eddbfa42c0"
NEW_BODY = "578a07bed56714cd2dfe2308ca30ced1f6fc6916fd7db9d79630a7b82b261655"
OLD_MCP = "7083e4d43044e7f2b0150b58fa3cc8cc45c599a68b1f3cafaf9242e0f0f79e68"
NEW_MCP = "1cd20508c9196bf9758d7df40ae699e6b83aefccb91a4c5242492f7993f6eb02"
API = "5091627a4dfd40c679ed4e2c0729cde507f705ab9c45c1e2eb82b42d29634bba"
INGESTOR = "8690d5fc25a742cdd4abbbb940b0f000f708ef567e5ff301fbfd3d27f449a743"
POD_UID = "b1fa2c0e-a995-481f-a29f-4cfaad4e697b"
DB_IMAGE = "docker.io/timescale/timescaledb@sha256:0af03ecf697825f6ddae76fd275d16bf46007bed6d00eb3d754779cb7db96fa6"
MIGRATION = "db/migrations/277-realized-solar-night-readback-timeline.sql"


class Refusal(Exception):
    pass


def require(ok, code):
    if not ok:
        raise Refusal(code)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def pairs(values):
    result = {}
    for key, value in values:
        require(key not in result, "duplicate_json_key")
        result[key] = value
    return result


def parse(raw):
    return json.loads(
        raw, object_pairs_hook=pairs, parse_constant=lambda value: (_ for _ in ()).throw(Refusal("nonfinite_json"))
    )


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def read_capture(directory):
    p = Path(directory)
    files = {}
    for name in ("receipt.json", "query.sql", "stdout", "stderr"):
        path = p / name
        require(path.is_file() and path.stat().st_size <= 2 * 1024 * 1024, "capture_file_bound")
        files[name] = path.read_bytes()
    receipt = parse(files["receipt.json"])
    require(receipt["exit"] == 0, "capture_command_failed")
    require(receipt["query_sha256"] == sha(files["query.sql"]), "submitted_query_hash")
    require(
        receipt["stdout_bytes"] == len(files["stdout"]) and receipt["stdout_sha256"] == sha(files["stdout"]),
        "capture_stdout_seal",
    )
    require(
        receipt["stderr_bytes"] == 0 and not files["stderr"] and receipt["stderr_sha256"] == sha(b""),
        "capture_stderr_not_empty",
    )
    require(
        receipt.get("same_database_container_state") is True and receipt["before"] == receipt["after"],
        "capture_database_stability",
    )
    native = receipt["before"]
    require(native["uid"] == POD_UID and len(native["containers"]) == 1, "exact_database_pod")
    container = native["containers"][0]
    require(container["name"] == "postgres" and container["imageID"] == DB_IMAGE, "exact_database_container")
    require(
        container["ready"] is True and container["restartCount"] == 0 and bool(container["state"].get("running")),
        "healthy_unrestarted_database",
    )
    records = {}
    for line in files["stdout"].splitlines():
        if not line.strip():
            continue
        value = parse(line)
        require(isinstance(value, dict) and value.get("kind") in KINDS, "unknown_state_record")
        require(value["kind"] not in records, "duplicate_state_kind")
        records[value["kind"]] = value
    require(set(records) == KINDS, "incomplete_state_inventory")
    context = records["context"]
    require(
        context["database"] == "verdify" and context["user"] == context["session_user"] == "verdify", "owner_context"
    )
    require(
        context["version"] == "160011"
        and context["recovery"] is False
        and context["postmaster"] == "2026-09-29T00:40:56.280382+00:00",
        "same_database_postmaster",
    )
    return records, receipt, {str(p / name): sha(raw) for name, raw in files.items()}


def ledger(rows):
    require(isinstance(rows, list) and bool(rows), "ledger_row_inventory")
    result = {}
    for row in rows:
        key = (row["source"], row["filename"])
        require(key not in result, "duplicate_ledger_identity")
        result[key] = row
    return result


def compare(before, after, before_receipt, after_receipt, mode, migration_sha=None):
    require(before_receipt["query_sha256"] == after_receipt["query_sha256"], "different_state_capture_source")
    require(before_receipt["after"] == after_receipt["before"], "database_container_changed_between_captures")
    before_time = datetime.fromisoformat(before["context"]["captured_at"])
    after_time = datetime.fromisoformat(after["context"]["captured_at"])
    require(before_time <= after_time, "capture_order")
    a, b = copy.deepcopy(before), copy.deepcopy(after)
    a["context"].pop("captured_at")
    b["context"].pop("captured_at")
    require(
        a["getter"]["definition_sha256"] == OLD_DEF and a["getter"]["body_sha256"] == OLD_BODY, "predecessor_getter"
    )
    require(a["mcp_boundary"]["sha256"] == OLD_MCP, "predecessor_mcp_boundary")
    require(
        a["api_boundary"]["sha256"] == API and a["ingestor_boundary"]["sha256"] == INGESTOR,
        "predecessor_other_boundaries",
    )
    old_ledger = ledger(a["ledger"]["rows"])
    require(
        max(r["seq"] for r in old_ledger.values() if r["source"] == "db/migrations") == 276, "predecessor_ledger276"
    )
    expected = copy.deepcopy(a)
    allowed = []
    if mode == "apply":
        require(
            isinstance(migration_sha, str) and re.fullmatch("[0-9a-f]{64}", migration_sha),
            "reviewed_migration_sha_required",
        )
        new_ledger = ledger(b["ledger"]["rows"])
        key = ("db/migrations", MIGRATION)
        require(
            set(new_ledger) - set(old_ledger) == {key} and not set(old_ledger) - set(new_ledger),
            "only277_added_to_ledger",
        )
        require(all(new_ledger[k] == v for k, v in old_ledger.items()), "old_ledger_row_changed")
        entry = new_ledger[key]
        require(
            set(entry)
            == {"seq", "sha256", "source", "filename", "applied_at", "applied_by", "duration_ms", "stamp_method"},
            "new_ledger_shape",
        )
        require(
            entry["seq"] == 277
            and entry["sha256"] == migration_sha
            and entry["stamp_method"] == "runner"
            and entry["applied_by"] == "verdify",
            "runner277_ledger_identity",
        )
        require(type(entry["duration_ms"]) is int and entry["duration_ms"] >= 0, "ledger_duration")
        require(
            before_time <= datetime.fromisoformat(entry["applied_at"]) <= after_time,
            "ledger_time_outside_capture_window",
        )
        expected["ledger"]["rows"] = b["ledger"]["rows"]
        expected["getter"]["definition_sha256"] = NEW_DEF
        expected["getter"]["body_sha256"] = NEW_BODY
        # The complete pg_proc row excluding prosrc stays exact, including OID,
        # owner, signature, ACL, language, volatility, strictness and configuration.
        rows = expected["mcp_receipt"]["rows"]
        require(len(rows) == 1 and rows[0].get("singleton") is True, "one_mcp_receipt")
        encoded = rows[0]["boundary_sha256"]
        require(
            isinstance(encoded, str) and encoded.endswith(OLD_MCP) and encoded.count(OLD_MCP) == 1,
            "predecessor_mcp_receipt",
        )
        rows[0]["boundary_sha256"] = encoded.replace(OLD_MCP, NEW_MCP)
        expected["mcp_boundary"]["sha256"] = NEW_MCP
        allowed = [
            "one runner-stamped277 ledger row",
            "getter definition/body hashes",
            "MCP receipt boundary hash",
            "MCP computed boundary hash",
        ]
    else:
        require(mode == "plan", "mode")
    changed = [kind for kind in sorted(KINDS) if expected[kind] != b[kind]]
    require(not changed, "unexpected_state_changes:" + ",".join(changed))
    return {
        "passed": True,
        "status": "EXACT_GETTER277_SUCCESSOR" if mode == "apply" else "EXACT_READ_ONLY_PLAN_NO_STATE_CHANGE",
        "allowed_changes": allowed,
        "compared_kinds": sorted(KINDS),
        "getter_other_pg_proc_metadata_equal": a["getter"]["metadata"] == b["getter"]["metadata"],
        "old_ledger_rows_exactly_preserved": True,
        "before_ledger_rows": len(old_ledger),
        "after_ledger_rows": len(b["ledger"]["rows"]),
        "api_ingestor_ordinary_receipts_security_study_equal": True,
        "password_proof": "presence-only plus role metadata/source custody; not verifier-value equality",
        "all_table_data_or_all_database_objects_captured": False,
        "whole_issue_acceptance": False,
        "state_record_sha256": {
            k: {"before": sha(canonical(a[k])), "after": sha(canonical(b[k]))} for k in sorted(KINDS)
        },
    }


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--before", required=True)
    p.add_argument("--after", required=True)
    p.add_argument("--mode", required=True, choices=["plan", "apply"])
    p.add_argument("--migration")
    p.add_argument("--expected-migration-sha256")
    p.add_argument("--output", required=True)
    args = p.parse_args()
    report = {
        "schema": "getter277-production-state-comparison-v1",
        "passed": False,
        "mode": args.mode,
        "source_sha256": sha(Path(__file__).read_bytes()),
        "input_sha256": {},
        "native_calls_performed": False,
    }
    try:
        before, br, bh = read_capture(args.before)
        report["input_sha256"].update(bh)
        after, ar, ah = read_capture(args.after)
        report["input_sha256"].update(ah)
        migration_sha = None
        if args.mode == "apply":
            require(
                bool(args.migration) and bool(args.expected_migration_sha256), "actual_migration_file_and_sha_required"
            )
            raw = Path(args.migration).read_bytes()
            migration_sha = sha(raw)
            require(len(raw) <= 128 * 1024 and migration_sha == args.expected_migration_sha256, "migration_source_seal")
            report["input_sha256"][args.migration] = migration_sha
        report.update(compare(before, after, br, ar, args.mode, migration_sha))
    except Exception as exc:
        report.update(
            status="REFUSED_OR_FAILED",
            passed=False,
            failure_type=type(exc).__name__,
            failure_code=str(exc) if isinstance(exc, Refusal) else None,
        )
    with Path(args.output).open("x") as f:
        f.write(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"status": report["status"], "passed": report["passed"], "output": args.output}))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
