#!/usr/bin/env python3
"""Pure owning-Job emitter/release-patch preparer; never runs kubectl or connects.

ROOT supplies the qualified real image digest, current rendered source, live
ConfigMap metadata and fresh named snapshots. No hook/Application sync is emitted.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path

NS = "verdify-prod"
IMAGE = "registry.vallery.net/verdifyconsultancy/verdify-migrate@sha256:"
CONTRACT_SHA = "90fac3dafbf927e6dfc67d8ec73e6b41c4f818f5c983216550848be8bf9dff6f"
CONTRACT_NAME = "verdify-c0-boundary-contract-240-248-c67h948tfk"
NAMES = {m: f"verdify-getter277-{m}-20261018-01" for m in ("plan", "apply")}
INNER_ENV = {
    "VERDIFY_MIGRATE_STATEMENT_TIMEOUT": "30s",
    "VERDIFY_MIGRATE_LOCK_TIMEOUT": "500ms",
    "VERDIFY_MIGRATE_IDLE_TX_TIMEOUT": "15s",
    "PGOPTIONS": "-c statement_timeout=30s -c lock_timeout=500ms -c idle_in_transaction_session_timeout=15s",
}
INIT_ORIGINAL = 'until pg_isready -h verdify-db -p 5432 -U verdify; do echo "waiting for db"; sleep 2; done'
INIT_BOUNDED = '''set -eu
i=0
while [ "$i" -lt 15 ]; do
  if pg_isready -t 2 -h verdify-db -p 5432 -U verdify; then exit 0; fi
  i=$((i + 1))
  if [ "$i" -lt 15 ]; then sleep 2; fi
done
echo "database readiness deadline exceeded" >&2
exit 1'''


def require(ok, code):
    if not ok:
        raise ValueError(code)


def raw_sha(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(value):
    return (json.dumps(value, sort_keys=True, separators=(",", ":")) + "\n").encode()


def load(path, expected=None):
    raw = Path(path).read_bytes()
    require(len(raw) <= 8 * 1024 * 1024, "bounded_input_size")
    if expected is not None:
        require(raw_sha(raw) == expected, "input_hash")
    return json.loads(raw), raw_sha(raw)


def hex_digest(value):
    require(isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value) and len(set(value)) > 1,
            "real_qualified_sha256_required")
    return value


def env_map(container):
    env = container.get("env", [])
    require(len({x["name"] for x in env}) == len(env), "duplicate_environment")
    return {x["name"]: x for x in env}


def owning_job(render):
    require(isinstance(render, list), "rendered_json_object_list_required")
    require(not any(x.get("kind") == "Secret" for x in render), "render_contains_secret")
    jobs = [x for x in render if x.get("kind") == "Job" and x.get("metadata", {}).get("name") == "verdify-migrate"]
    require(len(jobs) == 1, "one_owning_migration_job")
    job = jobs[0]
    require(job["apiVersion"] == "batch/v1" and job["metadata"].get("namespace") == NS, "owning_job_identity")
    pod = job["spec"]["template"]["spec"]
    require(len(pod["containers"]) == len(pod["initContainers"]) == 1, "owning_container_inventory")
    main, init = pod["containers"][0], pod["initContainers"][0]
    require(main["name"] == "migrate" and main["command"] == ["/usr/local/bin/migrate.sh"]
            and not main.get("args") and main["image"].startswith(IMAGE), "owning_main_source")
    require(init["name"] == "wait-for-db" and init["command"] == ["sh", "-c", INIT_ORIGINAL], "owning_init_source")
    require(pod["restartPolicy"] == "Never", "owning_restart_policy")
    require(pod["securityContext"] == {"runAsGroup": 1000, "runAsNonRoot": True, "runAsUser": 1000,
                                         "seccompProfile": {"type": "RuntimeDefault"}}, "owning_pod_security")
    for container in (main, init):
        security = container["securityContext"]
        require(security.get("readOnlyRootFilesystem") is True and security.get("allowPrivilegeEscalation") is False
                and security.get("capabilities") == {"drop": ["ALL"]}, "owning_container_security")
    env = env_map(main)
    for name, value in {"VERDIFY_MIGRATE_LEDGER": "1", "VERDIFY_C0_BOUNDARY_CONTRACT": "/db/c0-boundary-contract.json",
                        "VERDIFY_C0_BOUNDARY_CONTRACT_SHA256": CONTRACT_SHA}.items():
        require(env.get(name) == {"name": name, "value": value}, "owning_contract_environment")
    for name in ("POSTGRES_PASSWORD", "DB_PASS"):
        require(env.get(name) == {"name": name, "valueFrom": {"secretKeyRef": {
            "key": "POSTGRES_PASSWORD", "name": "verdify-app-secrets"}}}, "owning_secret_reference")
    require(set(env) == {"POSTGRES_PASSWORD", "DB_PASS", "VERDIFY_MIGRATE_LEDGER",
                         "VERDIFY_C0_BOUNDARY_CONTRACT", "VERDIFY_C0_BOUNDARY_CONTRACT_SHA256"}, "owning_env_inventory")
    require(main["envFrom"] == [{"configMapRef": {"name": "verdify-config"}}], "owning_config_reference")
    volumes = {v["name"]: v for v in pod["volumes"]}
    require(len(volumes) == len(pod["volumes"]) == 2 and volumes == {
        "c0-boundary-contract": {"name": "c0-boundary-contract", "configMap": {"defaultMode": 292, "name": CONTRACT_NAME}},
        "tmp": {"name": "tmp", "emptyDir": {}}}, "owning_volume_inventory")
    mounts = {v["name"]: v for v in main["volumeMounts"]}
    require(len(mounts) == len(main["volumeMounts"]) == 2 and mounts == {
        "c0-boundary-contract": {"mountPath": "/db/c0-boundary-contract.json", "name": "c0-boundary-contract",
                                 "readOnly": True, "subPath": "contract.json"},
        "tmp": {"mountPath": "/tmp", "name": "tmp"}}, "owning_mount_inventory")
    cms = [x for x in render if x.get("kind") == "ConfigMap" and x.get("metadata", {}).get("name") == CONTRACT_NAME]
    require(len(cms) == 1 and set(cms[0].get("data", {})) == {"contract.json"}, "rendered_contract_inventory")
    require(raw_sha(cms[0]["data"]["contract.json"].encode()) == CONTRACT_SHA, "rendered_contract_bytes")
    return job


def contract_metadata(metadata):
    # Metadata-only JSON prepared by ROOT; never a Secret JSON or secret value.
    require(set(metadata) == {"name", "namespace", "uid", "resourceVersion", "contract_sha256"}, "contract_metadata_shape")
    require(metadata["name"] == CONTRACT_NAME and metadata["namespace"] == NS
            and metadata["contract_sha256"] == CONTRACT_SHA, "live_contract_binding")
    require(re.fullmatch(r"[0-9a-f-]{36}", metadata["uid"]) and re.fullmatch(r"[0-9]+", metadata["resourceVersion"]),
            "live_contract_identity")


def emit(render, digest, mode, metadata):
    hex_digest(digest)
    require(mode in NAMES, "plan_or_apply_only")
    contract_metadata(metadata)
    source = owning_job(render)
    job = copy.deepcopy(source)
    job["metadata"]["name"] = NAMES[mode]
    # A standalone Job must not invite hook/full-sync/controller behavior.
    for key in ("argocd.argoproj.io/hook", "argocd.argoproj.io/hook-delete-policy"):
        job["metadata"].get("annotations", {}).pop(key, None)
    if not job["metadata"].get("annotations"):
        job["metadata"].pop("annotations", None)
    job["spec"].update(suspend=True, backoffLimit=0, activeDeadlineSeconds=300, completions=1, parallelism=1)
    pod = job["spec"]["template"]["spec"]
    # No API access is required; retain all owning user/security/Secret refs.
    pod["automountServiceAccountToken"] = False
    main = pod["containers"][0]
    main["image"] = IMAGE + digest
    main["env"] = [v for v in main["env"] if v["name"] not in {*INNER_ENV, "VERDIFY_MIGRATE_PLAN"}]
    main["env"].extend({"name": name, "value": value} for name, value in INNER_ENV.items())
    if mode == "plan":
        main["env"].append({"name": "VERDIFY_MIGRATE_PLAN", "value": "1"})
    pod["initContainers"][0]["command"] = ["sh", "-c", INIT_BOUNDED]
    return job


def normalized_spec(job, uid):
    spec = copy.deepcopy(job["spec"])
    for key, value in (("completionMode", "NonIndexed"), ("manualSelector", False),
                       ("podReplacementPolicy", "TerminatingOrFailed")):
        if spec.get(key) == value:
            spec.pop(key)
    selector = spec.pop("selector", None)
    require(selector in (None, {"matchLabels": {"batch.kubernetes.io/controller-uid": uid}}), "generated_job_selector")
    labels = spec["template"]["metadata"].get("labels", {})
    for key, value in (("batch.kubernetes.io/controller-uid", uid), ("controller-uid", uid),
                       ("batch.kubernetes.io/job-name", job["metadata"]["name"]), ("job-name", job["metadata"]["name"])):
        if key in labels:
            require(labels.pop(key) == value, "generated_job_label")
    pod = spec["template"]["spec"]
    for key, value in (("dnsPolicy", "ClusterFirst"), ("schedulerName", "default-scheduler"),
                       ("terminationGracePeriodSeconds", 30), ("enableServiceLinks", True),
                       ("serviceAccountName", "default"), ("serviceAccount", "default")):
        if pod.get(key) == value:
            pod.pop(key)
    for c in pod["containers"] + pod["initContainers"]:
        for key, value in (("imagePullPolicy", "IfNotPresent"), ("terminationMessagePath", "/dev/termination-log"),
                           ("terminationMessagePolicy", "File"), ("resources", {})):
            if c.get(key) == value:
                c.pop(key)
    return spec


def verify_suspended(desired, actual, expected_uid):
    meta = actual["metadata"]
    require(actual.get("kind") == "Job" and actual.get("apiVersion") == "batch/v1", "snapshot_kind")
    require(meta["name"] == desired["metadata"]["name"] and meta["namespace"] == NS
            and meta["uid"] == expected_uid and meta.get("generation") == 1, "exact_suspended_identity")
    require(not meta.get("deletionTimestamp") and not meta.get("ownerReferences"), "no_deleting_or_foreign_owner")
    require(meta.get("labels", {}) == desired["metadata"].get("labels", {})
            and meta.get("annotations", {}) == desired["metadata"].get("annotations", {}), "metadata_source_drift")
    require(actual["spec"].get("suspend") is True, "still_suspended")
    require(normalized_spec(actual, expected_uid) == normalized_spec(desired, expected_uid), "exact_desired_spec")
    status = actual.get("status", {})
    for key in ("active", "succeeded", "failed", "startTime", "completionTime", "ready", "terminating"):
        require(not status.get(key), "prior_execution_evidence")
    require(not any(status.get("uncountedTerminatedPods", {}).values()), "uncounted_execution_evidence")
    require(all(c.get("type") == "Suspended" and c.get("status") == "True" for c in status.get("conditions", [])),
            "unexpected_job_condition")


def release_patch(desired, created, fresh, pods, *, observed_at, now=None):
    now = now or datetime.now(timezone.utc)
    observed = datetime.fromisoformat(observed_at.replace("Z", "+00:00"))
    require(observed.tzinfo is not None and 0 <= (now - observed).total_seconds() <= 15, "fresh_get_expired")
    uid = created["metadata"]["uid"]
    require(re.fullmatch(r"[0-9a-f-]{36}", uid), "created_uid")
    verify_suspended(desired, created, uid)
    verify_suspended(desired, fresh, uid)
    require(created["spec"] == fresh["spec"], "created_to_fresh_spec_drift")
    require(pods.get("kind") == "List" and pods.get("items") == [], "named_job_has_pods")
    rv = fresh["metadata"]["resourceVersion"]
    require(re.fullmatch(r"[0-9]+", rv), "fresh_resource_version")
    return [
        {"op": "test", "path": "/metadata/uid", "value": uid},
        {"op": "test", "path": "/metadata/resourceVersion", "value": rv},
        {"op": "test", "path": "/metadata/generation", "value": 1},
        {"op": "test", "path": "/spec", "value": fresh["spec"]},
        {"op": "test", "path": "/spec/suspend", "value": True},
        {"op": "replace", "path": "/spec/suspend", "value": False},
    ]


def write_new(path, value):
    with Path(path).open("xb") as f:
        f.write(canonical(value))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="action", required=True)
    build = sub.add_parser("emit")
    for flag in ("render", "render-sha256", "image-digest", "source-revision", "contract-metadata", "output"):
        build.add_argument("--" + flag, required=True)
    patch = sub.add_parser("release-patch")
    for flag in ("manifest", "manifest-sha256", "created", "created-sha256", "fresh", "pods", "observed-at", "output"):
        patch.add_argument("--" + flag, required=True)
    args = parser.parse_args()
    if args.action == "emit":
        render, render_sha = load(args.render, hex_digest(args.render_sha256))
        metadata, metadata_sha = load(args.contract_metadata)
        require(re.fullmatch(r"[0-9a-f]{40}", args.source_revision), "exact_source_revision")
        out = Path(args.output)
        out.mkdir(exist_ok=False)
        write_new(out / "input-seal.json", {"source_revision": args.source_revision, "render_sha256": render_sha,
            "contract_metadata_sha256": metadata_sha, "qualified_image_digest": hex_digest(args.image_digest),
            "driver_sha256": raw_sha(Path(__file__).read_bytes()), "owning_job_sha256": raw_sha(canonical(owning_job(render)))})
        for mode in NAMES:
            write_new(out / (mode + "-job.json"), emit(render, args.image_digest, mode, metadata))
        write_new(out / "packet.json", {"status": "PREPARED_NOT_SUBMITTED", "source_revision": args.source_revision,
            "jobs": {m: {"name": NAMES[m], "sha256": raw_sha((out / (m + "-job.json")).read_bytes())} for m in NAMES},
            "namespace": NS, "existing_contract_metadata": metadata,
            "inner_apply_gucs": {"statement_timeout": "30s", "lock_timeout": "500ms", "idle_in_transaction_session_timeout": "15s"},
            "c0_metadata_psql_defaults": {"statement_timeout": "15min", "lock_timeout": "30s", "idle_in_transaction_session_timeout": "5min"},
            "c0_metadata_queries_set_local_statement_timeout": "30s",
            "all_connections_have_500ms_lock_timeout": False,
            "active_deadline_seconds": 300, "readiness_max_seconds": 58,
            "source_security_change": "automountServiceAccountToken false only; owning users, capabilities, rootfs, Secret refs retained",
            "no_other_migration_or_ddl_owner_may_overlap": True,
            "standalone_migrate_only_no_full_sync": True,
            "plan_only_does_not_qualify_apply": True,
            "apply_flag": "VERDIFY_MIGRATE_PLAN absent, not value0"})
    else:
        desired, _ = load(args.manifest, hex_digest(args.manifest_sha256))
        created, _ = load(args.created, hex_digest(args.created_sha256))
        fresh, _ = load(args.fresh)
        pods, _ = load(args.pods)
        require(desired["metadata"]["name"] in NAMES.values(), "fixed_job_name")
        write_new(args.output, release_patch(desired, created, fresh, pods, observed_at=args.observed_at))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (ValueError, KeyError, TypeError, OSError) as exc:
        # Input content may be private; never print arbitrary exception values.
        print(json.dumps({"status": "SOURCE_PREPARATION_REFUSED", "type": type(exc).__name__}))
        raise SystemExit(1) from None
