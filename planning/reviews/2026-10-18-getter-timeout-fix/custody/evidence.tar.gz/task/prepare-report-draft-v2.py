"""Private installed-proof draft; reads retained receipts, never GitHub/native state."""
import datetime
import hashlib
import json
import pathlib
import sys

ROOT = pathlib.Path('/Users/jason/.codex/worktrees/getter-timeout-fix-20261018/verdify-platform')
BASE = pathlib.Path('/private/tmp/verdify-getter-fix-20261018')
OUT = BASE / 'report-draft-v2'
OUT.mkdir(exist_ok=False)
sys.path.insert(0, str(ROOT))
from planning.schema import Backlog, load
from planning.render import issue_body, issue_title

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(name):
    return json.loads((BASE / name).read_text())

def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')

ci = read('corrected-source-ci-verified.json')
installed = read('owner-installed-receipt.json')
results = read('installed-getter-results-verified.json')
plan_proof = read('plan-state-unchanged.json')
apply_proof = read('applied-state-verified.json')
jobs = {mode: read(f'owning-{mode}-01/result.json') for mode in ('plan', 'apply')}
assert ci['status'] == 'SOURCE_GATE_THREE_BUILDS_AND_PIN_PUBLISHER_VERIFIED'
assert len(ci['pods']) == 5 and all(p['all_declared_containers_zero_exit_zero_restarts'] for p in ci['pods'])
assert installed['status'] == 'GETTER277_INSTALLED_EXACT_NATIVE_SUCCESSOR'
assert results['status'] == 'INSTALLED_ORDINARY_REAL_EPISODES_PASSED'
assert results['custom_generic_all46_values_equal'] and results['configured_product_timeout_ms'] == 15000
assert not results['timeout_increased'] and not results['whole_issue_410_acceptance']
assert plan_proof['passed'] and apply_proof['passed']
for job in jobs.values():
    assert any(c['type'] == 'Complete' and c['status'] == 'True' for c in job['conditions'])
    assert all(c['state']['terminated']['exitCode'] == 0 and c['restartCount'] == 0 for c in job['containers'])

plan = load(ROOT / 'planning/backlog.yaml')
items = {x.issue_number: x for x in plan.issues}
destination = 'planning/reviews/2026-10-18-getter-timeout-fix/README.md'
next410 = ('Use the installed validity-bearing results to complete a bounded daytime-coverage assessment and verify the intended admin/planner consumption paths through existing approved identities. Distinguish observed zero holds from complete measured absence, preserve ineffective/incomplete outcomes, and keep crop-sensing and physical-efficacy requirements explicit. Reuse the accepted getter delivery; no repair retry, new credential or broader audience is required by this checkpoint.')
next775 = ('Advance the remaining measured daytime evidence, intended outcome-consumer route, authentic scientific inputs and physical/recovery work. Reuse the installed getter and accepted MCP/S3B receipts; retain negative and inconclusive outcomes, unchanged acceptance edges and the original effort estimates without inferring remaining hours.')
baseline410 = ('Migration 277 is installed through the owning migrate-only plan/apply Jobs from qualified source 8d7ff1a2 and release-pin commit 8c224302. Corrected native workflow 26nj4 completed successfully with five Pods, all declared containers exiting zero without restarts, and three exact-source images; only migrate was promoted. The plan changed no captured state. Apply added exactly the runner-stamped 277 row, replaced the getter body and advanced the MCP seal/receipt; prior ledger rows, ordinary receipts and captured role/security/study metadata were preserved. Twenty native full-46-column synthetic parity cases and 2,673 genuine clone readback relations support the rewrite; original failures and the separate limits of those proofs remain retained.\n\nThe actual ordinary MCP LOGIN/attester path on the two unchanged replicas returned the original October 16 window in 11.816649 seconds with zero rows and pending status. The explicitly selected October 4 window returned four rows in 11.269874 seconds with a custom plan and 4.966761 seconds with a generic plan; all 46 values matched across those separate historical snapshots. Two episodes are complete/ineffective and two are incomplete/insufficient-evidence; none is effective. The configured 15-second timeout was unchanged. The earlier 3.174204-second clone candidate result is not an installed-production timing. Observed daylight had zero hold samples, but complete daytime coverage, positive admin dispatch and planner consumption are not proved. Runtime HTTP/smoke evidence is being finalized separately by ROOT.\n\nCurrent execution allocation: S3B follow-up. Next action: ' + next410 + '\n\nEvidence: ' + destination + '. All three acceptance clauses and completion edges remain open and unchanged; this completes the bounded getter repair, not the broader scientific/control issue.')
baseline775 = ('The selected getter repair is installed and its ordinary-role result path is verified. Source 8d7ff1a2 passed the full native gate and three selected builds; release-pin commit 8c224302 promoted only migrate. The owning plan/apply Jobs and exact poststate prove migration 277 plus its MCP seal/receipt, with prior ledger and captured ordinary authority/study state preserved. Actual ordinary calls completed within the unchanged 15-second budget: the original October 16 window returned zero rows/pending; the selected October 4 custom/generic calls returned the same four 46-column rows, with two ineffective and two insufficient-evidence dispositions. Neither clone timing nor narrow safety status is being presented as physical efficacy or full issue acceptance. Runtime HTTP/smoke evidence is being finalized separately by ROOT.\n\nCurrent execution allocation: ROLLUP. Next action: ' + next775 + '\n\nThe retained 18:13:18 UTC native graph matched the canonical plan: 47 open issues, 143 open acceptance clauses, 26 local plus HA #878 → #981 active edges (27 total), 24 closed predecessor records, matching parent/open-subissue links and no cycle in the captured graph. Final publication will refresh conformance. Preserve original 22–34h/40h estimates without inferring remaining hours.\n\nEvidence: ' + destination + '. Previously accepted S3B/MCP work and historical failures remain intact. Acceptance clauses, states, parentage and dependencies remain unchanged.')
how410 = list(items[410].how)
how410[0] = ('Reuse the installed migration 277, native parity and exact ledger/seal/receipt evidence. Preserve original failures, full 46-column results, NULL and tie behavior, helper cardinality and solar/response semantics; do not repeat the completed repair to claim broader acceptance.')
how410[1] = ('Reuse the accepted MCP-only release and actual installed ordinary-role getter results on both replicas. Verify positive outcome-tool dispatch through an existing approved admin identity and separately qualify the intended planner consumption path; do not silently add the admin-only tool to Iris or expand credentials/audiences for proof.')
how775 = list(items[775].how)
how775[2] = ('Reuse completed P1 native/P2 admission/P4 custody, accepted MCP release and the installed getter 277. Advance measured daytime coverage, intended admin/planner outcome consumption and physical/input gaps while retaining ineffective, incomplete and empty results and avoiding repeated accepted delivery.')
updates = {
 '410': {'baseline': baseline410, 'how': how410,
         'decision': 'The authorized getter repair is installed and ordinary-role behavior is verified within the existing 15-second product fence. No new credential, admin audience, planner access, controller tuning, physical experiment or OTA was created. Remaining daytime, consumer-route, sensing and physical acceptance is explicit; the repair is not a new approval gate for bounded follow-up work.',
         'next_action': next410},
 '775': {'baseline': baseline775, 'how': how775,
         'decision': items[775].decision,
         'next_action': next775}
}
write('proposed-updates.json', updates)
data = plan.model_dump()
for row in data['issues']:
    patch = updates.get(str(row['issue_number']))
    if patch:
        for field in ('baseline', 'how', 'decision'):
            row[field] = patch[field]
draft = Backlog.model_validate(data)
changed = {}
for before, after in zip(plan.model_dump()['issues'], draft.model_dump()['issues']):
    fields = [k for k in before if before[k] != after[k]]
    if fields:
        assert before['issue_number'] in (410, 775) and set(fields) <= {'baseline', 'how', 'decision'}
        changed[str(before['issue_number'])] = fields
assert len([x for x in draft.issues if x.status == 'open']) == 47
assert sum(len(x.acceptance) for x in draft.issues if x.status == 'open') == 143
keyed = {x.key: x for x in draft.issues}
edges = {(keyed[d].issue_number, x.issue_number) for x in draft.issues if x.status == 'open'
         for d in x.depends_on if keyed[d].status == 'open'}
assert len(edges) == 26
for item in draft.issues:
    if item.issue_number in (410, 775):
        (OUT / f'issue-{item.issue_number}-body.draft.md').write_text(issue_body(item, draft))

names = ['corrected-source-ci-verified.json', 'plan-state-unchanged.json', 'applied-state-verified.json',
         'owner-installed-receipt.json', 'installed-getter-results-verified.json',
         'owning-plan-01/result.json', 'owning-apply-01/result.json', 'graph-before-final/verified.json',
         'native-fixtures-b-01/receipt.json', 'native-fixtures-b-02/receipt.json', 'native-fixtures-b-02/stdout',
         'clone-a-b-comparison.json', 'clone-readback-parity-01/stdout',
         'production-candidate-b-service-01/stdout', 'production-empty-eligibility-01/stdout',
         'production-exact-migration-rollback-01/stdout', 'rollback-fresh-state-verification.json']
evidence = [{'path': str(BASE/n), 'bytes': (BASE/n).stat().st_size, 'sha256': sha(BASE/n)} for n in names]
write('evidence-index.private.json', evidence)
public = {
 'schema': 'verdify-getter277-installed-checkpoint/v1',
 'status': 'INSTALLED_GETTER_REPAIR_VERIFIED_RUNTIME_WRAPUP_PENDING',
 'build_source': ci['source_revision'], 'release_commit': installed['release_commit'],
 'workflow': {k: ci[k] for k in ('workflow','workflow_uid','finished_at')},
 'source_ci_pods': 5, 'all_declared_containers_zero_exit_zero_restarts': True,
 'built_profiles': ci['profile_set'], 'promoted_profiles': ['migrate'],
 'migrate_image': installed['image'],
 'owning_jobs': [{k: jobs[m][k] for k in ('mode','job','uid','pod','pod_uid','finished')} for m in ('plan','apply')],
 'runner277': installed['runner277'], 'getter': installed['getter'],
 'mcp_boundary_sha256': installed['boundaries']['mcp_boundary']['sha256'],
 'plan_state_unchanged': plan_proof['passed'], 'applied_state_exact_successor': apply_proof['passed'],
 'state_comparison_scope': apply_proof['compared_kinds'],
 'all_database_tables_or_objects_claimed': False, 'password_verifier_value_equality_claimed': False,
 'ordinary_results': results,
 'synthetic_native_parity_cases': 20, 'same_snapshot_real_readback_rows': 2673,
 'runtime_http_smoke_complete': False, 'runtime_note': 'ROOT will add its final runtime receipt; pending here by design.',
 'native_graph_last_verified_at': read('graph-before-final/verified.json')['checked_at'],
 'open_issues': 47, 'open_acceptance_clauses': 143, 'local_active_edges': 26,
 'external_active_edges': [{'predecessor': 'jvallery/homeassistant#878', 'dependent': 'VerdifyConsultancy/verdify-platform#981'}],
 'full_issue_410_accepted': False, 'full_campaign_775_accepted': False,
 'original_failures_preserved': True,
 'receipt_sha256': {n: sha(BASE/n) for n in names if n.endswith('.json')}
}
write('result.draft.json', public)
report = '''# Getter 277 installed repair and real outcome readback

The bounded getter timeout repair is installed, and actual ordinary MCP role calls now return results within the unchanged 15-second product limit. The original October 16 night remains empty/pending. The deliberately selected October 4 historical window returns four episodes: two complete but ineffective, and two incomplete with insufficient evidence. No episode is classified effective. This finishes the selected repair and result-path proof; #410 and #775 remain open.

## Actual delivery

The first source attempt `16d13f64` and workflow `5vzfd` failed the full gate because the new forward migration was missing from the historical baseline-stamp exception. Correction `8d7ff1a2829c246600da4f15027121e9c7193913` retained the already-qualified SQL and seals. Workflow `verdify-platform-ci-26nj4`, UID `74fa9db5-5fd2-4a52-abf5-6a210ec8c49f`, completed at 18:59:57 UTC. All five actual Pods have complete zero-exit, zero-restart container custody. The normal pipeline built ingestor, migrate and lab-publisher; only migrate was promoted by `8c2243020e82f52fbdf3169278715302f7688edf`.

The delivered migrate image is `registry.vallery.net/verdifyconsultancy/verdify-migrate@sha256:0bdb10cfd458de4b1bd4e201024efbf19aa724e0087cf5dcf88ce02c9a0043ae`. The owning plan Job UID `acb9cac5-d4fa-41dc-b3e1-ee5d95cddda8` completed without changing captured state. The separate apply Job UID `288535fc-7290-4954-bf65-ea206eb5ea5b` completed with both containers exiting zero and no restarts. Its runner stamped migration 277 at 19:03:05.611609 UTC. No full Application sync or unrelated bootstrap/study hook was used for this operation.

Exact poststate comparison permits only the new 277 ledger row, getter body/definition and MCP computed/stored boundary. All 284 prior ledger rows remain exact; the new count is 285. Captured ordinary receipts, role metadata, memberships/settings and study state match. Getter metadata other than its body is preserved. This is a scoped metadata/source comparison, not an all-table or whole-database proof; password evidence is presence-only plus source/role custody, not verifier-value equality.

| Bound source | SHA256 |
|---|---|
| Migration 277 | `a8a0bc063bd655d2e96dd3d424768169edb4ea714c7a1b51dca2b41cc39b29a1` |
| Getter body | `578a07bed56714cd2dfe2308ca30ced1f6fc6916fd7db9d79630a7b82b261655` |
| Installed definition | `89782089fd6ae3ecfeecdfbc1b730f6ab6a272c0da7b35ef562788eddbfa42c0` |
| MCP computed boundary and stored receipt | `1cd20508c9196bf9758d7df40ae699e6b83aefccb91a4c5242492f7993f6eb02` |

## Installed ordinary-role results

These measurements use the actual ordinary MCP LOGIN and attester on the two unchanged MCP replicas, in three separately captured read-only repeatable-read sessions. They are not clone measurements or owner-only ad-hoc candidate queries.

| Night | Prepared plan | Actual getter time | Result |
|---|---|---:|---|
| October 16 | Custom | 11.816649 s | 0 rows; pending |
| October 4 | Custom | 11.269874 s | 4 rows: 2 ineffective, 2 insufficient-evidence |
| October 4 | Generic | 4.966761 s | The same 4 rows, exact equality across all 46 fields |

The configured timeout remains 15,000 ms. No timeout was increased. The narrow safety field for the four historical rows is pass while evidence completeness remains two complete/two incomplete; that field does not turn the incomplete episodes into accepted scientific evidence. The October 16 empty result remains pending. These are finite measured calls, not a repeated-load latency guarantee or all-plan-mode proof for every date.

## Qualification and original limits

The rewrite preserves the 46-column contract, historical seed/tie semantics, grouped-event MAX, NULL-event stop behavior, both inner helper cardinalities and the scientific tail. Twenty actual native synthetic old/new full-row cases passed. A same-snapshot genuine clone relation comparison retained all 2,673 readback rows and found zero EXCEPT ALL differences, including NULL and duplicate multiplicity. These are complementary proofs: synthetic helpers do not prove physical behavior, and the readback relation deliberately excludes the helper/scientific tail.

The separate clone candidate B timing of 3.174204 seconds is retained as qualification evidence only. It is not advertised as installed production latency. Full original real-data reference calls timed out at 15 and 30 seconds, so no successful complete original real-data rowset exists. Candidate A/B four-row equality used separate historical snapshots. Original 2-second failures, the first fixture-runner syntax failure and the first full CI failure remain unchanged.

Before installation, the original October 16 source-body result had 2,785 climate/action/resolved minutes and 750 selected solar-night minutes, with zero active, demand or admitted minutes and no null served VPD. This supported a genuine empty result rather than missing all source input. Daylight observations contained zero hold-action samples and 12/2 ordinary dry-action samples across October 16/17, but complete daytime coverage was not established. Do not infer complete measured absence from those counts.

## Remaining work and publication boundary

ROOT is finalizing the post-migration HTTP, smoke, single-writer and runtime readback. Add that receipt here; this draft does not claim it completed. The getter repair itself and its ordinary-role result proof are complete and should not be queued again.

The next work is a bounded daytime-coverage assessment and the intended outcome-consumer route. Positive admin tool dispatch and ordinary-planner consumption are still unverified. Use existing approved identities and preserve the current audience boundary; this checkpoint does not require new credentials or silently expose the admin-only outcome tool to Iris. Physical efficacy, crop safety and missing sensing require their own evidence. The four real rows provide negative/incomplete results, not a controller-tuning or watering recommendation.

The retained 18:13:18 UTC native graph matched 47 open issues, 143 open acceptance clauses, 26 local plus HA #878 → #981 active edges, 24 closed predecessor records, exact open parent/subissue links and an acyclic captured graph. Final publication should refresh conformance after only #410/#775 baseline/how/decision wording changes. States, acceptance clauses, dependencies, assignees and priorities remain unchanged. Preserve the original 22–34h/40h estimates without inventing remaining hours.
'''
(OUT / 'README.draft.md').write_text(report)
write('handoff.json', {
 'status': 'INSTALLED_PROOF_DRAFT_RUNTIME_WRAPUP_PENDING', 'created_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'source_revision': ci['source_revision'], 'release_commit': installed['release_commit'],
 'canonical_backlog_sha256': sha(ROOT/'planning/backlog.yaml'), 'suggested_report_destination': destination,
 'changed_backlog_fields': changed, 'next_action_storage': 'Embedded in baseline; JSON next_action is a handoff field only.',
 'unchanged_acceptance_states_graph': True, 'open_issues':47, 'open_acceptance_clauses':143, 'local_edges':26, 'total_edges_with_external':27,
 'remaining_root_append': ['actual HTTP/smoke/single-writer/runtime receipt', 'final native graph/source conformance', 'final retained evidence/archive pointer'],
 'body_sync': 'Render with planning.render.issue_body/issue_title after final composition; fresh compare before body-only GitHub update. Preserve all metadata and states. ROOT sole writer.',
 'read_only_graph_helper': str(BASE/'read-graph-before-final.py'),
 'graph_helper_reuse': 'Create a new helper/output path bound to actual final source. Frozen helper expects16d and refuses overwrite; do not relabel its old receipt.',
 'source_edits':0, 'native_calls':0, 'github_calls':0, 'issue_closures':0
})
write('draft-manifest.json', {p.name:sha(p) for p in sorted(OUT.iterdir()) if p.is_file()})
print(json.dumps({'directory':str(OUT),'changed_fields':changed,'open':47,'acceptance_clauses':143,'local_edges':26,'whole_issue_closed':False}))
