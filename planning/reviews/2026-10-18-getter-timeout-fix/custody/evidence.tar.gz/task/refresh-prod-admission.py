import subprocess,json,pathlib,sys,datetime,hashlib
out=pathlib.Path(sys.argv[1]);out.mkdir(exist_ok=False);k=['kubectl','--context','vallery','--request-timeout=15s']
def get(args,label=None):
 raw=subprocess.check_output(k+args+['-o','json'],timeout=20);v=json.loads(raw)
 if label:(out/(label+'.json')).write_bytes(raw)
 return v
def qty(s):
 if isinstance(s,(float,int)):return float(s)
 for suffix,factor in [('Ki',1024),('Mi',1024**2),('Gi',1024**3),('Ti',1024**4),('n',1e-9),('u',1e-6),('m',1e-3)]:
  if s.endswith(suffix):return float(s[:-len(suffix)])*factor
 return float(s)
ns=['-n','verdify-prod'];app=get(['-n','argocd','get','application','verdify-prod-dark'],'app');assert app['metadata']['uid']=='cae977c6-dcd1-42aa-a526-dc9ff2bd8c69' and not app.get('operation') and app['status'].get('operationState',{}).get('phase')!='Running'
pods=get(ns+['get','pods'],'prod-pods');deps=get(ns+['get','deployments'],'prod-deploys');jobs=get(ns+['get','jobs'],'prod-jobs');assert not any(j['metadata']['name'].startswith(('verdify-migrate','verdify-getter277')) and j.get('status',{}).get('active',0) for j in jobs['items'])
get(ns+['get','service','verdify-db'],'db-service');get(ns+['get','endpointslice','-l','kubernetes.io/service-name=verdify-db'],'db-endpoints');limits=get(ns+['get','limitrange'],'limits');quotas=get(ns+['get','resourcequota'],'quota');assert len(limits['items'])==1 and limits['items'][0]['spec']=={'limits':[{'default':{'memory':'1Gi'},'defaultRequest':{'cpu':'25m','memory':'32Mi'},'max':{'memory':'6Gi'},'min':{'memory':'8Mi'},'type':'Container'}]};cm=get(ns+['get','configmap','verdify-c0-boundary-contract-240-248-c67h948tfk'],'c0-contract');assert cm['metadata']['uid']=='89cd52ad-8f9a-46e8-bf4d-1602c249b28f';digest=hashlib.sha256(cm['data']['contract.json'].encode()).hexdigest();assert digest=='90fac3dafbf927e6dfc67d8ec73e6b41c4f818f5c983216550848be8bf9dff6f'
(out/'c0-metadata.json').write_text(json.dumps({'name':cm['metadata']['name'],'namespace':cm['metadata']['namespace'],'uid':cm['metadata']['uid'],'resourceVersion':cm['metadata']['resourceVersion'],'contract_sha256':digest},indent=2)+'\n')
config=get(ns+['get','configmap','verdify-config']);forbidden={'VERDIFY_MIGRATE_PLAN','VERDIFY_MIGRATIONS_DIR','PGOPTIONS','VERDIFY_MIGRATE_STATEMENT_TIMEOUT','VERDIFY_MIGRATE_LOCK_TIMEOUT','VERDIFY_MIGRATE_IDLE_TX_TIMEOUT'};assert not forbidden & set(config.get('data',{}))
(out/'config-metadata.json').write_text(json.dumps({'name':config['metadata']['name'],'uid':config['metadata']['uid'],'resourceVersion':config['metadata']['resourceVersion'],'keys':sorted(config.get('data',{})),'forbidden_present':[]},indent=2)+'\n')
r=subprocess.check_output(k+ns+['get','secret','verdify-app-secrets','-o','jsonpath={.metadata.name}{" "}{.metadata.uid}{" "}{.metadata.resourceVersion}{"\\n"}'],timeout=20);(out/'secret-metadata.txt').write_bytes(r)
nodes=get(['get','nodes']);allpods=get(['get','pods','-A']);raw=subprocess.check_output(k+['get','--raw','/apis/metrics.k8s.io/v1beta1/nodes'],timeout=20);metrics={x['metadata']['name']:x for x in json.loads(raw)['items']};rows=[]
for n in nodes['items']:
 name=n['metadata']['name'];alloc={r:qty(n['status']['allocatable'][r]) for r in ('cpu','memory')};tot={r:0.0 for r in alloc};count=0
 for p in allpods['items']:
  if p['spec'].get('nodeName')!=name or p['status'].get('phase') in ('Succeeded','Failed'):continue
  count+=1
  for r in tot:
   regular=sum(qty(c.get('resources',{}).get('requests',{}).get(r,'0')) for c in p['spec'].get('containers',[]));init=max([qty(c.get('resources',{}).get('requests',{}).get(r,'0')) for c in p['spec'].get('initContainers',[])]+[0]);tot[r]+=max(regular,init)+qty(p['spec'].get('overhead',{}).get(r,'0'))
 cond={c['type']:c['status'] for c in n['status']['conditions']};eligible=not n['spec'].get('unschedulable',False) and not any(t.get('effect') in ('NoSchedule','NoExecute') for t in n['spec'].get('taints',[]));working={r:qty(metrics[name]['usage'][r]) for r in tot};rows.append({'name':name,'uid':n['metadata']['uid'],'eligible_without_tolerations':eligible,'conditions':cond,'allocatable':alloc,'requested':tot,'working':working,'active_pods':count,'job_request_fits':all(tot[r]+({'cpu':.025,'memory':32*1024**2}[r])<=alloc[r] for r in tot),'job_memory_limit_1Gi_with_healthy_capacity':working['memory']+1024**3<alloc['memory']*.9})
assert any(r['eligible_without_tolerations'] and r['conditions'].get('Ready')=='True' and all(r['conditions'].get(x)=='False' for x in ('MemoryPressure','DiskPressure','PIDPressure')) and r['job_request_fits'] and r['job_memory_limit_1Gi_with_healthy_capacity'] for r in rows)
result={'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'context':'vallery','namespace':'verdify-prod','placement':'owning singleton Job no affinity/tolerations; CPcordoned and dedicatednode8 excluded','job_resources':{'request_cpu':.025,'request_memory_Mi':32,'limit_memory_Mi':1024,'init_main_serial':True},'nodes':rows,'quota':quotas['items'],'namespace_limits':limits['items'],'app_uid':app['metadata']['uid'],'app_operation_running':False,'active_other_migrate':False,'secret_metadata_values_read':False};(out/'admission.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'observed_at':result['observed_at'],'eligible_nodes':[x['name'] for x in rows if x['eligible_without_tolerations']],'other_migration_or_argo_operation':False,'config_forbidden_keys_absent':True}))
