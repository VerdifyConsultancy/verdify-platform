#!/usr/bin/env python3
"""ROOT-only post-install read qualification; execute through existing MCP Pod stdin.

One ordinary-role prepared getter call per process, no retries, service imports,
HTTP routes, ACL changes, or writes. ROOT binds Pod/image and the installed owner
receipt outside this process. Credentials remain only in the existing environment.
"""

import argparse
import ast
import asyncio
import copy
import hashlib
import hmac
import json
import os
import re
import sys
import time
import urllib.parse
from collections import Counter
from datetime import date, datetime
from pathlib import Path

import asyncpg

SOURCE = Path("/app/mcp/server.py")
SOURCE_SHA = "db8cb106eb397219750548c9ab9e0ecc2a740f741d6cf58720d040fc0437ed91"
BAKED_REVISION = "d298f1ecca8249a3898339045e69dc08e7a85ab1"
EXPECTED_IMAGE = "sha256:264f5fcb4da78a068c5bc64ec2b70d9efe122a473a1f92bb5d923565fb47a393"
GETTER_DEF_SHA = "89782089fd6ae3ecfeecdfbc1b730f6ab6a272c0da7b35ef562788eddbfa42c0"
GETTER_BODY_SHA = "578a07bed56714cd2dfe2308ca30ced1f6fc6916fd7db9d79630a7b82b261655"
OWNER_MCP_SEAL = "1cd20508c9196bf9758d7df40ae699e6b83aefccb91a4c5242492f7993f6eb02"
LOGIN = "verdify_mcp_runtime_login"
POSTMASTER = "2026-09-29T00:40:56.280382+00:00"
MAX_OUTPUT = 4 * 1024 * 1024


class Refusal(Exception):
    """Only fixed, source-owned failure codes are printable."""


def require(condition, code):
    if not condition:
        raise Refusal(code)


def sha(value):
    return hashlib.sha256(value).hexdigest()


def encode(value):
    def default(item):
        if isinstance(item, (date, datetime)):
            return item.isoformat()
        raise TypeError("unsupported result type")

    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False, default=default).encode()


def installed_parts():
    require(SOURCE.stat().st_size <= 2 * 1024 * 1024, "installed_source_size")
    raw = SOURCE.read_bytes()
    require(sha(raw) == SOURCE_SHA, "installed_source_hash")
    require(os.environ.get("VERDIFY_GIT_SHA") == BAKED_REVISION, "baked_source_revision")
    tree = ast.parse(raw)
    fns = [n for n in tree.body if isinstance(n, ast.AsyncFunctionDef) and n.name == "outcome_kpi"]
    require(len(fns) == 1, "outcome_source_identity")
    fn = fns[0]
    dryout = [
        n
        for n in ast.walk(fn)
        if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "dryout_sql" for t in n.targets)
    ]
    projection = [
        n
        for n in ast.walk(fn)
        if isinstance(n, ast.Assign)
        and any(ast.unparse(t) == "vpd_policy['realized_solar_night_dryout']" for t in n.targets)
    ]
    attest = [
        n
        for n in tree.body
        if isinstance(n, ast.Assign)
        and any(isinstance(t, ast.Name) and t.id == "_MCP_RUNTIME_DB_ATTESTATION_SQL" for t in n.targets)
    ]
    require(len(dryout) == len(projection) == len(attest) == 1, "installed_source_assignment_count")
    query = ast.literal_eval(dryout[0].value)
    attest_sql = ast.literal_eval(attest[0].value)
    require(
        isinstance(query, str) and len(query) < 2000 and "$1::date" in query and "$2" in query, "getter_query_shape"
    )
    require(query.strip().endswith("ORDER BY episode_started_at"), "getter_query_order")
    require(len(projection[0].targets) == 1, "projection_assignment_shape")
    projection_code = compile(ast.Module(body=projection, type_ignores=[]), str(SOURCE), "exec")
    projection_text = ast.get_source_segment(raw.decode(), projection[0])
    # Deliberately inspect the existing admin-only declaration, without importing
    # the service or obtaining any token. Iris denial is separately smoke-tested.
    audience = [
        n
        for n in tree.body
        if isinstance(n, ast.AnnAssign) and isinstance(n.target, ast.Name) and n.target.id == "TOOL_AUDIENCES"
    ]
    require(len(audience) == 1 and isinstance(audience[0].value, ast.Dict), "audience_declaration")
    pairs = list(zip(audience[0].value.keys, audience[0].value.values, strict=True))
    outcome = [v for k, v in pairs if isinstance(k, ast.Constant) and k.value == "outcome_kpi"]
    require(len(outcome) == 1 and ast.unparse(outcome[0]) == "frozenset({'admin'})", "outcome_admin_boundary")
    return query, attest_sql, projection_code, sha(projection_text.encode())


META_SQL = """
SELECT current_user AS current_user, session_user AS session_user,
 current_database() AS database, pg_backend_pid() AS backend_pid,
 pg_postmaster_start_time() AS postmaster_started_at,
 current_setting('server_version_num') AS server_version_num,
 current_setting('search_path') AS search_path,
 current_setting('statement_timeout') AS statement_timeout,
 current_setting('lock_timeout') AS lock_timeout,
 current_setting('transaction_read_only') AS transaction_read_only,
 current_setting('plan_cache_mode') AS plan_cache_mode,
 pg_is_in_recovery() AS in_recovery,
 encode(sha256(convert_to(pg_get_functiondef(p.oid),'UTF8')),'hex') AS getter_definition_sha256,
 encode(sha256(convert_to(p.prosrc,'UTF8')),'hex') AS getter_body_sha256,
 p.prosecdef AS getter_security_definer, p.provolatile::text AS getter_volatility,
 p.proconfig AS getter_settings, p.prokind::text AS getter_kind,
 pg_get_userbyid(p.proowner) AS getter_owner,
 (SELECT count(*) FROM unnest(p.proargmodes) m WHERE m='t') AS output_columns
FROM pg_proc p WHERE p.oid='public.fn_realized_solar_night_dryout(date,date,text)'::regprocedure
"""


def check_metadata(value, mode):
    require(value["current_user"] == value["session_user"] == LOGIN, "ordinary_current_session_identity")
    require(value["database"] == "verdify" and value["server_version_num"] == "160011", "production_database_identity")
    require(
        value["postmaster_started_at"].isoformat() == POSTMASTER and value["in_recovery"] is False,
        "production_postmaster_identity",
    )
    require(value["search_path"] == "pg_catalog, public, pg_temp", "actual_role_search_path")
    require(value["statement_timeout"] == "15s" and value["lock_timeout"] == "500ms", "actual_statement_fence")
    require(value["transaction_read_only"] == "on" and value["plan_cache_mode"] == mode, "readonly_prepared_plan_mode")
    require(
        value["getter_definition_sha256"] == GETTER_DEF_SHA and value["getter_body_sha256"] == GETTER_BODY_SHA,
        "installed_getter_hashes",
    )
    require(
        value["getter_security_definer"] is False
        and value["getter_volatility"] == "s"
        and value["getter_settings"] is None,
        "getter_execution_metadata",
    )
    require(
        value["getter_kind"] == "f" and value["getter_owner"] == "verdify" and value["output_columns"] == 46,
        "getter_signature_owner",
    )


async def qualify(args, report):
    conn = None
    started = time.monotonic()
    phase = "source_contract"
    try:
        query, attest_sql, projection_code, projection_hash = installed_parts()
        report["source_contract_verified"] = True
        report["outcome_admin_only_source_boundary_verified"] = True
        require(os.environ.get("VERDIFY_MCP_RUNTIME_DB_ROLE_REQUIRED", "").strip() == "1", "ordinary_role_required")
        dsn = os.environ.get("DB_DSN", "")
        require(bool(dsn), "existing_dsn_required")
        try:
            parsed = urllib.parse.urlsplit(dsn)
            user = urllib.parse.unquote(parsed.username or "")
            password_present = bool(parsed.password)
        except ValueError:
            raise Refusal("existing_dsn_parse") from None
        require(
            hmac.compare_digest(user, LOGIN) and hmac.compare_digest(os.environ.get("DB_USER", ""), LOGIN),
            "existing_role_environment",
        )
        require(password_present and bool(os.environ.get("DB_PASSWORD")), "existing_password_presence")
        require(not os.environ.get("POSTGRES_PASSWORD") and not os.environ.get("DB_PASS"), "no_admin_password_alias")
        require(
            max(1000, int(os.environ.get("VERDIFY_MCP_DB_STATEMENT_TIMEOUT_MS", "15000"))) == 15000,
            "ordinary_service_budget",
        )
        # One session only. No pool fan-out and no fallback if authentication fails.
        phase = "connect"
        conn = await asyncpg.connect(
            dsn,
            timeout=5,
            command_timeout=17,
            server_settings={
                "application_name": "verdify-mcp-getter277-qualification",
                "statement_timeout": "15000ms",
                "lock_timeout": "500ms",
                "default_transaction_read_only": "on",
            },
        )
        async with conn.transaction(isolation="repeatable_read", readonly=True):
            await conn.execute("SET LOCAL plan_cache_mode = '" + args.plan_mode + "'")
            phase = "attest_before"
            require(await conn.fetchval(attest_sql) is True, "ordinary_attester_before")
            meta = dict(await conn.fetchrow(META_SQL))
            check_metadata(meta, args.plan_mode)
            report["before"] = meta
            report["ordinary_attester_before"] = True
            # This cap does not replace evidence completeness: the 501st row
            # refuses the run. There is no retry, pagination, or second getter call.
            bounded_query = query.strip().rstrip(";") + "\nLIMIT 501"
            report["installed_query_sha256"] = sha(query.encode())
            report["submitted_query_sha256"] = sha(bounded_query.encode())
            phase = "prepare"
            statement = await conn.prepare(bounded_query)
            attributes = statement.get_attributes()
            require(len(attributes) == 46, "prepared_output_columns")
            report["prepared_columns"] = [a.name for a in attributes]
            phase = "getter"
            began = time.monotonic()
            fetched = await statement.fetch(date.fromisoformat(args.night), "vallery")
            report["getter_elapsed_seconds"] = round(time.monotonic() - began, 6)
            require(len(fetched) <= 500, "episode_overflow_501")
            rows = [dict(row) for row in fetched]
            require(all(len(row) == 46 for row in rows), "actual_output_columns")
            require(all(row["night_date"] == date.fromisoformat(args.night) for row in rows), "actual_output_night")
            report["rows"] = rows
            report["row_count"] = len(rows)
            report["rows_sha256"] = sha(encode(rows))
            report["complete_within_500_row_cap"] = True
            phase = "projection"
            supplied = copy.deepcopy(rows)
            namespace = {
                "dryout": supplied,
                "vpd_policy": {},
                "__builtins__": {"sum": sum, "max": max, "any": any, "all": all},
            }
            exec(projection_code, namespace)  # noqa: S102 -- exact hash-bound installed assignment only
            projected = namespace["vpd_policy"]["realized_solar_night_dryout"]
            require(projected["episodes"] == rows and supplied == rows, "projection_preserves_all_rows")
            report["installed_projection"] = projected
            report["projection_assignment_sha256"] = projection_hash
            report["evidence_status_counts"] = dict(Counter(row["evidence_status"] for row in rows))
            report["daytime_count_availability"] = {}
            for field in ("daytime_dry_action_samples", "daytime_hold_admission_samples"):
                values = [row[field] for row in rows]
                available = bool(values) and all(type(v) is int and v >= 0 for v in values)
                report["daytime_count_availability"][field] = {
                    "availability": "present_on_all_episodes" if available else "unknown",
                    "acceptance_value": max(values) if available else None,
                    "actual_projection_value": projected[field],
                }
            phase = "attest_after"
            require(await conn.fetchval(attest_sql) is True, "ordinary_attester_after")
            after = dict(await conn.fetchrow(META_SQL))
            check_metadata(after, args.plan_mode)
            require(after == meta, "same_session_metadata_after")
            report["after"] = after
            report["ordinary_attester_after"] = True
            phase = "expected_observation"
            if args.night == "2026-10-16":
                require(not rows and projected["safety_gate_status"] == "pending", "oct16_empty_pending_regression")
            else:
                require(len(rows) == 4, "oct04_four_real_episodes")
                require(
                    projected["dispositions"]
                    == {"effective": 0, "ineffective": 2, "blocked": 0, "insufficient_evidence": 2},
                    "oct04_explicit_dispositions",
                )
                require(
                    report["evidence_status_counts"] == {"complete": 2, "incomplete": 2}, "oct04_evidence_distinction"
                )
            report.update(status="PASSED_INSTALLED_ORDINARY_GETTER_AND_PROJECTION", passed=True)
    except BaseException as exc:
        # Never serialize exception text, DSN, arguments, environment, or a trace.
        report.update(
            status="REFUSED_OR_FAILED",
            passed=False,
            failure={
                "phase": phase,
                "type": type(exc).__name__,
                "code": str(exc) if isinstance(exc, Refusal) else None,
                "sqlstate": getattr(exc, "sqlstate", None),
            },
        )
    finally:
        if conn is not None:
            try:
                await conn.close(timeout=2)
                report["connection_closed"] = True
            except BaseException as exc:
                conn.terminate()
                report["connection_closed"] = False
                report["connection_terminated"] = True
                report["cleanup_failure_type"] = type(exc).__name__
                report.update(status="FAILED_CONNECTION_CLEANUP", passed=False)
        report["elapsed_seconds"] = round(time.monotonic() - started, 6)


async def run(args, report):
    try:
        await asyncio.wait_for(qualify(args, report), timeout=30)
    except BaseException as exc:
        report.update(status="FAILED_PROCESS_DEADLINE", passed=False, failure={"type": type(exc).__name__})


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--night", choices=["2026-10-16", "2026-10-04"], required=True)
    parser.add_argument("--plan-mode", choices=["force_custom_plan", "force_generic_plan"], required=True)
    parser.add_argument("--owner-installed-receipt-sha256", required=True)
    args = parser.parse_args()
    if not re.fullmatch("[0-9a-f]{64}", args.owner_installed_receipt_sha256):
        raise SystemExit("exact owner installed receipt hash required")
    report = {
        "schema": "verdify-410-installed-ordinary-getter-v1",
        "status": "STARTED",
        "passed": False,
        "night": args.night,
        "greenhouse": "vallery",
        "plan_mode": args.plan_mode,
        "source_sha256": SOURCE_SHA,
        "baked_source_revision": BAKED_REVISION,
        "expected_image": EXPECTED_IMAGE,
        "image_and_pod_binding_verification": "external ROOT prerequisite; not inspected by this process",
        "owner_installed_receipt_sha256": args.owner_installed_receipt_sha256,
        "owner_receipt_independently_verified_by_this_process": False,
        "expected_mcp_seal_from_owner_receipt": OWNER_MCP_SEAL,
        "mcp_seal_directly_read_by_ordinary_role": False,
        "qualification_scope": "ONE_ORDINARY_DB_GETTER_CALL_AND_ACTUAL_INSTALLED_PROJECTION",
        "authenticated_dispatch_verified": False,
        "planner_consumption_verified": False,
        "outcome_admin_only_source_boundary_verified": False,
        "source_contract_verified": False,
        "safety_only_pass_is_not_effectiveness_or_complete_evidence": True,
        "whole_issue_acceptance": False,
        "getter_call_count_max": 1,
        "automatic_retries": 0,
        "runtime": {"python": sys.version, "asyncpg": asyncpg.__version__, "hostname": os.environ.get("HOSTNAME")},
    }
    asyncio.run(run(args, report))
    try:
        raw = encode(report)
        require(len(raw) <= MAX_OUTPUT, "receipt_output_size")
    except BaseException as exc:
        raw = encode(
            {
                "schema": report["schema"],
                "status": "FAILED_RECEIPT_ENCODING",
                "passed": False,
                "failure_type": type(exc).__name__,
                "whole_issue_acceptance": False,
            }
        )
        report["passed"] = False
    print(raw.decode())
    raise SystemExit(0 if report["passed"] else 1)
