"""Read-only GitHub snapshot and canonical comparison; writes private custody only."""
import datetime
import hashlib
import json
import pathlib
import subprocess
import sys

ROOT = pathlib.Path('/Users/jason/.codex/worktrees/getter-timeout-fix-20261018/verdify-platform')
OUT = pathlib.Path('/private/tmp/verdify-getter-fix-20261018/graph-final')
REPO = 'VerdifyConsultancy/verdify-platform'
EXPECTED_HEAD = 'ff8d72e18cd08625c2a888106be1572c9c04b079'
sys.path.insert(0, str(ROOT))
from planning.schema import load
from planning.render import issue_body, issue_title

QUERY = '''query {
 repository(owner:"VerdifyConsultancy",name:"verdify-platform") {
  nameWithOwner defaultBranchRef { name target { oid } }
  issues(first:100,states:OPEN) { totalCount pageInfo { hasNextPage }
   nodes { number title body state url updatedAt
    parent { number state repository { nameWithOwner } }
    blockedBy(first:100) { totalCount pageInfo { hasNextPage } nodes { number state url repository { nameWithOwner } } }
    subIssues(first:100) { totalCount pageInfo { hasNextPage } nodes { number state repository { nameWithOwner } } }
   }
  }
  accepted802:issue(number:802) { number state stateReason closedAt }
  accepted977:issue(number:977) { number state stateReason closedAt }
  accepted980:issue(number:980) { number state stateReason closedAt }
 }
 externalRepository:repository(owner:"jvallery",name:"homeassistant") {
  nameWithOwner issue(number:878) { number state url
   parent { number state repository { nameWithOwner } }
   blockedBy(first:100) { totalCount pageInfo { hasNextPage } nodes { number state url repository { nameWithOwner } } }
   subIssues(first:100) { totalCount pageInfo { hasNextPage } nodes { number state repository { nameWithOwner } } }
  }
 }
}'''

def digest(data):
    return hashlib.sha256(data).hexdigest()

def gh(args, stem):
    p = subprocess.run(['gh', *args], cwd=ROOT, capture_output=True, timeout=60)
    (OUT / (stem + '.private.json')).write_bytes(p.stdout)
    (OUT / (stem + '.stderr')).write_bytes(p.stderr)
    if p.returncode:
        raise RuntimeError(f'{stem} read failed exit {p.returncode}; original output retained')
    result = json.loads(p.stdout)
    if isinstance(result, dict) and result.get('errors'):
        raise RuntimeError(f'{stem} GraphQL errors retained')
    return result, digest(p.stdout)

def cycle_paths(graph):
    done, active, cycles = set(), [], []
    def visit(node):
        if node in active:
            cycles.append(active[active.index(node):] + [node])
            return
        if node in done:
            return
        active.append(node)
        for child in graph.get(node, []):
            visit(child)
        active.pop()
        done.add(node)
    for node in graph:
        visit(node)
    return cycles

def identity(node):
    return f"{node['repository']['nameWithOwner']}#{node['number']}"

OUT.mkdir(exist_ok=False)
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
(OUT / 'query.json').write_text(json.dumps({'query': QUERY}) + '\n')
source_head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
assert source_head == EXPECTED_HEAD, source_head
plan = load(ROOT / 'planning/backlog.yaml')
keyed = {x.key: x for x in plan.issues}
items = {x.issue_number: x for x in plan.issues if x.status == 'open'}
native, raw_hash = gh(['api', 'graphql', '--input', str(OUT / 'query.json')], 'native-graph')
comment, comment_hash = gh(['api', f'repos/{REPO}/issues/comments/6253284314'], '410-inflight-comment')
repo = native['data']['repository']
connection = repo['issues']
rows = connection['nodes']
errors = []
def require(check, message):
    if not check:
        errors.append(message)
require(connection['totalCount'] == len(rows) and not connection['pageInfo']['hasNextPage'], 'open issues truncated')
require(set(items) == {x['number'] for x in rows}, 'canonical open issue numbers differ')
require(len(rows) == len(items) == 47, 'open count is not 47')
require(repo['defaultBranchRef']['target']['oid'] == EXPECTED_HEAD, 'remote main differs from reviewed source')
contracts, edges, parent_edges, child_edges = [], [], [], []
for row in rows:
    number = row['number']
    item = items.get(number)
    if item is None:
        continue
    body_equal = row['body'] == issue_body(item, plan)
    title_equal = row['title'] == issue_title(item)
    require(body_equal and title_equal and row['state'] == 'OPEN', f'canonical issue contract mismatch #{number}')
    contracts.append({'number': number, 'state': row['state'], 'updated_at': row['updatedAt'],
                      'body_sha256': digest(row['body'].encode()), 'title_sha256': digest(row['title'].encode()),
                      'body_matches': body_equal, 'title_matches': title_equal,
                      'acceptance_clauses': len(item.acceptance)})
    parent = row['parent']
    expected_parent = f'{REPO}#{keyed[item.parent].issue_number}' if item.parent else None
    require((identity(parent) if parent else None) == expected_parent, f'parent mismatch #{number}')
    if parent:
        parent_edges.append((identity(parent), f'{REPO}#{number}'))
    for name in ('subIssues', 'blockedBy'):
        relation = row[name]
        require(relation['totalCount'] == len(relation['nodes']) and not relation['pageInfo']['hasNextPage'], f'{name} truncated #{number}')
    expected_children = {f'{REPO}#{x.issue_number}' for x in items.values() if x.parent == item.key}
    require({identity(x) for x in row['subIssues']['nodes'] if x['state'] == 'OPEN'} == expected_children, f'open subissue mismatch #{number}')
    for child in row['subIssues']['nodes']:
        child_edges.append((f'{REPO}#{number}', identity(child)))
    for blocker in row['blockedBy']['nodes']:
        edges.append({'predecessor_repo': blocker['repository']['nameWithOwner'], 'predecessor': blocker['number'],
                      'dependent': number, 'state': blocker['state']})
active = [e for e in edges if e['state'] == 'OPEN']
local = [e for e in active if e['predecessor_repo'] == REPO]
external = [e for e in active if e['predecessor_repo'] != REPO]
closed = [e for e in edges if e['state'] == 'CLOSED']
expected = {(keyed[d].issue_number, x.issue_number) for x in items.values() for d in x.depends_on if keyed[d].status == 'open'}
require({(x['predecessor'], x['dependent']) for x in local} == expected, 'local dependency graph differs')
require(len(local) == 26 and len(active) == 27, 'active dependency count differs')
require(external == [{'predecessor_repo': 'jvallery/homeassistant', 'predecessor': 878, 'dependent': 981, 'state': 'OPEN'}], 'external dependency differs')
require(len(closed) == 24, 'closed predecessor record count differs')
blocking = {}
parentage = {}
for e in edges:
    blocking.setdefault(f"{e['predecessor_repo']}#{e['predecessor']}", []).append(f"{REPO}#{e['dependent']}")
for p, c in set(parent_edges + child_edges):
    parentage.setdefault(p, []).append(c)
ext = native['data']['externalRepository']['issue']
require(ext['state'] == 'OPEN', 'external predecessor no longer open')
for name in ('subIssues', 'blockedBy'):
    relation = ext[name]
    require(relation['totalCount'] == len(relation['nodes']) and not relation['pageInfo']['hasNextPage'], f'external {name} truncated')
for blocker in ext['blockedBy']['nodes']:
    blocking.setdefault(identity(blocker), []).append('jvallery/homeassistant#878')
if ext['parent']:
    parentage.setdefault(identity(ext['parent']), []).append('jvallery/homeassistant#878')
for child in ext['subIssues']['nodes']:
    parentage.setdefault('jvallery/homeassistant#878', []).append(identity(child))
blocking_cycles, parent_cycles = cycle_paths(blocking), cycle_paths(parentage)
require(not blocking_cycles and not parent_cycles, 'cycle in captured relationship graph')
accepted = [repo[f'accepted{n}'] for n in (802, 977, 980)]
require(all(x['state'] == 'CLOSED' and x['stateReason'] == 'COMPLETED' for x in accepted), 'accepted closure state changed')
require(comment['id'] == 6253284314 and comment['issue_url'].endswith('/issues/410'), 'in-flight comment identity differs')
acs = sum(len(x.acceptance) for x in items.values())
require(acs == 143, 'open acceptance clause count differs')
receipt = {
 'schema': 'verdify-getter-final-native-graph/v1',
 'started_at': started, 'checked_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'status': 'MATCH' if not errors else 'DRIFT', 'errors': errors,
 'source_revision': source_head, 'remote_main': repo['defaultBranchRef']['target']['oid'],
 'backlog_sha256': digest((ROOT / 'planning/backlog.yaml').read_bytes()),
 'native_raw_sha256': raw_hash, 'inflight_comment_raw_sha256': comment_hash,
 'open_issues': len(rows), 'canonical_records': len(plan.issues), 'open_acceptance_clauses': acs,
 'local_active_edges': len(local), 'external_active_edges': external, 'total_active_edges': len(active),
 'closed_predecessor_records': len(closed), 'contracts': sorted(contracts, key=lambda x:x['number']),
 'edges': edges, 'parent_edges': parent_edges, 'subissue_edges': child_edges,
 'blocking_cycles': blocking_cycles, 'parent_cycles': parent_cycles,
 'cycle_scope': 'Captured all 47 local open issues and their immediate parent/subissue/blocker references plus external HA#878 relationships; no claim about unrelated transitive external graphs.',
 'accepted_history': accepted,
 'inflight_comment': {'id': comment['id'], 'url': comment['html_url'], 'created_at': comment['created_at'], 'updated_at': comment['updated_at'], 'body_sha256': digest(comment['body'].encode())},
 'verified_final_scope': {'issues': [410, 775], 'fields': ['baseline', 'how', 'decision'], 'acceptance_or_dependency_changes_justified_by_this_snapshot': False},
 'github_mutations': 0, 'source_mutations': 0
}
target = OUT / 'verified.json'
target.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({k: receipt[k] for k in ('status','checked_at','source_revision','remote_main','open_issues','open_acceptance_clauses','local_active_edges','total_active_edges','closed_predecessor_records','errors')}))
print('receipt_sha256=' + digest(target.read_bytes()))
