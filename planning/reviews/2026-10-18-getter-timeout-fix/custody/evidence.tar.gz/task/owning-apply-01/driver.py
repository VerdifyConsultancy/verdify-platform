import sys,json,pathlib,subprocess,hashlib,datetime,time,importlib.util
mode,packet,outdir=sys.argv[1:];assert mode in ('plan','apply');packet=pathlib.Path(packet);out=pathlib.Path(outdir);out.mkdir(exist_ok=False)
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
k=['kubectl','--context','vallery','--request-timeout=15s','-n','verdify-prod'];manifest=packet/(mode+'-job.json');desired=json.loads(manifest.read_bytes());name=desired['metadata']['name'];uid=None
driver=pathlib.Path(__file__).read_bytes();(out/'driver.py').write_bytes(driver);driver_sha256=hashlib.sha256(driver).hexdigest()
sequence=0
def failhook(kind,value,tb):
 save('failure.json',{'status':'FAILED_OR_UNKNOWN_DO_NOT_RESUBMIT','exception_type':kind.__name__,'orchestrator_sha256':driver_sha256,'mode':mode,'job':name,'uid':uid,'at':stamp()})
 print(json.dumps({'status':'FAILED_OR_UNKNOWN_DO_NOT_RESUBMIT','exception_type':kind.__name__}),file=sys.stderr)
sys.excepthook=failhook
def save(n,v):
 p=out/n;p.write_bytes(v if isinstance(v,bytes) else (json.dumps(v,indent=2)+'\n').encode());return p
def call(args,label,valid=True):
 global sequence
 sequence+=1;label=f'{sequence:03d}-'+label;t=stamp()
 try:r=subprocess.run(k+args,capture_output=True,timeout=25)
 except subprocess.TimeoutExpired as e:
  save(label+'.partial.stdout',e.stdout or b'');save(label+'.partial.stderr',e.stderr or b'');save(label+'.call.json',{'start':t,'end':stamp(),'outcome':'TRANSPORT_TIMEOUT_UNKNOWN_NO_RETRY'});raise
 save(label+'.stdout',r.stdout);save(label+'.stderr',r.stderr);save(label+'.call.json',{'start':t,'end':stamp(),'exit':r.returncode,'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(r.stderr).hexdigest()});
 if valid:assert r.returncode==0,(label,r.returncode)
 return r
spec=importlib.util.spec_from_file_location('emitter','/private/tmp/verdify-getter277-owning-job.py');em=importlib.util.module_from_spec(spec);spec.loader.exec_module(em)
# Preconditions: fresh external admission and owner state, no owning migration or sync overlap.
r=call(['get','job',name,'-o','json'],'absence',False);assert r.returncode!=0 and b'NotFound' in r.stderr
config=json.loads(call(['get','configmap','verdify-config','-o','json'],'config-preflight').stdout)
assert not set(config.get('data',{})) & {'VERDIFY_MIGRATE_PLAN','VERDIFY_MIGRATIONS_DIR','PGOPTIONS','VERDIFY_MIGRATE_STATEMENT_TIMEOUT','VERDIFY_MIGRATE_LOCK_TIMEOUT','VERDIFY_MIGRATE_IDLE_TX_TIMEOUT'},'config injection'
cm=json.loads(call(['get','configmap',em.CONTRACT_NAME,'-o','json'],'contract-preflight').stdout);assert hashlib.sha256(cm['data']['contract.json'].encode()).hexdigest()==em.CONTRACT_SHA
r=call(['create','-f',str(manifest),'-o','json'],'create');created=json.loads(r.stdout);uid=created['metadata']['uid'];em.verify_suspended(desired,created,uid);save('created.json',created)
pods=json.loads(call(['get','pods','-l','batch.kubernetes.io/job-name='+name,'-o','json'],'suspended-pods').stdout);assert pods['items']==[];save('empty-pods.json',pods)
fresh=json.loads(call(['get','job',name,'-o','json'],'fresh-suspended').stdout);observed=stamp();save('fresh.json',fresh)
patch=em.release_patch(desired,created,fresh,pods,observed_at=observed);patchpath=save('release-patch.json',patch)
# Exactly one UID/RV/spec-tested mutation. Any uncertain outcome stops without retry.
released=json.loads(call(['patch','job',name,'--type=json','--patch-file',str(patchpath),'-o','json'],'release').stdout);assert released['metadata']['uid']==uid and released['spec']['suspend'] is False
seen={};end=time.monotonic()+340;terminal=None
while time.monotonic()<end:
 j=json.loads(call(['get','job',name,'-o','json'],'current-job').stdout);assert j['metadata']['uid']==uid
 ps=json.loads(call(['get','pods','-l','batch.kubernetes.io/job-name='+name,'-o','json'],'current-pods').stdout)
 assert len(ps['items'])<=1,'unexpected retry/multiple Pods'
 for p in ps['items']:
  assert any(x['uid']==uid for x in p['metadata'].get('ownerReferences',[]));pn=p['metadata']['name'];seen[pn]=p;save(pn+'.json',p)
  for c in p['status'].get('initContainerStatuses',[])+p['status'].get('containerStatuses',[]):
   if c.get('state',{}).get('running') or c.get('state',{}).get('terminated'):
    call(['logs',pn,'-c',c['name']],pn+'-'+c['name']+'-log',False)
 cond=j.get('status',{}).get('conditions',[])
 if any(c['type'] in ('Complete','Failed') and c['status']=='True' for c in cond):terminal=j;break
 time.sleep(3)
assert terminal is not None,'deadline no terminal; DO NOT RESUBMIT'
assert len(seen)==1
p=next(iter(seen.values()));cs=p['status'].get('initContainerStatuses',[])+p['status'].get('containerStatuses',[])
assert {x['name'] for x in cs}=={'migrate','wait-for-db'} and len(cs)==2
assert len(p['spec']['containers'])==len(p['spec']['initContainers'])==1
assert all(c.get('resources')=={'limits':{'memory':'1Gi'},'requests':{'cpu':'25m','memory':'32Mi'}} for c in p['spec']['containers']+p['spec']['initContainers'])
assert p['spec']['containers'][0]['image']==desired['spec']['template']['spec']['containers'][0]['image']
assert p['spec']['initContainers'][0]['image']==desired['spec']['template']['spec']['initContainers'][0]['image']
main=next(x for x in cs if x['name']=='migrate');init=next(x for x in cs if x['name']=='wait-for-db')
assert main['imageID']==desired['spec']['template']['spec']['containers'][0]['image']
assert '@sha256:' in init['imageID']
final_logs={}
for c in cs:
 r=call(['logs',p['metadata']['name'],'-c',c['name']],'FINAL-'+c['name']+'-log');assert r.stdout;final_logs[c['name']]={'bytes':len(r.stdout),'sha256':hashlib.sha256(r.stdout).hexdigest()}
result={'orchestrator_sha256':driver_sha256,'init_identity_scope':'declared owning image reference and observed resolved digest; no independent init digest pin claimed','final_logs':final_logs,'mode':mode,'job':name,'uid':uid,'manifest_sha256':sha(manifest),'finished':stamp(),'conditions':terminal['status'].get('conditions'),'pod':p['metadata']['name'],'pod_uid':p['metadata']['uid'],'node':p['spec'].get('nodeName'),'containers':cs,'passed':any(c['type']=='Complete' and c['status']=='True' for c in terminal['status'].get('conditions',[])) and len(cs)==2 and all(c['state'].get('terminated',{}).get('exitCode')==0 and c['restartCount']==0 for c in cs)}
save('result.json',result);print(json.dumps(result,indent=2));assert result['passed'],'Job failed retained; DO NOT RESUBMIT'
