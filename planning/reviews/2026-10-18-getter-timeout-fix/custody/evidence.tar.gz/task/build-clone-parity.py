from pathlib import Path
import re
repo=Path('/Users/jason/.codex/worktrees/getter-timeout-fix-20261018/verdify-platform');base=Path('/private/tmp/verdify-getter-fix-20261018');pilot=(repo/'planning/reviews/2026-10-18-s3b-execution/p3-solar-night/pilot-2026-10-16.sql').read_text();guard=pilot.split('-- The existing getter executes once.')[0].replace('BEGIN READ ONLY;','BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY;').replace("current_database()='verdify'","current_database()='verdify_rehearsal'").replace("current_user='verdify' AND session_user='verdify'","current_user='postgres' AND session_user='postgres'").replace('2026-09-29T00:40:56.280382+00:00','2026-10-12T18:37:06.874379+00:00')
guard=guard.replace("SET LOCAL statement_timeout='2s';","SET LOCAL statement_timeout='2s';\nSET LOCAL temp_file_limit='64MB';")
source=(repo/'db/migrations/191-realized-solar-night-dryout-episodes.sql').read_text().split('CREATE OR REPLACE FUNCTION public.fn_realized_solar_night_dryout(',1)[1];names=re.findall(r'^    (\w+) ',source.split('RETURNS TABLE(',1)[1].split('\n)',1)[0],re.M);assert len(names)==46
body=Path('/private/tmp/verdify-410-getter-fix-20261018/candidate-body.sql').read_text().strip().removesuffix(';');body=re.sub(r'\bp_start_night\b',"DATE '2026-10-04'",body);body=re.sub(r'\bp_end_night\b',"DATE '2026-10-04'",body);body=re.sub(r'\bp_greenhouse_id\b',"'vallery'::text",body)
queries=[('reference',"SELECT * FROM public.fn_realized_solar_night_dryout(DATE '2026-10-04',DATE '2026-10-04','vallery')"),('timeline',f'SELECT * FROM ({body}) candidate('+','.join(names)+')')]
sql=guard+"\n-- Independent cloned-data parity date; original production Oct16 pilot unchanged.\nSET LOCAL statement_timeout='15s';\n\\timing on\n"
for name,query in queries:
 sql+=f"WITH bounded AS MATERIALIZED ({query} ORDER BY episode_started_at,episode_id LIMIT 501) SELECT jsonb_build_object('kind','{name}','date','2026-10-04','row_count',count(*),'overflow',count(*)>500,'rows',coalesce(jsonb_agg(to_jsonb(b) ORDER BY episode_started_at,episode_id),'[]'::jsonb)) FROM bounded b;\n"
sql+='ROLLBACK;\n';(base/'clone-parity-oct04.sql').write_text(sql)
