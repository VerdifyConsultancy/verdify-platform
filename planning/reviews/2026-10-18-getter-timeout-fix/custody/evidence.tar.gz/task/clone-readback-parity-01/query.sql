-- New compositional relation proof, not another old full-getter retry.
-- One15s data statement, one2s metadata guard; same immutable clone Oct4 source window.
-- Both sides share materialized source climate/grouped events in one repeatable-read snapshot.
-- No helper functions or physical effects; <=5 exact mismatch rows per direction.
-- One preselected complete adjacent-day window. ROOT executes once, no retry/expansion.
-- Calendar completeness is not a claim of telemetry coverage or efficacy.
BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY;
SET LOCAL statement_timeout='2s';
SET LOCAL temp_file_limit='64MB';
SET LOCAL lock_timeout='500ms';
SET LOCAL idle_in_transaction_session_timeout='10s';
SET LOCAL max_parallel_workers_per_gather=0;
SET LOCAL work_mem='4MB';
SET LOCAL TimeZone='UTC';
WITH expected_functions(name,sha) AS (VALUES
('fn_absolute_humidity_g_m3','c14ce18c1811fec25416262983126072deca690991c3b60df73b69d08fb13c92'),
('fn_band_setpoints','58a0e95e646a5de45c022438546608e1677adad000800c6784e0f6316241b281'),
('fn_center_band_setpoints','718de2d0507b4dc0adc86b8b8fdc6e93be0008a3b0041c320b8ac97eff45aaea'),
('fn_crop_band_value','e5682cb83e81c57ee44254c555d775e4f7dedf1078af3ba98ccc97f71c03d9e0'),
('fn_current_season','c35ff6fc0aa046b208da7ff7a9f03a9fcba658d0ed652c01b08f0b826e544130'),
('fn_diurnal_interp','002befc3228b8484c5bd130039ea375d987044ee53a83d3b2d6626cce37f1978'),
('fn_hermite_phase','f9642002e69bbac2d1a2dc7f9a19fb069ea86295c995713eaf37c8efa2e164fb'),
('fn_house_vpd_control_band','7aad695981e7883e562a93a1a2dceaf55a1a5bb17ccf4007748a9c851069279e'),
('fn_realized_solar_night_dryout','b9626fd5882392bcf00c080550b6ab5000cc5ed8a63ea8dceb806e76aae6d3a6'),
('fn_solar_phase','960f6e4c435ce534db8956630bd32408a3d1294362b2aef44c018189d250e715'),
('fn_solar_sunrise_hour','66795353790f6678c02f8f6af5e6d576fe8177714b07a679925360bd1f851d51'),
('fn_solar_sunset_hour','227310e3542f7e0bc06f0639724a72444a8366320cb30da07ecfc01f185a9c79'),
('fn_zone_vpd_targets','71109e38a269c68d9d1112ad4e6cf60a5efaba15b49045b1ef119a6ba658e1ff')
), expected_ledger(filename,sha) AS (VALUES
('db/migrations/145-vanda-band-and-join-fix.sql','c599744bc497a0c6bc5c39644a17eeeec7b658fc4b1081afcf65aa94e6818f35'),
('db/migrations/164-zone-vpd-targets-solar-repoint.sql','078c7e1afe025c3fa14d8ec39d422707a1f22867844959bce526907cacb0b262'),
('db/migrations/165-band-solar-noon-repoint.sql','2cdf3d6b657e2e8d1c95ebb73cc724bc9f8465a95b0e4c5e74a6deb0c9d46bed'),
('db/migrations/170-band-harmonic-smooth-curve.sql','f3e93f7df52ad899ea192ed90849a36ec79b7bc7f86a487a28d5af53024ef49b'),
('db/migrations/172-smooth-solar-phase.sql','bf0c60dc6f3553be395c32a22bdd5d1c00f3addfd689aa1def3f796db6db431e'),
('db/migrations/181-serve-band-target-one-source.sql','7992b80335450c5851545d9695811f54c20df780ec18c5ee95f2a15b888fe67a'),
('db/migrations/186-noaa-solar-phase-parity.sql','9e1e33b5005e183a35d84dd9b41d96b4d535faa99945d7ae6c89b196d4569e28'),
('db/migrations/191-realized-solar-night-dryout-episodes.sql','9aea5b0f7878df3a585884743a4d5eaf8b989c39f18cd09698e9b4973394c211')
), verdict AS (
 SELECT NOT pg_is_in_recovery()
  AND current_setting('transaction_isolation')='repeatable read'
  AND current_database()='verdify_rehearsal'
  AND current_user='postgres' AND session_user='postgres'
  AND current_setting('transaction_read_only')='on'
  AND pg_postmaster_start_time()='2026-10-12T18:37:06.874379+00:00'::timestamptz
  AND DATE '2026-10-04' <= (now() AT TIME ZONE 'America/Denver')::date - 2
  AND (SELECT count(*)=13 AND bool_and(
       encode(sha256(convert_to(pg_get_functiondef(p.oid),'UTF8')),'hex')=e.sha
       AND pg_get_userbyid(p.proowner)='verdify' AND p.proconfig IS NULL)
    FROM expected_functions e JOIN pg_namespace n ON n.nspname='public'
    JOIN pg_proc p ON p.pronamespace=n.oid AND p.proname=e.name AND p.prokind='f')
  AND (SELECT count(*)=8 AND bool_and(m.sha256=e.sha)
    FROM expected_ledger e JOIN public.schema_migrations m
      ON m.source='db/migrations' AND m.filename=e.filename) AS ok
)
SELECT json_build_object('kind','clone_readback_relation_identity_guard','passed',1/(CASE WHEN ok THEN 1 ELSE 0 END),
 'identity_receipt_sha256','970852793d4ab0648c6b5cf8b52a5139df9f83bb7c3fa20594253fef83296388','night_date','2026-10-04',
 'database',current_database(),'postmaster_started_at',pg_postmaster_start_time(),
 'captured_at',clock_timestamp(), 'read_only',current_setting('transaction_read_only')) FROM verdict;

SET LOCAL statement_timeout='15s';
WITH bounds AS NOT MATERIALIZED (
    SELECT
        DATE '2026-10-04'::timestamp AT TIME ZONE 'America/Denver' AS start_ts,
        (DATE '2026-10-04' + 2)::timestamp AT TIME ZONE 'America/Denver' AS end_ts
),
climate_minute AS MATERIALIZED (
    SELECT
        date_trunc('minute', c.ts) AS bucket,
        avg(c.temp_avg)::double precision AS temp_f,
        avg(c.vpd_avg)::double precision AS vpd_kpa,
        avg(c.rh_avg)::double precision AS rh_pct,
        avg(c.outdoor_temp_f)::double precision AS outdoor_temp_f,
        avg(c.outdoor_rh_pct)::double precision AS outdoor_rh_pct
    FROM public.climate c
    CROSS JOIN bounds b
    WHERE c.greenhouse_id = 'vallery'::text
      AND c.ts >= b.start_ts
      AND c.ts < b.end_ts
      AND c.temp_avg IS NOT NULL
      AND c.vpd_avg IS NOT NULL
      AND c.rh_avg IS NOT NULL
    GROUP BY date_trunc('minute', c.ts)
),
setpoint_event_rows AS (
    SELECT s.greenhouse_id, s.parameter, s.ts, s.value::double precision AS value
    FROM public.setpoint_snapshot s
    CROSS JOIN bounds b
    WHERE s.greenhouse_id = 'vallery'::text
      AND s.parameter IN ('temp_low', 'vpd_low')
      AND s.ts >= b.start_ts
      AND s.ts < b.end_ts

    UNION ALL

    (SELECT DISTINCT ON (s.greenhouse_id, s.parameter)
        s.greenhouse_id, s.parameter, s.ts, s.value::double precision
     FROM public.setpoint_snapshot s
     CROSS JOIN bounds b
     WHERE s.greenhouse_id = 'vallery'::text
       AND s.parameter IN ('temp_low', 'vpd_low')
       AND s.ts < b.start_ts
     ORDER BY s.greenhouse_id, s.parameter, s.ts DESC)
),
setpoint_events AS MATERIALIZED (
    SELECT greenhouse_id, parameter, ts, max(value)::double precision AS value
    FROM setpoint_event_rows
    GROUP BY greenhouse_id, parameter, ts
),
setpoint_intervals AS MATERIALIZED (
    SELECT
        e.*,
        lead(e.ts, 1, b.end_ts) OVER (
            PARTITION BY e.greenhouse_id, e.parameter ORDER BY e.ts
        ) AS next_ts
    FROM setpoint_events e
    CROSS JOIN bounds b
),
readback_points AS (
    SELECT bucket AS ts, NULL::text AS parameter, NULL::double precision AS value
    FROM climate_minute
    UNION ALL SELECT ts, parameter, value FROM setpoint_events
),
readback_timeline AS (
    SELECT ts, parameter, value,
      max(ts) FILTER (WHERE parameter='temp_low') OVER (
        ORDER BY ts GROUPS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS temp_ts,
      max(ts) FILTER (WHERE parameter='vpd_low') OVER (
        ORDER BY ts GROUPS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS vpd_ts
    FROM readback_points
),
readback_values AS (
    SELECT ts, parameter,
      max(value) FILTER (WHERE parameter='temp_low') OVER (
        PARTITION BY temp_ts) AS temp_value,
      max(value) FILTER (WHERE parameter='vpd_low') OVER (
        PARTITION BY vpd_ts) AS vpd_value
    FROM readback_timeline
),
readback_climate AS (
    SELECT ts AS bucket, temp_value, vpd_value
    FROM readback_values WHERE parameter IS NULL
),
old_readbacks AS MATERIALIZED (
 SELECT c.bucket,temp_readback.value AS temp_value,vpd_readback.value AS vpd_value
 FROM climate_minute c
 LEFT JOIN setpoint_intervals temp_readback
   ON temp_readback.greenhouse_id='vallery'
  AND temp_readback.parameter='temp_low'
  AND c.bucket>=temp_readback.ts AND c.bucket<temp_readback.next_ts
 LEFT JOIN setpoint_intervals vpd_readback
   ON vpd_readback.greenhouse_id='vallery'
  AND vpd_readback.parameter='vpd_low'
  AND c.bucket>=vpd_readback.ts AND c.bucket<vpd_readback.next_ts
),
new_readbacks AS MATERIALIZED (
 SELECT bucket,temp_value,vpd_value FROM readback_climate
),
old_only AS MATERIALIZED (
 SELECT * FROM old_readbacks EXCEPT ALL SELECT * FROM new_readbacks
),
new_only AS MATERIALIZED (
 SELECT * FROM new_readbacks EXCEPT ALL SELECT * FROM old_readbacks
),
parity_result AS MATERIALIZED (
 SELECT jsonb_build_object(
 'kind','same_snapshot_original_interval_vs_candidate_b_readback_relation',
 'date','2026-10-04','candidate_b_body_sha256','578a07bed56714cd2dfe2308ca30ced1f6fc6916fd7db9d79630a7b82b261655',
 'comparison','EXCEPT ALL in both directions; NULL and duplicate multiplicity retained',
 'source_climate_minutes',(SELECT count(*) FROM climate_minute),
 'source_grouped_events',(SELECT count(*) FROM setpoint_events),
 'source_intervals',(SELECT count(*) FROM setpoint_intervals),
 'old_rows',(SELECT count(*) FROM old_readbacks),
 'new_rows',(SELECT count(*) FROM new_readbacks),
 'old_null_temp',(SELECT count(*) FROM old_readbacks WHERE temp_value IS NULL),
 'new_null_temp',(SELECT count(*) FROM new_readbacks WHERE temp_value IS NULL),
 'old_null_vpd',(SELECT count(*) FROM old_readbacks WHERE vpd_value IS NULL),
 'new_null_vpd',(SELECT count(*) FROM new_readbacks WHERE vpd_value IS NULL),
 'old_only_rows',(SELECT count(*) FROM old_only),
 'new_only_rows',(SELECT count(*) FROM new_only),
 'equal',NOT EXISTS(SELECT 1 FROM old_only) AND NOT EXISTS(SELECT 1 FROM new_only),
 'old_only_sample',COALESCE((SELECT jsonb_agg(to_jsonb(x) ORDER BY bucket,temp_value NULLS FIRST,vpd_value NULLS FIRST)
   FROM (SELECT * FROM old_only ORDER BY bucket,temp_value NULLS FIRST,vpd_value NULLS FIRST LIMIT 5)x),'[]'::jsonb),
 'new_only_sample',COALESCE((SELECT jsonb_agg(to_jsonb(x) ORDER BY bucket,temp_value NULLS FIRST,vpd_value NULLS FIRST)
   FROM (SELECT * FROM new_only ORDER BY bucket,temp_value NULLS FIRST,vpd_value NULLS FIRST LIMIT 5)x),'[]'::jsonb),
 'full_getter_parity_claimed',false,'helpers_executed',false
 ) AS result
),
completion_clock AS MATERIALIZED (
 SELECT result,statement_timestamp() AS query_started_at,clock_timestamp() AS query_finished_at
 FROM parity_result
)
SELECT result||jsonb_build_object('query_started_at',query_started_at,'query_finished_at',query_finished_at,
 'query_elapsed_ms',extract(epoch FROM(query_finished_at-query_started_at))*1000)
FROM completion_clock;
ROLLBACK;
