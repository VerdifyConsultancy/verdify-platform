"""Build private drafts from retained source/evidence. No native or GitHub calls."""
import copy
import datetime
import hashlib
import json
import pathlib
import sys

ROOT = pathlib.Path('/Users/jason/.codex/worktrees/getter-timeout-fix-20261018/verdify-platform')
BASE = pathlib.Path('/private/tmp/verdify-getter-fix-20261018')
OUT = BASE / 'report-draft'
OUT.mkdir(exist_ok=False)
sys.path.insert(0, str(ROOT))
from planning.schema import Backlog, load
from planning.render import issue_body, issue_title

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write_json(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')

source = '8d7ff1a2829c246600da4f15027121e9c7193913'
report_path = 'planning/reviews/2026-10-18-getter-timeout-fix/README.md'
plan = load(ROOT / 'planning/backlog.yaml')
items = {x.issue_number: x for x in plan.issues}
next410 = ('Complete the exact-source native gate and migrate image, then run the reviewed owning migration-only plan/apply Jobs and verify the277 ledger, function and MCP receipt. Through the unchanged ordinary MCP identities, retain installed October16 and explicitly selected October4 full46-column results within the configured15-second budget, custom/generic planning, HTTP/role guards and runtime readback. Keep daytime completeness, positive admin/planner consumption and physical/crop claims open.')
next775 = ('Finish the selected277 migration delivery and installed ordinary-role verification, then record only the measured getter outcome. Reuse accepted MCP and S3B receipts; retain the remaining authentic-input, measured daytime, planner-route and physical/recovery work without repeating accepted delivery or changing acceptance edges.')
baseline410 = ('The selected getter correction is implemented in immutable migration277 at source16d13f64, followed by8d7ff1a2 correcting the historical baseline-stamp exception caught by the first full native gate. It preserves all46 outputs, upstream seed/tie semantics, NULL stop behavior, inner-helper cardinality and scientific expressions. Twenty native synthetic old/new full-row cases passed;2673 real clone readback relations matched exactly under one snapshot. Candidate B returned four October4 clone episodes in3174.204ms, equal to candidate A across all46 fields in separate read-only snapshots; no successful full original real-data result exists because its15s/30s attempts timed out.\n\nThe exact production migration and MCP receipt update passed inside a transaction that rolled back, followed by fresh unchanged-state readback. A source-body production October16 query returned zero episodes in3972.272ms client timing (3967.348ms server query elapsed), retaining2785 climate/action/resolved minutes and750 selected solar-night minutes with zero demand/admitted/active minutes and no null served VPD. Observed daylight had zero hold samples and12/2 ordinary dry-action samples, but complete daytime coverage is not established. These are candidate/rehearsal results, not installed-getter acceptance. The first main CI5vzfd failed and remains retained; corrected source8d7ff1a2 workflow26nj4 is running at this draft checkpoint. No277 installation or installed ordinary-role result is claimed. The prior MCP incomplete-status correction remains accepted.\n\nCurrent execution allocation: S3B follow-up. Next action: ' + next410 + '\n\nEvidence: ' + report_path + ' (draft pending final delivery receipts); prior planning/reviews/2026-10-18-getter-mcp-release/README.md remains unchanged. All three acceptance clauses and completion edges remain open and unchanged.')
baseline775 = ('The selected getter follow-up has a semantics-preserving migration277 source candidate,20 passing native full46-column synthetic parity cases,2673 matching genuine clone readback relations, and an exact production body/receipt rollback rehearsal with unchanged state. The October16 source-body query completed with zero episodes because the captured solar night had zero demand; this is not proof of complete daytime coverage or a finished scientific outcome. The first full native CI5vzfd failed on the missing forward-successor baseline exception; correction8d7ff1a2 preserves the already-qualified277 SQL and seals, and workflow26nj4 is running at this draft checkpoint. Production installation and installed ordinary MCP behavior remain pending. Previously accepted S3B and MCP-only release receipts remain valid within their stated scopes.\n\nCurrent execution allocation: ROLLUP. Next action: ' + next775 + '\n\nFresh native graph at18:13:18UTC matched source16d13f64:47open issues,143 open acceptance clauses,26 local plusHA878→981 active edges (27 total),24 closed predecessor records, matching parent/open-subissue links and no cycle in the captured graph. The later8d7ff1a2 source correction does not edit planning. Preserve original22–34h/40h estimates without inferring remaining hours.\n\nEvidence: ' + report_path + ' (draft pending final delivery receipts). Acceptance clauses, states, parentage and dependencies remain unchanged.')
updates = {'410': {'baseline': baseline410, 'next_action': next410}, '775': {'baseline': baseline775, 'next_action': next775}}
write_json('proposed-updates.json', updates)
data = plan.model_dump()
for item in data['issues']:
    if str(item['issue_number']) in updates:
        item['baseline'] = updates[str(item['issue_number'])]['baseline']
draft = Backlog.model_validate(data)
for item in draft.issues:
    if item.issue_number in (410, 775):
        (OUT / f'issue-{item.issue_number}-body.draft.md').write_text(issue_body(item, draft))

# These existing strategy/decision sentences become historical/stale as the
# selected optimization advances. They are suggestions only, outside the
# requested baseline-only proposed patch; ROOT chooses the final exact scope.
write_json('additional-stale-wording-for-root-review.json', {
 'scope': 'Not applied to proposed-updates.json or rendered baseline-only bodies.',
 '410': {
  'how[0]': {'before': items[410].how[0], 'suggested': 'Reuse the retained diagnosis, original failures and qualified277 parity/rollback evidence. Finish exact-source delivery and installed getter verification; preserve full46-column results, source/tie/fallback/solar/response semantics and negative/incomplete dispositions.'},
  'decision': {'before': items[410].decision, 'suggested': 'The selected getter repair is authorized and277 source qualification is recorded; production installation and installed-role results remain pending at this checkpoint. No new credential, admin audience, planner expansion, controller tuning, physical experiment or OTA is part of this repair.'}},
 '775': {'how[2]': {'before': items[775].how[2], 'suggested': 'Reuse completed P1 native/P2 admission/P4 custody, accepted MCP release and getter277 qualification. Finish the selected getter delivery and retain genuine outcomes, authenticated admin/planner route and physical/input gaps without repeating accepted work.'}}
})

evidence_names = [
 'native-fixtures-b-01/receipt.json', 'native-fixtures-b-01/stdout',
 'native-fixtures-b-02/receipt.json', 'native-fixtures-b-02/stdout',
 'clone-candidate-oct04-01/receipt.json', 'clone-candidate-oct04-01/stdout',
 'clone-candidate-b-oct04-01/receipt.json', 'clone-candidate-b-oct04-01/stdout',
 'clone-a-b-comparison.json', 'clone-readback-parity-01/receipt.json', 'clone-readback-parity-01/stdout',
 'production-exact-migration-rollback-01/receipt.json', 'production-exact-migration-rollback-01/stdout',
 'production-state-before/receipt.json', 'production-state-before/stdout',
 'production-state-after-exact-rehearsal/receipt.json', 'production-state-after-exact-rehearsal/stdout',
 'rollback-fresh-state-verification.json',
 'production-candidate-b-service-01/receipt.json', 'production-candidate-b-service-01/stdout',
 'production-empty-eligibility-01/receipt.json', 'production-empty-eligibility-01/stdout',
 'graph-before-final/verified.json', 'corrected-source-impact/receipt.json',
 'source-main-ci-watch-v2/workflow-final-5363482b707bbc50d20bcb6699d539bc3a2584935f439c8f58e8835775cfafb4.json'
]
evidence = [{'path': str(BASE/n), 'bytes': (BASE/n).stat().st_size, 'sha256': sha(BASE/n)} for n in evidence_names]
write_json('evidence-index.private.json', evidence)
report = '''# Getter277 qualification and delivery checkpoint

Migration277 is source-qualified; production installation and installed ordinary-role acceptance remain pending. This draft records completed evidence without completing #410 or #775. ROOT must replace the pending delivery section from actual receipts before publishing a final acceptance report.

The original getter exceeded the bounded diagnostic fence. Bounds inlining fixed chunk pruning but did not cure execution time. The selected rewrite carries already-grouped readback values across timestamp peers, preserving a NULL event as a stop, materializes shared resolved rows and daylight classification, and retains both inner band helpers and the unchanged scientific tail. The46-column signature, seed DISTINCT ON behavior and grouped-event MAX remain unchanged; no deterministic tie policy was invented.

| Qualification | Actual result | Boundary |
|---|---|---|
| Native private PostgreSQL parity |20 old/new full46-column cases passed | Synthetic helpers/fixtures; original semicolon-defect attempt retained as failed |
| Genuine clone readback relation |2673 old and new rows, zero EXCEPT ALL differences, including NULL and multiplicity | One shared snapshot; helper calls excluded; not complete genuine old/new getter parity |
| Genuine clone October4 candidate A/B |Four46-column rows equal; A13936.825ms, B3174.204ms | Separate read-only snapshots; old complete reference timed out15s and30s, so no old full-result equivalence claim |
| Exact production migration rehearsal |New definition and MCP receipt agreed; ROLLBACK; fresh full retained state matched | No277 ledger row or committed installation |
| Original October16 production source-body query |Zero episodes;3967.348ms server elapsed /3972.272ms client timing | Ad-hoc candidate body, not installed getter or ordinary-role proof |
| October16 eligibility |2785 climate/action/resolved minutes;750 selected solar-night minutes; zero active/demand/admitted minutes and zero null servedVPD | No artificial episode or broadened date selected to hide the empty night |
| Daylight observations |Zero hold-action samples;12 and2 dry-action samples onOctober16/17 | Incomplete coverage remains explicit; this is not a complete measured-zero daytime acceptance |

Source16d13f641dd1ab3ce9fc3bb7ac5ad16432782afc added277 and its exact successor contracts. Its full native workflow `verdify-platform-ci-5vzfd` (UID57a15f09-89e0-4961-9231-d36625de6071) failed at18:22:05UTC. The missing forward-successor exception in the historical baseline-stamp test was corrected by8d7ff1a2829c246600da4f15027121e9c7193913. The migration bytes and measured seals were preserved. Corrected workflow `verdify-platform-ci-26nj4` (UID74fa9db5-5fd2-4a52-abf5-6a210ec8c49f) is running at this draft checkpoint; no full gate or candidate-image success is claimed yet.

The measured migration SHA256 is `a8a0bc063bd655d2e96dd3d424768169edb4ea714c7a1b51dca2b41cc39b29a1`, getter body `578a07bed56714cd2dfe2308ca30ced1f6fc6916fd7db9d79630a7b82b261655`, installed-definition rehearsal `89782089fd6ae3ecfeecdfbc1b730f6ab6a272c0da7b35ef562788eddbfa42c0`, and MCP successor `1cd20508c9196bf9758d7df40ae699e6b83aefccb91a4c5242492f7993f6eb02`. API/ingestor seals remain unchanged. Only the existing MCP receipt boundary field is changed by277; the owning runner supplies the atomic ledger transaction. A later rollback needs a new qualified forward migration, not an old image pin or unledgered function replacement.

Pending delivery evidence must record the exact-source main gate and migrate image, the owning plan-only result showing only277 pending, and the separate apply Job's actual UID/Pod/image/full logs/terminal result. Promote only the migrate image. Do not replay unrelated bootstrap or study hooks. Retain exact277 runner stamp, definition/body/seal/receipt and unchanged ordinary authorities, credentials, study, workload identities and other release pins. The apply manifest must not inherit `VERDIFY_MIGRATE_PLAN` through the live ConfigMap.

After installation, retain actual ordinary MCP LOGIN/attester behavior on both unchanged replicas using the configured15-second limit, the originalOctober16 result and the explicitly selected historicalOctober4 positive-result window, and custom/generic prepared-query behavior. Record actual negative/incomplete outcomes, HTTP audience/tool denial and readiness, smoke and the single writer. This draft claims none of those pending operations. The earlier2-second failures remain failures; later service-budget qualification does not relabel them.

The fresh18:13:18UTC native graph matched canonical source16d13f64:47open issues,143open acceptance clauses,26local+HA878→981=27active edges,24closed predecessor records, matching parent/open-subissue relationships and no cycle in the captured graph. Source8d7ff1a2 changes no planning fields. Final publication should refresh this snapshot and synchronize only the intended #410/#775 wording, preserving states, acceptance clauses and dependency edges.

#410 remains open. Complete measured daytime evidence, actual positive admin/planner outcome consumption and broader physical/crop efficacy are not proved by this getter correction. The existing admin-only outcome tool is not silently added to Iris, and no credentials, controller tuning, OTA, physical experiment or experiment authority are created.
'''
(OUT / 'README.draft.md').write_text(report)
write_json('handoff.json', {
 'status': 'DRAFT_PRODUCTION_PENDING', 'created_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'source_revision': source, 'backlog_sha256': sha(ROOT/'planning/backlog.yaml'),
 'suggested_report_destination': report_path,
 'proposed_backlog_fields': {'410': ['baseline'], '775': ['baseline']},
 'next_action_storage': 'Embedded in baseline after "Next action:"; WorkItem has no standalone next_action field. JSON next_action is handoff text only.',
 'unmodified': ['acceptance','accepted','status','parent','depends_on','stage','priority','effort','owner_role','title'],
 'old_baseline_sha256': {str(n): hashlib.sha256(items[n].baseline.encode()).hexdigest() for n in (410,775)},
 'body_sync': 'Use planning.schema.load and planning.render.issue_body/issue_title after final source composition. Compare fresh GH body/title/state to the retained before-image before a body-only PATCH; retain labels/assignees/milestone/closed state. ROOT alone writes.',
 'graph_helper': str(BASE/'read-graph-before-final.py'),
 'graph_helper_reuse': 'Copy to a NEW helper/output path and bind the actual finalized source HEAD. The frozen helper expects16d13f64 and refuses overwrite; do not rerun unchanged after main advance.',
 'validation': 'Render/validate canonical source and verify all47 current titles/bodies plus143AC/26local+HA878->981 edges, exact parents/open-subissues, and captured graph acyclicity after publication.',
 'additional_stale_wording': 'additional-stale-wording-for-root-review.json lists3 optional current-strategy/decision replacements; not applied in the requested baseline-only bodies.',
 'future_receipts_required': ['exact-source main CI terminal and migrate digest','owning plan/apply Job terminal receipts','installed277 ledger/body/definition/MCP receipt','ordinary LOGIN/attester custom+generic results','actual episode/disposition and day-coverage readback','HTTP/runtime stability','fresh final source/GitHub graph conformance'],
 'issue_closures': 0, 'native_actions': 0, 'github_actions': 0
})
write_json('draft-manifest.json', {p.name: sha(p) for p in sorted(OUT.iterdir()) if p.is_file()})
print(str(OUT))
print('Canonical draft retains47open/143AC and changes only2baselines.')
